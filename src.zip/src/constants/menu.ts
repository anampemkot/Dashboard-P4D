export interface MenuItem {
  id: string;
  label: string;
  path: string;
  subtitle?: string; // Additional contextual subtitle for rich presentation
  children?: MenuItem[];
}

export const MENU: MenuItem[] = [
  {
    id: "menu-1",
    label: "Pajak Hotel & Resto",
    path: "/admin/menu-1",
    subtitle: "Pajak Hotel & Penginapan",
    children: [
      { id: "menu-1-1", label: "Monitoring Hotel", path: "/admin/menu-1/sub-1", subtitle: "Monitoring Real-time Hotel" },
      { id: "menu-1-2", label: "Rekapitulasi Omzet", path: "/admin/menu-1/sub-2", subtitle: "Rekapitulasi Omzet Bulanan" },
    ],
  },
  {
    id: "menu-2",
    label: "Pelayanan Publik",
    path: "/admin/menu-2",
    subtitle: "BR-02 Pelayanan & SLA Publik",
  },
  {
    id: "menu-3",
    label: "Pendataan Objek Pajak",
    path: "/admin/menu-3",
    subtitle: "BR-03 Pendataan Objek Pajak",
  },
  {
    id: "menu-4",
    label: "Pendaftaran WP & OP",
    path: "/admin/menu-4",
    subtitle: "BR-04 Pendaftaran WP & OP",
  },
  {
    id: "menu-5",
    label: "Penetapan SKPD",
    path: "/admin/menu-5",
    subtitle: "BR-05 Penetapan SKPD & Ketetapan",
  },
  {
    id: "menu-6",
    label: "Basis Data Pajak",
    path: "/admin/menu-6",
    subtitle: "BR-06 Master Data & Quality Index",
  },
  {
    id: "menu-7",
    label: "Peta Potensi Pajak",
    path: "/admin/menu-7",
    subtitle: "BR-07 Diagnostik Spasial & Penugasan Survei",
  },
  {
    id: "menu-8",
    label: "Potensi & Ekstensifikasi",
    path: "/admin/menu-8",
    subtitle: "BR-08 Potensi Pajak & Ekstensifikasi",
  },
  {
    id: "menu-9",
    label: "Monitoring Permohonan",
    path: "/admin/menu-9",
    subtitle: "BR-09 Antrean & Progres Berkas Layanan",
  },
  {
    id: "menu-10",
    label: "SLA Pelayanan",
    path: "/admin/menu-10",
    subtitle: "BR-10 Kepatuhan SLA & Kinerja Petugas",
  },
  {
    id: "menu-11",
    label: "Kepatuhan Administrasi",
    path: "/admin/menu-11",
    subtitle: "BR-11 Indeks Kepatuhan & Penertiban Data",
  },
  {
    id: "menu-12",
    label: "Peta Kepatuhan Spasial",
    path: "/admin/menu-12",
    subtitle: "BR-12 Distribusi Spasial Pelanggaran",
  },
  {
    id: "menu-15",
    label: "Piutang & Penagihan",
    path: "/admin/menu-15",
    subtitle: "BR-13 Pengelolaan Piutang & Penagihan",
  },
  {
    id: "menu-16",
    label: "Performa & Realisasi",
    path: "/admin/menu-16",
    subtitle: "BR-14 Performa & Realisasi Pendapatan",
  },
  {
    id: "menu-ui-kit",
    label: "UI Kit System",
    path: "/admin/ui-kit",
    subtitle: "Katalog Varian & Palet Warna",
    children: [
      { id: "menu-uikit-foundations", label: "01 · Foundations", path: "/admin/ui-kit/foundations" },
      { id: "menu-uikit-core-ui", label: "02 · Core UI", path: "/admin/ui-kit/core-ui" },
      { id: "menu-uikit-forms-inputs", label: "03 · Forms & Inputs", path: "/admin/ui-kit/forms-inputs" },
      { id: "menu-uikit-navigation", label: "04 · Navigation", path: "/admin/ui-kit/navigation" },
      { id: "menu-uikit-layouts-structure", label: "05 · Layouts & Structure", path: "/admin/ui-kit/layouts-structure" },
      { id: "menu-uikit-data-tables-lists", label: "06 · Data Tables & Lists", path: "/admin/ui-kit/data-tables-lists" },
      { id: "menu-uikit-data-visualization", label: "07 · Data Visualization", path: "/admin/ui-kit/data-visualization" },
      { id: "menu-uikit-feedback-overlays", label: "08 · Feedback & Overlays", path: "/admin/ui-kit/feedback-overlays" },
      { id: "menu-uikit-advanced-ai", label: "09 · Advanced & AI", path: "/admin/ui-kit/advanced-ai" },
      { id: "menu-uikit-templates-patterns", label: "10 · Templates & Patterns", path: "/admin/ui-kit/templates-patterns" },
      { id: "menu-uikit-misc", label: "11 · Misc", path: "/admin/ui-kit/misc" },
    ],
  },
];
