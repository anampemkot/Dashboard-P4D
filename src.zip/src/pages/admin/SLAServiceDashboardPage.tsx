import * as React from "react";
import {
  ScorecardApp,
  CardApp,
  BadgeApp,
  ButtonApp,
  TextApp,
  AdvanceFilterApp,
  DataTableApp,
  ChartApp,
  DropdownApp,
  ProgressListApp,
  useToastApp,
  useRealtimeValue,
  QuickPreset,
} from "@/packages/design-system";
import {
  RefreshCw,
  Download,
  Filter,
  Calendar,
  Timer,
  FileText,
  CheckCircle2,
  AlertTriangle,
  Clock,
} from "lucide-react";
import { CHART_COLORS } from "@/constants/chartColors";

const COLOR_KRITIS = "#f43f5e";

// Donut kepatuhan SLA — dua irisan, nilai di tengah lubang donut.
const KEPATUHAN_SLA = [
  { name: "Terpenuhi", value: 82, fill: CHART_COLORS.emerald },
  { name: "Terlambat", value: 18, fill: COLOR_KRITIS },
];

// Titik kritis keterlambatan per jenis layanan — nilai mengikuti acuan.
const TITIK_KRITIS = [
  { id: "mutasi", label: "Mutasi PBB-P2", jumlah: 35, severity: "kritis" as const },
  { id: "pengurangan", label: "Pengurangan", jumlah: 20, severity: "kritis" as const },
  { id: "keberatan", label: "Keberatan", jumlah: 15, severity: "waspada" as const },
  { id: "lainnya", label: "Lainnya", jumlah: 11, severity: "waspada" as const },
];
const TITIK_KRITIS_MAKS = 40;

// Rapor kinerja — jumlah berkas yang terlambat di tangan tiap petugas.
const RAPOR_KINERJA = [
  { id: "budi", nama: "Budi Santoso", peran: "Petugas Pelayanan", terlambat: 45 },
  { id: "rina", nama: "Rina Amelia", peran: "Petugas Pelayanan", terlambat: 20 },
  { id: "siti", nama: "Siti Nurhaliza", peran: "Petugas Pelayanan", terlambat: 16 },
];


const DOKUMEN_TERLAMBAT = [
  {
    id: "TK-202608-001",
    jenis: "Mutasi PBB-P2",
    tglMasuk: "01 Agu 2026",
    batasSla: "06 Agu 2026",
    telat: 9,
    petugas: "Budi Santoso",
    aksi: "Eskalasi",
  },
  {
    id: "TK-202608-042",
    jenis: "Pengurangan",
    tglMasuk: "05 Agu 2026",
    batasSla: "10 Agu 2026",
    telat: 5,
    petugas: "Rina Amelia",
    aksi: "Tegur",
  },
  {
    id: "TK-202608-105",
    jenis: "Keberatan",
    tglMasuk: "10 Agu 2026",
    batasSla: "15 Agu 2026",
    telat: 2,
    petugas: "Siti Nurhaliza",
    aksi: "Eskalasi",
  },
  {
    id: "TK-202608-118",
    jenis: "Mutasi PBB-P2",
    tglMasuk: "11 Agu 2026",
    batasSla: "16 Agu 2026",
    telat: 4,
    petugas: "Budi Santoso",
    aksi: "Eskalasi",
  },
  {
    id: "TK-202608-133",
    jenis: "Pembetulan",
    tglMasuk: "13 Agu 2026",
    batasSla: "18 Agu 2026",
    telat: 1,
    petugas: "Rina Amelia",
    aksi: "Tegur",
  },
];

const slaFilterFields = [
  {
    id: "jenisLayanan",
    label: "Jenis Layanan",
    type: "select" as const,
    placeholder: "Pilih Jenis Layanan...",
    options: [
      { value: "all", label: "Semua Jenis Layanan" },
      { value: "mutasi", label: "Mutasi PBB-P2" },
      { value: "pengurangan", label: "Pengurangan" },
      { value: "keberatan", label: "Keberatan" },
      { value: "pembetulan", label: "Pembetulan" },
    ],
  },
  {
    id: "statusSla",
    label: "Status SLA",
    type: "select" as const,
    placeholder: "Semua Status...",
    options: [
      { value: "all", label: "Semua Status SLA" },
      { value: "terpenuhi", label: "Tepat Waktu" },
      { value: "terlambat", label: "Melewati Batas SLA" },
    ],
  },
  {
    id: "petugas",
    label: "Petugas Penanggung Jawab",
    type: "select" as const,
    placeholder: "Semua Petugas...",
    options: [
      { value: "all", label: "Semua Petugas" },
      ...RAPOR_KINERJA.map((p) => ({ value: p.id, label: p.nama })),
    ],
  },
  {
    id: "periode",
    label: "Periode Pengukuran",
    type: "select" as const,
    placeholder: "Pilih Periode...",
    options: [
      { value: "agustus", label: "Agustus 2026 (Berjalan)" },
      { value: "juli", label: "Juli 2026" },
      { value: "q3", label: "Triwulan III 2026" },
    ],
  },
];

const quickPresets: QuickPreset[] = [
  { label: "Semua Layanan", values: { jenisLayanan: "all", statusSla: "all" } },
  { label: "Hanya Terlambat", values: { statusSla: "terlambat" } },
  { label: "Mutasi PBB-P2", values: { jenisLayanan: "mutasi" } },
  { label: "Beban Budi Santoso", values: { petugas: "budi" } },
];

export function SLAServiceDashboardPage() {
  const { toast } = useToastApp();
  const [filterValues, setFilterValues] = React.useState<Record<string, any>>({});

  // Volume & jumlah dokumen bergerak sepanjang hari kerja. Rata-rata waktu
  // proses dan target 5 hari TIDAK di-live-kan: keduanya hasil hitung
  // periodik dan angka kebijakan, bukan aliran transaksi.
  const liveTotalLayanan = useRealtimeValue({
    initialValue: 450,
    update: (v) => v + (Math.random() > 0.5 ? 1 : 0),
    intervalMs: 8000,
  });
  const liveTerlambat = useRealtimeValue({
    initialValue: 81,
    update: (v) => Math.max(60, v + (Math.random() > 0.7 ? 1 : -1)),
    intervalMs: 11000,
  });

  const handleResetFilter = () => {
    setFilterValues({});
    toast.info("Filter SLA Direset", {
      description: "Semua kriteria jenis layanan, status SLA, dan petugas dikembalikan ke kondisi awal.",
    });
  };

  const titikKritisItems = TITIK_KRITIS.map((t) => ({
    id: t.id,
    label: t.label,
    value: `${t.jumlah} berkas`,
    segments: [
      {
        percent: (t.jumlah / TITIK_KRITIS_MAKS) * 100,
        color: t.severity === "kritis" ? COLOR_KRITIS : CHART_COLORS.amber,
      },
    ],
  }));

  // Acuan menampilkan rapor kinerja tanpa bar: jumlah tanggungan sudah
  // terbaca dari badge-nya sendiri, dan bar di sini justru menyiratkan
  // "progres" padahal yang diukur adalah tunggakan.
  const raporItems = RAPOR_KINERJA.map((p) => ({
    id: p.id,
    label: p.nama,
    secondaryLabel: p.peran,
    value: "",
    badge: (
      <BadgeApp
        id={`badge-terlambat-${p.id}`}
        variant={p.terlambat >= 40 ? "solidRose" : "solidAmber"}
        size="sm"
      >
        {p.terlambat} Terlambat
      </BadgeApp>
    ),
    segments: [],
  }));

  const tableColumns = [
    {
      accessorKey: "id",
      header: "No. Tiket / Jenis Layanan",
      cell: ({ row }: any) => (
        <div>
          <TextApp id={`tiket-${row.original.id}`} variant="caption" weight="bold" className="block text-ink">
            {row.original.jenis}
          </TextApp>
          <span className="font-mono text-[11px] text-ink-muted">#{row.original.id}</span>
        </div>
      ),
    },
    { accessorKey: "tglMasuk", header: "Tanggal Masuk" },
    { accessorKey: "batasSla", header: "Batas SLA" },
    {
      accessorKey: "telat",
      header: "Keterlambatan",
      cell: ({ row }: any) => (
        <BadgeApp
          id={`badge-telat-${row.original.id}`}
          variant={row.original.telat >= 5 ? "solidRose" : "solidAmber"}
          size="sm"
        >
          {row.original.telat} Hari
        </BadgeApp>
      ),
    },
    { accessorKey: "petugas", header: "Petugas" },
    {
      id: "actions",
      header: "Aksi",
      cell: ({ row }: any) => (
        <ButtonApp
          id={`btn-aksi-${row.original.id}`}
          variant={row.original.aksi === "Eskalasi" ? "primary" : "secondary"}
          size="sm"
          rounded="lg"
          onClick={() =>
            toast.vibrant(`${row.original.aksi} Dikirim`, {
              description: `Tiket #${row.original.id} diteruskan ke ${row.original.petugas}.`,
            })
          }
        >
          {row.original.aksi}
        </ButtonApp>
      ),
    },
  ];

  return (
    <div id="sla-dashboard-root" className="space-y-6 pb-12">
      {/* ------------------------------------------------------------- */}
      {/* HEADER PAGE                                                   */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col justify-between gap-4 border-b border-hairline-soft pb-4 md:flex-row md:items-center">
        <div>
          <div className="mb-1 flex flex-wrap items-center gap-x-3 gap-y-1.5">
            <BadgeApp id="hdr-badge-br10" variant="solidPurple" size="sm">
              BR-10 · Dashboard SLA Pelayanan
            </BadgeApp>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <Timer className="h-3.5 w-3.5 text-vibrant-purple" />
              Kepatuhan SLA & Kinerja Petugas
            </span>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <Calendar className="h-3.5 w-3.5 text-vibrant-purple" />
              Periode Agustus 2026
            </span>
          </div>
          <TextApp id="hdr-title-sla" variant="h2" className="tracking-tight text-ink">
            Dashboard SLA Pelayanan Perpajakan Daerah
          </TextApp>
          <TextApp id="hdr-sub-sla" variant="body" className="text-xs text-ink-secondary">
            Monitoring Kepatuhan Batas Waktu Layanan, Titik Kritis Keterlambatan, & Rapor Kinerja Petugas
          </TextApp>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <ButtonApp
            id="btn-refresh-sla"
            variant="secondary"
            size="sm"
            rounded="lg"
            onClick={() =>
              toast.info("Data SLA Disinkronkan", {
                description: "Perhitungan durasi layanan diperbarui dari sistem antrean PTSP.",
              })
            }
            leftIcon={<RefreshCw className="h-3.5 w-3.5" />}
          >
            Sync Data
          </ButtonApp>
          <ButtonApp
            id="btn-export-sla"
            variant="primary"
            size="sm"
            rounded="lg"
            leftIcon={<Download className="h-3.5 w-3.5" />}
            onClick={() =>
              toast.vibrant("Laporan SLA Diunduh", {
                description: "Berisi rincian dokumen melewati batas SLA beserta penanggung jawabnya.",
              })
            }
          >
            Cetak Laporan SLA
          </ButtonApp>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* FILTER BAR */}
      {/* ------------------------------------------------------------- */}
      <div className="flex w-full min-w-0 flex-nowrap items-center gap-2 overflow-x-auto rounded-2xl border border-hairline bg-surface px-3 py-3 shadow-xs">
        <span className="flex shrink-0 items-center gap-1.5 whitespace-nowrap text-xs font-semibold text-ink-secondary">
          <Filter className="h-4 w-4 text-vibrant-purple" />
          Filter:
        </span>

        {/* Shortcut inline utk field yang paling sering dipakai — nilainya
            dibagi dgn AdvanceFilterApp supaya tidak jadi kontrol kosmetik. */}
        <div className="w-52 shrink-0">
          <DropdownApp
            id="select-jenis-layanan-sla"
            value={String(filterValues.jenisLayanan ?? "all")}
            onChange={(value) => setFilterValues((prev) => ({ ...prev, jenisLayanan: String(value) }))}
            options={[
              { label: "Semua Jenis Layanan", value: "all" },
              { label: "Mutasi PBB-P2", value: "mutasi" },
              { label: "Pengurangan", value: "pengurangan" },
              { label: "Keberatan", value: "keberatan" },
              { label: "Pembetulan", value: "pembetulan" },
            ]}
            size="sm"
            rounded="lg"
            menuPortal
          />
        </div>

        <div className="ml-auto shrink-0">
          <AdvanceFilterApp
            id="filter-sla-pelayanan"
            displayMode="modal"
            showActivePills={false}
            className="w-auto"
            triggerLabel="Advance Filter SLA"
            triggerVariant="secondary"
            triggerSize="sm"
            triggerRounded="lg"
            title="Filter Kepatuhan SLA & Penanggung Jawab"
            fields={slaFilterFields}
            values={filterValues}
            onChange={setFilterValues}
            quickPresets={quickPresets}
            onReset={handleResetFilter}
            onApply={() => {
              toast.vibrant("Filter SLA Diterapkan", {
                description: "Menampilkan pengukuran SLA sesuai kriteria yang dipilih.",
              });
            }}
          />
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* SCORECARD SLA (BR-10)                                          */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col gap-2">
        <TextApp
          id="label-ringkasan-sla-heading"
          variant="caption"
          weight="bold"
          className="uppercase tracking-widest text-ink-muted"
        >
          Ringkasan Kepatuhan SLA
        </TextApp>
        <div className="grid grid-cols-1 items-stretch gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <ScorecardApp
            id="card-total-layanan-diukur"
            variant="clayPurple"
            title="Total Layanan Diukur"
            value={liveTotalLayanan}
            live
            unit="Dokumen"
            description="Seluruh berkas layanan yang masuk perhitungan SLA bulan ini"
            trend={{ value: "+4,2%", label: "vs Bulan Lalu", isPositive: true, direction: "up" }}
            icon={<FileText className="h-5 w-5 text-white" />}
            infoTooltip="Jumlah dokumen layanan yang durasinya diukur terhadap batas SLA."
            infoContent={{
              formula: "Jumlah berkas layanan selesai + berkas berjalan yang sudah melewati batas SLA",
              period: "Bulan berjalan (real-time)",
              source: "SIMPAD — Modul Antrean PTSP",
              lastUpdated: "Baru saja",
            }}
            insight={{
              title: "Total Layanan Diukur",
              value: "450 Dokumen",
              status: "sehat",
              meta: ["Volume", "Pengukuran SLA", "Agustus 2026"],
              summary:
                "Angka ini adalah penyebut seluruh persentase SLA di halaman ini. Tanpa memperhatikannya, kenaikan persentase keterlambatan bisa salah dibaca — bisa jadi bukan kinerjanya yang memburuk, melainkan volumenya yang melonjak.",
              current: [
                "450 dokumen diukur bulan ini, naik 4,2% dari bulan sebelumnya.",
                "Komposisi didominasi Mutasi PBB-P2 dan Pengurangan.",
              ],
              insights: [
                "Kenaikan volume 4,2% berbarengan dengan keterlambatan yang stabil menandakan kapasitas layanan masih mengimbangi permintaan.",
              ],
              tacticalRecs: [
                "Bandingkan tren volume dengan jumlah petugas aktif sebelum menyimpulkan ada penurunan kinerja.",
              ],
              strategicRecs: [
                "Tetapkan ambang volume yang memicu penambahan petugas otomatis, bukan menunggu SLA jebol lebih dulu.",
              ],
              glossary: [
                { term: "SLA", expansion: "Service Level Agreement", definition: "batas waktu maksimal penyelesaian sebuah layanan." },
              ],
              dataNotes: ["Snapshot real-time dari sistem antrean."],
            }}
          />

          <ScorecardApp
            id="card-sla-terpenuhi"
            variant="emerald"
            title="SLA Terpenuhi"
            value="82%"
            unit="Tepat Waktu"
            description="369 dokumen selesai sebelum batas waktu"
            progress={{ value: 82, max: 100, label: "Kepatuhan SLA" }}
            trend={{ value: "+1,8%", label: "vs Bulan Lalu", isPositive: true, direction: "up" }}
            icon={<CheckCircle2 className="h-5 w-5 text-emerald-700 dark:text-emerald-200" />}
            infoTooltip="Persentase dokumen yang selesai sebelum melewati batas SLA."
            infoContent={{
              formula: "(Dokumen selesai tepat waktu / Total dokumen diukur) x 100%",
              period: "Bulan berjalan",
              source: "SIMPAD — Modul Antrean PTSP",
              lastUpdated: "Hari ini",
            }}
            insight={{
              title: "SLA Terpenuhi",
              value: "82% (369 Dokumen)",
              status: "waspada",
              meta: ["Kepatuhan", "SLA", "Agustus 2026"],
              summary:
                "Persentase dokumen yang selesai sebelum batas waktu. Target nasional 90%, sehingga posisi 82% masih di bawah — bukan gagal, tapi belum aman.",
              current: [
                "82% dari 450 dokumen selesai tepat waktu, naik 1,8% dari bulan lalu.",
                "Selisih 8 poin menuju target nasional setara sekitar 36 dokumen.",
              ],
              insights: [
                "Perbaikan 1,8% per bulan berarti target 90% baru tercapai sekitar empat bulan lagi bila lajunya tidak dipercepat.",
              ],
              tacticalRecs: [
                "Fokuskan perbaikan pada Mutasi PBB-P2 — satu jenis layanan ini menyumbang keterlambatan terbanyak.",
              ],
              strategicRecs: [
                "Tinjau ulang batas SLA per jenis layanan; batas yang tidak realistis akan terus menghasilkan pelanggaran meski prosesnya sudah efisien.",
              ],
              dataNotes: ["Target nasional 90% dipakai sebagai pembanding."],
            }}
          />

          <ScorecardApp
            id="card-sla-terlambat"
            variant="alert"
            title="SLA Terlambat"
            value={liveTerlambat}
            live
            unit="Dokumen Melewati Batas"
            description="18% dari total dokumen yang diukur"
            trend={{ value: "-1,8%", label: "Penurunan Keterlambatan", isPositive: true, direction: "down" }}
            icon={<AlertTriangle className="h-5 w-5 text-rose-600" />}
            infoTooltip="Jumlah dokumen yang penyelesaiannya melewati batas SLA."
            infoContent={{
              formula: "Jumlah dokumen dengan durasi penyelesaian > batas SLA jenis layanannya",
              period: "Bulan berjalan (real-time)",
              source: "SIMPAD — Modul Antrean PTSP",
              lastUpdated: "Baru saja",
            }}
            insight={{
              title: "SLA Terlambat",
              value: "81 Dokumen (18%)",
              status: "kritis",
              meta: ["Pelanggaran", "SLA", "Agustus 2026"],
              summary:
                "Dokumen yang penyelesaiannya melewati batas waktu. Setiap satuan di sini adalah wajib pajak yang menunggu lebih lama dari yang dijanjikan.",
              current: [
                "81 dokumen terlambat, turun dari bulan sebelumnya.",
                "Lebih dari separuh berasal dari satu jenis layanan: Mutasi PBB-P2.",
              ],
              insights: [
                "Keterlambatan terkonsentrasi, bukan menyebar — artinya masalahnya ada pada satu alur proses tertentu, bukan pada kapasitas secara keseluruhan.",
              ],
              tacticalRecs: [
                "Telusuri alur Mutasi PBB-P2 tahap demi tahap untuk menemukan langkah yang paling lama mengendap.",
              ],
              strategicRecs: [
                "Otomasi verifikasi dokumen pendukung pada layanan bervolume tinggi agar antrean tidak menumpuk di verifikator.",
              ],
              dataNotes: ["Snapshot real-time; angka bergerak seiring berkas diselesaikan."],
            }}
          />

          <ScorecardApp
            id="card-rata-waktu-proses"
            variant="clayYellow"
            title="Rata-rata Waktu Proses"
            // Tidak di-live-kan: hasil hitung periodik atas seluruh berkas
            // selesai, bukan angka yang bergerak per transaksi.
            value="6,5"
            unit="Hari per Dokumen"
            description="Target maksimal 5 hari kerja per dokumen"
            trend={{ value: "+1,5 Hari", label: "di atas target", isPositive: false, direction: "up" }}
            icon={<Clock className="h-5 w-5 text-[#5c4300] dark:text-amber-300" />}
            infoTooltip="Rata-rata durasi penyelesaian seluruh dokumen layanan."
            infoContent={{
              formula: "Total hari penyelesaian seluruh dokumen / Jumlah dokumen selesai",
              period: "Bulan berjalan",
              source: "SIMPAD — Modul Antrean PTSP",
              lastUpdated: "Hari ini",
            }}
            insight={{
              title: "Rata-rata Waktu Proses",
              value: "6,5 Hari (Target 5)",
              status: "kritis",
              meta: ["Durasi", "Efisiensi Proses", "Agustus 2026"],
              summary:
                "Rata-rata lama penyelesaian satu dokumen. Berada 1,5 hari di atas target, dan karena ini rata-rata, sebagian dokumen tentu jauh lebih lama dari angka ini.",
              current: [
                "Rata-rata 6,5 hari terhadap target 5 hari kerja.",
                "Dokumen terlambat terparah mencapai 9 hari melewati batas.",
              ],
              insights: [
                "Rata-rata menyembunyikan sebaran: memperbaiki ekor yang paling lambat akan menurunkan angka ini lebih cepat daripada mempercepat berkas yang sudah tepat waktu.",
              ],
              tacticalRecs: [
                "Pantau dokumen yang sudah melewati hari ke-4 sebagai peringatan dini, jangan menunggu sampai jatuh tempo.",
              ],
              strategicRecs: [
                "Susun ulang urutan verifikasi supaya berkas sederhana tidak mengantre di belakang berkas kompleks.",
              ],
              dataNotes: ["Target 5 hari adalah ketetapan kebijakan, bukan hasil pengukuran."],
            }}
          />
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* GAUGE + TITIK KRITIS + RAPOR KINERJA (BR-10)                   */}
      {/* ------------------------------------------------------------- */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <CardApp
          id="card-gauge-kepatuhan-sla"
          className="flex flex-col border-hairline-soft p-5"
          insight={{
            title: "Kepatuhan SLA Keseluruhan",
            value: "82% dari target 90%",
            status: "waspada",
            meta: ["Kepatuhan", "Ringkasan", "Agustus 2026"],
            summary:
              "Gauge ini meringkas seluruh halaman menjadi satu angka: berapa persen janji waktu layanan yang benar-benar ditepati. Garis penanda menunjukkan posisi target nasional.",
            current: ["Capaian 82% masih 8 poin di bawah target nasional 90%."],
            insights: [
              "Jarak menuju target setara sekitar 36 dokumen — jumlah yang realistis dikejar dalam satu hingga dua bulan bila difokuskan pada satu jenis layanan.",
            ],
            tacticalRecs: ["Jadikan 90% sebagai target triwulan, bukan target tahunan."],
            strategicRecs: [
              "Publikasikan capaian SLA secara berkala agar tekanan perbaikan datang dari transparansi, bukan hanya dari pengawasan internal.",
            ],
            dataNotes: ["Penanda pada gauge adalah target nasional 90%."],
          }}
        >
          <div className="mb-3">
            <TextApp id="title-gauge-sla" variant="h3" weight="bold" className="text-ink-primary">
              Kepatuhan SLA Keseluruhan
            </TextApp>
            <TextApp id="sub-gauge-sla" variant="caption" className="text-ink-secondary">
              Proporsi berkas tepat waktu terhadap seluruh layanan yang diukur.
            </TextApp>
          </div>

          {/* Donut penuh dengan angka di tengah, mengikuti acuan. Label
              ditumpuk di tengah lubang donut lewat wrapper relatif. */}
          <div className="relative flex flex-1 items-center justify-center">
            <ChartApp
              id="chart-kepatuhan-sla"
              type="pie"
              data={KEPATUHAN_SLA}
              innerRadius={72}
              outerRadius={96}
              valueFormatter={(v) => `${v}%`}
              height={240}
              showLegend={false}
            />
            <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
              <TextApp id="gauge-sla-value" variant="h2" weight="bold" className="text-emerald-600 dark:text-emerald-400">
                82%
              </TextApp>
              <TextApp
                id="gauge-sla-label"
                variant="caption"
                weight="bold"
                className="uppercase tracking-widest text-ink-muted"
              >
                Terpenuhi
              </TextApp>
            </div>
          </div>

          <div className="mt-3 flex items-center justify-center gap-4 border-t border-hairline-soft pt-3">
            {KEPATUHAN_SLA.map((s) => (
              <span key={s.name} className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: s.fill }} />
                <TextApp id={`legend-sla-${s.name}`} variant="caption" className="text-[11px] text-ink-secondary">
                  {s.name} {s.value}%
                </TextApp>
              </span>
            ))}
          </div>
        </CardApp>

        <CardApp
          id="card-titik-kritis"
          className="flex flex-col border-hairline-soft p-5"
          insight={{
            title: "Titik Kritis Keterlambatan",
            value: "Mutasi PBB-P2 tertinggi",
            status: "kritis",
            meta: ["Diagnosis", "Per Jenis Layanan", "Agustus 2026"],
            summary:
              "Memecah keterlambatan menurut jenis layanan. Fungsinya menjawab pertanyaan 'di mana' masalahnya, bukan sekadar 'berapa banyak'.",
            current: [
              "Mutasi PBB-P2 menyumbang 35 dari 81 berkas terlambat — hampir separuh total.",
              "Tiga jenis layanan lain menyumbang sisanya secara merata.",
            ],
            insights: [
              "Satu jenis layanan mendominasi pelanggaran, sehingga perbaikan terarah akan jauh lebih berdampak daripada program efisiensi menyeluruh.",
            ],
            tacticalRecs: [
              "Bedah alur Mutasi PBB-P2 lebih dulu sebelum menyentuh jenis layanan lain.",
            ],
            strategicRecs: [
              "Tetapkan batas SLA berbeda per jenis layanan sesuai kompleksitasnya, bukan satu angka seragam.",
            ],
            dataNotes: ["Jumlah dihitung dari berkas yang melewati batas SLA bulan berjalan."],
          }}
        >
          <div className="mb-4">
            <TextApp id="title-titik-kritis" variant="h3" weight="bold" className="text-ink-primary">
              Titik Kritis Keterlambatan
            </TextApp>
            <TextApp id="sub-titik-kritis" variant="caption" className="text-ink-secondary">
              Sebaran berkas terlambat menurut jenis layanan.
            </TextApp>
          </div>

          <ProgressListApp id="list-titik-kritis" items={titikKritisItems} />
        </CardApp>

        <CardApp
          id="card-rapor-kinerja"
          className="flex flex-col border-hairline-soft p-5"
          insight={{
            title: "Rapor Kinerja Petugas",
            value: "3 petugas menanggung 81 berkas",
            status: "waspada",
            meta: ["Kinerja", "Beban Petugas", "Agustus 2026"],
            summary:
              "Menampilkan berapa berkas terlambat yang saat ini ada di tangan tiap petugas. Dibaca sebagai peta beban, bukan sebagai daftar kesalahan.",
            current: [
              "Budi Santoso menanggung 45 berkas terlambat, lebih dari dua kali lipat petugas lain.",
            ],
            insights: [
              "Timpangnya beban menunjukkan masalah distribusi penugasan, bukan semata perbedaan kecepatan kerja antar-petugas.",
            ],
            tacticalRecs: [
              "Redistribusi sebagian berkas Budi Santoso ke petugas dengan beban di bawah 20.",
            ],
            strategicRecs: [
              "Terapkan pembagian berkas otomatis berbasis beban aktif supaya penumpukan tidak terulang.",
            ],
            dataNotes: ["Hanya menghitung berkas yang sudah melewati batas SLA."],
          }}
        >
          <div className="mb-4">
            <TextApp id="title-rapor-kinerja" variant="h3" weight="bold" className="text-ink-primary">
              Rapor Kinerja Petugas
            </TextApp>
            <TextApp id="sub-rapor-kinerja" variant="caption" className="text-ink-secondary">
              Tanggungan berkas terlambat per penanggung jawab.
            </TextApp>
          </div>

          <ProgressListApp id="list-rapor-kinerja" items={raporItems} />
        </CardApp>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* RINCIAN DOKUMEN TERLAMBAT (BR-10)                              */}
      {/* ------------------------------------------------------------- */}
      <CardApp id="card-table-dokumen-terlambat" className="border-hairline-soft p-5">
        <DataTableApp
          id="datatable-dokumen-terlambat"
          title="Rincian Dokumen Terlambat (SLA Breach)"
          description="Berkas yang penyelesaiannya melewati batas SLA beserta penanggung jawab dan tindakan yang disarankan."
          toolbarLayout="singleRow"
          data={DOKUMEN_TERLAMBAT}
          columns={tableColumns}
          getRowId={(row) => row.id}
          searchPlaceholder="Cari no. tiket, jenis layanan, atau petugas..."
          pageSize={5}
        />
      </CardApp>
    </div>
  );
}

export default SLAServiceDashboardPage;
