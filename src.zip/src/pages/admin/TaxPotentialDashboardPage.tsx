import * as React from "react";
import {
  ScorecardApp,
  CardApp,
  BadgeApp,
  ButtonApp,
  TextApp,
  AdvanceFilterApp,
  DataTableApp,
  DropdownApp,
  MapsApp,
  ChartApp,
  FunnelChartApp,
  ProgressListApp,
  useToastApp,
  useRealtimeValue,
  QuickPreset,
  MapPolygon,
} from "@/packages/design-system";
import {
  RefreshCw,
  Download,
  Filter,
  Calendar,
  MapPin,
  CheckCircle2,
  Target,
  TrendingUp,
  Sparkles,
} from "lucide-react";
import { CHART_COLORS } from "@/constants/chartColors";
import { KEMANTREN_POLYGONS, YOGYAKARTA_CENTER } from "@/constants/mockKemantrenPolygons";

// Tiga tingkat potensi ekstensifikasi — warna diskret + legenda, bukan ramp.
const TINGKAT_POTENSI = {
  tinggi: { label: "Tinggi", color: CHART_COLORS.purple },
  sedang: { label: "Sedang", color: CHART_COLORS.blue },
  rendah: { label: "Rendah", color: CHART_COLORS.cyan },
} as const;

type TingkatPotensi = keyof typeof TINGKAT_POTENSI;

const SEBARAN_POTENSI: Array<{ id: string; kemantren: keyof typeof KEMANTREN_POLYGONS; tingkat: TingkatPotensi }> = [
  { id: "umbulharjo", kemantren: "Umbulharjo", tingkat: "tinggi" },
  { id: "gondokusuman", kemantren: "Gondokusuman", tingkat: "tinggi" },
  { id: "gondomanan", kemantren: "Gondomanan", tingkat: "sedang" },
  { id: "jetis", kemantren: "Jetis", tingkat: "sedang" },
  { id: "kotagede", kemantren: "Kotagede", tingkat: "sedang" },
  { id: "mantrijeron", kemantren: "Mantrijeron", tingkat: "rendah" },
  { id: "tegalrejo", kemantren: "Tegalrejo", tingkat: "rendah" },
];

// Alur konversi ekstensifikasi — dirender sebagai varian `steps`: tiga kartu
// bertahap dihubungkan panah, karena yang dilaporkan adalah angka tiap tahap
// (450 → 200 → 150), bukan bentuk penyempitannya. Persentase konversi antar
// tahap (44% dan 75%) dicetak sendiri oleh FunnelChartApp.
const ALUR_KONVERSI = [
  { label: "Hasil Survei", value: 450, color: CHART_COLORS.blue },
  { label: "Hasil Uji Petik", value: 200, color: CHART_COLORS.purple },
  { label: "OP Baru Ditetapkan", value: 150, color: CHART_COLORS.emerald },
];

// Rasio konversi enam bulan terakhir. Kartu bertahap di atasnya hanya memotret
// satu periode — angka 44% dan 75% tidak memberi tahu apakah itu membaik atau
// memburuk. Titik terakhir grafik ini sengaja sama persis dengan kedua angka
// tersebut, jadi kartu dan grafik terbaca sebagai satu cerita.
const TREN_KONVERSI = [
  { bulan: "Mar", ujiPetik: 38, penetapan: 68 },
  { bulan: "Apr", ujiPetik: 41, penetapan: 70 },
  { bulan: "Mei", ujiPetik: 39, penetapan: 66 },
  { bulan: "Jun", ujiPetik: 43, penetapan: 72 },
  { bulan: "Jul", ujiPetik: 42, penetapan: 74 },
  { bulan: "Agu", ujiPetik: 44, penetapan: 75 },
];

// Selisih laporan awal vs hasil uji petik (Top 3) — satuan juta rupiah.
const SELISIH_UJI_PETIK = [
  { wilayah: "Umbulharjo", laporanAwal: 490, hasilUjiPetik: 210 },
  { wilayah: "Gondokusuman", laporanAwal: 385, hasilUjiPetik: 145 },
  { wilayah: "Jetis", laporanAwal: 280, hasilUjiPetik: 95 },
];

const VALIDASI_POTENSI = [
  {
    id: "vp-001",
    wp: "PT Hotel Mataram Raya",
    objek: "Mataram Boutique Hotel",
    wilayah: "Umbulharjo",
    jenis: "PBJT Hotel",
    laporanAwal: 125_000_000,
    ujiPetik: 175_000_000,
    status: "Siap Ditetapkan" as const,
  },
  {
    id: "vp-002",
    wp: "Resto Sari Laras",
    objek: "Cabang Kusumanegara",
    wilayah: "Gondokusuman",
    jenis: "PBJT Restoran",
    laporanAwal: 45_000_000,
    ujiPetik: 75_000_000,
    status: "Menunggu Validasi" as const,
  },
  {
    id: "vp-003",
    wp: "Kawasan Parkir Tugu",
    objek: "Lahan Terbuka Tugu",
    wilayah: "Jetis",
    jenis: "PBJT Parkir",
    laporanAwal: 15_000_000,
    ujiPetik: 35_000_000,
    status: "Siap Ditetapkan" as const,
  },
  {
    id: "vp-004",
    wp: "Kos Eksklusif Seturan",
    objek: "Gedung Kos 24 Kamar",
    wilayah: "Gondokusuman",
    jenis: "PBJT Jasa Kos",
    laporanAwal: 22_000_000,
    ujiPetik: 41_000_000,
    status: "Menunggu Validasi" as const,
  },
  {
    id: "vp-005",
    wp: "CV Reklame Sejahtera",
    objek: "Billboard Ring Road",
    wilayah: "Kotagede",
    jenis: "Pajak Reklame",
    laporanAwal: 18_000_000,
    ujiPetik: 30_000_000,
    status: "Siap Ditetapkan" as const,
  },
];

const potensiFilterFields = [
  {
    id: "tingkatPotensi",
    label: "Tingkat Potensi",
    type: "select" as const,
    placeholder: "Pilih Tingkat...",
    options: [
      { value: "all", label: "Semua Tingkat Potensi" },
      { value: "tinggi", label: "Potensi Tinggi" },
      { value: "sedang", label: "Potensi Sedang" },
      { value: "rendah", label: "Potensi Rendah" },
    ],
  },
  {
    id: "jenisPajak",
    label: "Jenis Pajak",
    type: "select" as const,
    placeholder: "Pilih Jenis Pajak...",
    options: [
      { value: "all", label: "Semua Jenis Pajak" },
      { value: "pbjt_hotel", label: "PBJT Jasa Perhotelan" },
      { value: "pbjt_resto", label: "PBJT Restoran" },
      { value: "pbjt_parkir", label: "PBJT Jasa Parkir" },
      { value: "reklame", label: "Pajak Reklame" },
    ],
  },
  {
    id: "statusValidasi",
    label: "Status Validasi",
    type: "select" as const,
    placeholder: "Semua Status...",
    options: [
      { value: "all", label: "Semua Status Validasi" },
      { value: "siap", label: "Siap Ditetapkan" },
      { value: "menunggu", label: "Menunggu Validasi" },
    ],
  },
  {
    id: "periode",
    label: "Periode Survei",
    type: "select" as const,
    placeholder: "Pilih Periode...",
    options: [
      { value: "agustus", label: "Agustus 2026 (Berjalan)" },
      { value: "juli", label: "Juli 2026" },
      { value: "q3", label: "Triwulan III 2026" },
    ],
  },
];

const quickPresets: QuickPreset[] = [
  { label: "Semua Potensi", values: { tingkatPotensi: "all", statusValidasi: "all" } },
  { label: "Zona Potensi Tinggi", values: { tingkatPotensi: "tinggi" } },
  { label: "Siap Ditetapkan", values: { statusValidasi: "siap" } },
  { label: "Menunggu Validasi", values: { statusValidasi: "menunggu" } },
];

const formatRupiah = (value: number) => `Rp ${value.toLocaleString("id-ID")}`;

export function TaxPotentialDashboardPage() {
  const { toast } = useToastApp();
  const [filterValues, setFilterValues] = React.useState<Record<string, any>>({});

  // Hasil survei & uji petik bertambah terus selama tim di lapangan.
  const liveTitikSurvei = useRealtimeValue({
    initialValue: 450,
    update: (v) => v + (Math.random() > 0.6 ? 1 : 0),
    intervalMs: 8000,
  });
  const liveObjekBaru = useRealtimeValue({
    initialValue: 150,
    update: (v) => v + (Math.random() > 0.75 ? 1 : 0),
    intervalMs: 12000,
  });

  const handleResetFilter = () => {
    setFilterValues({});
    toast.info("Filter Potensi Direset", {
      description: "Semua kriteria tingkat potensi, jenis pajak, dan status validasi dikembalikan ke kondisi awal.",
    });
  };

  const activeTingkat = String(filterValues.tingkatPotensi ?? "all");

  const mapPolygons: MapPolygon[] = React.useMemo(
    () =>
      SEBARAN_POTENSI.filter((s) => activeTingkat === "all" || s.tingkat === activeTingkat).map((s) => {
        const tingkat = TINGKAT_POTENSI[s.tingkat];
        return {
          id: s.id,
          positions: KEMANTREN_POLYGONS[s.kemantren],
          title: s.kemantren,
          color: tingkat.color,
          fillColor: tingkat.color,
          // Makin tinggi tingkatnya makin pekat, supaya gradasi potensi
          // terbaca sekilas tanpa harus membaca legenda lebih dulu.
          fillOpacity: s.tingkat === "tinggi" ? 0.55 : s.tingkat === "sedang" ? 0.38 : 0.22,
          weight: 1.5,
          // Nama wilayah dan tingkat potensinya menempel di tengah bentuknya —
          // pekat/pucatnya isian menunjukkan gradasi, labelnya menyebut nilainya.
          centerLabel: `${s.kemantren} · ${tingkat.label}`,
          centerLabelAlert: s.tingkat === "tinggi",
          popup: `${s.kemantren} — Potensi ${tingkat.label}`,
        };
      }),
    [activeTingkat],
  );

  // Skala bar dibandingkan terhadap total tertinggi supaya panjang batang
  // antarwilayah sebanding, bukan dinormalkan per baris.
  const selisihMaks = Math.max(...SELISIH_UJI_PETIK.map((s) => s.laporanAwal + s.hasilUjiPetik));

  const selisihItems = SELISIH_UJI_PETIK.map((s) => ({
    id: s.wilayah.toLowerCase(),
    label: s.wilayah,
    value: (
      <span className="text-emerald-600 dark:text-emerald-400">+Rp {s.hasilUjiPetik} Jt</span>
    ),
    segments: [
      { percent: (s.laporanAwal / selisihMaks) * 100, color: CHART_COLORS.blue, label: "Laporan Awal" },
      { percent: (s.hasilUjiPetik / selisihMaks) * 100, color: CHART_COLORS.emerald, label: "Tambahan Hasil Uji Petik" },
    ],
  }));

  const tableColumns = [
    {
      accessorKey: "wp",
      header: "Nama Wajib Pajak / Objek",
      cell: ({ row }: any) => (
        <div>
          <TextApp id={`wp-${row.original.id}`} variant="caption" weight="bold" className="block text-ink">
            {row.original.wp}
          </TextApp>
          <span className="text-[11px] text-ink-muted">Objek: {row.original.objek}</span>
        </div>
      ),
    },
    { accessorKey: "wilayah", header: "Wilayah" },
    {
      accessorKey: "jenis",
      header: "Jenis Pajak",
      cell: ({ row }: any) => (
        <BadgeApp id={`badge-jenis-${row.original.id}`} variant="neutral" size="sm">
          {row.original.jenis}
        </BadgeApp>
      ),
    },
    {
      accessorKey: "laporanAwal",
      header: "Laporan Awal",
      cell: ({ row }: any) => (
        <span className="font-mono text-xs text-ink-muted">{formatRupiah(row.original.laporanAwal)}</span>
      ),
    },
    {
      accessorKey: "ujiPetik",
      header: "Uji Petik Riil",
      cell: ({ row }: any) => (
        <span className="font-mono text-xs text-ink-secondary">{formatRupiah(row.original.ujiPetik)}</span>
      ),
    },
    {
      id: "selisih",
      header: "Selisih Potensi",
      cell: ({ row }: any) => (
        <span className="font-mono text-xs font-bold text-emerald-600 dark:text-emerald-400">
          +{formatRupiah(row.original.ujiPetik - row.original.laporanAwal)}
        </span>
      ),
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }: any) => (
        <BadgeApp
          id={`badge-status-${row.original.id}`}
          variant={row.original.status === "Siap Ditetapkan" ? "solidEmerald" : "solidAmber"}
          size="sm"
        >
          {row.original.status}
        </BadgeApp>
      ),
    },
  ];

  return (
    <div id="potensi-pajak-dashboard-root" className="space-y-6 pb-12">
      {/* ------------------------------------------------------------- */}
      {/* HEADER PAGE                                                   */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col justify-between gap-4 border-b border-hairline-soft pb-4 md:flex-row md:items-center">
        <div>
          <div className="mb-1 flex flex-wrap items-center gap-x-3 gap-y-1.5">
            <BadgeApp id="hdr-badge-br08" variant="solidPurple" size="sm">
              BR-08 · Dashboard Potensi Pajak & Ekstensifikasi
            </BadgeApp>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <Sparkles className="h-3.5 w-3.5 text-vibrant-purple" />
              Survei, Uji Petik, & Penetapan OP Baru
            </span>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <Calendar className="h-3.5 w-3.5 text-vibrant-purple" />
              Periode Agustus 2026
            </span>
          </div>
          <TextApp id="hdr-title-potensi" variant="h2" className="tracking-tight text-ink">
            Dashboard Potensi Pajak & Ekstensifikasi
          </TextApp>
          <TextApp id="hdr-sub-potensi" variant="body" className="text-xs text-ink-secondary">
            Monitoring Hasil Survei Lapangan, Konversi Uji Petik, & Validasi Potensi Penerimaan Baru
          </TextApp>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <ButtonApp
            id="btn-refresh-potensi"
            variant="secondary"
            size="sm"
            rounded="lg"
            onClick={() =>
              toast.info("Data Potensi Disinkronkan", {
                description: "Hasil survei lapangan dan uji petik terbaru diperbarui dari sistem.",
              })
            }
            leftIcon={<RefreshCw className="h-3.5 w-3.5" />}
          >
            Sync Survei
          </ButtonApp>
          <ButtonApp
            id="btn-export-potensi"
            variant="primary"
            size="sm"
            rounded="lg"
            leftIcon={<Download className="h-3.5 w-3.5" />}
            onClick={() =>
              toast.vibrant("Laporan Ekstensifikasi Diunduh", {
                description: "Berisi rincian validasi potensi baru beserta selisih terhadap laporan awal.",
              })
            }
          >
            Cetak Laporan Potensi
          </ButtonApp>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* FILTER BAR */}
      {/* ------------------------------------------------------------- */}
      <div className="flex w-full min-w-0 flex-nowrap items-center gap-2 overflow-x-auto rounded-2xl border border-hairline bg-surface px-3 py-3 shadow-xs">
        <span className="flex shrink-0 items-center gap-1.5 whitespace-nowrap text-xs font-semibold text-ink-secondary">
          <Filter className="h-4 w-4 text-vibrant-purple" />
          Filter:
        </span>

        {/* Shortcut inline tingkat potensi — nilainya dibagi dgn
            AdvanceFilterApp DAN menyaring zona pada peta di bawah. */}
        <div className="w-52 shrink-0">
          <DropdownApp
            id="select-tingkat-potensi"
            value={activeTingkat}
            onChange={(value) => setFilterValues((prev) => ({ ...prev, tingkatPotensi: String(value) }))}
            options={[
              { label: "Semua Tingkat Potensi", value: "all" },
              { label: "Potensi Tinggi", value: "tinggi" },
              { label: "Potensi Sedang", value: "sedang" },
              { label: "Potensi Rendah", value: "rendah" },
            ]}
            size="sm"
            rounded="lg"
            menuPortal
          />
        </div>

        <div className="ml-auto shrink-0">
          <AdvanceFilterApp
            id="filter-potensi-ekstensifikasi"
            displayMode="modal"
            showActivePills={false}
            className="w-auto"
            triggerLabel="Advance Filter Potensi"
            triggerVariant="secondary"
            triggerSize="sm"
            triggerRounded="lg"
            title="Filter Potensi Ekstensifikasi & Status Validasi"
            fields={potensiFilterFields}
            values={filterValues}
            onChange={setFilterValues}
            quickPresets={quickPresets}
            onReset={handleResetFilter}
            onApply={() => {
              toast.vibrant("Filter Potensi Diterapkan", {
                description: "Peta sebaran dan rincian validasi menyesuaikan kriteria yang dipilih.",
              });
            }}
          />
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* SCORECARD EKSTENSIFIKASI (BR-08)                               */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col gap-2">
        <TextApp
          id="label-statistik-ekstensifikasi-heading"
          variant="caption"
          weight="bold"
          className="uppercase tracking-widest text-ink-muted"
        >
          Statistik Ekstensifikasi
        </TextApp>
        <div className="grid grid-cols-1 items-stretch gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <ScorecardApp
            id="card-total-titik-survei"
            variant="clayBlue"
            title="Total Titik Survei"
            value={liveTitikSurvei}
            live
            unit="Titik Terdata"
            description="Lokasi hasil penyisiran lapangan periode berjalan"
            trend={{ value: "44%", label: "Lanjut ke Uji Petik", isPositive: true, direction: "up" }}
            icon={<MapPin className="h-5 w-5 text-[#1e3a8a] dark:text-blue-200" />}
            infoTooltip="Jumlah titik lokasi yang disurvei tim lapangan pada periode berjalan."
            infoContent={{
              formula: "Jumlah titik lokasi yang tercatat pada penyisiran lapangan periode berjalan",
              period: "Bulan berjalan (real-time)",
              source: "SIMPAD — Modul Survei Ekstensifikasi",
              lastUpdated: "Baru saja",
            }}
            insight={{
              title: "Total Titik Survei",
              value: "450 Titik",
              status: "sehat",
              meta: ["Ekstensifikasi", "Survei Lapangan", "Agustus 2026"],
              summary:
                "Titik masuk seluruh alur ekstensifikasi. Semua angka lain di halaman ini adalah turunan dari sini, sehingga naik-turunnya menentukan lebar corong di bawah.",
              current: [
                "450 titik disurvei periode ini, 44% di antaranya lanjut ke tahap uji petik.",
              ],
              insights: [
                "Rasio konversi 44% ke uji petik tergolong wajar — separuh lebih titik survei memang berakhir tidak memenuhi syarat.",
              ],
              tacticalRecs: [
                "Perbaiki kriteria penyaringan awal supaya tim tidak menghabiskan waktu pada titik yang jelas tidak memenuhi syarat.",
              ],
              strategicRecs: [
                "Pakai data spasial BR-07 untuk menentukan wilayah survei, bukan penyisiran merata.",
              ],
              dataNotes: ["Snapshot real-time; angka bertambah selama tim di lapangan."],
            }}
          />

          <ScorecardApp
            id="card-validasi-uji-petik"
            variant="emerald"
            title="Validasi Uji Petik"
            // Tidak di-live-kan: nilai rekap hasil uji petik yang ditutup
            // per periode, bukan angka yang bergerak per transaksi.
            value="Rp 2.450 Jt"
            unit="Nilai Tervalidasi"
            description="Nilai riil hasil pemeriksaan lapangan"
            trend={{ value: "+Rp 450 Jt", label: "Selisih Positif", isPositive: true, direction: "up" }}
            icon={<CheckCircle2 className="h-5 w-5 text-emerald-700 dark:text-emerald-200" />}
            infoTooltip="Total nilai potensi yang sudah diverifikasi lewat uji petik lapangan."
            infoContent={{
              formula: "Total nilai riil hasil uji petik atas objek yang diperiksa",
              period: "Rekap periode berjalan",
              source: "SIMPAD — Modul Uji Petik",
              lastUpdated: "Akhir pekan lalu",
            }}
            insight={{
              title: "Validasi Uji Petik",
              value: "Rp 2.450 Juta",
              status: "sehat",
              meta: ["Ekstensifikasi", "Uji Petik", "Agustus 2026"],
              summary:
                "Nilai yang benar-benar terverifikasi di lapangan, bukan lagi estimasi. Selisih positif Rp 450 juta berarti laporan mandiri wajib pajak selama ini di bawah kondisi sebenarnya.",
              current: [
                "Rp 2.450 juta tervalidasi, Rp 450 juta di atas nilai yang dilaporkan sendiri.",
              ],
              insights: [
                "Selisih yang konsisten positif menandakan pelaporan mandiri sistematis lebih rendah dari kenyataan, bukan sekadar kesalahan hitung acak.",
              ],
              tacticalRecs: [
                "Perluas uji petik ke jenis pajak dengan pola selisih serupa sebelum menutup periode.",
              ],
              strategicRecs: [
                "Jadikan besaran selisih sebagai dasar penilaian risiko untuk menentukan siapa yang diperiksa tahun depan.",
              ],
              glossary: [
                { term: "Uji Petik", definition: "pemeriksaan sampel langsung di lokasi untuk memverifikasi laporan wajib pajak." },
              ],
              dataNotes: ["Rekap periodik, bukan angka real-time."],
            }}
          />

          <ScorecardApp
            id="card-objek-pajak-baru"
            variant="clayPurple"
            title="Objek Pajak Baru"
            value={liveObjekBaru}
            live
            unit="OP Ditetapkan"
            description="Objek yang lolos hingga tahap penetapan resmi"
            trend={{ value: "75%", label: "Konversi dari Uji Petik", isPositive: true, direction: "up" }}
            icon={<Target className="h-5 w-5 text-white" />}
            infoTooltip="Objek pajak baru yang sudah resmi ditetapkan bulan ini."
            infoContent={{
              formula: "Jumlah objek pajak baru yang terbit ketetapannya pada periode berjalan",
              period: "Bulan berjalan (real-time)",
              source: "SIMPAD — Modul Penetapan",
              lastUpdated: "Baru saja",
            }}
            insight={{
              title: "Objek Pajak Baru",
              value: "150 Objek Pajak",
              status: "sehat",
              meta: ["Ekstensifikasi", "Penetapan", "Agustus 2026"],
              summary:
                "Ujung dari seluruh alur: objek yang benar-benar masuk basis pajak dan mulai menghasilkan penerimaan. Inilah satu-satunya angka yang berdampak langsung ke kas daerah.",
              current: [
                "150 objek baru ditetapkan, 75% dari yang lolos uji petik.",
                "Sepertiga sisanya gugur pada tahap validasi dokumen.",
              ],
              insights: [
                "Kebocoran terbesar justru bukan di lapangan, melainkan pada tahap validasi dokumen setelah uji petik selesai.",
              ],
              tacticalRecs: [
                "Telusuri alasan 25% yang gugur pasca uji petik — bila administratif, itu bisa diperbaiki tanpa turun lapangan lagi.",
              ],
              strategicRecs: [
                "Satukan berkas uji petik dan berkas penetapan agar tidak ada data yang harus dikumpulkan dua kali.",
              ],
              dataNotes: ["Snapshot real-time dari modul penetapan."],
            }}
          />

          <ScorecardApp
            id="card-total-potensi-baru"
            variant="clayYellow"
            title="Total Potensi Baru"
            // Tidak di-live-kan: proyeksi tahunan atas objek yang sudah
            // ditetapkan, dihitung ulang tiap penutupan periode.
            value="Rp 1.250 Jt"
            unit="Proyeksi Setahun"
            description="Tambahan penerimaan dari objek pajak baru"
            trend={{ value: "15%", label: "dari Target Tahunan", isPositive: true, direction: "up" }}
            icon={<TrendingUp className="h-5 w-5 text-[#5c4300] dark:text-amber-300" />}
            infoTooltip="Proyeksi tambahan penerimaan setahun dari objek pajak baru."
            infoContent={{
              formula: "Jumlah ketetapan objek baru x proyeksi masa pajak setahun",
              period: "Proyeksi tahunan (rekap periodik)",
              source: "SIMPAD — Modul Penetapan",
              lastUpdated: "Akhir pekan lalu",
            }}
            insight={{
              title: "Total Potensi Baru",
              value: "Rp 1.250 Juta",
              status: "waspada",
              meta: ["Ekstensifikasi", "Proyeksi Penerimaan", "TA 2026"],
              summary:
                "Perkiraan tambahan penerimaan setahun dari objek yang baru ditetapkan. Baru menutup 15% target tahunan ekstensifikasi.",
              current: [
                "Rp 1.250 juta terkumpul dari target tahunan, setara 15%.",
              ],
              insights: [
                "Dengan laju saat ini, target tahunan tidak akan tercapai — perlu penambahan cakupan survei, bukan sekadar mempercepat proses yang ada.",
              ],
              tacticalRecs: [
                "Arahkan survei berikutnya ke zona potensi tinggi pada peta di bawah untuk menaikkan nilai per titik.",
              ],
              strategicRecs: [
                "Tinjau ulang realisme target tahunan terhadap kapasitas tim survei yang tersedia.",
              ],
              dataNotes: ["Angka proyeksi, bukan penerimaan yang sudah masuk kas."],
            }}
          />
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* PETA SEBARAN POTENSI (BR-08)                                   */}
      {/* ------------------------------------------------------------- */}
      <CardApp
        id="card-map-sebaran-potensi"
        className="flex flex-col border-hairline-soft p-5"
        insight={{
          title: "Peta Sebaran Potensi Ekstensifikasi",
          value: `${SEBARAN_POTENSI.filter((s) => s.tingkat === "tinggi").length} Zona Potensi Tinggi`,
          status: "waspada",
          meta: ["Spasial", "Potensi Ekstensifikasi", "Agustus 2026"],
          summary:
            "Membagi kemantren menjadi tiga tingkat potensi ekstensifikasi. Dipakai untuk memilih wilayah survei berikutnya agar nilai per titik survei lebih tinggi.",
          current: [
            "Dua kemantren masuk zona potensi tinggi, tiga sedang, dua rendah.",
            "Zona tinggi berimpit dengan kawasan komersial padat.",
          ],
          insights: [
            "Menyurvei zona tinggi menghasilkan nilai jauh lebih besar per titik dibanding penyisiran merata, meski jumlah titiknya sama.",
          ],
          tacticalRecs: [
            "Alokasikan minimal dua pertiga kapasitas survei berikutnya ke zona potensi tinggi.",
          ],
          strategicRecs: [
            "Perbarui klasifikasi zona tiap semester supaya wilayah yang sudah tergarap tidak terus jadi prioritas.",
          ],
          dataNotes: ["Batas wilayah adalah aproksimasi untuk keperluan visualisasi."],
        }}
      >
        <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
          <div>
            <TextApp id="title-map-potensi" variant="h3" weight="bold" className="text-ink-primary">
              Peta Sebaran Potensi Ekstensifikasi
            </TextApp>
            <TextApp id="sub-map-potensi" variant="caption" className="text-ink-secondary">
              Klasifikasi tingkat potensi per kemantren untuk penentuan target survei.
            </TextApp>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {Object.entries(TINGKAT_POTENSI).map(([key, tingkat]) => (
              <span key={key} className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: tingkat.color }} />
                <TextApp id={`legend-potensi-${key}`} variant="caption" className="text-[11px] text-ink-secondary">
                  {tingkat.label}
                </TextApp>
              </span>
            ))}
          </div>
        </div>

        <div className="h-[420px] w-full overflow-hidden rounded-xl border border-hairline-soft">
          <MapsApp
            id="map-sebaran-potensi"
            center={YOGYAKARTA_CENTER}
            zoom={12}
            polygons={mapPolygons}
            tileProvider="carto-light"
            showControls
            className="h-full w-full"
          />
        </div>
      </CardApp>

      {/* ------------------------------------------------------------- */}
      {/* ALUR KONVERSI + SELISIH UJI PETIK (BR-08)                      */}
      {/* ------------------------------------------------------------- */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <CardApp
          id="card-alur-konversi"
          className="flex flex-col border-hairline-soft p-5"
          insight={{
            title: "Alur Konversi Ekstensifikasi",
            value: "450 → 200 → 150",
            status: "waspada",
            meta: ["Konversi", "Alur Ekstensifikasi", "Agustus 2026"],
            summary:
              "Corong tiga tahap dari survei sampai penetapan. Menunjukkan di tahap mana kandidat objek pajak paling banyak gugur.",
            current: [
              "Dari 450 titik survei, 200 lolos uji petik (44%), dan 150 akhirnya ditetapkan (75%).",
              "Kebocoran terbesar terjadi pada transisi survei ke uji petik.",
            ],
            insights: [
              "Penyusutan 56% di tahap pertama itu wajar dan sehat — yang perlu diwaspadai justru bila angkanya terlalu kecil, karena berarti penyaringan awal terlalu longgar.",
            ],
            tacticalRecs: [
              "Fokuskan perbaikan pada tahap kedua: 25% yang gugur setelah uji petik adalah kandidat yang sudah terbukti layak.",
            ],
            strategicRecs: [
              "Pantau rasio konversi antar-periode; penurunan mendadak menandakan ada perubahan kriteria yang tidak disengaja.",
            ],
            dataNotes: ["Persentase konversi dihitung terhadap tahap sebelumnya."],
          }}
        >
          <div className="mb-4">
            <TextApp id="title-alur-konversi" variant="h3" weight="bold" className="text-ink-primary">
              Alur Konversi Ekstensifikasi
            </TextApp>
            <TextApp id="sub-alur-konversi" variant="caption" className="text-ink-secondary">
              Penyusutan kandidat objek pajak dari survei hingga penetapan.
            </TextApp>
          </div>

          <div className="flex flex-1 flex-col">
            <FunnelChartApp id="funnel-alur-konversi" variant="steps" data={ALUR_KONVERSI} />

            <div className="mt-5 flex flex-1 flex-col border-t border-hairline-soft pt-4">
              <div className="mb-1 flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
                <TextApp id="title-tren-konversi" variant="caption" weight="bold" className="text-ink">
                  Tren Rasio Konversi
                </TextApp>
                <TextApp id="sub-tren-konversi" variant="caption" className="text-[11px] text-ink-secondary">
                  Enam bulan terakhir — titik paling kanan adalah angka pada kartu di atas.
                </TextApp>
              </div>

              <ChartApp
                id="chart-tren-konversi"
                type="line"
                data={TREN_KONVERSI}
                xKey="bulan"
                height={168}
                series={[
                  // Warna tiap garis mengikuti kartu tahap yang rasionya diukur,
                  // jadi 44% di kartu ungu dan 75% di kartu hijau bisa dilacak
                  // ke garisnya tanpa perlu membaca legenda lebih dulu.
                  { key: "ujiPetik", label: "Survei → Uji Petik", color: CHART_COLORS.purple },
                  { key: "penetapan", label: "Uji Petik → Penetapan", color: CHART_COLORS.emerald },
                ]}
                valueFormatter={(value) => `${value}%`}
              />
            </div>
          </div>
        </CardApp>

        <CardApp
          id="card-selisih-uji-petik"
          className="flex flex-col border-hairline-soft p-5"
          insight={{
            title: "Selisih Laporan vs Uji Petik",
            value: "Umbulharjo +Rp 210 Jt",
            status: "waspada",
            meta: ["Verifikasi", "Selisih Nilai", "Agustus 2026"],
            summary:
              "Membandingkan nilai yang dilaporkan wajib pajak dengan hasil pemeriksaan lapangan. Selisihnya menunjukkan besaran potensi yang selama ini tidak tercatat.",
            current: [
              "Umbulharjo menyumbang selisih terbesar, Rp 210 juta di atas laporan awal.",
              "Ketiga wilayah teratas semuanya bernilai positif.",
            ],
            insights: [
              "Tidak ada satu pun wilayah dengan selisih negatif — polanya searah, yang menandakan pelaporan mandiri memang cenderung di bawah kondisi sebenarnya.",
            ],
            tacticalRecs: [
              "Jadikan tiga wilayah ini sebagai sampel prioritas pemeriksaan periode berikutnya.",
            ],
            strategicRecs: [
              "Terapkan pembanding nilai berbasis zona agar laporan yang jauh di bawah rata-rata zonanya otomatis tertandai.",
            ],
            dataNotes: ["Satuan dalam juta rupiah."],
          }}
        >
          <div className="mb-4">
            <TextApp id="title-selisih-uji-petik" variant="h3" weight="bold" className="text-ink-primary">
              Selisih Laporan vs Uji Petik (Top 3)
            </TextApp>
            <TextApp id="sub-selisih-uji-petik" variant="caption" className="text-ink-secondary">
              Nilai laporan awal dibanding temuan riil di lapangan — satuan juta rupiah.
            </TextApp>
          </div>

          {/* Bar dua segmen per wilayah dengan selisih tercetak di kanan —
              mengikuti acuan. ChartApp bar horizontal sempat dipakai di sini,
              tapi sumbu & grid-nya justru mengaburkan yang ingin dibaca:
              besaran selisihnya, bukan posisi absolut tiap batang. */}
          <ProgressListApp id="list-selisih-uji-petik" items={selisihItems} />

          <div className="mt-4 flex items-center gap-4 border-t border-hairline-soft pt-3">
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: CHART_COLORS.blue }} />
              <TextApp id="legend-laporan-awal" variant="caption" className="text-[11px] text-ink-secondary">
                Laporan Awal
              </TextApp>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: CHART_COLORS.emerald }} />
              <TextApp id="legend-hasil-uji-petik" variant="caption" className="text-[11px] text-ink-secondary">
                Tambahan Hasil Uji Petik
              </TextApp>
            </span>
          </div>
        </CardApp>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* RINCIAN VALIDASI POTENSI BARU (BR-08)                          */}
      {/* ------------------------------------------------------------- */}
      <CardApp id="card-table-validasi-potensi" className="border-hairline-soft p-5">
        <DataTableApp
          id="datatable-validasi-potensi"
          title="Rincian Validasi Potensi Baru"
          description="Objek hasil uji petik beserta perbandingan nilai laporan awal dan temuan riil di lapangan."
          toolbarLayout="singleRow"
          data={VALIDASI_POTENSI}
          columns={tableColumns}
          getRowId={(row) => row.id}
          searchPlaceholder="Cari wajib pajak, objek, wilayah, atau jenis pajak..."
          pageSize={5}
        />
      </CardApp>
    </div>
  );
}

export default TaxPotentialDashboardPage;
