import * as React from "react";
import {
  ScorecardApp,
  CardApp,
  BadgeApp,
  ButtonApp,
  TextApp,
  AdvanceFilterApp,
  DataTableApp,
  ChartApp,
  GaugeChartApp,
  HeatmapApp,
  DialogApp,
  DropdownApp,
  useToastApp,
  useRealtimeValue,
  useRealtimeRows,
  QuickPreset,
} from "@/packages/design-system";
import {
  Database,
  RefreshCw,
  Download,
  Eye,
  Activity,
  TrendingUp,
  Layers,
  Calendar,
  Filter,
  Users,
  Map,
  ClipboardCheck,
  Copy,
  AlertTriangle,
  Clock,
} from "lucide-react";
import { CHART_COLORS } from "@/constants/chartColors";

// Filter Field Configuration for BR-06
const basisDataFilterFields = [
  {
    id: "sektorPajak",
    label: "Sektor Pajak",
    type: "select" as const,
    placeholder: "Pilih Sektor Pajak...",
    options: [
      { value: "all", label: "Semua Sektor Pajak" },
      { value: "pbb_p2", label: "PBB-P2 (Pedesaan & Perkotaan)" },
      { value: "pbjt_makanan", label: "PBJT Makanan & Minuman" },
      { value: "pbjt_hotel", label: "PBJT Jasa Perhotelan" },
      { value: "pbjt_hiburan", label: "PBJT Jasa Kesenian & Hiburan" },
      { value: "bphtb", label: "BPHTB (Bea Perolehan Hak)" },
      { value: "reklame", label: "Pajak Reklame" },
      { value: "air_tanah", label: "Pajak Air Tanah (PAT)" },
    ],
  },
  {
    id: "kecamatan",
    label: "Wilayah Kecamatan",
    type: "select" as const,
    placeholder: "Pilih Kecamatan...",
    options: [
      { value: "all", label: "Semua Kecamatan (14 Wilayah)" },
      { value: "gondomanan", label: "Kecamatan Gondomanan" },
      { value: "danurejan", label: "Kecamatan Danurejan" },
      { value: "kraton", label: "Kecamatan Kraton" },
      { value: "jetis", label: "Kecamatan Jetis" },
      { value: "umbulharjo", label: "Kecamatan Umbulharjo" },
      { value: "mantrijeron", label: "Kecamatan Mantrijeron" },
      { value: "kotagede", label: "Kecamatan Kotagede" },
      { value: "gondokusuman", label: "Kecamatan Gondokusuman" },
    ],
  },
  {
    id: "kategoriIsu",
    label: "Kategori Isu Kualitas Data",
    type: "select" as const,
    placeholder: "Semua Kategori Isu...",
    options: [
      { value: "all", label: "Semua Kategori Isu" },
      { value: "data_ganda", label: "Data Ganda (Duplicate NIK/NOP)" },
      { value: "tidak_valid", label: "Data Tidak Valid (NIK/Alamat)" },
      { value: "belum_verifikasi", label: "Belum Diverifikasi Lapangan" },
      { value: "data_incomplete", label: "Data Tidak Lengkap (Incomplete)" },
    ],
  },
  {
    id: "statusAudit",
    label: "Status Pembersihan / Cleansing",
    type: "select" as const,
    placeholder: "Semua Status Audit...",
    options: [
      { value: "all", label: "Semua Status Audit" },
      { value: "teridentifikasi", label: "Teridentifikasi Sistem" },
      { value: "proses_cleansing", label: "Dalam Proses Perbaikan" },
      { value: "diverifikasi", label: "Selesai Diverifikasi Valid" },
    ],
  },
];

const quickPresets: QuickPreset[] = [
  { label: "Semua Record Basis Data", values: { kategoriIsu: "all", statusAudit: "all" } },
  { label: "Anomali Data Ganda", values: { kategoriIsu: "data_ganda" } },
  { label: "Format NIK / NOP Invalid", values: { kategoriIsu: "tidak_valid" } },
  { label: "Pending Verifikasi", values: { kategoriIsu: "belum_verifikasi" } },
];

// Matriks Anomali Sektoral — persis nilai referensi ZIP (satuan ribuan record).
const anomaliSektoralData = [
  { x: "Data Tidak Lengkap", y: "PBB", value: 4.2 },
  { x: "Data Ganda", y: "PBB", value: 1.1 },
  { x: "Data Tidak Valid", y: "PBB", value: 8.5 },
  { x: "Data Tidak Lengkap", y: "Reklame", value: 0.8 },
  { x: "Data Ganda", y: "Reklame", value: 5.2 },
  { x: "Data Tidak Valid", y: "Reklame", value: 0.5 },
  { x: "Data Tidak Lengkap", y: "PAT", value: 0.1 },
  { x: "Data Ganda", y: "PAT", value: 0.0 },
  { x: "Data Tidak Valid", y: "PAT", value: 0.2 },
  { x: "Data Tidak Lengkap", y: "PBJT", value: 1.8 },
  { x: "Data Ganda", y: "PBJT", value: 0.4 },
  { x: "Data Tidak Valid", y: "PBJT", value: 2.1 },
  { x: "Data Tidak Lengkap", y: "BPHTB", value: 0.1 },
  { x: "Data Ganda", y: "BPHTB", value: 3.1 },
  { x: "Data Tidak Valid", y: "BPHTB", value: 0.1 },
];

// Status Validasi Dokumen — donut, persis referensi ZIP.
const statusValidasiDokumenData = [
  { name: "Terverifikasi", value: 60, fill: CHART_COLORS.emerald },
  { name: "Belum Diverifikasi", value: 24, fill: CHART_COLORS.amber },
  { name: "Gagal Verifikasi", value: 16, fill: CHART_COLORS.blue },
];

// Tren Anomali & Cleansing Data (6 bulan terakhir) — persis pola referensi ZIP
// (tren menurun Jul->Des seiring otomatisasi deduplikasi).
const trenAnomaliData = [
  { bulan: "Jul", dataGanda: 420, tidakValid: 315, belumDiverif: 262 },
  { bulan: "Agu", dataGanda: 368, tidakValid: 294, belumDiverif: 210 },
  { bulan: "Sep", dataGanda: 315, tidakValid: 262, belumDiverif: 189 },
  { bulan: "Okt", dataGanda: 262, tidakValid: 210, belumDiverif: 158 },
  { bulan: "Nov", dataGanda: 189, tidakValid: 158, belumDiverif: 126 },
  { bulan: "Des", dataGanda: 126, tidakValid: 105, belumDiverif: 84 },
];

// Mock Audit Flagged Records Table Data
const mockAuditRecords = [
  {
    id: "AUD-001",
    refID: "NPWPD-P.2.0034821.04.12",
    namaSubjek: "PT Kuliner Rasa Jogja",
    sektor: "PBJT Makanan & Minuman",
    jenisIsu: "Data Ganda",
    deskripsiIsu: "Terdeteksi 2 NPWPD aktif dengan NIK Direktur & Alamat Usaha persis sama",
    skorDQI: "68.5%",
    statusAudit: "Teridentifikasi Sistem",
    tglTemuan: "24 Jul 2026",
    petugasAudit: "Tim Quality Control BPKPAD",
    kecamatan: "Gondomanan",
  },
  {
    id: "AUD-002",
    refID: "NOP-34.71.010.002.015.0019",
    namaSubjek: "Tanah & Bangunan Malioboro",
    sektor: "PBB-P2",
    jenisIsu: "Data Tidak Valid",
    deskripsiIsu: "Format NIK Pemilik hanya 15 digit (Dukcapil Mismatch API)",
    skorDQI: "72.0%",
    statusAudit: "Dalam Proses Perbaikan",
    tglTemuan: "22 Jul 2026",
    petugasAudit: "Siti Rahmawati, S.E.",
    kecamatan: "Danurejan",
  },
  {
    id: "AUD-003",
    refID: "NPWPD-P.1.0019230.01.15",
    namaSubjek: "Hotel Grand Ambarrukmo Branch",
    sektor: "PBJT Jasa Perhotelan",
    jenisIsu: "Belum Diverifikasi",
    deskripsiIsu: "Pendaftaran Mandiri Web SIMPAD belum dilakukan Ground Check Lapangan",
    skorDQI: "81.4%",
    statusAudit: "Teridentifikasi Sistem",
    tglTemuan: "20 Jul 2026",
    petugasAudit: "Budi Santoso, S.STP",
    kecamatan: "Gondokusuman",
  },
  {
    id: "AUD-004",
    refID: "NOP-34.71.040.008.001.0082",
    namaSubjek: "Billboard Tugu Jogja Monument",
    sektor: "Pajak Reklame",
    jenisIsu: "Data Tidak Lengkap",
    deskripsiIsu: "Foto Objek Pajak & Titik Koordinat GPS Spasial belum diunggah",
    skorDQI: "64.0%",
    statusAudit: "Dalam Proses Perbaikan",
    tglTemuan: "18 Jul 2026",
    petugasAudit: "Agus Setiawan",
    kecamatan: "Jetis",
  },
  {
    id: "AUD-005",
    refID: "NPWPD-P.4.0081293.03.11",
    namaSubjek: "Resto Tradisional Raminten",
    sektor: "PBJT Makanan & Minuman",
    jenisIsu: "Data Ganda",
    deskripsiIsu: "Duplikasi NIB OSS dengan nama entitas usaha cabang",
    skorDQI: "75.2%",
    statusAudit: "Selesai Diverifikasi Valid",
    tglTemuan: "15 Jul 2026",
    petugasAudit: "Tim Verifikasi Wilayah",
    kecamatan: "Gondokusuman",
  },
];

// Realtime feed audit — pola sama seperti useRealtimeRows di halaman lain.
const AUD_NAMA_POOL = [
  "Toko Batik Pasar Beringharjo", "CV Souvenir Malioboro Jaya", "Warung Gudeg Bu Slamet",
  "PT Konveksi Kotagede Mandiri", "Rumah Kos Mahasiswa Seturan", "UD Perak Kotagede Asli",
];
const AUD_SEKTOR_POOL = ["PBJT Makanan & Minuman", "PBB-P2", "PBJT Jasa Perhotelan", "Pajak Reklame", "BPHTB"];
const AUD_ISU_POOL: Array<{ jenis: string; deskripsi: string }> = [
  { jenis: "Data Ganda", deskripsi: "Terdeteksi duplikasi NIK/NIB pada entitas berbeda" },
  { jenis: "Data Tidak Valid", deskripsi: "Format NIK/NOP mismatch dengan API Dukcapil/SIMPAD" },
  { jenis: "Belum Diverifikasi", deskripsi: "Belum dilakukan Ground Check Lapangan" },
  { jenis: "Data Tidak Lengkap", deskripsi: "Foto objek pajak & koordinat GPS belum diunggah" },
];
const AUD_STATUS_POOL = ["Teridentifikasi Sistem", "Dalam Proses Perbaikan", "Selesai Diverifikasi Valid"];
const AUD_PETUGAS_POOL = ["Siti Rahmawati, S.E.", "Budi Santoso, S.STP", "Agus Setiawan", "Tim Quality Control BPKPAD"];
const AUD_KECAMATAN_POOL = ["Gondomanan", "Danurejan", "Gondokusuman", "Jetis"];

function generateNextAuditRecord(): typeof mockAuditRecords[0] {
  const now = new Date();
  const seq = `${now.getTime().toString().slice(-6)}${Math.floor(Math.random() * 900) + 100}`;
  const isu = AUD_ISU_POOL[Math.floor(Math.random() * AUD_ISU_POOL.length)];
  return {
    id: `AUD-${seq}`,
    refID: `NPWPD-P.${Math.floor(Math.random() * 4) + 1}.00${Math.floor(Math.random() * 90000) + 10000}.0${Math.floor(Math.random() * 9) + 1}.${Math.floor(Math.random() * 90) + 10}`,
    namaSubjek: AUD_NAMA_POOL[Math.floor(Math.random() * AUD_NAMA_POOL.length)],
    sektor: AUD_SEKTOR_POOL[Math.floor(Math.random() * AUD_SEKTOR_POOL.length)],
    jenisIsu: isu.jenis,
    deskripsiIsu: isu.deskripsi,
    skorDQI: `${(60 + Math.random() * 30).toFixed(1)}%`,
    statusAudit: AUD_STATUS_POOL[Math.floor(Math.random() * AUD_STATUS_POOL.length)],
    tglTemuan: now.toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" }),
    petugasAudit: AUD_PETUGAS_POOL[Math.floor(Math.random() * AUD_PETUGAS_POOL.length)],
    kecamatan: AUD_KECAMATAN_POOL[Math.floor(Math.random() * AUD_KECAMATAN_POOL.length)],
  };
}

export function TaxDatabaseDashboardPage() {
  const { toast } = useToastApp();

  // Detail Modal State
  const [selectedRecord, setSelectedRecord] = React.useState<typeof mockAuditRecords[0] | null>(null);
  const [isDetailDialogOpen, setIsDetailDialogOpen] = React.useState(false);

  // Realtime KPI — DQI & basis WP/OP mengikuti pola realtime standar kita;
  // ZIP referensi menampilkan angka ini statis (audit snapshot), tapi kita
  // tetap patuh pada aturan realtime-by-default untuk metrik utama.
  const liveDqiScore = useRealtimeValue({ initialValue: 86.4, update: (v) => Math.min(99.9, Math.max(70, v + (Math.random() - 0.45) * 0.3)), intervalMs: 9000 });
  const liveTotalWp = useRealtimeValue({ initialValue: 124502, update: (v) => v + Math.floor(Math.random() * 3), intervalMs: 8000 });
  const liveTotalOp = useRealtimeValue({ initialValue: 224103, update: (v) => v + Math.floor(Math.random() * 4), intervalMs: 7500 });
  // Anomali basis data — angkanya konsisten dengan kolom Matriks Anomali
  // Sektoral di bawah (Data Ganda 9,8rb; Tidak Valid 11,4rb; Tidak Lengkap
  // 7,0rb) dan slice "Belum Diverifikasi" (24%) pada donut Status Validasi.
  const liveDataGanda = useRealtimeValue({ initialValue: 9800, update: (v) => Math.max(8000, v - Math.floor(Math.random() * 3)), intervalMs: 10000 });
  const liveDataTidakValid = useRealtimeValue({ initialValue: 11400, update: (v) => Math.max(9000, v - Math.floor(Math.random() * 3)), intervalMs: 11000 });
  const liveBelumDiverifikasi = useRealtimeValue({ initialValue: 83665, update: (v) => Math.max(70000, v - Math.floor(Math.random() * 5)), intervalMs: 8500 });

  // Realtime feed tabel audit — baris baru masuk dari atas, di-highlight.
  const { rows: liveAuditRecords, newRowIds: newAuditRecordIds } = useRealtimeRows({
    initialRows: mockAuditRecords,
    getId: (row) => row.id,
    generate: generateNextAuditRecord,
    intervalMs: 11000,
    maxRows: 20,
  });

  // Active Filter state
  const [filterValues, setFilterValues] = React.useState<Record<string, any>>({});

  const handleResetFilter = () => {
    setFilterValues({});
    toast.info("Filter Direset", {
      description: "Semua kriteria filter basis data pajak telah dikembalikan ke kondisi default.",
    });
  };

  const handleExportReport = () => {
    toast.success("Laporan Basis Data Diexport", {
      description: "Berkas PDF/XLSX Audit Kualitas Basis Data Pajak & Cleansing BR-06 berhasil diunduh.",
    });
  };

  const handleOpenDetailModal = (record: typeof mockAuditRecords[0]) => {
    setSelectedRecord(record);
    setIsDetailDialogOpen(true);
  };

  // Columns for DataTableApp (Dashboard Kualitas Data Table)
  const tableColumns = [
    {
      accessorKey: "refID",
      header: "Ref Identitas / NOP",
      cell: ({ row }: any) => (
        <div>
          <div className="font-mono text-xs font-bold text-vibrant-purple">
            {row.original.refID}
          </div>
          <div className="text-[10px] text-ink-secondary">Ref ID: {row.original.id}</div>
        </div>
      ),
    },
    {
      accessorKey: "namaSubjek",
      header: "Nama Subjek / Objek Pajak",
      cell: ({ row }: any) => (
        <div className="font-medium text-ink-primary text-xs">
          {row.original.namaSubjek}
        </div>
      ),
    },
    {
      accessorKey: "sektor",
      header: "Sektor Pajak",
      cell: ({ row }: any) => (
        <BadgeApp id={`badge-sektor-aud-${row.original.id}`} variant="solidAmber" size="sm">
          {row.original.sektor}
        </BadgeApp>
      ),
    },
    {
      accessorKey: "jenisIsu",
      header: "Kategori Anomali / Isu",
      cell: ({ row }: any) => {
        const val = row.original.jenisIsu;
        let badgeVariant: any = "solidRose";
        if (val === "Data Ganda") badgeVariant = "solidRose";
        if (val === "Data Tidak Valid") badgeVariant = "solidAmber";
        if (val === "Belum Diverifikasi") badgeVariant = "blue";
        if (val === "Data Tidak Lengkap") badgeVariant = "solidPurple";

        return <BadgeApp id={`badge-isu-${row.original.id}`} variant={badgeVariant} size="sm">{val}</BadgeApp>;
      },
    },
    {
      accessorKey: "skorDQI",
      header: "Skor DQI",
      cell: ({ row }: any) => (
        <span className="font-mono font-bold text-xs text-amber-700 dark:text-amber-400">
          {row.original.skorDQI}
        </span>
      ),
    },
    {
      accessorKey: "statusAudit",
      header: "Status Cleansing",
      cell: ({ row }: any) => {
        const val = row.original.statusAudit;
        let badgeVariant: any = "solidEmerald";
        if (val === "Selesai Diverifikasi Valid") badgeVariant = "solidEmerald";
        if (val === "Dalam Proses Perbaikan") badgeVariant = "solidAmber";
        if (val === "Teridentifikasi Sistem") badgeVariant = "solidRose";

        return <BadgeApp id={`badge-status-aud-${row.original.id}`} variant={badgeVariant} size="sm">{val}</BadgeApp>;
      },
    },
    {
      accessorKey: "tglTemuan",
      header: "Tgl Temuan",
      cell: ({ row }: any) => (
        <div className="text-xs font-mono text-ink-secondary">{row.original.tglTemuan}</div>
      ),
    },
    {
      id: "actions",
      header: "Aksi",
      cell: ({ row }: any) => (
        <ButtonApp
          id={`btn-detail-aud-${row.original.id}`}
          variant="purpleDark"
          theme="default"
          size="sm"
          rounded="pill"
          onClick={() => handleOpenDetailModal(row.original)}
          className="flex items-center gap-1 text-[11px] h-7 px-2.5"
        >
          <Eye className="w-3.5 h-3.5" />
          Audit
        </ButtonApp>
      ),
    },
  ];

  return (
    <div id="basis-data-dashboard-root" className="space-y-6 pb-12">
      {/* ------------------------------------------------------------- */}
      {/* HEADER PAGE                                                   */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col justify-between gap-4 border-b border-hairline-soft pb-4 md:flex-row md:items-center">
        <div>
          <div className="mb-1 flex flex-wrap items-center gap-x-3 gap-y-1.5">
            <BadgeApp id="hdr-badge-br06" variant="solidPurple" size="sm">
              BR-06 · Dashboard Basis Data Pajak
            </BadgeApp>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <Database className="h-3.5 w-3.5 text-vibrant-purple" />
              Master Data Governance & DQI
            </span>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <Calendar className="h-3.5 w-3.5 text-vibrant-purple" />
              TA 2026 Audit
            </span>
          </div>
          <TextApp id="hdr-title-basisdata" variant="h2" className="tracking-tight text-ink">
            Dashboard Tata Kelola Basis Data Pajak & Quality Index
          </TextApp>
          <TextApp id="hdr-sub-basisdata" variant="body" className="text-xs text-ink-secondary">
            Monitoring Master Wajib Pajak, Objek Pajak, Kelengkapan NIK/NIB, Rekonsiliasi Data Ganda, & Data Quality Index (DQI)
          </TextApp>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <ButtonApp
            id="btn-refresh-basisdata"
            variant="secondary"
            size="sm"
            rounded="lg"
            onClick={() =>
              toast.info("Audit Basis Data Dijalankan", {
                description: "Proses validasi NIK Dukcapil & NOP SIMPAD selesai diperbarui secara otomatis.",
              })
            }
            leftIcon={<RefreshCw className="h-3.5 w-3.5" />}
          >
            Audit System
          </ButtonApp>
          <ButtonApp
            id="btn-export-basisdata-report"
            variant="primary"
            size="sm"
            rounded="lg"
            leftIcon={<Download className="h-3.5 w-3.5" />}
            onClick={handleExportReport}
          >
            Cetak Laporan Kualitas Data
          </ButtonApp>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* FILTER BAR */}
      {/* ------------------------------------------------------------- */}
      <div className="flex w-full min-w-0 flex-nowrap items-center gap-2 overflow-x-auto rounded-2xl border border-hairline bg-surface px-3 py-3 shadow-xs">
        <span className="flex shrink-0 items-center gap-1.5 whitespace-nowrap text-xs font-semibold text-ink-secondary">
          <Filter className="h-4 w-4 text-vibrant-purple" />
          Filter:
        </span>

        {/* Shortcut inline utk field yang paling sering dipakai — nilainya
            dibagi dgn AdvanceFilterApp supaya tidak jadi kontrol kosmetik. */}
        <div className="w-60 shrink-0">
          <DropdownApp
            id="select-sektor-pajak-basis-data"
            value={String(filterValues.sektorPajak ?? "all")}
            onChange={(value) =>
              setFilterValues((prev) => ({ ...prev, sektorPajak: String(value) }))
            }
            options={[
              { label: "Semua Sektor Pajak", value: "all" },
              { label: "PBB-P2 (Pedesaan & Perkotaan)", value: "pbb_p2" },
              { label: "PBJT Makanan & Minuman", value: "pbjt_makanan" },
              { label: "PBJT Jasa Perhotelan", value: "pbjt_hotel" },
              { label: "PBJT Jasa Kesenian & Hiburan", value: "pbjt_hiburan" },
              { label: "BPHTB (Bea Perolehan Hak)", value: "bphtb" },
              { label: "Pajak Reklame", value: "reklame" },
              { label: "Pajak Air Tanah (PAT)", value: "air_tanah" },
            ]}
            size="sm"
            rounded="lg"
            menuPortal
          />
        </div>

        <div className="ml-auto shrink-0">
          <AdvanceFilterApp
            id="filter-basis-data-pajak"
            displayMode="modal"
            showActivePills={false}
            className="w-auto"
            triggerLabel="Advance Filter Basis Data"
            triggerVariant="secondary"
            triggerSize="sm"
            triggerRounded="lg"
            title="Filter Anomali Basis Data & Sektor Pajak"
            fields={basisDataFilterFields}
            values={filterValues}
            onChange={setFilterValues}
            quickPresets={quickPresets}
            onReset={handleResetFilter}
            onApply={() => {
              toast.vibrant("Filter Basis Data Berhasil Diterapkan", {
                description: "Menampilkan data anomali dan master record berdasarkan kriteria filter.",
              });
            }}
          />
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* SCORECARD BR-06 (Item 1 s/d 6)                                 */}
      {/* 2 baris kartu tanpa chart pendamping -> heading kategori per    */}
      {/* baris, pola sama dengan Dashboard Pendataan (BR-03).           */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col gap-2">
        <TextApp id="label-statistik-basis-data-heading" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted">
          Statistik Basis Data
        </TextApp>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-stretch">
          <div className="col-span-1 flex flex-col h-full">
            <ScorecardApp
              id="card-jumlah-wp"
              variant="clayPurple"
              title="Jumlah Wajib Pajak"
              value={liveTotalWp}
              live
              unit="WP Terdaftar"
              description="Master Wajib Pajak Daerah Kota Yogyakarta"
              trend={{ value: "+6.4%", label: "Pertumbuhan YTD", isPositive: true, direction: "up" }}
              icon={<Users className="w-5 h-5 text-white" />}
              infoTooltip="Total record Wajib Pajak pada master database SIMPAD."
              infoContent={{
                formula: "Total record Wajib Pajak (NPWPD) aktif & nonaktif pada master database",
                period: "Snapshot (real-time)",
                source: "SIMPAD — Master Wajib Pajak",
                lastUpdated: "Baru saja",
              }}
              insight={{
                title: "Jumlah Wajib Pajak",
                value: "124.502 WP",
                status: "sehat",
                meta: ["Indikator", "Master Data WP", "TA 2026"],
                summary: "Jumlah Wajib Pajak mengukur seluruh record NPWPD pada master database, menjadi penyebut utama perhitungan Data Quality Index.",
                current: [
                  "Basis 124.502 WP dengan rasio kepemilikan rata-rata 1,8 OP per WP.",
                  "92% record sudah terintegrasi penuh dengan data Objek Pajak, 8% masih anomali link.",
                ],
                insights: [
                  "Rasio 1,8 OP/WP wajar untuk komposisi kota — mayoritas WP memiliki lebih dari satu objek pajak.",
                ],
                tacticalRecs: [
                  "Telusuri 8% anomali link WP-OP untuk memastikan tidak ada objek pajak tanpa subjek yang sah.",
                ],
                strategicRecs: [
                  "Jadikan rasio OP/WP sebagai indikator dini potensi ekstensifikasi per kecamatan.",
                ],
                dataNotes: ["Snapshot master data live, pembaruan real-time."],
              }}
            />
          </div>

          <div className="col-span-1 flex flex-col h-full">
            <ScorecardApp
              id="card-jumlah-op"
              variant="clayBlue"
              title="Jumlah Objek Pajak"
              value={liveTotalOp}
              live
              unit="OP Terdaftar"
              description="Master Objek Pajak (NOP) Daerah Kota Yogyakarta"
              trend={{ value: "+7.1%", label: "Pertumbuhan YTD", isPositive: true, direction: "up" }}
              icon={<Map className="w-5 h-5 text-[#1e3a8a] dark:text-blue-200" />}
              infoTooltip="Total record Objek Pajak (NOP) pada master database SIMPAD."
              infoContent={{
                formula: "Total record Objek Pajak (NOP) tanah, bangunan & unit usaha pada master database",
                period: "Snapshot (real-time)",
                source: "SIMPAD — Master Objek Pajak",
                lastUpdated: "Baru saja",
              }}
              insight={{
                title: "Jumlah Objek Pajak",
                value: "224.103 OP",
                status: "sehat",
                meta: ["Indikator", "Master Data OP", "TA 2026"],
                summary: "Jumlah Objek Pajak mengukur seluruh record NOP pada master database — basis perhitungan ketetapan dan target pendapatan.",
                current: [
                  "Basis 224.103 OP, setara 45% dari total entitas basis data (WP + OP).",
                  "Tumbuh 7,1% YTD, sedikit lebih cepat dari pertumbuhan WP (6,4%).",
                ],
                insights: [
                  "OP tumbuh lebih cepat dari WP — indikasi ekspansi multi-objek pada wajib pajak yang sudah terdaftar.",
                ],
                tacticalRecs: [
                  "Cross-check OP baru terhadap WP induknya untuk mencegah NOP ganda pada objek yang sama.",
                ],
                strategicRecs: [
                  "Bangun proyeksi kapasitas penilaian mengikuti laju pertumbuhan NOP tahunan.",
                ],
                dataNotes: ["Snapshot master data live, pembaruan real-time."],
              }}
            />
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <TextApp id="label-kualitas-anomali-heading" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted">
          Kualitas & Anomali Data
        </TextApp>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 items-stretch">
          <div className="col-span-1 flex flex-col h-full">
            <ScorecardApp
              id="card-kelengkapan-data"
              variant="clayYellow"
              title="Kelengkapan Data"
              value="98.0%"
              unit="Field Wajib Terisi"
              description="7.000 record masih tidak lengkap dari 348.605"
              progress={{ value: 98, max: 100, label: "Capaian kelengkapan", color: CHART_COLORS.amber }}
              trend={{ value: "+1.4%", label: "vs Bulan Lalu", isPositive: true, direction: "up" }}
              icon={<ClipboardCheck className="w-5 h-5 text-[#5c4300] dark:text-amber-300" />}
              infoTooltip="Rasio record dengan seluruh field wajib (NIK/NIB, alamat, koordinat) terisi lengkap."
              infoContent={{
                formula: "(Total record − record tidak lengkap) ÷ total record × 100%",
                period: "Snapshot (real-time)",
                source: "SIMPAD — Audit Kelengkapan Field",
                lastUpdated: "5 menit lalu",
              }}
              insight={{
                title: "Kelengkapan Data",
                value: "98,0% Lengkap",
                status: "sehat",
                meta: ["Indikator", "Kelengkapan Field", "Real-time"],
                summary: "Kelengkapan Data mengukur rasio record yang seluruh field wajibnya (NIK/NIB, alamat, koordinat objek) sudah terisi terhadap total record basis data.",
                current: [
                  "98,0% record lengkap; 7.000 record dari 348.605 masih menyisakan field kosong.",
                  "Naik 1,4 poin dibanding bulan lalu seiring proses cleansing berjalan.",
                ],
                insights: [
                  "PBB menyumbang porsi terbesar record tidak lengkap (4.200 dari 7.000) — terkonsentrasi, bukan menyebar.",
                ],
                tacticalRecs: [
                  "Fokuskan pelengkapan field pada sektor PBB yang menyumbang 60% total record tidak lengkap.",
                ],
                strategicRecs: [
                  "Terapkan validasi field wajib di titik input agar record baru tidak menambah backlog.",
                ],
                dataNotes: ["Dihitung dari kolom Data Tidak Lengkap pada Matriks Anomali Sektoral."],
              }}
            />
          </div>

          <div className="col-span-1 flex flex-col h-full">
            <ScorecardApp
              id="card-data-ganda"
              variant="default"
              title="Data Ganda"
              value={liveDataGanda}
              live
              unit="Record Duplikat"
              description="Duplikasi NIK/NIB & NOP tumpuk terdeteksi"
              trend={{ value: "-18.4%", label: "Turun vs Jul", isPositive: true, direction: "down" }}
              icon={<Copy className="w-5 h-5 text-purple-600" />}
              infoTooltip="Record terdeteksi duplikat berdasarkan kesamaan NIK/NIB atau NOP."
              infoContent={{
                formula: "Jumlah record dengan NIK/NIB atau NOP identik pada lebih dari satu entri aktif",
                period: "Snapshot (real-time)",
                source: "SIMPAD — Engine Deduplikasi",
                lastUpdated: "10 menit lalu",
              }}
              insight={{
                title: "Data Ganda",
                value: "9.800 Record",
                status: "waspada",
                meta: ["Indikator", "Anomali Duplikasi", "Real-time"],
                summary: "Data Ganda mengukur record yang terdeteksi duplikat berdasarkan kesamaan NIK/NIB Wajib Pajak atau NOP Objek Pajak.",
                current: [
                  "9.800 record duplikat terdeteksi, setara 2,8% dari total basis data.",
                  "Turun 18,4% sejak Juli seiring otomatisasi deduplikasi berjalan.",
                ],
                insights: [
                  "Reklame (5.200) dan BPHTB (3.100) menyumbang 85% total duplikasi — terpusat di dua sektor saja.",
                ],
                tacticalRecs: [
                  "Prioritaskan merge record duplikat sektor Reklame yang menyumbang porsi terbesar.",
                ],
                strategicRecs: [
                  "Terapkan unique constraint NIK/NOP di level database agar duplikasi tidak terbentuk ulang.",
                ],
                dataNotes: ["Selaras dengan kolom Data Ganda pada Matriks Anomali Sektoral."],
              }}
            />
          </div>

          <div className="col-span-1 flex flex-col h-full">
            <ScorecardApp
              id="card-data-tidak-valid"
              variant="default"
              title="Data Tidak Valid"
              value={liveDataTidakValid}
              live
              unit="Record Invalid"
              description="Format NIK/NOP salah atau mismatch Dukcapil"
              trend={{ value: "-12.7%", label: "Turun vs Jul", isPositive: true, direction: "down" }}
              icon={<AlertTriangle className="w-5 h-5 text-amber-500" />}
              infoTooltip="Record dengan format NIK/NOP tidak sesuai standar atau gagal verifikasi Dukcapil."
              infoContent={{
                formula: "Jumlah record gagal validasi format NIK/NOP atau mismatch terhadap API Dukcapil/OSS",
                period: "Snapshot (real-time)",
                source: "SIMPAD — Validator Dukcapil & OSS",
                lastUpdated: "10 menit lalu",
              }}
              insight={{
                title: "Data Tidak Valid",
                value: "11.400 Record",
                status: "waspada",
                meta: ["Indikator", "Anomali Validitas", "Real-time"],
                summary: "Data Tidak Valid mengukur record yang gagal validasi format (NIK 16 digit, struktur NOP) atau tidak cocok saat dicek ke API Dukcapil/OSS.",
                current: [
                  "11.400 record invalid — kategori anomali terbesar di basis data.",
                  "Turun 12,7% sejak Juli, namun masih di atas Data Ganda (9.800).",
                ],
                insights: [
                  "PBB menyumbang 8.500 dari 11.400 record invalid — mayoritas berupa NIK pemilik tidak lengkap 16 digit.",
                ],
                tacticalRecs: [
                  "Jalankan batch re-verifikasi NIK PBB terhadap API Dukcapil untuk memangkas porsi terbesar.",
                ],
                strategicRecs: [
                  "Wajibkan validasi NIK real-time saat pendaftaran agar record invalid tidak bertambah.",
                ],
                dataNotes: ["Selaras dengan kolom Data Tidak Valid pada Matriks Anomali Sektoral."],
              }}
            />
          </div>

          <div className="col-span-1 flex flex-col h-full">
            <ScorecardApp
              id="card-belum-diverifikasi"
              variant="default"
              title="Data Belum Diverifikasi"
              value={liveBelumDiverifikasi}
              live
              unit="Record Pending"
              description="24% dari total dokumen menunggu verifikasi"
              trend={{ value: "-9.3%", label: "Turun vs Jul", isPositive: true, direction: "down" }}
              icon={<Clock className="w-5 h-5 text-blue-500" />}
              infoTooltip="Record yang belum melalui ground check lapangan atau verifikasi dokumen."
              infoContent={{
                formula: "Jumlah record berstatus belum terverifikasi ÷ total dokumen basis data",
                period: "Snapshot (real-time)",
                source: "SIMPAD — Modul Verifikasi Dokumen",
                lastUpdated: "5 menit lalu",
              }}
              insight={{
                title: "Data Belum Diverifikasi",
                value: "83.665 Record",
                status: "waspada",
                meta: ["Indikator", "Siklus Verifikasi", "Real-time"],
                summary: "Data Belum Diverifikasi mengukur record yang sudah masuk basis data namun belum melalui ground check lapangan atau verifikasi dokumen pendukung.",
                current: [
                  "83.665 record pending, setara 24% dari total dokumen basis data.",
                  "60% dokumen sudah terverifikasi, 16% sisanya gagal verifikasi dan perlu perbaikan.",
                ],
                insights: [
                  "Porsi pending (24%) jauh lebih besar dari gagal verifikasi (16%) — hambatan utamanya kapasitas verifikasi, bukan kualitas berkas.",
                ],
                tacticalRecs: [
                  "Tambah kapasitas tim ground check untuk memangkas antrean 83.665 record pending.",
                ],
                strategicRecs: [
                  "Terapkan verifikasi berbasis sampling risiko agar record bernilai tinggi diprioritaskan.",
                ],
                dataNotes: ["Selaras dengan slice Belum Diverifikasi pada donut Status Validasi Dokumen."],
              }}
            />
          </div>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* SECTION 1: KUALITAS & INTEGRITAS DATA                          */}
      {/* Struktur mengikuti referensi ZIP BasisPajakView.tsx persis:    */}
      {/* DQI Gauge (1-col) + Nexus WP & OP (2-col).                     */}
      {/* ------------------------------------------------------------- */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
        <div className="lg:col-span-1 flex flex-col">
          <CardApp
            id="card-dqi-gauge"
            className="p-5 border-hairline-soft flex-1 flex flex-col"
            insight={{
              title: "Data Quality Index (DQI)",
              value: "86,4 / 100",
              status: "sehat",
              meta: ["Indikator", "Kesehatan Basis Data", "Real-time"],
              summary: "Data Quality Index (DQI) mengukur skor komposit kesehatan basis data pajak — gabungan kelengkapan, validitas, dan bebas duplikasi seluruh record WP & OP.",
              current: [
                "Skor DQI terkini 86,4/100, berstatus SEHAT.",
                "Skor bergerak dalam rentang wajar seiring proses cleansing berjalan otomatis.",
              ],
              insights: [
                "Skor 86,4 berada di atas ambang batas SEHAT (≥ 70), namun belum mencapai grade tertinggi — masih ada ruang perbaikan pada segmen Perlu Review/Kritis.",
              ],
              tacticalRecs: [
                "Prioritaskan penyelesaian record berstatus Kritis sebelum audit tahunan berikutnya.",
              ],
              strategicRecs: [
                "Otomatisasi validasi berkelanjutan agar skor DQI naik secara konsisten dari waktu ke waktu.",
              ],
              dataNotes: ["Skor live, pembaruan real-time dari hasil audit otomatis."],
            }}
          >
            <div className="mb-4">
              <TextApp id="label-dqi-eyebrow" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted">
                Data Quality Index (DQI)
              </TextApp>
              <TextApp id="title-dqi-gauge" variant="h4" weight="bold" className="text-ink-primary mt-0.5">
                Kesehatan Basis Data
              </TextApp>
            </div>

            <div className="flex-1 flex items-center justify-center py-2">
              <GaugeChartApp
                id="gauge-dqi"
                value={liveDqiScore}
                min={0}
                max={100}
                target={90}
                label="SEHAT"
                valueFormatter={(v) => v.toFixed(1)}
                className="max-w-[220px]"
              />
            </div>

            <div className="flex items-center justify-center gap-4 mt-2">
              <div className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-emerald-500" />
                <TextApp id="legend-dqi-valid" variant="caption" weight="bold" className="uppercase tracking-wide text-ink-secondary">Valid</TextApp>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-amber-500" />
                <TextApp id="legend-dqi-review" variant="caption" weight="bold" className="uppercase tracking-wide text-ink-secondary">Perlu Review</TextApp>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-rose-500" />
                <TextApp id="legend-dqi-kritis" variant="caption" weight="bold" className="uppercase tracking-wide text-ink-secondary">Kritis</TextApp>
              </div>
            </div>
          </CardApp>
        </div>

        <div className="lg:col-span-2 flex flex-col">
          <CardApp
            id="card-nexus-wp-op"
            className="p-5 border-hairline-soft flex-1 flex flex-col"
            insight={{
              title: "Konektivitas WP & OP",
              value: "92% Terintegrasi",
              status: "sehat",
              meta: ["Indikator", "Nexus Integritas Data", "Real-time"],
              summary: "Konektivitas WP & OP mengukur seberapa baik tautan (link) antara entitas Wajib Pajak dan Objek Pajak dalam basis data terjaga konsisten.",
              current: [
                "124.502 WP tertaut ke 224.103 OP, rasio kepemilikan rata-rata 1,8 OP/WP.",
                "92% tautan terintegrasi valid; 8% terdeteksi anomali link (mismatch/orphan record).",
              ],
              insights: [
                "8% anomali link setara puluhan ribu record berpotensi menyebabkan salah alamat ketetapan pajak jika tidak dibersihkan.",
              ],
              tacticalRecs: [
                "Audit prioritas pada record dengan anomali link tertinggi per sektor (lihat Matriks Anomali Sektoral).",
              ],
              strategicRecs: [
                "Bangun validasi otomatis saat entri data baru agar anomali link tidak terus bertambah.",
              ],
              dataNotes: ["Snapshot basis data live, pembaruan real-time."],
            }}
          >
            <div className="mb-4">
              <TextApp id="label-nexus-eyebrow" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted">
                Nexus Integritas Data
              </TextApp>
              <TextApp id="title-nexus-wp-op" variant="h4" weight="bold" className="text-ink-primary mt-0.5">
                Konektivitas WP & OP
              </TextApp>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-end justify-between gap-4 py-4">
              <div className="sm:w-1/4">
                <TextApp id="label-total-wp-nexus" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted mb-1">
                  Total Wajib Pajak
                </TextApp>
                <TextApp id="value-total-wp-nexus" variant="h2" weight="bold" className="text-ink-primary tabular-nums">
                  {liveTotalWp.toLocaleString("id-ID")}
                </TextApp>
              </div>

              <div className="flex-1 px-0 sm:px-6 pb-1">
                <div className="h-2.5 w-full rounded-full overflow-hidden flex bg-surface-subtle">
                  <div className="h-full bg-sky-600" style={{ width: "55%" }} />
                  <div className="h-full bg-sky-300" style={{ width: "45%" }} />
                </div>
                <div className="flex justify-between mt-2">
                  <TextApp id="label-entity-wp" variant="caption" className="font-mono text-ink-muted">ENTITY_WP (55%)</TextApp>
                  <TextApp id="label-entity-op" variant="caption" className="font-mono text-ink-muted">ENTITY_OP (45%)</TextApp>
                </div>
              </div>

              <div className="sm:w-1/4 sm:text-right">
                <TextApp id="label-total-op-nexus" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted mb-1">
                  Total Objek Pajak
                </TextApp>
                <TextApp id="value-total-op-nexus" variant="h2" weight="bold" className="text-ink-primary tabular-nums">
                  {liveTotalOp.toLocaleString("id-ID")}
                </TextApp>
              </div>
            </div>

            <div className="mt-auto bg-surface-subtle rounded-xl p-4 border border-hairline-soft flex flex-wrap items-center justify-between gap-4">
              <div>
                <TextApp id="label-rasio-kepemilikan" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted mb-1">
                  Rasio Kepemilikan Rata-rata
                </TextApp>
                <div className="flex items-baseline gap-1.5">
                  <TextApp id="value-rasio-kepemilikan" variant="h3" weight="bold" className="text-ink-primary">1,8</TextApp>
                  <TextApp id="unit-rasio-kepemilikan" variant="body" className="text-ink-secondary">OP/WP</TextApp>
                </div>
              </div>
              <div className="flex gap-8">
                <div className="text-right">
                  <TextApp id="label-terintegrasi" variant="caption" weight="bold" className="uppercase tracking-widest text-emerald-600 mb-1">
                    Terintegrasi
                  </TextApp>
                  <TextApp id="value-terintegrasi" variant="h4" weight="bold" className="text-ink-primary">92%</TextApp>
                </div>
                <div className="text-right">
                  <TextApp id="label-anomali-link" variant="caption" weight="bold" className="uppercase tracking-widest text-rose-600 mb-1">
                    Anomali Link
                  </TextApp>
                  <TextApp id="value-anomali-link" variant="h4" weight="bold" className="text-rose-600">8%</TextApp>
                </div>
              </div>
            </div>
          </CardApp>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* SECTION 2: DIAGNOSTIK & VERIFIKASI                             */}
      {/* Matriks Anomali Sektoral (2-col, Heatmap) + Status Validasi    */}
      {/* Dokumen (1-col, Donut) — sesuai referensi ZIP.                 */}
      {/* ------------------------------------------------------------- */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
        <div className="lg:col-span-2 flex flex-col">
          <CardApp
            id="card-matriks-anomali-sektoral"
            className="p-5 border-hairline-soft flex-1 flex flex-col"
            insight={{
              title: "Matriks Anomali Sektoral",
              value: "8,5k Data Tidak Valid (PBB)",
              status: "waspada",
              meta: ["Indikator", "Diagnostik Kesalahan", "Real-time"],
              summary: "Matriks Anomali Sektoral memetakan jumlah record bermasalah per sektor pajak (baris) terhadap jenis kesalahan (kolom): data tidak lengkap, data ganda, dan data tidak valid.",
              current: [
                "Sel dengan tingkat kesalahan tertinggi: PBB × Data Tidak Valid (8,5k) dan Reklame × Data Ganda (5,2k).",
                "PAT konsisten memiliki kesalahan terendah di semua kategori — kualitas data sektor ini paling baik.",
              ],
              insights: [
                "PBB dan Reklame menyumbang mayoritas volume anomali — kedua sektor ini sebaiknya jadi prioritas program cleansing berikutnya.",
              ],
              tacticalRecs: [
                "Fokuskan tim cleansing pada sel PBB×Tidak Valid dan Reklame×Data Ganda terlebih dahulu (dampak terbesar).",
              ],
              strategicRecs: [
                "Investigasi akar penyebab tingginya Data Tidak Valid pada PBB — kemungkinan sumber input data legacy yang belum tervalidasi API Dukcapil.",
              ],
              dataNotes: ["Satuan ribuan record, snapshot audit terbaru."],
            }}
          >
            <div className="mb-4">
              <TextApp id="label-anomali-eyebrow" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted">
                Diagnostik Kesalahan
              </TextApp>
              <TextApp id="title-matriks-anomali" variant="h4" weight="bold" className="text-ink-primary mt-0.5">
                Matriks Anomali Sektoral
              </TextApp>
            </div>

            <div className="flex-1 flex items-center">
              <HeatmapApp
                id="heatmap-anomali-sektoral"
                data={anomaliSektoralData}
                variant="matrix"
                maxHeight={185}
                autoLoop={true}
                valueFormatter={(v) => `${v.toFixed(1)}k`}
                className="w-full"
              />
            </div>
          </CardApp>
        </div>

        <div className="lg:col-span-1 flex flex-col">
          <CardApp
            id="card-status-validasi-dokumen"
            className="p-5 border-hairline-soft flex-1 flex flex-col"
            insight={{
              title: "Status Validasi Dokumen",
              value: "60% Terverifikasi",
              status: "waspada",
              meta: ["Indikator", "Siklus Verifikasi", "Real-time"],
              summary: "Status Validasi Dokumen menunjukkan tahap siklus verifikasi seluruh dokumen basis data: sudah terverifikasi, belum diverifikasi, atau gagal verifikasi.",
              current: [
                "60% dokumen sudah terverifikasi, 24% masih menunggu (belum diverifikasi), 16% gagal verifikasi.",
                "Total 40% dokumen (belum + gagal) masih memerlukan tindak lanjut tim verifikasi.",
              ],
              insights: [
                "Porsi gagal verifikasi (16%) tergolong signifikan — perlu diagnosis apakah kegagalan disebabkan data sumber yang cacat atau proses verifikasi itu sendiri.",
              ],
              tacticalRecs: [
                "Prioritaskan penyelesaian 24% dokumen belum diverifikasi sebelum menambah antrean baru.",
              ],
              strategicRecs: [
                "Audit akar penyebab 16% kegagalan verifikasi untuk mencegah pola berulang di periode berikutnya.",
              ],
              dataNotes: ["Snapshot siklus verifikasi, pembaruan berkala."],
            }}
          >
            <div className="mb-4">
              <TextApp id="label-validasi-eyebrow" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted">
                Siklus Verifikasi
              </TextApp>
              <TextApp id="title-status-validasi" variant="h4" weight="bold" className="text-ink-primary mt-0.5">
                Status Validasi Dokumen
              </TextApp>
            </div>

            <div className="flex-1 min-h-[220px] w-full">
              <ChartApp
                id="chart-donut-status-validasi"
                type="pie"
                data={statusValidasiDokumenData}
                xKey="name"
                yKey="value"
                height="100%"
                innerRadius={55}
                outerRadius={85}
                showLegend
              />
            </div>
          </CardApp>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* SECTION 3: EVALUASI TEMPORAL                                   */}
      {/* Tren Anomali & Cleansing Data (stacked bar) — sesuai referensi */}
      {/* ZIP, full-width.                                               */}
      {/* ------------------------------------------------------------- */}
      <CardApp
        id="card-tren-anomali-cleansing"
        className="p-5 border-hairline-soft"
        insight={{
          title: "Tren Anomali & Cleansing Data",
          value: "-70% Data Ganda (6 Bulan)",
          status: "sehat",
          meta: ["Indikator", "Evaluasi Temporal", "6 Bulan Terakhir"],
          summary: "Tren Anomali & Cleansing Data melacak jumlah record bermasalah (data ganda, tidak valid, belum diverifikasi) sepanjang 6 bulan terakhir untuk mengevaluasi efektivitas proses cleansing.",
          current: [
            "Data Ganda turun dari 420 (Jul) menjadi 126 (Des) — penurunan 70% dalam 6 bulan.",
            "Ketiga kategori anomali menurun konsisten tiap bulan, tanpa ada bulan yang naik kembali.",
          ],
          insights: [
            "Laju cleansing data meningkat 14,2% dalam 3 bulan terakhir melalui otomatisasi deduplikasi — tren penurunan diperkirakan berlanjut jika otomatisasi dipertahankan.",
          ],
          tacticalRecs: [
            "Pertahankan proses otomatisasi deduplikasi yang telah terbukti efektif menurunkan anomali secara konsisten.",
          ],
          strategicRecs: [
            "Proyeksikan target zero-anomaly berdasarkan tren penurunan 6 bulan ini untuk perencanaan cleansing tahun berikutnya.",
          ],
          dataNotes: ["Data bulanan Jul-Des 2026, satuan jumlah record."],
        }}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 mb-4 border-b border-hairline-soft">
          <div>
            <TextApp id="label-temporal-eyebrow" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted">
              Evaluasi Temporal
            </TextApp>
            <TextApp id="title-tren-anomali" variant="h4" weight="bold" className="text-ink-primary mt-0.5">
              Tren Anomali & Cleansing Data (6 Bulan Terakhir)
            </TextApp>
          </div>
        </div>

        <div className="h-[280px] w-full mb-6">
          <ChartApp
            id="chart-tren-anomali-cleansing"
            type="bar"
            data={trenAnomaliData}
            xKey="bulan"
            height="100%"
            series={[
              { key: "dataGanda", label: "Data Ganda", color: CHART_COLORS.purple, stackId: "anomali" },
              { key: "tidakValid", label: "Tidak Valid", color: CHART_COLORS.blue, stackId: "anomali" },
              { key: "belumDiverif", label: "Belum Diverif", color: CHART_COLORS.cyan, stackId: "anomali" },
            ]}
            showGrid
            showTooltip
            showLegend
          />
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-surface-subtle border border-hairline-soft p-4 rounded-xl">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-100 text-emerald-600 dark:bg-emerald-950/40">
              <Activity className="w-5 h-5" />
            </div>
            <TextApp id="text-cleansing-summary" variant="body" weight="medium" className="text-ink-secondary">
              Laju cleansing data meningkat <span className="font-bold text-emerald-600">14,2%</span> dalam 3 bulan terakhir melalui otomatisasi deduplikasi.
            </TextApp>
          </div>

          <div className="flex gap-2">
            <ButtonApp id="btn-resolve-all-errors" variant="secondary" size="sm" rounded="pill">
              Resolve All Errors
            </ButtonApp>
            <ButtonApp id="btn-unduh-laporan-trend" variant="purpleDark" theme="default" size="sm" rounded="pill">
              Unduh Laporan Trend
            </ButtonApp>
          </div>
        </div>
      </CardApp>

      {/* ------------------------------------------------------------- */}
      {/* DATA TABLE DASHBOARD KUALITAS DATA & ANOMALI AUDIT             */}
      {/* ------------------------------------------------------------- */}
      <CardApp id="card-table-audit-records" className="p-5 border-hairline-soft">
        <DataTableApp
          id="datatable-audit-records"
          title="Master Table Anomali Basis Data & Action Plan Cleansing"
          description="Daftar Record Wajib Pajak / Objek Pajak Terdeteksi Anomali Data Ganda, Mismatch NIK, dan Incomplete"
          rightHeaderAction={
            <BadgeApp id="badge-tbl-recent-aud" variant="solidAmber" size="sm">Temuan Anomali Terbaru</BadgeApp>
          }
          toolbarLayout="singleRow"
          data={liveAuditRecords}
          newRowIds={newAuditRecordIds}
          getRowId={(row) => row.id}
          columns={tableColumns}
          searchPlaceholder="Cari Ref ID, NPWPD/NOP, Nama Subjek, atau Petugas Audit..."
          pageSize={5}
        />
      </CardApp>

      {/* ------------------------------------------------------------- */}
      {/* DETAIL DIALOG MODAL (Portalled by DialogApp)                   */}
      {/* ------------------------------------------------------------- */}
      {selectedRecord && (
        <DialogApp
          id="dialog-detail-audit-record"
          isOpen={isDetailDialogOpen}
          onClose={() => setIsDetailDialogOpen(false)}
          title={`Audit Record: ${selectedRecord.refID}`}
          description="Rincian temuan anomali data dan rekomendasi tindakan pembersihan (cleansing)."
          size="lg"
        >
          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-3 p-3 bg-surface-subtle rounded-xl border border-hairline-soft">
              <div>
                <span className="text-ink-secondary block">Ref Identitas / NOP:</span>
                <span className="font-mono font-bold text-vibrant-purple">{selectedRecord.refID}</span>
              </div>
              <div>
                <span className="text-ink-secondary block">Nama Subjek / WP:</span>
                <span className="font-bold text-ink-primary">{selectedRecord.namaSubjek}</span>
              </div>
              <div>
                <span className="text-ink-secondary block">Kategori Isu:</span>
                <BadgeApp id="badge-dlg-isu" variant="solidRose" size="sm">{selectedRecord.jenisIsu}</BadgeApp>
              </div>
              <div>
                <span className="text-ink-secondary block">Skor DQI Record:</span>
                <span className="font-mono font-bold text-amber-700 dark:text-amber-400">{selectedRecord.skorDQI}</span>
              </div>
            </div>

            <div className="p-3 border border-hairline-soft rounded-xl space-y-2">
              <div className="font-semibold text-ink-primary flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-vibrant-purple" />
                <span>Deskripsi Anomali & Rencana Cleansing</span>
              </div>
              <p className="text-ink-secondary">
                Deskripsi Anomali: <span className="text-ink-primary font-medium">{selectedRecord.deskripsiIsu}</span>
              </p>
              <p className="text-ink-secondary">
                Wilayah Audit: <span className="text-ink-primary font-medium">Kecamatan {selectedRecord.kecamatan}</span> | Petugas: <span className="text-ink-primary font-medium">{selectedRecord.petugasAudit}</span>
              </p>
              <p className="text-ink-secondary">
                Status Cleansing: <BadgeApp id="badge-dlg-status-aud" variant="solidEmerald" size="sm">{selectedRecord.statusAudit}</BadgeApp>
              </p>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <ButtonApp
                id="btn-close-detail-audit-dialog"
                variant="purpleDark"
                theme="default"
                size="sm"
                rounded="pill"
                onClick={() => setIsDetailDialogOpen(false)}
              >
                Tutup Audit
              </ButtonApp>
            </div>
          </div>
        </DialogApp>
      )}
    </div>
  );
}

export default TaxDatabaseDashboardPage;
