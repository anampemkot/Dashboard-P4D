import * as React from "react";
import {
  CardApp,
  BadgeApp,
  ButtonApp,
  TextApp,
  AdvanceFilterApp,
  DataTableApp,
  ChartApp,
  ChartToolbarApp,
  SankeyDiagramApp,
  TreemapChartApp,
  DialogApp,
  DropdownApp,
  useToastApp,
  useRealtimeRows,
  QuickPreset,
} from "@/packages/design-system";
import {
  FileText,
  Network,
  BarChart3,
  RefreshCw,
  Download,
  Eye,
  Layers,
  Calendar,
  Filter,
} from "lucide-react";
import { CHART_COLORS, CHART_TARGET_COLOR, CHART_COLOR_PURPLE_SOFT } from "@/constants/chartColors";

// Filter Field Configuration for BR-05
const penetapanFilterFields = [
  {
    id: "sektorPajak",
    label: "Sektor Pajak",
    type: "select" as const,
    placeholder: "Pilih Sektor Pajak...",
    options: [
      { value: "all", label: "Semua Sektor Pajak" },
      { value: "pbb_p2", label: "PBB-P2 (Pedesaan & Perkotaan)" },
      { value: "pbjt_makanan", label: "PBJT Makanan & Minuman" },
      { value: "pbjt_hotel", label: "PBJT Jasa Perhotelan" },
      { value: "pbjt_hiburan", label: "PBJT Jasa Kesenian & Hiburan" },
      { value: "pbjt_parkir", label: "PBJT Jasa Parkir" },
      { value: "pbjt_ppj", label: "PBJT Tenaga Listrik (PPJ)" },
      { value: "bphtb", label: "BPHTB (Bea Perolehan Hak)" },
      { value: "reklame", label: "Pajak Reklame" },
      { value: "air_tanah", label: "Pajak Air Tanah (PAT)" },
    ],
  },
  {
    id: "kecamatan",
    label: "Wilayah Kecamatan",
    type: "select" as const,
    placeholder: "Pilih Kecamatan...",
    options: [
      { value: "all", label: "Semua Kecamatan (14 Wilayah)" },
      { value: "gondomanan", label: "Kecamatan Gondomanan" },
      { value: "danurejan", label: "Kecamatan Danurejan" },
      { value: "kraton", label: "Kecamatan Kraton" },
      { value: "jetis", label: "Kecamatan Jetis" },
      { value: "umbulharjo", label: "Kecamatan Umbulharjo" },
      { value: "mantrijeron", label: "Kecamatan Mantrijeron" },
      { value: "kotagede", label: "Kecamatan Kotagede" },
      { value: "gondokusuman", label: "Kecamatan Gondokusuman" },
    ],
  },
  {
    id: "jenisKetetapan",
    label: "Jenis Dokumen Penetapan",
    type: "select" as const,
    placeholder: "Pilih Jenis Dokumen...",
    options: [
      { value: "all", label: "Semua Jenis SKP" },
      { value: "skpd_jabatan", label: "SKPD Off-Official / Jabatan" },
      { value: "sptpd_self", label: "SPTPD Self-Assessment" },
      { value: "skpdkb", label: "SKPDKB (Kurang Bayar)" },
      { value: "skpdt", label: "SKPDT (Tambahan)" },
      { value: "skpd_nihil", label: "SKPDN (Nihil)" },
    ],
  },
  {
    id: "bulanPenetapan",
    label: "Bulan Penetapan",
    type: "select" as const,
    placeholder: "Pilih Bulan...",
    options: [
      { value: "all", label: "Semua Bulan (Jan - Des)" },
      { value: "07", label: "Juli 2026 (Berjalan)" },
      { value: "06", label: "Juni 2026" },
      { value: "05", label: "Mei 2026" },
      { value: "04", label: "April 2026" },
      { value: "03", label: "Maret 2026" },
    ],
  },
  {
    id: "tahunAnggaran",
    label: "Tahun Anggaran",
    type: "select" as const,
    placeholder: "Tahun...",
    options: [
      { value: "2026", label: "Tahun 2026 (Berjalan)" },
      { value: "2025", label: "Tahun 2025" },
      { value: "2024", label: "Tahun 2024" },
    ],
  },
];

const quickPresets: QuickPreset[] = [
  { label: "Semua Penetapan 2026", values: { jenisKetetapan: "all", bulanPenetapan: "all" } },
  { label: "PBB Masa 2026", values: { sektorPajak: "pbb_p2" } },
  { label: "PBJT Self Assessment", values: { jenisKetetapan: "sptpd_self" } },
  { label: "Penetapan Juli 2026", values: { bulanPenetapan: "07" } },
];

// Alur Dokumen — Sankey Total Dokumen -> SPPT/SKPD/E-SPTPD, persis referensi ZIP.
const alurDokumenNodes = [{ name: "Total Dokumen (1,2 Juta)" }, { name: "SPPT (850k)" }, { name: "SKPD (120k)" }, { name: "E-SPTPD (230k)" }];
const alurDokumenLinks = [
  { source: 0, target: 1, value: 850 },
  { source: 0, target: 2, value: 120 },
  { source: 0, target: 3, value: 230 },
];

// Distribusi Nilai Pajak — Treemap OFFICIAL vs SELF, persis nilai referensi ZIP (satuan Miliar Rp).
const distribusiOfficialData = [
  { name: "PBB", size: 4200, fill: CHART_COLORS.purple },
  { name: "Opsen PKB", size: 2500, fill: CHART_COLORS.blue },
  { name: "O. BBNKB", size: 2200, fill: CHART_COLORS.emerald },
  { name: "Reklame", size: 800, fill: CHART_COLORS.amber },
  { name: "PAT", size: 300, fill: CHART_COLORS.cyan },
];
const distribusiSelfData = [
  { name: "BPHTB", size: 1800, fill: CHART_COLORS.purple },
  { name: "PBJT Tenaga Listrik", size: 1200, fill: CHART_COLORS.blue },
  { name: "PBJT Jasa Perhotelan", size: 800, fill: CHART_COLORS.emerald },
  { name: "PBJT Kes. & Hiburan", size: 500, fill: CHART_COLORS.amber },
  { name: "PBJT Makanan & Minuman", size: 400, fill: CHART_COLORS.cyan },
  { name: "PBJT Parkir", size: 150, fill: CHART_COLOR_PURPLE_SOFT },
];

// Official Assessment — combo chart volume (bar) vs nilai (line), persis referensi ZIP.
const officialAssessmentData = [
  { name: "PBB", volume: 850000, nilai: 4200000000000 },
  { name: "Reklame", volume: 120000, nilai: 800000000000 },
  { name: "PAT", volume: 45000, nilai: 300000000000 },
  { name: "O. PKB", volume: 310000, nilai: 2500000000000 },
  { name: "O. BBNKB", volume: 280000, nilai: 2200000000000 },
];

// Self Assessment (E-SPTPD) — bubble chart volume vs nilai vs avg/doc, persis referensi ZIP.
const selfAssessmentData = [
  { name: "BPHTB", shortName: "BPHTB", volume: 50, nilai: 1800, avg: 36 },
  { name: "PBJT Tenaga Listrik", shortName: "Listrik", volume: 80, nilai: 1200, avg: 15 },
  { name: "PBJT Jasa Perhotelan", shortName: "Hotel", volume: 150, nilai: 800, avg: 5 },
  { name: "PBJT Kes. & Hiburan", shortName: "Hiburan", volume: 40, nilai: 500, avg: 12.5 },
  { name: "PBJT Makanan & Minuman", shortName: "Mamin", volume: 100, nilai: 400, avg: 4 },
  { name: "PBJT Parkir", shortName: "Parkir", volume: 180, nilai: 150, avg: 0.8 },
];

// Tren Target vs Realisasi — data bulanan persis referensi ZIP (nilai & target dalam Rupiah penuh).
const trenTargetRealisasiData = [
  { name: "Jan", volume: 170000, nilai: 400000000000, target: 600000000000 },
  { name: "Feb", volume: 197000, nilai: 450000000000, target: 600000000000 },
  { name: "Mar", volume: 235000, nilai: 500000000000, target: 600000000000 },
  { name: "Apr", volume: 365000, nilai: 800000000000, target: 600000000000 },
  { name: "Mei", volume: 435000, nilai: 900000000000, target: 600000000000 },
  { name: "Jun", volume: 515000, nilai: 1100000000000, target: 600000000000 },
  { name: "Jul", volume: 655000, nilai: 1300000000000, target: 600000000000 },
  { name: "Agu", volume: 800000, nilai: 1600000000000, target: 600000000000 },
  { name: "Sep", volume: 845000, nilai: 1800000000000, target: 600000000000 },
  { name: "Okt", volume: 885000, nilai: 1900000000000, target: 600000000000 },
  { name: "Nov", volume: 1100000, nilai: 2400000000000, target: 600000000000 },
  { name: "Des", volume: 0, nilai: 0, target: 600000000000 },
];

const TREN_PERIODS = [
  { id: "harian", label: "Harian" },
  { id: "performance", label: "Performance" },
  { id: "quarter", label: "Quarter" },
  { id: "yoy", label: "YoY" },
  { id: "mom", label: "MoM" },
];

// Ketetapan Harian (BR-05 item 6) — 14 hari terakhir bulan berjalan.
// Target harian = target bulanan Rp 600 M dibagi 30 hari = Rp 20 M/hari.
const TARGET_HARIAN = 20000000000;
const trenHarianData = [
  { name: "21", nilai: 18400000000 },
  { name: "22", nilai: 22100000000 },
  { name: "23", nilai: 19800000000 },
  { name: "24", nilai: 24500000000 },
  { name: "25", nilai: 12300000000 },
  { name: "26", nilai: 9800000000 },
  { name: "27", nilai: 21700000000 },
  { name: "28", nilai: 23900000000 },
  { name: "29", nilai: 26400000000 },
  { name: "30", nilai: 20900000000 },
  { name: "31", nilai: 25800000000 },
  { name: "01", nilai: 17600000000 },
  { name: "02", nilai: 11200000000 },
  { name: "03", nilai: 28300000000 },
].map((row) => ({ ...row, target: TARGET_HARIAN }));

// Quarter aggregation (Q1-Q4) dari trenTargetRealisasiData — dipakai mode "Quarter".
const trenQuarterData = [
  { name: "Q1", nilai: 400000000000 + 450000000000 + 500000000000, target: 1800000000000 },
  { name: "Q2", nilai: 800000000000 + 900000000000 + 1100000000000, target: 1800000000000 },
  { name: "Q3", nilai: 1300000000000 + 1600000000000 + 1800000000000, target: 1800000000000 },
  { name: "Q4", nilai: 1900000000000 + 2400000000000 + 0, target: 1800000000000 },
];

// MoM growth (%) dari trenTargetRealisasiData — dipakai mode "MoM".
const trenMomData = trenTargetRealisasiData.slice(1).map((row, idx) => {
  const prev = trenTargetRealisasiData[idx].nilai;
  const growth = prev > 0 ? ((row.nilai - prev) / prev) * 100 : 0;
  return { name: row.name, growth: Number(growth.toFixed(1)) };
});

const formatRupiahCompact = (value: number) => {
  if (value >= 1e12) return `${(value / 1e12).toFixed(1)}T`;
  if (value >= 1e9) return `${(value / 1e9).toFixed(1)}M`;
  if (value >= 1e6) return `${(value / 1e6).toFixed(1)}Jt`;
  return value.toString();
};

// Mock Record Table for SKPD Penetapan
const mockPenetapanRecords = [
  {
    id: "SKP-2026-001",
    noSKPD: "SKPD/2026/PBB/008921",
    npwpd: "P.3.0041209.08.22",
    namaWajibPajak: "Gedung Plaza Malioboro Utama",
    sektor: "PBB-P2",
    jenisDokumen: "SKPD Jabatan",
    nilaiMasa: "Rp 1.450.000.000",
    tglPenetapan: "24 Jul 2026",
    jatuhTempo: "31 Agu 2026",
    status: "Ditetapkan",
    kecamatan: "Gondomanan",
  },
  {
    id: "SKP-2026-002",
    noSKPD: "SKPD/2026/PBJT/004312",
    npwpd: "P.2.0034821.04.12",
    namaWajibPajak: "PT Kuliner Rasa Jogja",
    sektor: "PBJT Makanan & Minuman",
    jenisDokumen: "SPTPD Self Assessment",
    nilaiMasa: "Rp 325.400.000",
    tglPenetapan: "22 Jul 2026",
    jatuhTempo: "15 Agu 2026",
    status: "Ditetapkan",
    kecamatan: "Danurejan",
  },
  {
    id: "SKP-2026-003",
    noSKPD: "SKPD/2026/BPHTB/001209",
    npwpd: "P.1.0019230.01.15",
    namaWajibPajak: "CV Ambarrukmo Hotel Branch",
    sektor: "BPHTB",
    jenisDokumen: "SKPDKB Kurang Bayar",
    nilaiMasa: "Rp 890.000.000",
    tglPenetapan: "20 Jul 2026",
    jatuhTempo: "20 Agu 2026",
    status: "Proses Verifikasi",
    kecamatan: "Gondokusuman",
  },
  {
    id: "SKP-2026-004",
    noSKPD: "SKPD/2026/PBJT/008819",
    npwpd: "P.2.0091204.05.18",
    namaWajibPajak: "Billboard Simpang Tugu Jogja",
    sektor: "Pajak Reklame",
    jenisDokumen: "SKPD Jabatan",
    nilaiMasa: "Rp 185.000.000",
    tglPenetapan: "18 Jul 2026",
    jatuhTempo: "18 Agu 2026",
    status: "Ditetapkan",
    kecamatan: "Jetis",
  },
  {
    id: "SKP-2026-005",
    noSKPD: "SKPD/2026/PAT/000412",
    npwpd: "P.5.0012941.02.10",
    namaWajibPajak: "Hotel Tentrem Spa & Pool",
    sektor: "Pajak Air Tanah",
    jenisDokumen: "SKPD Jabatan",
    nilaiMasa: "Rp 42.800.000",
    tglPenetapan: "15 Jul 2026",
    jatuhTempo: "15 Agu 2026",
    status: "Ditetapkan",
    kecamatan: "Jetis",
  },
];

// Realtime feed SKPD — pola sama seperti useRealtimeRows di halaman lain.
const SKP_NAMA_POOL = [
  "Toko Batik Pasar Beringharjo", "CV Souvenir Malioboro Jaya", "Warung Gudeg Bu Slamet",
  "PT Konveksi Kotagede Mandiri", "Rumah Kos Mahasiswa Seturan", "UD Perak Kotagede Asli",
];
const SKP_SEKTOR_POOL = ["PBB-P2", "PBJT Makanan & Minuman", "BPHTB", "Pajak Reklame", "Pajak Air Tanah"];
const SKP_JENIS_POOL = ["SKPD Jabatan", "SPTPD Self Assessment", "SKPDKB Kurang Bayar"];
const SKP_STATUS_POOL = ["Ditetapkan", "Proses Verifikasi"];
const SKP_KECAMATAN_POOL = ["Gondomanan", "Danurejan", "Gondokusuman", "Jetis"];

function generateNextPenetapanRecord(): typeof mockPenetapanRecords[0] {
  const now = new Date();
  const seq = `${now.getTime().toString().slice(-6)}${Math.floor(Math.random() * 900) + 100}`;
  const jatuhTempo = new Date(now.getTime() + 25 * 24 * 60 * 60 * 1000);
  return {
    id: `SKP-2026-${seq}`,
    noSKPD: `SKPD/2026/AUTO/${seq}`,
    npwpd: `P.${Math.floor(Math.random() * 4) + 1}.00${Math.floor(Math.random() * 90000) + 10000}.0${Math.floor(Math.random() * 9) + 1}.${Math.floor(Math.random() * 90) + 10}`,
    namaWajibPajak: SKP_NAMA_POOL[Math.floor(Math.random() * SKP_NAMA_POOL.length)],
    sektor: SKP_SEKTOR_POOL[Math.floor(Math.random() * SKP_SEKTOR_POOL.length)],
    jenisDokumen: SKP_JENIS_POOL[Math.floor(Math.random() * SKP_JENIS_POOL.length)],
    nilaiMasa: `Rp ${(Math.floor(Math.random() * 900) + 100).toLocaleString("id-ID")}.000.000`,
    tglPenetapan: now.toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" }),
    jatuhTempo: jatuhTempo.toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" }),
    status: SKP_STATUS_POOL[Math.floor(Math.random() * SKP_STATUS_POOL.length)],
    kecamatan: SKP_KECAMATAN_POOL[Math.floor(Math.random() * SKP_KECAMATAN_POOL.length)],
  };
}

export function AssessmentDashboardPage() {
  const { toast } = useToastApp();

  // Detail Modal Dialog State
  const [selectedRecord, setSelectedRecord] = React.useState<typeof mockPenetapanRecords[0] | null>(null);
  const [isDetailDialogOpen, setIsDetailDialogOpen] = React.useState(false);

  // Distribusi Nilai Pajak — toggle OFFICIAL/SELF, persis referensi ZIP.
  const [distMode, setDistMode] = React.useState<"official" | "self">("official");

  // Tren Target vs Realisasi — ChartToolbarApp periode, fungsional (bukan kosmetik)
  // mengikuti pola kartu "Analisis Pendapatan" TaxDashboardPage.
  const [trenPeriod, setTrenPeriod] = React.useState("performance");

  // Realtime feed tabel SKPD — baris baru masuk dari atas, di-highlight.
  const { rows: livePenetapanRecords, newRowIds: newPenetapanRecordIds } = useRealtimeRows({
    initialRows: mockPenetapanRecords,
    getId: (row) => row.id,
    generate: generateNextPenetapanRecord,
    intervalMs: 10500,
    maxRows: 20,
  });

  // Active Filter state
  const [filterValues, setFilterValues] = React.useState<Record<string, any>>({});

  const handleResetFilter = () => {
    setFilterValues({});
    toast.info("Filter Direset", {
      description: "Semua kriteria filter penetapan telah dikembalikan ke kondisi default.",
    });
  };

  const handleExportReport = () => {
    toast.success("Laporan Penetapan Diexport", {
      description: "Berkas PDF/XLSX Rekapitulasi SKPD & Nilai Ketetapan Pajak BR-05 berhasil diunduh.",
    });
  };

  const handleOpenDetailModal = (record: typeof mockPenetapanRecords[0]) => {
    setSelectedRecord(record);
    setIsDetailDialogOpen(true);
  };

  // Columns for DataTableApp
  const tableColumns = [
    {
      accessorKey: "noSKPD",
      header: "No. SKPD / Dokumen",
      cell: ({ row }: any) => (
        <div>
          <div className="font-mono text-xs font-bold text-vibrant-purple">
            {row.original.noSKPD}
          </div>
          <div className="text-[10px] text-ink-secondary">NPWPD: {row.original.npwpd}</div>
        </div>
      ),
    },
    {
      accessorKey: "namaWajibPajak",
      header: "Wajib Pajak / Subjek",
      cell: ({ row }: any) => (
        <div className="font-medium text-ink-primary text-xs">
          {row.original.namaWajibPajak}
        </div>
      ),
    },
    {
      accessorKey: "sektor",
      header: "Sektor Pajak",
      cell: ({ row }: any) => (
        <BadgeApp id={`badge-sektor-skp-${row.original.id}`} variant="solidAmber" size="sm">
          {row.original.sektor}
        </BadgeApp>
      ),
    },
    {
      accessorKey: "jenisDokumen",
      header: "Jenis SKP",
      cell: ({ row }: any) => (
        <span className="text-xs text-ink-secondary font-medium">
          {row.original.jenisDokumen}
        </span>
      ),
    },
    {
      accessorKey: "nilaiMasa",
      header: "Nilai Ketetapan",
      cell: ({ row }: any) => (
        <div className="font-mono font-bold text-xs text-emerald-700 dark:text-emerald-400">
          {row.original.nilaiMasa}
        </div>
      ),
    },
    {
      accessorKey: "tglPenetapan",
      header: "Tgl Penetapan",
      cell: ({ row }: any) => (
        <div className="text-xs font-mono text-ink-secondary">{row.original.tglPenetapan}</div>
      ),
    },
    {
      accessorKey: "status",
      header: "Status SKPD",
      cell: ({ row }: any) => {
        const val = row.original.status;
        let badgeVariant: any = "solidEmerald";
        if (val === "Ditetapkan") badgeVariant = "solidEmerald";
        if (val === "Proses Verifikasi") badgeVariant = "blue";

        return <BadgeApp id={`badge-status-skp-${row.original.id}`} variant={badgeVariant} size="sm">{val}</BadgeApp>;
      },
    },
    {
      id: "actions",
      header: "Aksi",
      cell: ({ row }: any) => (
        <ButtonApp
          id={`btn-detail-skp-${row.original.id}`}
          variant="purpleDark"
          theme="default"
          size="sm"
          rounded="pill"
          onClick={() => handleOpenDetailModal(row.original)}
          className="flex items-center gap-1 text-[11px] h-7 px-2.5"
        >
          <Eye className="w-3.5 h-3.5" />
          Detail
        </ButtonApp>
      ),
    },
  ];

  return (
    <div id="penetapan-dashboard-root" className="space-y-6 pb-12">
      {/* ------------------------------------------------------------- */}
      {/* HEADER PAGE                                                   */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col justify-between gap-4 border-b border-hairline-soft pb-4 md:flex-row md:items-center">
        <div>
          <div className="mb-1 flex flex-wrap items-center gap-x-3 gap-y-1.5">
            <BadgeApp id="hdr-badge-br05" variant="solidPurple" size="sm">
              BR-05 · Dashboard Penetapan
            </BadgeApp>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <FileText className="h-3.5 w-3.5 text-vibrant-purple" />
              SKPD & Ketetapan Pajak Daerah
            </span>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <Calendar className="h-3.5 w-3.5 text-vibrant-purple" />
              Tahun Anggaran 2026
            </span>
          </div>
          <TextApp id="hdr-title-penetapan" variant="h2" className="tracking-tight text-ink">
            Dashboard Penetapan Pajak Daerah
          </TextApp>
          <TextApp id="hdr-sub-penetapan" variant="body" className="text-xs text-ink-secondary">
            Monitoring Jumlah SKPD, Nilai Ketetapan, PBB-P2, PBJT, BPHTB, serta Ketetapan Harian & Bulanan
          </TextApp>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <ButtonApp
            id="btn-refresh-penetapan-data"
            variant="secondary"
            size="sm"
            rounded="lg"
            onClick={() =>
              toast.info("Data Penetapan Disinkronisasi", {
                description: "Database SKPD & Ketetapan Pajak Daerah telah diperbarui secara terpadu.",
              })
            }
            leftIcon={<RefreshCw className="h-3.5 w-3.5" />}
          >
            Refresh
          </ButtonApp>
          <ButtonApp
            id="btn-export-penetapan-report"
            variant="primary"
            size="sm"
            rounded="lg"
            leftIcon={<Download className="h-3.5 w-3.5" />}
            onClick={handleExportReport}
          >
            Cetak Laporan Penetapan
          </ButtonApp>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* FILTER BAR */}
      {/* ------------------------------------------------------------- */}
      <div className="flex w-full min-w-0 flex-nowrap items-center gap-2 overflow-x-auto rounded-2xl border border-hairline bg-surface px-3 py-3 shadow-xs">
        <span className="flex shrink-0 items-center gap-1.5 whitespace-nowrap text-xs font-semibold text-ink-secondary">
          <Filter className="h-4 w-4 text-vibrant-purple" />
          Filter:
        </span>

        {/* Shortcut inline utk field yang paling sering dipakai — nilainya
            dibagi dgn AdvanceFilterApp supaya tidak jadi kontrol kosmetik. */}
        <div className="w-52 shrink-0">
          <DropdownApp
            id="select-tahun-anggaran-penetapan"
            value={String(filterValues.tahunAnggaran ?? "2026")}
            onChange={(value) =>
              setFilterValues((prev) => ({ ...prev, tahunAnggaran: String(value) }))
            }
            options={[
              { label: "Tahun 2026 (Berjalan)", value: "2026" },
              { label: "Tahun 2025", value: "2025" },
              { label: "Tahun 2024", value: "2024" },
            ]}
            size="sm"
            rounded="lg"
            menuPortal
          />
        </div>

        <div className="ml-auto shrink-0">
          <AdvanceFilterApp
            id="filter-penetapan-skpd"
            displayMode="modal"
            showActivePills={false}
            className="w-auto"
            triggerLabel="Advance Filter Penetapan"
            triggerVariant="secondary"
            triggerSize="sm"
            triggerRounded="lg"
            title="Filter Penetapan SKPD & Sektor Pajak"
            fields={penetapanFilterFields}
            values={filterValues}
            onChange={setFilterValues}
            quickPresets={quickPresets}
            onReset={handleResetFilter}
            onApply={() => {
              toast.vibrant("Filter Penetapan Berhasil Diterapkan", {
                description: "Menampilkan data ketetapan berdasarkan kriteria yang dipilih.",
              });
            }}
          />
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* ALUR DOKUMEN (SANKEY) + DISTRIBUSI NILAI PAJAK (TREEMAP)       */}
      {/* Struktur mengikuti referensi ZIP PenetapanView.tsx persis.     */}
      {/* ------------------------------------------------------------- */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <div className="lg:col-span-5 flex flex-col">
          <CardApp
            id="card-alur-dokumen"
            className="p-5 border-hairline-soft flex-1 flex flex-col"
            insight={{
              title: "Alur Dokumen",
              value: "1,2 Juta Total Dokumen",
              status: "sehat",
              meta: ["Visualisasi", "Volume Transaksi", "TA 2026"],
              summary: "Alur Dokumen memvisualisasikan pembagian Total Dokumen penetapan menjadi tiga jenis surat ketetapan: SPPT (PBB), SKPD (Official Assessment), dan E-SPTPD (Self Assessment).",
              current: [
                "Total 1,2 juta dokumen terbagi: SPPT 850k (70,8%), E-SPTPD 230k (19,2%), SKPD 120k (10%).",
                "SPPT (PBB) mendominasi volume dokumen — konsisten dengan basis NOP PBB yang jauh lebih besar dari sektor lain.",
              ],
              insights: [
                "Dominasi SPPT menegaskan PBB sebagai kontributor volume terbesar meski nilainya perlu dibandingkan dengan Distribusi Nilai Pajak (volume tinggi tidak selalu berarti nilai tertinggi per dokumen).",
              ],
              tacticalRecs: [
                "Pantau kapasitas pencetakan/distribusi SPPT menjelang musim penagihan PBB tahunan.",
              ],
              strategicRecs: [
                "Evaluasi proporsi E-SPTPD terhadap SKPD dari waktu ke waktu sebagai indikator keberhasilan migrasi ke self-assessment.",
              ],
              dataNotes: ["Snapshot volume dokumen TA 2026."],
            }}
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <TextApp id="label-alur-eyebrow" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted">
                  Alur Dokumen
                </TextApp>
                <TextApp id="title-alur-dokumen" variant="h4" weight="bold" className="text-ink-primary mt-0.5">
                  Volume Transaksi
                </TextApp>
              </div>
              <Network className="w-5 h-5 text-ink-muted" />
            </div>

            <div className="flex-1 min-h-[220px] flex items-center">
              <SankeyDiagramApp id="sankey-alur-dokumen" nodes={alurDokumenNodes} links={alurDokumenLinks} height={240} className="w-full" />
            </div>
          </CardApp>
        </div>

        <div className="lg:col-span-7 flex flex-col">
          <CardApp
            id="card-distribusi-nilai-pajak"
            className="p-5 border-hairline-soft flex-1 flex flex-col"
            insight={{
              title: "Distribusi Nilai Pajak",
              value: distMode === "official" ? "PBB Rp 4,2T Tertinggi" : "BPHTB Rp 1,8T Tertinggi",
              status: "sehat",
              meta: ["Visualisasi", "Ketetapan (Rp)", "TA 2026"],
              summary: "Distribusi Nilai Pajak memetakan proporsi nilai ketetapan per sektor pajak — mode OFFICIAL (SKPD/SPPT dari jabatan) dan mode SELF (SPTPD self-assessment WP).",
              current: [
                "Mode OFFICIAL: PBB Rp 4,2T mendominasi, diikuti Opsen PKB Rp 2,5T dan O. BBNKB Rp 2,2T.",
                "Mode SELF: BPHTB Rp 1,8T tertinggi, diikuti PBJT Tenaga Listrik Rp 1,2T.",
              ],
              insights: [
                "PBB mendominasi baik dari sisi volume dokumen (Alur Dokumen) maupun nilai ketetapan (mosaic OFFICIAL) — kontributor utama basis pajak daerah.",
                "Di sisi SELF, BPHTB unggul nilai meski volume dokumennya (self-assessment) relatif rendah — nilai per transaksi BPHTB jauh lebih tinggi dari sektor PBJT lain.",
              ],
              tacticalRecs: [
                "Prioritaskan audit kepatuhan BPHTB mengingat nilai per transaksinya besar dan berbasis self-assessment (risiko under-reporting lebih tinggi).",
              ],
              strategicRecs: [
                "Gunakan mosaic OFFICIAL vs SELF untuk mengevaluasi sektor mana yang paling cocok didorong migrasi ke self-assessment.",
              ],
              dataNotes: ["Snapshot ketetapan TA 2026, satuan Rupiah."],
            }}
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <TextApp id="label-distribusi-eyebrow" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted">
                  Distribusi Nilai Pajak
                </TextApp>
                <TextApp id="title-distribusi-nilai" variant="h4" weight="bold" className="text-ink-primary mt-0.5">
                  Ketetapan (Rp)
                </TextApp>
              </div>
              <div className="flex items-center p-1 bg-surface-subtle rounded-lg border border-hairline-soft">
                <ButtonApp id="btn-dist-official" variant={distMode === "official" ? "white" : "ghost"} size="sm" rounded="md" onClick={() => setDistMode("official")}>
                  OFFICIAL
                </ButtonApp>
                <ButtonApp id="btn-dist-self" variant={distMode === "self" ? "white" : "ghost"} size="sm" rounded="md" onClick={() => setDistMode("self")}>
                  SELF
                </ButtonApp>
              </div>
            </div>

            <div className="flex-1 min-h-[220px]">
              <TreemapChartApp
                id={distMode === "official" ? "treemap-distribusi-official" : "treemap-distribusi-self"}
                data={distMode === "official" ? distribusiOfficialData : distribusiSelfData}
                height={240}
                className="h-full"
              />
            </div>
          </CardApp>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* OFFICIAL ASSESSMENT (COMBO) + SELF ASSESSMENT (BUBBLE)        */}
      {/* ------------------------------------------------------------- */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
        <div className="flex flex-col">
          <CardApp
            id="card-official-assessment"
            className="p-5 border-hairline-soft flex-1 flex flex-col"
            insight={{
              title: "Official Assessment",
              value: "PBB Volume 850k, Nilai Rp 4,2T",
              status: "sehat",
              meta: ["Visualisasi", "Volume vs Nilai", "TA 2026"],
              summary: "Official Assessment membandingkan volume dokumen (bar) dan nilai ketetapan (garis) per sektor yang ditetapkan secara jabatan (SKPD/SPPT).",
              current: [
                "PBB memimpin baik volume (850k) maupun nilai (Rp 4,2T) — sektor terbesar di kedua dimensi.",
                "O. PKB memiliki volume lebih rendah dari PBB namun nilai per dokumen relatif tinggi (Rp 2,5T dari 310k dokumen).",
              ],
              insights: [
                "PAT memiliki volume dan nilai terendah di antara 5 sektor official — kontribusinya terhadap total ketetapan official relatif kecil.",
              ],
              tacticalRecs: [
                "Pastikan kapasitas verifikasi cukup untuk menangani volume tinggi PBB tanpa menurunkan akurasi ketetapan.",
              ],
              strategicRecs: [
                "Evaluasi rasio nilai/volume tiap sektor untuk identifikasi sektor dengan potensi ekstensifikasi tertinggi.",
              ],
              dataNotes: ["Data TA 2026, volume dalam dokumen, nilai dalam Rupiah."],
            }}
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <TextApp id="label-official-eyebrow" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted">
                  Official Assessment
                </TextApp>
                <TextApp id="title-official-assessment" variant="h4" weight="bold" className="text-ink-primary mt-0.5">
                  Volume vs Nilai
                </TextApp>
              </div>
              <div className="flex items-center gap-3 text-xs font-medium">
                <div className="flex items-center gap-1.5">
                  <span className="h-2.5 w-2.5 rounded-sm bg-blue-300" />
                  <span className="text-ink-secondary">Volume</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="h-0.5 w-4 bg-emerald-700" />
                  <span className="text-ink-secondary">Nilai (Rp)</span>
                </div>
              </div>
            </div>

            <div className="flex-1 min-h-[260px] w-full">
              <ChartApp
                id="chart-official-assessment-combo"
                type="combo"
                data={officialAssessmentData}
                xKey="name"
                height="100%"
                valueFormatter={formatRupiahCompact}
                series={[
                  { key: "volume", label: "Volume", color: CHART_COLORS.blue, chartType: "bar", yAxisId: "left" },
                  { key: "nilai", label: "Nilai (Rp)", color: CHART_COLORS.emerald, chartType: "line", yAxisId: "right" },
                ]}
                showGrid
                showTooltip
                showLegend={false}
              />
            </div>
          </CardApp>
        </div>

        <div className="flex flex-col">
          <CardApp
            id="card-self-assessment"
            className="p-5 border-hairline-soft flex-1 flex flex-col"
            insight={{
              title: "Self Assessment (E-SPTPD)",
              value: "BPHTB Rp 36 Jt/Dokumen (Tertinggi)",
              status: "sehat",
              meta: ["Visualisasi", "Laporan vs Nilai", "TA 2026"],
              summary: "Self Assessment (E-SPTPD) membandingkan volume laporan mandiri WP terhadap nilai ketetapan, dengan ukuran gelembung mewakili rata-rata nilai per dokumen.",
              current: [
                "BPHTB memiliki rata-rata nilai per dokumen tertinggi (Rp 36 Jt) meski volume laporannya (50) paling rendah.",
                "PBJT Parkir memiliki volume laporan tertinggi (180) namun rata-rata nilai per dokumen terendah (Rp 0,8 Jt).",
              ],
              insights: [
                "Pola terbalik antara volume dan rata-rata nilai (BPHTB vs Parkir) mencerminkan karakteristik transaksi — BPHTB bernilai besar tapi jarang, Parkir bernilai kecil tapi sering.",
              ],
              tacticalRecs: [
                "Prioritaskan audit kepatuhan self-assessment BPHTB mengingat nilai per dokumennya besar (risiko under-reporting tinggi bernilai tinggi).",
              ],
              strategicRecs: [
                "Evaluasi ambang batas otomatisasi verifikasi E-SPTPD berdasarkan rata-rata nilai per sektor.",
              ],
              dataNotes: ["Ukuran gelembung = rata-rata nilai per dokumen (Rp Juta)."],
            }}
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <TextApp id="label-self-eyebrow" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted">
                  Self Assessment (E-SPTPD)
                </TextApp>
                <TextApp id="title-self-assessment" variant="h4" weight="bold" className="text-ink-primary mt-0.5">
                  Laporan vs Nilai
                </TextApp>
              </div>
              <TextApp id="label-avg-per-doc" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted">
                Avg Value / Doc
              </TextApp>
            </div>

            <div className="flex-1 min-h-[260px] w-full">
              <ChartApp
                id="chart-self-assessment-bubble"
                type="bubble"
                data={selfAssessmentData}
                scatterXKey="volume"
                scatterYKey="nilai"
                bubbleSizeKey="avg"
                xAxisLabel="Volume Dokumen"
                yAxisLabel="Nilai Ketetapan"
                height="100%"
                series={[{ key: "nilai", label: "Pajak", color: CHART_COLORS.purple }]}
                showGrid
                showTooltip
                showLegend={false}
              />
            </div>
          </CardApp>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* TREN TARGET VS REALISASI — ChartToolbarApp fungsional          */}
      {/* ------------------------------------------------------------- */}
      <CardApp
        id="card-tren-target-realisasi"
        className="p-5 border-hairline-soft"
        insight={{
          title: "Tren Target vs Realisasi",
          value: "Rp 2,4T Realisasi Nov (Tertinggi)",
          status: "sehat",
          meta: ["Visualisasi", "Kinerja Penetapan", "TA 2026"],
          summary: "Tren Target vs Realisasi memvisualisasikan kinerja bulanan penetapan pajak dibanding target tetap Rp 600M per bulan sepanjang TA 2026.",
          current: [
            "Realisasi melampaui target sejak April dan terus tumbuh hingga puncak Rp 2,4T di November.",
            "Desember belum terealisasi (data belum lengkap/periode berjalan).",
          ],
          insights: [
            "Tren pertumbuhan konsisten Jan-Nov menunjukkan momentum penetapan yang terus menguat sepanjang tahun, jauh melampaui target tetap.",
          ],
          tacticalRecs: [
            "Pantau penutupan Desember agar data penetapan bulan terakhir tahun anggaran tercatat lengkap.",
          ],
          strategicRecs: [
            "Evaluasi apakah target tetap Rp 600M/bulan masih relevan mengingat realisasi konsisten jauh melampaui angka tersebut sejak pertengahan tahun.",
          ],
          dataNotes: ["Gunakan toggle Performance/Quarter/YoY/MoM untuk cara baca berbeda atas data yang sama."],
        }}
      >
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-lg bg-surface-subtle border border-hairline-soft">
            <BarChart3 className="w-5 h-5 text-ink-secondary" />
          </div>
          <div>
            <TextApp id="title-tren-target-realisasi" variant="h3" weight="bold" className="text-ink-primary">
              Tren Target vs Realisasi
            </TextApp>
            <TextApp id="sub-tren-target-realisasi" variant="caption" className="text-ink-secondary">
              Visualisasi kinerja target dan realisasi penetapan pajak.
            </TextApp>
          </div>
        </div>

        <ChartToolbarApp
          id="toolbar-tren-target-realisasi"
          legend={[
            { label: "Target", value: "Rp 600 M/bulan", color: CHART_TARGET_COLOR },
            { label: "Realisasi", value: "Rp 2,4 T (Nov)", color: CHART_COLORS.emerald },
          ]}
          periods={TREN_PERIODS}
          selectedPeriod={trenPeriod}
          onPeriodChange={setTrenPeriod}
          className="mb-4 py-3 border-y border-hairline-soft"
        />

        <div className="h-[320px] w-full">
          {trenPeriod === "harian" && (
            <ChartApp
              id="chart-tren-harian"
              // Target harian = garis acuan (dashed), ketetapan = bar.
              // Keduanya Rupiah sehingga berbagi sumbu kiri.
              type="combo"
              data={trenHarianData}
              xKey="name"
              height="100%"
              valueFormatter={formatRupiahCompact}
              series={[
                { key: "nilai", label: "Ketetapan Harian", color: CHART_COLORS.emerald, chartType: "bar" },
                { key: "target", label: "Target Harian", color: CHART_TARGET_COLOR, chartType: "line", strokeDasharray: "5 4" },
              ]}
              showGrid
              showTooltip
              showLegend
            />
          )}

          {trenPeriod === "performance" && (
            <ChartApp
              id="chart-tren-performance"
              type="combo"
              data={trenTargetRealisasiData}
              xKey="name"
              height="100%"
              valueFormatter={formatRupiahCompact}
              series={[
                { key: "nilai", label: "Realisasi", color: CHART_COLORS.emerald, chartType: "bar" },
                { key: "target", label: "Target", color: CHART_TARGET_COLOR, chartType: "line", strokeDasharray: "5 4" },
              ]}
              showGrid
              showTooltip
              showLegend
            />
          )}
          {trenPeriod === "quarter" && (
            <ChartApp
              id="chart-tren-quarter"
              type="combo"
              data={trenQuarterData}
              xKey="name"
              height="100%"
              valueFormatter={formatRupiahCompact}
              series={[
                { key: "nilai", label: "Realisasi", color: CHART_COLORS.emerald, chartType: "bar" },
                { key: "target", label: "Target", color: CHART_TARGET_COLOR, chartType: "line", strokeDasharray: "5 4" },
              ]}
              showGrid
              showTooltip
              showLegend
            />
          )}
          {trenPeriod === "yoy" && (
            <ChartApp
              id="chart-tren-yoy"
              type="line"
              data={trenTargetRealisasiData}
              xKey="name"
              height="100%"
              valueFormatter={formatRupiahCompact}
              series={[
                { key: "target", label: "Target", color: CHART_TARGET_COLOR },
                { key: "nilai", label: "Realisasi 2026", color: CHART_COLORS.emerald },
              ]}
              showGrid
              showTooltip
              showLegend
            />
          )}
          {trenPeriod === "mom" && (
            <ChartApp
              id="chart-tren-mom"
              type="bar"
              data={trenMomData}
              xKey="name"
              height="100%"
              series={[{ key: "growth", label: "Growth MoM (%)", color: CHART_COLORS.emerald }]}
              showGrid
              showTooltip
              showLegend
            />
          )}
        </div>
      </CardApp>

      {/* ------------------------------------------------------------- */}
      {/* DATA TABLE REKAPITULASI PENETAPAN SKPD                        */}
      {/* ------------------------------------------------------------- */}
      <CardApp id="card-table-penetapan-records" className="p-5 border-hairline-soft">
        <DataTableApp
          id="datatable-penetapan-records"
          title="Daftar Ketetapan Pajak Daerah & Surat Ketetapan (SKPD)"
          description="Rekapitulasi Dokumen SKPD Jabatan, SPTPD Self Assessment, & SKPDKB Kurang Bayar"
          rightHeaderAction={
            <BadgeApp id="badge-tbl-recent-skp" variant="solidAmber" size="sm">Penetapan Terbaru</BadgeApp>
          }
          toolbarLayout="singleRow"
          data={livePenetapanRecords}
          newRowIds={newPenetapanRecordIds}
          getRowId={(row) => row.id}
          columns={tableColumns}
          searchPlaceholder="Cari No. SKPD, NPWPD, Wajib Pajak, atau Sektor..."
          pageSize={5}
        />
      </CardApp>

      {/* ------------------------------------------------------------- */}
      {/* DETAIL DIALOG MODAL (Portalled by DialogApp)                   */}
      {/* ------------------------------------------------------------- */}
      {selectedRecord && (
        <DialogApp
          id="dialog-detail-penetapan-skp"
          isOpen={isDetailDialogOpen}
          onClose={() => setIsDetailDialogOpen(false)}
          title={`Detail SKPD: ${selectedRecord.noSKPD}`}
          description="Rincian penetapan pajak daerah dan jadwal jatuh tempo pembayaran."
          size="lg"
        >
          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-3 p-3 bg-surface-subtle rounded-xl border border-hairline-soft">
              <div>
                <span className="text-ink-secondary block">No. SKPD Dokumen:</span>
                <span className="font-mono font-bold text-vibrant-purple">{selectedRecord.noSKPD}</span>
              </div>
              <div>
                <span className="text-ink-secondary block">Nama Wajib Pajak:</span>
                <span className="font-bold text-ink-primary">{selectedRecord.namaWajibPajak}</span>
              </div>
              <div>
                <span className="text-ink-secondary block">Sektor Pajak:</span>
                <BadgeApp id="badge-dlg-sektor-skp" variant="solidAmber" size="sm">{selectedRecord.sektor}</BadgeApp>
              </div>
              <div>
                <span className="text-ink-secondary block">Nilai Ketetapan:</span>
                <span className="font-mono font-bold text-emerald-700 dark:text-emerald-400">{selectedRecord.nilaiMasa}</span>
              </div>
            </div>

            <div className="p-3 border border-hairline-soft rounded-xl space-y-2">
              <div className="font-semibold text-ink-primary flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-vibrant-purple" />
                <span>Informasi Tanggal & Status Dokumen</span>
              </div>
              <p className="text-ink-secondary">
                Jenis Dokumen: <span className="text-ink-primary font-medium">{selectedRecord.jenisDokumen}</span>
              </p>
              <p className="text-ink-secondary">
                Tanggal Penetapan: <span className="text-ink-primary font-medium">{selectedRecord.tglPenetapan}</span> | Jatuh Tempo: <span className="text-rose-600 font-medium">{selectedRecord.jatuhTempo}</span>
              </p>
              <p className="text-ink-secondary">
                Status Dokumen: <BadgeApp id="badge-dlg-status-skp" variant="solidEmerald" size="sm">{selectedRecord.status}</BadgeApp>
              </p>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <ButtonApp
                id="btn-close-detail-penetapan-dialog"
                variant="purpleDark"
                theme="default"
                size="sm"
                rounded="pill"
                onClick={() => setIsDetailDialogOpen(false)}
              >
                Tutup Detail
              </ButtonApp>
            </div>
          </div>
        </DialogApp>
      )}
    </div>
  );
}

export default AssessmentDashboardPage;
