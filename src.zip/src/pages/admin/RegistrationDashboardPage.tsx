import * as React from "react";
import {
  ScorecardApp,
  CardApp,
  BadgeApp,
  ButtonApp,
  TextApp,
  AdvanceFilterApp,
  DataTableApp,
  ChartApp,
  SearchBarApp,
  DropdownApp,
  TabsApp,
  TabsListApp,
  TabsTriggerApp,
  useToastApp,
  useRealtimeValue,
  QuickPreset,
} from "@/packages/design-system";
import { cn } from "@/lib/utils";
import { UserPlus, Users, Map, BarChart3, RefreshCw, Download, Calendar, Filter } from "lucide-react";
import { CHART_COLORS } from "@/constants/chartColors";

// Filter Field Configuration for BR-04
const pendaftaranFilterFields = [
  {
    id: "sektorPajak",
    label: "Sektor Pajak",
    type: "select" as const,
    placeholder: "Pilih Sektor Pajak...",
    options: [
      { value: "all", label: "Semua Sektor Pajak" },
      { value: "pbb_p2", label: "PBB-P2 (Pedesaan & Perkotaan)" },
      { value: "bphtb", label: "BPHTB (Bea Perolehan Hak)" },
      { value: "pbjt_makanan", label: "PBJT Makanan & Minuman" },
      { value: "pbjt_hotel", label: "PBJT Jasa Perhotelan" },
      { value: "pbjt_hiburan", label: "PBJT Jasa Kesenian & Hiburan" },
      { value: "reklame", label: "Pajak Reklame" },
      { value: "air_tanah", label: "Pajak Air Tanah (PAT)" },
    ],
  },
  {
    id: "kecamatan",
    label: "Wilayah Kecamatan",
    type: "select" as const,
    placeholder: "Pilih Kecamatan...",
    options: [
      { value: "all", label: "Semua Kecamatan (14 Wilayah)" },
      { value: "gondomanan", label: "Kecamatan Gondomanan" },
      { value: "danurejan", label: "Kecamatan Danurejan" },
      { value: "kraton", label: "Kecamatan Kraton" },
      { value: "jetis", label: "Kecamatan Jetis" },
      { value: "umbulharjo", label: "Kecamatan Umbulharjo" },
      { value: "mantrijeron", label: "Kecamatan Mantrijeron" },
      { value: "kotagede", label: "Kecamatan Kotagede" },
      { value: "gondokusuman", label: "Kecamatan Gondokusuman" },
    ],
  },
  {
    id: "jenisPermohonan",
    label: "Jenis Pendaftaran / Permohonan",
    type: "select" as const,
    placeholder: "Pilih Jenis...",
    options: [
      { value: "all", label: "Semua Permohonan" },
      { value: "wp_baru", label: "Wajib Pajak (WP) Baru" },
      { value: "op_baru", label: "Objek Pajak (OP) Baru" },
      { value: "perubahan_data", label: "Perubahan Data / Mutasi" },
      { value: "penutupan_usaha", label: "Penutupan Usaha / Non-Aktif" },
    ],
  },
  {
    id: "statusAkun",
    label: "Status Akun / Permohonan",
    type: "select" as const,
    placeholder: "Semua Status...",
    options: [
      { value: "all", label: "Semua Status" },
      { value: "disetujui", label: "Disetujui / NPWPD Aktif" },
      { value: "dalam_proses", label: "Proses Verifikasi" },
      { value: "butuh_perbaikan", label: "Perbaikan Berkas" },
      { value: "ditolak", label: "Ditolak" },
    ],
  },
  {
    id: "tahunAnggaran",
    label: "Tahun Anggaran",
    type: "select" as const,
    placeholder: "Tahun...",
    options: [
      { value: "2026", label: "Tahun 2026 (Berjalan)" },
      { value: "2025", label: "Tahun 2025" },
      { value: "2024", label: "Tahun 2024" },
    ],
  },
];

const quickPresets: QuickPreset[] = [
  { label: "Semua Pendaftaran", values: { jenisPermohonan: "all", statusAkun: "all" } },
  { label: "WP Baru 2026", values: { jenisPermohonan: "wp_baru" } },
  { label: "OP Baru 2026", values: { jenisPermohonan: "op_baru" } },
  { label: "Perubahan Data", values: { jenisPermohonan: "perubahan_data" } },
  { label: "Penutupan Usaha", values: { jenisPermohonan: "penutupan_usaha" } },
];

// Data rekap bulanan WP & OP — struktur & nilai persis mengikuti referensi
// ZIP (PendaftaranView.tsx: `registrationData`). Bulan terakhir (Jun) dibuat
// live via useRealtimeValue di dalam komponen; bulan lain tetap statis
// sesuai referensi.
// `wpMutasi` / `opMutasi` = Perubahan Data (BR-04 item 3): ganti nama, alamat,
// klasifikasi, atau pecah/gabung NOP. Bukan penambahan/pengurangan basis, jadi
// tidak ikut diperhitungkan pada Net Pertumbuhan.
const REGISTRATION_MONTHLY_BASE = [
  { tahun: 2026, name: "Jan", wpEksisting: 135000, wpBaru: 120, wpTutup: 15, wpMutasi: 85, opEksisting: 420000, opBaru: 250, opTutup: 45, opMutasi: 160 },
  { tahun: 2026, name: "Feb", wpEksisting: 135105, wpBaru: 150, wpTutup: 20, wpMutasi: 92, opEksisting: 420205, opBaru: 280, opTutup: 50, opMutasi: 175 },
  { tahun: 2026, name: "Mar", wpEksisting: 135235, wpBaru: 180, wpTutup: 12, wpMutasi: 110, opEksisting: 420435, opBaru: 350, opTutup: 38, opMutasi: 210 },
  { tahun: 2026, name: "Apr", wpEksisting: 135403, wpBaru: 220, wpTutup: 25, wpMutasi: 128, opEksisting: 420747, opBaru: 420, opTutup: 60, opMutasi: 245 },
  { tahun: 2026, name: "Mei", wpEksisting: 135598, wpBaru: 250, wpTutup: 18, wpMutasi: 145, opEksisting: 421107, opBaru: 480, opTutup: 42, opMutasi: 280 },
  { tahun: 2026, name: "Jun", wpEksisting: 135830, wpBaru: 310, wpTutup: 30, wpMutasi: 168, opEksisting: 421545, opBaru: 550, opTutup: 75, opMutasi: 320 },
];

type RegistrationMonthlyRow = ReturnType<typeof buildMonthlyRow>;

function buildMonthlyRow(
  base: (typeof REGISTRATION_MONTHLY_BASE)[number],
  wpBaru: number,
  wpTutup: number,
  opBaru: number,
  opTutup: number
) {
  const netWp = wpBaru - wpTutup;
  const netOp = opBaru - opTutup;
  return {
    ...base,
    wpBaru,
    wpTutup,
    netWp,
    wpTotal: base.wpEksisting + netWp,
    opBaru,
    opTutup,
    netOp,
    opTotal: base.opEksisting + netOp,
  };
}

export function RegistrationDashboardPage() {
  const { toast } = useToastApp();

  // --- KPI kartu database WP & OP — semua running count, bukan target/config tetap.
  const liveTotalWp = useRealtimeValue({ initialValue: 142394, update: (v) => v + Math.floor(Math.random() * 3), intervalMs: 7000 });
  const liveWpAktif = useRealtimeValue({ initialValue: 135200, update: (v) => v + Math.floor(Math.random() * 3), intervalMs: 7500 });
  const liveWpNonaktif = useRealtimeValue({ initialValue: 7194, update: (v) => Math.max(6000, v + (Math.random() > 0.5 ? 1 : -1)), intervalMs: 11000 });
  const liveWpBaruYtd = useRealtimeValue({ initialValue: 1230, update: (v) => v + Math.floor(Math.random() * 2), intervalMs: 9500 });

  const liveTotalOp = useRealtimeValue({ initialValue: 450120, update: (v) => v + Math.floor(Math.random() * 4), intervalMs: 6500 });
  const liveOpAktif = useRealtimeValue({ initialValue: 425100, update: (v) => v + Math.floor(Math.random() * 4), intervalMs: 7200 });
  const liveOpNonaktif = useRealtimeValue({ initialValue: 25020, update: (v) => Math.max(20000, v + (Math.random() > 0.5 ? 1 : -1)), intervalMs: 10500 });
  const liveOpBaruYtd = useRealtimeValue({ initialValue: 2330, update: (v) => v + Math.floor(Math.random() * 3), intervalMs: 9000 });

  // --- Bulan berjalan (Jun) pada tabel & chart rekap bulanan — live tick.
  const liveJunWpBaru = useRealtimeValue({ initialValue: 310, update: (v) => v + Math.floor(Math.random() * 2), intervalMs: 9000 });
  const liveJunWpTutup = useRealtimeValue({ initialValue: 30, update: (v) => v + (Math.random() > 0.75 ? 1 : 0), intervalMs: 13000 });
  const liveJunOpBaru = useRealtimeValue({ initialValue: 550, update: (v) => v + Math.floor(Math.random() * 3), intervalMs: 8500 });
  const liveJunOpTutup = useRealtimeValue({ initialValue: 75, update: (v) => v + (Math.random() > 0.7 ? 1 : 0), intervalMs: 12000 });

  const registrationMonthlyData: RegistrationMonthlyRow[] = React.useMemo(() => {
    return REGISTRATION_MONTHLY_BASE.map((base, index) => {
      const isCurrentMonth = index === REGISTRATION_MONTHLY_BASE.length - 1;
      return buildMonthlyRow(
        base,
        isCurrentMonth ? liveJunWpBaru : base.wpBaru,
        isCurrentMonth ? liveJunWpTutup : base.wpTutup,
        isCurrentMonth ? liveJunOpBaru : base.opBaru,
        isCurrentMonth ? liveJunOpTutup : base.opTutup
      );
    });
  }, [liveJunWpBaru, liveJunWpTutup, liveJunOpBaru, liveJunOpTutup]);

  // --- Toggle chart "Pergerakan Pendaftaran": mode WP/OP + visibilitas seri.
  const [chartMode, setChartMode] = React.useState<"wp" | "op">("wp");
  const [visibleSeries, setVisibleSeries] = React.useState({ baru: true, nonaktif: true });
  const [pendaftaranChartSearch, setPendaftaranChartSearch] = React.useState("");
  const [pendaftaranChartJenisPajak, setPendaftaranChartJenisPajak] = React.useState("all");

  const chartSeries = React.useMemo(() => {
    const series: { key: string; label: string; color: string }[] = [];
    if (chartMode === "wp") {
      if (visibleSeries.baru) series.push({ key: "wpBaru", label: "WP Baru", color: CHART_COLORS.blue });
      if (visibleSeries.nonaktif) series.push({ key: "wpTutup", label: "WP Nonaktif", color: CHART_COLORS.amber });
    } else {
      if (visibleSeries.baru) series.push({ key: "opBaru", label: "OP Baru", color: CHART_COLORS.purple });
      if (visibleSeries.nonaktif) series.push({ key: "opTutup", label: "OP Nonaktif", color: CHART_COLORS.amber });
    }
    return series;
  }, [chartMode, visibleSeries]);

  // Active Filters state
  const [filterValues, setFilterValues] = React.useState<Record<string, any>>({});

  const handleResetFilter = () => {
    setFilterValues({});
    toast.info("Filter Direset", {
      description: "Semua kriteria filter pendaftaran telah dikembalikan ke kondisi default.",
    });
  };

  const handleExportReport = () => {
    toast.success("Laporan Pendaftaran Diexport", {
      description: "Berkas PDF/XLSX Rekapitulasi Registration & Growth Wajib Pajak BR-04 berhasil diunduh.",
    });
  };

  // Kolom tabel rekap bulanan OP — persis field referensi ZIP.
  const opTableColumns = [
    { accessorKey: "tahun", header: "Tahun" },
    { accessorKey: "name", header: "Bulan" },
    {
      accessorKey: "opEksisting",
      header: "OP Eksisting",
      cell: ({ row }: any) => <span className="text-ink-secondary">{row.original.opEksisting.toLocaleString("id-ID")}</span>,
    },
    {
      accessorKey: "opBaru",
      header: "OP Baru",
      cell: ({ row }: any) => <span className="text-ink-secondary">{row.original.opBaru.toLocaleString("id-ID")}</span>,
    },
    {
      accessorKey: "opTutup",
      header: "OP Tutup",
      cell: ({ row }: any) => <span className="text-ink-secondary">{row.original.opTutup.toLocaleString("id-ID")}</span>,
    },
    {
      accessorKey: "opMutasi",
      header: "Perubahan Data",
      cell: ({ row }: any) => <span className="text-ink-secondary">{row.original.opMutasi.toLocaleString("id-ID")}</span>,
    },
    {
      accessorKey: "netOp",
      header: "Net Pertumbuhan",
      cell: ({ row }: any) => (
        <span className="text-emerald-600 font-medium">+{row.original.netOp.toLocaleString("id-ID")}</span>
      ),
    },
    {
      accessorKey: "opTotal",
      header: "Total OP Terdaftar",
      cell: ({ row }: any) => <span className="font-bold text-ink-primary">{row.original.opTotal.toLocaleString("id-ID")}</span>,
    },
  ];

  // Kolom tabel rekap bulanan WP — persis field referensi ZIP.
  const wpTableColumns = [
    { accessorKey: "tahun", header: "Tahun" },
    { accessorKey: "name", header: "Bulan" },
    {
      accessorKey: "wpEksisting",
      header: "WP Eksisting",
      cell: ({ row }: any) => <span className="text-ink-secondary">{row.original.wpEksisting.toLocaleString("id-ID")}</span>,
    },
    {
      accessorKey: "wpBaru",
      header: "WP Baru",
      cell: ({ row }: any) => <span className="text-ink-secondary">{row.original.wpBaru.toLocaleString("id-ID")}</span>,
    },
    {
      accessorKey: "wpTutup",
      header: "WP Tutup",
      cell: ({ row }: any) => <span className="text-ink-secondary">{row.original.wpTutup.toLocaleString("id-ID")}</span>,
    },
    {
      accessorKey: "wpMutasi",
      header: "Perubahan Data",
      cell: ({ row }: any) => <span className="text-ink-secondary">{row.original.wpMutasi.toLocaleString("id-ID")}</span>,
    },
    {
      accessorKey: "netWp",
      header: "Net Pertumbuhan",
      cell: ({ row }: any) => (
        <span className="text-emerald-600 font-medium">+{row.original.netWp.toLocaleString("id-ID")}</span>
      ),
    },
    {
      accessorKey: "wpTotal",
      header: "Total WP Terdaftar",
      cell: ({ row }: any) => <span className="font-bold text-ink-primary">{row.original.wpTotal.toLocaleString("id-ID")}</span>,
    },
  ];

  return (
    <div id="pendaftaran-dashboard-root" className="space-y-6 pb-12">
      {/* ------------------------------------------------------------- */}
      {/* HEADER PAGE                                                   */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col justify-between gap-4 border-b border-hairline-soft pb-4 md:flex-row md:items-center">
        <div>
          <div className="mb-1 flex flex-wrap items-center gap-x-3 gap-y-1.5">
            <BadgeApp id="hdr-badge-br04" variant="solidPurple" size="sm">
              BR-04 · Dashboard Pendaftaran
            </BadgeApp>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <UserPlus className="h-3.5 w-3.5 text-vibrant-purple" />
              Wajib Pajak & Objek Pajak
            </span>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <Calendar className="h-3.5 w-3.5 text-vibrant-purple" />
              Tahun Anggaran 2026
            </span>
          </div>
          <TextApp id="hdr-title-pendaftaran" variant="h2" className="tracking-tight text-ink">
            Dashboard Pendaftaran Wajib Pajak & Objek Pajak
          </TextApp>
          <TextApp id="hdr-sub-pendaftaran" variant="body" className="text-xs text-ink-secondary">
            Monitoring Pertumbuhan Wajib Pajak (WP), Objek Pajak (OP), Mutasi Perubahan Data, & Status Keaktifan
          </TextApp>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <ButtonApp
            id="btn-refresh-pendaftaran-data"
            variant="secondary"
            size="sm"
            rounded="lg"
            onClick={() =>
              toast.info("Data Disinkronisasi", {
                description: "Database pendaftaran Wajib Pajak & Objek Pajak telah diperbarui secara live.",
              })
            }
            leftIcon={<RefreshCw className="h-3.5 w-3.5" />}
          >
            Refresh
          </ButtonApp>
          <ButtonApp
            id="btn-export-pendaftaran-report"
            variant="primary"
            size="sm"
            rounded="lg"
            leftIcon={<Download className="h-3.5 w-3.5" />}
            onClick={handleExportReport}
          >
            Cetak Laporan Pendaftaran
          </ButtonApp>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* FILTER BAR */}
      {/* ------------------------------------------------------------- */}
      <div className="flex w-full min-w-0 flex-nowrap items-center gap-2 overflow-x-auto rounded-2xl border border-hairline bg-surface px-3 py-3 shadow-xs">
        <span className="flex shrink-0 items-center gap-1.5 whitespace-nowrap text-xs font-semibold text-ink-secondary">
          <Filter className="h-4 w-4 text-vibrant-purple" />
          Filter:
        </span>

        {/* Shortcut inline utk field yang paling sering dipakai — nilainya
            dibagi dgn AdvanceFilterApp supaya tidak jadi kontrol kosmetik. */}
        <div className="w-52 shrink-0">
          <DropdownApp
            id="select-tahun-anggaran-pendaftaran"
            value={String(filterValues.tahunAnggaran ?? "2026")}
            onChange={(value) =>
              setFilterValues((prev) => ({ ...prev, tahunAnggaran: String(value) }))
            }
            options={[
              { label: "Tahun 2026 (Berjalan)", value: "2026" },
              { label: "Tahun 2025", value: "2025" },
              { label: "Tahun 2024", value: "2024" },
            ]}
            size="sm"
            rounded="lg"
            menuPortal
          />
        </div>

        <div className="ml-auto shrink-0">
          <AdvanceFilterApp
            id="filter-pendaftaran-wp-op"
            displayMode="modal"
            showActivePills={false}
            className="w-auto"
            triggerLabel="Advance Filter Pendaftaran"
            triggerVariant="secondary"
            triggerSize="sm"
            triggerRounded="lg"
            title="Filter Pendaftaran Wajib Pajak & Objek Pajak"
            fields={pendaftaranFilterFields}
            values={filterValues}
            onChange={setFilterValues}
            quickPresets={quickPresets}
            onReset={handleResetFilter}
            onApply={() => {
              toast.vibrant("Filter Pendaftaran Berhasil Diterapkan", {
                description: "Menampilkan data pendaftaran berdasarkan kriteria yang dipilih.",
              });
            }}
          />
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* KARTU DATABASE WP & OP + CHART PERGERAKAN PENDAFTARAN         */}
      {/* Struktur mengikuti referensi ZIP PendaftaranView.tsx persis:   */}
      {/* 2 kartu database (kiri) + 1 kartu chart toggle WP/OP (kanan). */}
      {/* ------------------------------------------------------------- */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
        <div className="lg:col-span-4 flex flex-col gap-4">
          <ScorecardApp
            id="card-total-wp"
            variant="purple"
            title="Total Database WP"
            value={liveTotalWp}
            live
            description="Wajib Pajak Terdaftar"
            icon={<Users className="w-5 h-5" />}
            infoTooltip="Total Wajib Pajak Daerah (WP) yang terdaftar di sistem SIMPAD Kota Yogyakarta."
            infoContent={{
              formula: "Total Wajib Pajak Daerah yang terdaftar di sistem SIMPAD, terdiri dari WP aktif, nonaktif, dan baru (YTD)",
              period: "Snapshot (real-time)",
              source: "SIMPAD — Modul Registrasi WP",
              lastUpdated: "Baru saja",
            }}
            className="flex-1"
            breakdown={[
              { id: "wp-aktif", label: "WP Aktif", value: liveWpAktif, percent: 95, color: CHART_COLORS.emerald },
              { id: "wp-nonaktif", label: "WP Nonaktif", value: liveWpNonaktif, percent: 5, color: CHART_COLORS.amber },
              { id: "wp-baru-ytd", label: "WP Baru (YTD)", value: liveWpBaruYtd, percent: 15, color: CHART_COLORS.blue },
            ]}
            insight={{
              title: "Analisis Wajib Pajak (WP)",
              value: "142.394 WP",
              status: "sehat",
              meta: ["Indikator", "Basis Data WP", "TA 2026"],
              summary: "Total Database WP mengukur seluruh Wajib Pajak Daerah yang terdaftar di sistem SIMPAD, terdiri dari WP berstatus aktif membayar, nonaktif/pasif sementara, dan WP baru yang terdaftar sepanjang tahun berjalan (YTD).",
              current: [
                "Total database 142.394 WP, dengan 135.200 (95%) berstatus aktif dan 7.194 (5%) nonaktif.",
                "WP Baru (YTD) mencapai 1.230, setara 15% dari basis WP aktif — indikasi akuisisi berjalan sehat.",
              ],
              insights: [
                "Rasio WP Aktif terhadap WP Nonaktif sekitar 18,8:1 — mayoritas basis WP tetap produktif membayar.",
                "Volume WP Baru YTD relatif proporsional terhadap total basis, tidak menunjukkan lonjakan/penurunan akuisisi yang tidak wajar.",
              ],
              tacticalRecs: [
                "Pantau WP nonaktif yang mendekati batas waktu agar segera direklasifikasi (aktif kembali atau penutupan resmi).",
                "Audit sampel WP Baru YTD untuk memastikan validitas alamat & legalitas usaha sebelum dianggap basis permanen.",
              ],
              strategicRecs: [
                "Bangun dashboard tren WP Aktif vs Nonaktif per kecamatan untuk deteksi dini wilayah dengan churn tinggi.",
                "Evaluasi kanal pendaftaran digital untuk mempercepat konversi WP Baru menjadi WP Aktif membayar penuh.",
              ],
              glossary: [
                { term: "NPWPD", expansion: "Nomor Pokok Wajib Pajak Daerah", definition: "identitas resmi Wajib Pajak dalam sistem administrasi pajak daerah." },
                { term: "YTD", expansion: "Year to Date", definition: "akumulasi nilai sejak awal tahun anggaran berjalan sampai hari ini." },
              ],
              dataNotes: ["Snapshot basis data live dari sistem SIMPAD, pembaruan real-time."],
            }}
          />

          <ScorecardApp
            id="card-total-op"
            variant="emerald"
            title="Total Database OP"
            value={liveTotalOp}
            live
            description="Objek Pajak Terdaftar"
            icon={<Map className="w-5 h-5" />}
            infoTooltip="Total Objek Pajak (OP) — tanah, bangunan, atau unit usaha — yang terdaftar dengan Nomor Objek Pajak (NOP)."
            infoContent={{
              formula: "Total Objek Pajak (tanah, bangunan, unit usaha) yang terdaftar dengan NOP",
              period: "Snapshot (real-time)",
              source: "SIMPAD — Modul Registrasi OP",
              lastUpdated: "Baru saja",
            }}
            className="flex-1"
            breakdown={[
              { id: "op-aktif", label: "OP Aktif", value: liveOpAktif, percent: 94, color: CHART_COLORS.emerald },
              { id: "op-nonaktif", label: "OP Nonaktif", value: liveOpNonaktif, percent: 6, color: CHART_COLORS.amber },
              { id: "op-baru-ytd", label: "OP Baru (YTD)", value: liveOpBaruYtd, percent: 18, color: CHART_COLORS.purple },
            ]}
            insight={{
              title: "Analisis Objek Pajak (OP)",
              value: "450.120 OP",
              status: "sehat",
              meta: ["Indikator", "Basis Data OP", "TA 2026"],
              summary: "Total Database OP mengukur seluruh Objek Pajak (tanah, bangunan, unit usaha) yang terdaftar dengan Nomor Objek Pajak (NOP), terdiri dari OP aktif, nonaktif, dan OP baru yang didaftarkan sepanjang tahun berjalan (YTD).",
              current: [
                "Total database 450.120 OP, dengan 425.100 (94%) berstatus aktif dan 25.020 (6%) nonaktif.",
                "OP Baru (YTD) mencapai 2.330, setara 18% dari basis OP aktif — rasio OP:WP baru sekitar 1,26.",
              ],
              insights: [
                "Pertumbuhan OP Baru yang lebih tinggi dari WP Baru mengindikasikan ekspansi multi-objek pada WP yang sudah terdaftar.",
                "Rasio OP Aktif terhadap OP Nonaktif sekitar 17:1 — basis OP tetap sehat dan mayoritas produktif.",
              ],
              tacticalRecs: [
                "Cross-check OP baru dengan WP terkait untuk memastikan tidak ada duplikasi NOP pada objek yang sama.",
                "Prioritaskan verifikasi lapangan untuk OP nonaktif bernilai ketetapan tinggi.",
              ],
              strategicRecs: [
                "Bangun laporan rasio OP:WP per kecamatan untuk mendeteksi wilayah dengan konsentrasi multi-objek tinggi.",
                "Evaluasi kapasitas tim survei lapangan menjelang musim puncak pendaftaran OP berikutnya.",
              ],
              glossary: [
                { term: "NOP", expansion: "Nomor Objek Pajak", definition: "identitas unik untuk setiap objek pajak (tanah/bangunan/unit usaha) dalam basis data pajak daerah." },
              ],
              dataNotes: ["Snapshot basis data live dari sistem SIMPAD, pembaruan real-time."],
            }}
          />
        </div>

        <div className="lg:col-span-8">
          <CardApp
            id="card-chart-pergerakan-pendaftaran"
            className="p-5 border-hairline-soft h-full flex flex-col"
            insight={{
              title: "Tren Registrasi",
              value: "Pergerakan Pendaftaran",
              status: "sehat",
              meta: ["Visualisasi", "Tren Bulanan", "TA 2026"],
              summary: "Pergerakan Pendaftaran memvisualisasikan tren bulanan pendaftaran Wajib Pajak (WP) dan Objek Pajak (OP) baru dibanding penutupan/nonaktifasi, untuk memantau laju akuisisi neto basis data pajak daerah.",
              current: [
                "Puncak registrasi WP & OP terjadi pada periode Mei–Jun (musim ramai usaha kuliner & wisata Kota Yogyakarta).",
                "Volume Baru secara konsisten jauh lebih besar dibanding Tutup/Nonaktif pada kedua mode (WP maupun OP).",
              ],
              insights: [
                "Pola musiman WP dan OP sejajar — keduanya didorong faktor musim usaha yang sama, bukan gejala yang independen.",
                "Laju pertumbuhan neto (Baru dikurangi Tutup) tetap positif di setiap bulan, menandakan basis data terus berkembang sehat.",
              ],
              tacticalRecs: [
                "Pantau kapasitas verifikasi berkas pada bulan puncak agar SLA registrasi tidak molor.",
                "Gunakan toggle WP/OP untuk membandingkan pola musiman kedua basis data secara cepat.",
              ],
              strategicRecs: [
                "Siapkan proyeksi kapasitas loket/verifikator untuk musim puncak pendaftaran tahun berikutnya berdasar pola historis ini.",
              ],
              dataNotes: ["Data rekap bulanan, kolom bulan berjalan diperbarui secara real-time."],
            }}
          >
            <div className="flex items-start justify-between gap-3 mb-3">
              <div className="flex items-center gap-3 min-w-0">
                <div className="p-2 rounded-lg bg-surface-subtle border border-hairline-soft shrink-0">
                  <BarChart3 className="w-5 h-5 text-ink-secondary" />
                </div>
                <div className="min-w-0">
                  <TextApp id="title-chart-pergerakan" variant="h4" weight="bold" className="text-ink-primary">
                    Pergerakan Pendaftaran
                  </TextApp>
                  <TextApp id="sub-chart-pergerakan" variant="caption" className="text-ink-secondary">
                    Visualisasi tren pendaftaran Wajib Pajak dan Objek Pajak baru vs penutupan.
                  </TextApp>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 pb-3 border-b border-hairline-soft mb-3">
              <div className="w-full sm:w-56">
                <SearchBarApp
                  id="search-chart-pergerakan"
                  size="sm"
                  rounded="lg"
                  placeholder="Cari bulan..."
                  value={pendaftaranChartSearch}
                  onSearchChange={setPendaftaranChartSearch}
                />
              </div>
              <div className="w-full sm:w-56">
                <DropdownApp
                  id="select-jenis-pajak-pergerakan"
                  size="sm"
                  rounded="lg"
                  value={pendaftaranChartJenisPajak}
                  onChange={(value) => setPendaftaranChartJenisPajak(String(value))}
                  options={[
                    { value: "all", label: "Semua Jenis Pajak" },
                    { value: "pbb", label: "PBB-P2" },
                    { value: "pbjt", label: "PBJT" },
                    { value: "bphtb", label: "BPHTB" },
                  ]}
                />
              </div>
            </div>

            <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-3 py-3 border-b border-hairline-soft mb-4">
              <div className="flex items-center gap-5">
                <button
                  id="toggle-legend-baru"
                  type="button"
                  onClick={() => setVisibleSeries((prev) => ({ ...prev, baru: !prev.baru }))}
                  className={cn("flex items-center gap-2 transition-opacity cursor-pointer", visibleSeries.baru ? "opacity-100" : "opacity-40")}
                >
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: chartMode === "wp" ? CHART_COLORS.blue : CHART_COLORS.purple }} />
                  <span className="text-xs font-semibold text-ink-secondary">Baru</span>
                </button>
                <button
                  id="toggle-legend-nonaktif"
                  type="button"
                  onClick={() => setVisibleSeries((prev) => ({ ...prev, nonaktif: !prev.nonaktif }))}
                  className={cn("flex items-center gap-2 transition-opacity cursor-pointer", visibleSeries.nonaktif ? "opacity-100" : "opacity-40")}
                >
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: CHART_COLORS.amber }} />
                  <span className="text-xs font-semibold text-ink-secondary">Nonaktif</span>
                </button>
              </div>

              <TabsApp id="tabs-chart-mode" value={chartMode} onValueChange={(v) => setChartMode(v as "wp" | "op")} className="w-fit shrink-0">
                <TabsListApp id="tabs-chart-mode-list" variant="pills" size="sm" rounded="full" fitContent>
                  <TabsTriggerApp id="tab-chart-mode-wp" value="wp" variant="pills" rounded="full" size="sm">Wajib Pajak (WP)</TabsTriggerApp>
                  <TabsTriggerApp id="tab-chart-mode-op" value="op" variant="pills" rounded="full" size="sm">Objek Pajak (OP)</TabsTriggerApp>
                </TabsListApp>
              </TabsApp>
            </div>

            <div className="flex-1 min-h-[320px] w-full">
              <ChartApp
                id="chart-pergerakan-pendaftaran"
                type="bar"
                height="100%"
                data={registrationMonthlyData}
                xKey="name"
                series={chartSeries}
                showGrid
                showTooltip
                showLegend={false}
              />
            </div>
          </CardApp>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* TABEL REKAP PENDAFTARAN OP — struktur & kolom sesuai referensi */}
      {/* ------------------------------------------------------------- */}
      <CardApp id="card-table-pendaftaran-op" className="p-5 border-hairline-soft">
        <DataTableApp
          id="datatable-pendaftaran-op"
          title="Data Pendaftaran Objek Pajak (OP)"
          description="Rekapitulasi jumlah OP baru per bulan berdasarkan realisasi pendaftaran"
          toolbarLayout="singleRow"
          data={registrationMonthlyData}
          getRowId={(row) => `${row.tahun}-${row.name}-op`}
          columns={opTableColumns}
          searchPlaceholder="Filter bulan..."
          enableRowSelection={false}
          pageSize={10}
        />
      </CardApp>

      {/* ------------------------------------------------------------- */}
      {/* TABEL REKAP PENDAFTARAN WP — struktur & kolom sesuai referensi */}
      {/* ------------------------------------------------------------- */}
      <CardApp id="card-table-pendaftaran-wp" className="p-5 border-hairline-soft">
        <DataTableApp
          id="datatable-pendaftaran-wp"
          title="Data Pendaftaran Wajib Pajak (WP)"
          description="Rekapitulasi jumlah WP baru per bulan berdasarkan realisasi pendaftaran"
          toolbarLayout="singleRow"
          data={registrationMonthlyData}
          getRowId={(row) => `${row.tahun}-${row.name}-wp`}
          columns={wpTableColumns}
          searchPlaceholder="Filter bulan..."
          enableRowSelection={false}
          pageSize={10}
        />
      </CardApp>
    </div>
  );
}

export default RegistrationDashboardPage;
