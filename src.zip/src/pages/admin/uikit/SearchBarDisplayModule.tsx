import * as React from "react";
import {
  SearchBarApp,
  ButtonApp,
  InputApp,
  SearchBarVariant,
  SearchBarSize,
  SearchBarRounded,
  SearchBarBgColor,
} from "@/packages/design-system";
import { Search, Code, Check } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid, ShowcaseGroup } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

const VARIANTS: SearchBarVariant[] = ["standard", "withFilter", "expandable"];
const SIZES: SearchBarSize[] = ["sm", "md", "lg"];
const ROUNDED: SearchBarRounded[] = ["none", "sm", "md", "lg", "pill"];
const BG_COLORS: SearchBarBgColor[] = ["surface", "transparent", "elevated"];

export function SearchBarDisplayModule() {
  // Playground state
  const [playQuery, setPlayQuery] = React.useState("Wajib Pajak PBB 2026");
  const [playVariant, setPlayVariant] = React.useState<SearchBarVariant>("standard");
  const [playSize, setPlaySize] = React.useState<SearchBarSize>("md");
  const [playRounded, setPlayRounded] = React.useState<SearchBarRounded>("pill");
  const [playBgColor, setPlayBgColor] = React.useState<SearchBarBgColor>("surface");
  const [playPlaceholder, setPlayPlaceholder] = React.useState("Cari NOP, nama WP, atau alamat...");
  const [playShowClear, setPlayShowClear] = React.useState(true);
  const [playShowFilter, setPlayShowFilter] = React.useState(false);
  const [playFilterActive, setPlayFilterActive] = React.useState(false);
  const [playFilterCount] = React.useState(2);
  const [playDisabled, setPlayDisabled] = React.useState(false);
  const [playErrorState, setPlayErrorState] = React.useState(false);
  const [playErrorMsg, setPlayErrorMsg] = React.useState("NOP tidak ditemukan dalam sistem BPKAD.");
  const [playShortcut, setPlayShortcut] = React.useState("Ctrl+K");
  const [playExpanded, setPlayExpanded] = React.useState(false);

  const [copied, setCopied] = React.useState(false);

  // Demo state for standalone showcases
  const [stdQuery, setStdQuery] = React.useState("02.34.567.890");
  const [filterQuery, setFilterQuery] = React.useState("Kecamatan Gondomanan");
  const [activeFiltersCount, setActiveFiltersCount] = React.useState(3);
  const [expQuery, setExpQuery] = React.useState("");
  const [expState, setExpState] = React.useState(false);

  // Generate code snippet string
  const variantStr = playVariant !== "standard" ? `\n  variant="${playVariant}"` : "";
  const sizeStr = playSize !== "md" ? `\n  size="${playSize}"` : "";
  const roundedStr = playRounded !== "pill" ? `\n  rounded="${playRounded}"` : "";
  const bgStr = playBgColor !== "surface" ? `\n  bgColor="${playBgColor}"` : "";
  const placeholderStr = playPlaceholder !== "Cari data..." ? `\n  placeholder="${playPlaceholder}"` : "";
  const clearStr = !playShowClear ? `\n  showClear={false}` : "";
  const filterStr = playShowFilter ? `\n  showFilter` : "";
  const filterActStr = playFilterActive ? `\n  filterActive={${playFilterCount}}` : "";
  const disabledStr = playDisabled ? `\n  disabled` : "";
  const errorStr = playErrorState ? `\n  error="${playErrorMsg}"` : "";
  const shortcutStr = playShortcut.trim() ? `\n  shortcutKey="${playShortcut}"` : "";

  const codeSnippet = `<SearchBarApp
  id="tax-search-input"
  value={searchQuery}
  onSearchChange={(val) => setSearchQuery(val)}
  onSearch={(query) => console.log('Executing search for:', query)}${variantStr}${sizeStr}${roundedStr}${bgStr}${placeholderStr}${clearStr}${filterStr}${filterActStr}${shortcutStr}${errorStr}${disabledStr}
/>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-searchbar-module"
      icon={<Search className="w-5 h-5 text-vibrant-purple-dark" />}
      title="SearchBarApp"
      description="Bilah pencarian cepat responsif dengan varian Standard, With Filter, dan Expandable — dilengkapi ikon pencarian, tombol pembersih otomatis, indikator jumlah filter aktif, dukungan status, variasi background & border, serta preset corner radius."
    >
      <ShowcaseGroup id="searchbar-group-variant" title="Variant" description="standard · withFilter · expandable" cols={1}>
        <ShowcaseCard
          id="searchbar-showcase-variant-standard"
          title="Variant standard"
          description="Bilah pencarian polos dengan shortcut key hint"
          align="start"
          code={`<SearchBarApp id="sb" variant="standard" shortcutKey="Ctrl+K" />`}
        >
          <SearchBarApp id="searchbar-showcase-variant-standard-demo" variant="standard" value={stdQuery} onSearchChange={setStdQuery} placeholder="Cari NOP / Wajib Pajak..." shortcutKey="Ctrl+K" />
        </ShowcaseCard>

        <ShowcaseCard
          id="searchbar-showcase-variant-with-filter"
          title="Variant withFilter"
          description="Tombol filter dengan indikator jumlah aktif"
          align="start"
          code={`<SearchBarApp id="sb" variant="withFilter" filterActive={3} onFilterClick={...} />`}
        >
          <SearchBarApp
            id="searchbar-showcase-variant-with-filter-demo"
            variant="withFilter"
            value={filterQuery}
            onSearchChange={setFilterQuery}
            placeholder="Cari wilayah objek..."
            filterActive={activeFiltersCount}
            filterLabel="Filter"
            onFilterClick={() => setActiveFiltersCount((prev) => (prev > 0 ? 0 : 3))}
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="searchbar-showcase-variant-expandable"
          title="Variant expandable"
          description="Ikon yang melebar jadi bilah penuh saat diklik"
          align="start"
          code={`<SearchBarApp id="sb" variant="expandable" expanded={open} onExpandedChange={setOpen} />`}
        >
          <div className="flex items-center justify-end">
            <SearchBarApp id="searchbar-showcase-variant-expandable-demo" variant="expandable" expanded={expState} onExpandedChange={setExpState} value={expQuery} onSearchChange={setExpQuery} placeholder="Cari cepat..." />
          </div>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="searchbar-group-state" title="Component State" description="default · focused · disabled · error" cols={1}>
        <ShowcaseCard
          id="searchbar-showcase-state-default"
          title="State default"
          description="Belum diisi, hanya placeholder"
          align="start"
          code={`<SearchBarApp id="sb" placeholder="..." helperText="..." />`}
        >
          <SearchBarApp id="searchbar-showcase-state-default-demo" placeholder="Ketik kueri pencarian..." helperText="Gunakan kata kunci NOP, nama wajib pajak, atau kelurahan." />
        </ShowcaseCard>

        <ShowcaseCard
          id="searchbar-showcase-state-focused"
          title="State focused"
          description="Terisi nilai, ring aksen ungu vibrant aktif"
          align="start"
          code={`<SearchBarApp id="sb" defaultValue="..." autoFocus />`}
        >
          <SearchBarApp id="searchbar-showcase-state-focused-demo" defaultValue="34.71.010.002.015" helperText="Aksen ring berwarna ungu vibrant aktif saat kursor di dalam area." />
        </ShowcaseCard>

        <ShowcaseCard
          id="searchbar-showcase-state-disabled"
          title="State disabled"
          description="Terkunci, tidak menerima input"
          align="start"
          code={`<SearchBarApp id="sb" disabled defaultValue="..." />`}
        >
          <SearchBarApp id="searchbar-showcase-state-disabled-demo" disabled defaultValue="Pencarian Terkunci" helperText="Pencarian dinonaktifkan sementara oleh sistem administrasi." />
        </ShowcaseCard>

        <ShowcaseCard
          id="searchbar-showcase-state-error"
          title="State error"
          description="Validasi gagal, disertai pesan error"
          align="start"
          code={`<SearchBarApp id="sb" defaultValue="..." error="..." />`}
        >
          <SearchBarApp id="searchbar-showcase-state-error-demo" defaultValue="99.99.999" error="Format NOP tidak valid (harus 18 digit angka standar BPKAD)." />
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="searchbar-group-bg" title="Background Style" description="surface (default) · transparent · elevated" cols={1}>
        <ShowcaseCard
          id="searchbar-showcase-bg-surface"
          title="Background surface"
          description="Latar putih hairline — default katalog"
          align="start"
          code={`<SearchBarApp id="sb" bgColor="surface" />`}
        >
          <SearchBarApp id="searchbar-showcase-bg-surface-demo" bgColor="surface" placeholder="Latar surface..." />
        </ShowcaseCard>

        <ShowcaseCard
          id="searchbar-showcase-bg-transparent"
          title="Background transparent"
          description="Latar transparan, menyatu dengan container"
          align="start"
          code={`<SearchBarApp id="sb" bgColor="transparent" />`}
        >
          <SearchBarApp id="searchbar-showcase-bg-transparent-demo" bgColor="transparent" placeholder="Latar transparent..." />
        </ShowcaseCard>

        <ShowcaseCard
          id="searchbar-showcase-bg-elevated"
          title="Background elevated"
          description="Latar dengan bayangan terangkat"
          align="start"
          code={`<SearchBarApp id="sb" bgColor="elevated" />`}
        >
          <SearchBarApp id="searchbar-showcase-bg-elevated-demo" bgColor="elevated" placeholder="Latar elevated..." />
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="searchbar-group-size" title="Ukuran" description="sm 34px · md 42px (default) · lg 50px" cols={3}>
        <ShowcaseCard
          id="searchbar-showcase-size-sm"
          title="Ukuran sm"
          description="Tinggi 34px"
          align="start"
          code={`<SearchBarApp id="sb" size="sm" />`}
        >
          <SearchBarApp id="searchbar-showcase-size-sm-demo" size="sm" placeholder="Ukuran sm (34px)..." />
        </ShowcaseCard>

        <ShowcaseCard
          id="searchbar-showcase-size-md"
          title="Ukuran md"
          description="Tinggi 42px"
          align="start"
          code={`<SearchBarApp id="sb" size="md" />`}
        >
          <SearchBarApp id="searchbar-showcase-size-md-demo" size="md" placeholder="Ukuran md (42px)..." />
        </ShowcaseCard>

        <ShowcaseCard
          id="searchbar-showcase-size-lg"
          title="Ukuran lg"
          description="Tinggi 50px"
          align="start"
          code={`<SearchBarApp id="sb" size="lg" />`}
        >
          <SearchBarApp id="searchbar-showcase-size-lg-demo" size="lg" placeholder="Ukuran lg (50px)..." />
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="searchbar-group-rounded" title="Corner Radius" description="sm · full — Foundation" cols={2}>
        <ShowcaseCard
          id="searchbar-showcase-rounded-sm"
          title="Rounded sm"
          description="Radius kecil"
          align="start"
          code={`<SearchBarApp id="sb" rounded="sm" />`}
        >
          <SearchBarApp id="searchbar-showcase-rounded-sm-demo" rounded="sm" placeholder="Sudut kecil..." />
        </ShowcaseCard>

        <ShowcaseCard
          id="searchbar-showcase-rounded-full"
          title="Rounded full"
          description="Pill penuh"
          align="start"
          code={`<SearchBarApp id="sb" rounded="full" />`}
        >
          <SearchBarApp id="searchbar-showcase-rounded-full-demo" rounded="full" placeholder="Sudut pill..." />
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGrid cols={1}>
        <ShowcaseCard
          id="searchbar-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap SearchBarApp dengan kode JSX yang dihasilkan"
          align="start"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            <div className="flex flex-col gap-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Input Value</span>
                  <InputApp id="sb-play-val" size="sm" rounded="lg" value={playQuery} onChange={(e) => setPlayQuery(e.target.value)} placeholder="Nilai kueri pencarian..." />
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Placeholder</span>
                  <InputApp id="sb-play-ph" size="sm" rounded="lg" value={playPlaceholder} onChange={(e) => setPlayPlaceholder(e.target.value)} placeholder="Placeholder pencarian..." />
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Variant</span>
                <div className="flex gap-1.5">
                  {VARIANTS.map((v) => (
                    <PlaygroundChip key={v} id={`sb-play-var-${v}`} active={playVariant === v} onClick={() => setPlayVariant(v)} className="flex-1">
                      {v}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Size</span>
                  <div className="flex gap-1">
                    {SIZES.map((s) => (
                      <PlaygroundChip key={s} id={`sb-play-size-${s}`} active={playSize === s} onClick={() => setPlaySize(s)} className="flex-1">
                        {s}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Corner Radius</span>
                  <div className="flex flex-wrap gap-1">
                    {ROUNDED.map((r) => (
                      <PlaygroundChip key={r} id={`sb-play-rad-${r}`} active={playRounded === r} onClick={() => setPlayRounded(r)}>
                        {r}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Background Style</span>
                <div className="flex gap-1.5">
                  {BG_COLORS.map((b) => (
                    <PlaygroundChip key={b} id={`sb-play-bg-${b}`} active={playBgColor === b} onClick={() => setPlayBgColor(b)} className="flex-1">
                      {b}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Shortcut Key Label</span>
                <InputApp id="sb-play-sc" size="sm" rounded="lg" value={playShortcut} onChange={(e) => setPlayShortcut(e.target.value)} placeholder="cth: Ctrl+K, ⌘K, Alt+S" />
              </div>

              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Clear 'X'</span>
                  <PlaygroundChip id="sb-play-clear-toggle" active={playShowClear} onClick={() => setPlayShowClear((v) => !v)}>
                    {playShowClear ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Filter Button</span>
                  <PlaygroundChip id="sb-play-filter-toggle" active={playShowFilter} onClick={() => setPlayShowFilter((v) => !v)}>
                    {playShowFilter ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Filter Active</span>
                  <PlaygroundChip id="sb-play-filteract-toggle" active={playFilterActive} onClick={() => setPlayFilterActive((v) => !v)}>
                    {playFilterActive ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Disabled</span>
                  <PlaygroundChip id="sb-play-disabled-toggle" active={playDisabled} onClick={() => setPlayDisabled((v) => !v)}>
                    {playDisabled ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Error State</span>
                <PlaygroundChip id="sb-play-error-toggle" active={playErrorState} onClick={() => setPlayErrorState((v) => !v)}>
                  {playErrorState ? "ON" : "OFF"}
                </PlaygroundChip>
                {playErrorState && (
                  <div className="mt-2">
                    <InputApp id="sb-play-errmsg" size="sm" rounded="lg" value={playErrorMsg} onChange={(e) => setPlayErrorMsg(e.target.value)} placeholder="Pesan error..." />
                  </div>
                )}
              </div>
            </div>

            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex flex-col items-center justify-center gap-3 rounded-lg border border-dashed border-hairline bg-surface p-4">
                  <SearchBarApp
                    id="playground-interactive-searchbar"
                    value={playQuery}
                    onSearchChange={setPlayQuery}
                    variant={playVariant}
                    size={playSize}
                    rounded={playRounded}
                    bgColor={playBgColor}
                    placeholder={playPlaceholder}
                    showClear={playShowClear}
                    showFilter={playShowFilter}
                    filterActive={playFilterActive ? playFilterCount : false}
                    filterLabel={playShowFilter || playVariant === "withFilter" ? "Filter" : undefined}
                    onFilterClick={() => setPlayFilterActive(!playFilterActive)}
                    shortcutKey={playShortcut || undefined}
                    disabled={playDisabled}
                    error={playErrorState ? playErrorMsg : undefined}
                    expanded={playExpanded}
                    onExpandedChange={setPlayExpanded}
                  />
                  <div className="flex w-full items-center justify-between rounded-lg bg-surface-soft p-3 font-mono text-xs text-ink-secondary">
                    <span>
                      Query Text: <strong className="text-vibrant-purple-dark">{playQuery || "(Kosong)"}</strong>
                    </span>
                    <ButtonApp id="sb-play-reset" variant="ghost" size="sm" onClick={() => setPlayQuery("")} className="h-6 min-h-6 px-2 text-[10px]">
                      Reset Text
                    </ButtonApp>
                  </div>
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="sb-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeSnippet}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
