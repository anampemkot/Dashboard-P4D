import * as React from "react";
import {
  TooltipApp,
  ButtonApp,
  DropdownApp,
  InputApp,
  CheckboxApp,
  BadgeApp,
  TooltipPosition,
  TooltipTheme,
  TooltipMaxWidth,
} from "@/packages/design-system";
import {
  HelpCircle,
  Code,
  Check,
  Info,
  ExternalLink,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  MousePointer,
  MessageCircle,
} from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid, ShowcaseGroup } from "./shared/ShowcaseCard";

export function TooltipDisplayModule() {
  // Playground state
  const [playTitle, setPlayTitle] = React.useState("Petunjuk Pajak PBB-P2");
  const [playContent, setPlayContent] = React.useState("Pembayaran pajak tepat waktu menghindari denda 2% per bulan.");
  const [playHasLink, setPlayHasLink] = React.useState(true);
  const [playLinkLabel, setPlayLinkLabel] = React.useState("Lihat Regulasi Lengkap");
  const [playPosition, setPlayPosition] = React.useState<TooltipPosition>("top");
  const [playTheme, setPlayTheme] = React.useState<TooltipTheme>("dark");
  const [playShowArrow, setPlayShowArrow] = React.useState(true);
  const [playDelayMs, setPlayDelayMs] = React.useState(150);
  const [playTrigger, setPlayTrigger] = React.useState<"hover" | "click">("hover");
  const [playMaxWidth, setPlayMaxWidth] = React.useState<TooltipMaxWidth>("sm");
  const [copied, setCopied] = React.useState(false);

  const titlePropStr = playTitle.trim() ? `\n  title="${playTitle}"` : "";
  const linkPropStr = playHasLink && playLinkLabel.trim()
    ? `\n  link={{ label: "${playLinkLabel}", href: "https://pajak.go.id" }}`
    : "";
  const arrowPropStr = !playShowArrow ? `\n  showArrow={false}` : "";
  const delayPropStr = playDelayMs !== 150 ? `\n  delayMs={${playDelayMs}}` : "";
  const triggerPropStr = playTrigger !== "hover" ? `\n  trigger="${playTrigger}"` : "";
  const maxWidthPropStr = playMaxWidth !== "sm" ? `\n  maxWidth="${playMaxWidth}"` : "";

  const codeSnippet = `<TooltipApp
  id="my-tooltip"
  content="${playContent}"${titlePropStr}${linkPropStr}
  position="${playPosition}"
  theme="${playTheme}"${arrowPropStr}${delayPropStr}${triggerPropStr}${maxWidthPropStr}
>
  <ButtonApp id="trigger-btn" variant="vibrantPurple">
    Hover Me
  </ButtonApp>
</TooltipApp>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-tooltip-module"
      icon={<MessageCircle className="w-5 h-5 text-vibrant-purple-dark" />}
      title="TooltipApp"
      description="Pop-up info kontekstual ringkas saat user hover atau klik elemen. Mendukung text only, title, action link, 8 posisi, theme warna, arrow indicator, hover delay, trigger, dan max width — P4D BPKAD Kota Yogyakarta."
    >
      {/*
        Setiap kartu lama mencampur beberapa prop TooltipApp sekaligus.
        Dipecah per axis; forceOpen dipertahankan supaya tooltip terlihat
        statis di katalog tanpa perlu hover.
      */}
      <ShowcaseGroup id="tooltip-group-content" title="Content" description="Text only · dengan title · dengan action link" cols={3}>
        <ShowcaseCard
          id="tooltip-showcase-content-text-only"
          title="Content text only"
          description="Isi tanpa judul, bentuk paling ringkas"
          code={`<TooltipApp id="t" content="NOP terdiri dari 18 digit." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-content-text-only-demo" content="NOP (Nomor Objek Pajak) terdiri dari 18 digit angka unik." position="top" theme="dark" forceOpen><ButtonApp id="btn-tooltip-content-text-only" variant="outline" size="sm" leftIcon={<HelpCircle className="w-3.5 h-3.5 text-ink-muted" />}>Hover NOP Info</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-content-title"
          title="Content dengan title"
          description="Header terpisah di atas isi"
          code={`<TooltipApp id="t" title="Jatuh Tempo" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-content-title-demo" title="Masa Jatuh Tempo" content="Jatuh tempo penetapan SPPT PBB-P2 adalah 31 Agustus 2026." position="top" theme="dark" forceOpen><ButtonApp id="btn-tooltip-content-title" variant="vibrantPurple" size="sm" leftIcon={<Info className="w-3.5 h-3.5" />}>Hover Jatuh Tempo</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-content-link"
          title="Content dengan action link"
          description="Tautan aksi di footer tooltip"
          code={`<TooltipApp id="t" title="Bebas Denda" content="..." link={{ label: "Syarat", href: "#" }} forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-content-link-demo" title="Bebas Denda Pajak" content="Program pemutihan denda berlaku hingga akhir bulan ini." link={{ label: "Pelajari Syarat & Ketentuan", href: "#" }} position="top" theme="dark" forceOpen><ButtonApp id="btn-tooltip-content-link" variant="primary" size="sm" leftIcon={<ExternalLink className="w-3.5 h-3.5" />}>Hover Syarat Pemutihan</ButtonApp></TooltipApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="tooltip-group-position" title="Position" description="top · bottom · left · right · top-start · top-end · bottom-start · bottom-end — semua forceOpen agar terlihat statis" cols={4}>
        <ShowcaseCard
          id="tooltip-showcase-position-top"
          title="Position top"
          description="Atas, rata tengah"
          code={`<TooltipApp id="t" position="top" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-position-top-demo" position="top" content="Posisi top" forceOpen><ButtonApp id="btn-tooltip-position-top" variant="outline" size="sm">top</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-position-bottom"
          title="Position bottom"
          description="Bawah, rata tengah"
          code={`<TooltipApp id="t" position="bottom" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-position-bottom-demo" position="bottom" content="Posisi bottom" forceOpen><ButtonApp id="btn-tooltip-position-bottom" variant="outline" size="sm">bottom</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-position-left"
          title="Position left"
          description="Kiri, rata tengah"
          code={`<TooltipApp id="t" position="left" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-position-left-demo" position="left" content="Posisi left" forceOpen><ButtonApp id="btn-tooltip-position-left" variant="outline" size="sm">left</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-position-right"
          title="Position right"
          description="Kanan, rata tengah"
          code={`<TooltipApp id="t" position="right" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-position-right-demo" position="right" content="Posisi right" forceOpen><ButtonApp id="btn-tooltip-position-right" variant="outline" size="sm">right</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-position-top-start"
          title="Position top-start"
          description="Atas, rata mulai (kiri)"
          code={`<TooltipApp id="t" position="top-start" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-position-top-start-demo" position="top-start" content="Posisi top-start" forceOpen><ButtonApp id="btn-tooltip-position-top-start" variant="outline" size="sm">top-start</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-position-top-end"
          title="Position top-end"
          description="Atas, rata akhir (kanan)"
          code={`<TooltipApp id="t" position="top-end" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-position-top-end-demo" position="top-end" content="Posisi top-end" forceOpen><ButtonApp id="btn-tooltip-position-top-end" variant="outline" size="sm">top-end</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-position-bottom-start"
          title="Position bottom-start"
          description="Bawah, rata mulai (kiri)"
          code={`<TooltipApp id="t" position="bottom-start" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-position-bottom-start-demo" position="bottom-start" content="Posisi bottom-start" forceOpen><ButtonApp id="btn-tooltip-position-bottom-start" variant="outline" size="sm">bottom-start</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-position-bottom-end"
          title="Position bottom-end"
          description="Bawah, rata akhir (kanan)"
          code={`<TooltipApp id="t" position="bottom-end" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-position-bottom-end-demo" position="bottom-end" content="Posisi bottom-end" forceOpen><ButtonApp id="btn-tooltip-position-bottom-end" variant="outline" size="sm">bottom-end</ButtonApp></TooltipApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="tooltip-group-theme" title="Theme" description="dark (default) · light · vibrant · brand · info · success · warning · error" cols={4}>
        <ShowcaseCard
          id="tooltip-showcase-theme-dark"
          title="Theme dark"
          description="Kombinasi klasik gelap kontras tinggi — default katalog"
          code={`<TooltipApp id="t" theme="dark" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-theme-dark-demo" theme="dark" title="Dark Theme" content="Contoh isi tooltip theme dark." position="top" forceOpen><ButtonApp id="btn-tooltip-theme-dark" variant="outline" size="sm">dark</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-theme-light"
          title="Theme light"
          description="Kartu terang dengan border hairline"
          code={`<TooltipApp id="t" theme="light" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-theme-light-demo" theme="light" title="Light Theme" content="Contoh isi tooltip theme light." position="top" forceOpen><ButtonApp id="btn-tooltip-theme-light" variant="outline" size="sm">light</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-theme-vibrant"
          title="Theme vibrant"
          description="Aksen warna ungu vibrant menonjol"
          code={`<TooltipApp id="t" theme="vibrant" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-theme-vibrant-demo" theme="vibrant" title="Vibrant Theme" content="Contoh isi tooltip theme vibrant." position="top" forceOpen><ButtonApp id="btn-tooltip-theme-vibrant" variant="outline" size="sm">vibrant</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-theme-brand"
          title="Theme brand"
          description="Aksen warna ungu brand"
          code={`<TooltipApp id="t" theme="brand" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-theme-brand-demo" theme="brand" title="Brand Theme" content="Contoh isi tooltip theme brand." position="top" forceOpen><ButtonApp id="btn-tooltip-theme-brand" variant="outline" size="sm">brand</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-theme-info"
          title="Theme info"
          description="Status petunjuk informasi umum"
          code={`<TooltipApp id="t" theme="info" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-theme-info-demo" theme="info" title="Info Theme" content="Contoh isi tooltip theme info." position="top" forceOpen><ButtonApp id="btn-tooltip-theme-info" variant="outline" size="sm">info</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-theme-success"
          title="Theme success"
          description="Petunjuk status sukses / terverifikasi"
          code={`<TooltipApp id="t" theme="success" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-theme-success-demo" theme="success" title="Success Theme" content="Contoh isi tooltip theme success." position="top" forceOpen><ButtonApp id="btn-tooltip-theme-success" variant="outline" size="sm">success</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-theme-warning"
          title="Theme warning"
          description="Petunjuk status perlu perhatian"
          code={`<TooltipApp id="t" theme="warning" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-theme-warning-demo" theme="warning" title="Warning Theme" content="Contoh isi tooltip theme warning." position="top" forceOpen><ButtonApp id="btn-tooltip-theme-warning" variant="outline" size="sm">warning</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-theme-error"
          title="Theme error"
          description="Indikasi kesalahan atau tunggakan"
          code={`<TooltipApp id="t" theme="error" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-theme-error-demo" theme="error" title="Error Theme" content="Contoh isi tooltip theme error." position="top" forceOpen><ButtonApp id="btn-tooltip-theme-error" variant="outline" size="sm">error</ButtonApp></TooltipApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      {/*
        "Delay, Trigger & Arrow" mencampur 3 prop tak berkaitan dalam satu
        kartu. Dibongkar jadi tiga grup sesuai prop aslinya.
      */}
      <ShowcaseGroup id="tooltip-group-delay" title="Delay" description="delayMs: 0ms (instan) · 150ms (default) · 300ms · 500ms" cols={4}>
        <ShowcaseCard
          id="tooltip-showcase-delay-0"
          title="Delay 0ms"
          description="Tampil seketika tanpa jeda"
          code={`<TooltipApp id="t" delayMs={0} content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-delay-0-demo" delayMs={0} content="Delay 0ms" forceOpen><ButtonApp id="btn-tooltip-delay-0" variant="outline" size="sm">0ms</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-delay-150"
          title="Delay 150ms"
          description="Jeda standar katalog"
          code={`<TooltipApp id="t" delayMs={150} content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-delay-150-demo" delayMs={150} content="Delay 150ms" forceOpen><ButtonApp id="btn-tooltip-delay-150" variant="outline" size="sm">150ms</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-delay-300"
          title="Delay 300ms"
          description="Jeda sedang"
          code={`<TooltipApp id="t" delayMs={300} content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-delay-300-demo" delayMs={300} content="Delay 300ms" forceOpen><ButtonApp id="btn-tooltip-delay-300" variant="outline" size="sm">300ms</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-delay-500"
          title="Delay 500ms"
          description="Jeda paling lambat"
          code={`<TooltipApp id="t" delayMs={500} content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-delay-500-demo" delayMs={500} content="Delay 500ms" forceOpen><ButtonApp id="btn-tooltip-delay-500" variant="outline" size="sm">500ms</ButtonApp></TooltipApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="tooltip-group-trigger" title="Trigger" description="hover (default) · click" cols={2}>
        <ShowcaseCard
          id="tooltip-showcase-trigger-hover"
          title="Trigger hover"
          description="Tampil saat pointer hover di atas elemen"
          code={`<TooltipApp id="t" trigger="hover" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-trigger-hover-demo" trigger="hover" content="Tampil saat mouse hover" forceOpen><ButtonApp id="btn-tooltip-trigger-hover" variant="vibrantPurple" size="sm">Hover Trigger</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-trigger-click"
          title="Trigger click"
          description="Tampil/tutup lewat klik, tidak bergantung hover"
          code={`<TooltipApp id="t" trigger="click" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-trigger-click-demo" trigger="click" title="Klik Aktif" content="Klik kembali untuk menutup tooltip ini." forceOpen><ButtonApp id="btn-tooltip-trigger-click" variant="primary" size="sm">Click Trigger</ButtonApp></TooltipApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="tooltip-group-arrow" title="Arrow Indicator" description="showArrow: true (default) · false" cols={2}>
        <ShowcaseCard
          id="tooltip-showcase-arrow-true"
          title="showArrow true"
          description="Panah penunjuk arah ke elemen trigger"
          code={`<TooltipApp id="t" showArrow content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-arrow-true-demo" showArrow content="Dengan panah indicator" forceOpen><ButtonApp id="btn-tooltip-arrow-true" variant="outline" size="sm">With Arrow</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-arrow-false"
          title="showArrow false"
          description="Kotak mengambang bersih tanpa panah"
          code={`<TooltipApp id="t" showArrow={false} content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-arrow-false-demo" showArrow={false} content="Tanpa panah indicator (Clean Floating Box)" forceOpen><ButtonApp id="btn-tooltip-arrow-false" variant="outline" size="sm">No Arrow</ButtonApp></TooltipApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="tooltip-group-maxwidth" title="Max Width" description="xs 160px · sm 220px · md 280px (default) · lg 360px" cols={3}>
        <ShowcaseCard
          id="tooltip-showcase-maxwidth-xs"
          title="Max Width xs"
          description="Lebar paling sempit, teks membungkus rapat"
          code={`<TooltipApp id="t" maxWidth="xs" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-maxwidth-xs-demo" maxWidth="xs" title="Lebar XS" content="Teks panjang otomatis dibungkus menjadi beberapa baris rapat." position="top" forceOpen><ButtonApp id="btn-tooltip-maxwidth-xs" variant="outline" size="sm">Max Width XS</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-maxwidth-md"
          title="Max Width md"
          description="Lebar standar katalog"
          code={`<TooltipApp id="t" maxWidth="md" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-maxwidth-md-demo" maxWidth="md" title="Lebar MD" content="Teks panjang otomatis dibungkus menjadi beberapa baris rapat." position="top" forceOpen><ButtonApp id="btn-tooltip-maxwidth-md" variant="outline" size="sm">Max Width MD</ButtonApp></TooltipApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tooltip-showcase-maxwidth-lg"
          title="Max Width lg"
          description="Lebar luas untuk rincian panjang"
          code={`<TooltipApp id="t" maxWidth="lg" content="..." forceOpen>...</TooltipApp>`}
        >
          <TooltipApp id="tooltip-showcase-maxwidth-lg-demo" maxWidth="lg" title="Lebar LG" content="Teks panjang otomatis dibungkus menjadi beberapa baris rapat." position="top" forceOpen><ButtonApp id="btn-tooltip-maxwidth-lg" variant="outline" size="sm">Max Width LG</ButtonApp></TooltipApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGrid cols={1}>
        {/* Playground — span penuh */}
        <ShowcaseCard
          id="tooltip-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap TooltipApp dengan kode JSX yang dihasilkan"
          align="start"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            {/* Controls */}
            <div className="flex flex-col gap-4">
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Title / Header</span>
                <InputApp id="tt-play-title" value={playTitle} onChange={(e) => setPlayTitle(e.target.value)} placeholder="Judul Tooltip..." />
              </div>
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Content Body Text</span>
                <InputApp id="tt-play-content" value={playContent} onChange={(e) => setPlayContent(e.target.value)} placeholder="Isi Teks Tooltip..." />
              </div>

              <div className="rounded-lg border border-hairline-soft bg-surface-soft/60 p-3 space-y-2">
                <CheckboxApp id="tt-play-haslink" checked={playHasLink} onChange={(e) => setPlayHasLink(e.target.checked)} label="Sertakan Action Link / Tombol" />
                {playHasLink && (
                  <InputApp id="tt-play-linklabel" value={playLinkLabel} onChange={(e) => setPlayLinkLabel(e.target.value)} placeholder="Label Teks Link..." />
                )}
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Position</span>
                  <DropdownApp
                    id="tt-play-pos"
                    value={playPosition}
                    onChange={(value) => setPlayPosition(value as TooltipPosition)}
                    options={[
                      { value: "top", label: "Top" },
                      { value: "top-start", label: "Top-Start" },
                      { value: "top-end", label: "Top-End" },
                      { value: "bottom", label: "Bottom" },
                      { value: "bottom-start", label: "Bottom-Start" },
                      { value: "bottom-end", label: "Bottom-End" },
                      { value: "left", label: "Left" },
                      { value: "right", label: "Right" },
                    ]}
                  />
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Theme Color</span>
                  <DropdownApp
                    id="tt-play-theme"
                    value={playTheme}
                    onChange={(value) => setPlayTheme(value as TooltipTheme)}
                    options={[
                      { value: "dark", label: "Dark (Slate)" },
                      { value: "light", label: "Light Surface" },
                      { value: "vibrant", label: "Vibrant Purple" },
                      { value: "brand", label: "Brand Purple" },
                      { value: "info", label: "Info Sky" },
                      { value: "success", label: "Success Green" },
                      { value: "warning", label: "Warning Amber" },
                      { value: "error", label: "Error Red" },
                    ]}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Delay (ms)</span>
                  <DropdownApp
                    id="tt-play-delay"
                    value={String(playDelayMs)}
                    onChange={(value) => setPlayDelayMs(Number(value))}
                    options={[
                      { value: "0", label: "0ms" },
                      { value: "150", label: "150ms" },
                      { value: "300", label: "300ms" },
                      { value: "500", label: "500ms" },
                    ]}
                  />
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Trigger</span>
                  <DropdownApp
                    id="tt-play-trig"
                    value={playTrigger}
                    onChange={(value) => setPlayTrigger(value as "hover" | "click")}
                    options={[
                      { value: "hover", label: "Hover" },
                      { value: "click", label: "Click" },
                    ]}
                  />
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Max Width</span>
                  <DropdownApp
                    id="tt-play-mw"
                    value={String(playMaxWidth)}
                    onChange={(value) => setPlayMaxWidth(value as TooltipMaxWidth)}
                    options={[
                      { value: "xs", label: "XS (160px)" },
                      { value: "sm", label: "SM (220px)" },
                      { value: "md", label: "MD (280px)" },
                      { value: "lg", label: "LG (360px)" },
                    ]}
                  />
                </div>
              </div>

              <CheckboxApp id="tt-play-arrow" checked={playShowArrow} onChange={(e) => setPlayShowArrow(e.target.checked)} label="Tampilkan Panah Indicator (Arrow)" />
            </div>

            {/* Live Output & Code */}
            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[160px] items-center justify-center rounded-lg border border-dashed border-hairline bg-surface p-4">
                  <TooltipApp
                    id="playground-interactive-tt"
                    title={playTitle || undefined}
                    content={playContent}
                    link={playHasLink && playLinkLabel.trim() ? { label: playLinkLabel, href: "https://pajak.go.id" } : undefined}
                    position={playPosition}
                    theme={playTheme}
                    showArrow={playShowArrow}
                    delayMs={playDelayMs}
                    trigger={playTrigger}
                    maxWidth={playMaxWidth}
                  >
                    <ButtonApp id="btn-play-trigger" variant="vibrantPurple" size="md" leftIcon={<MousePointer className="w-4 h-4" />}>
                      {playTrigger === "click" ? "Klik Me!" : "Hover Me!"}
                    </ButtonApp>
                  </TooltipApp>
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="copy-tt-code"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeSnippet}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
