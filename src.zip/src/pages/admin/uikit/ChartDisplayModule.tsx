import * as React from "react";
import {
  ChartApp,
  CHART_PALETTES,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
  ChartConfig,
  ChartToolbarApp,
  type ChartToolbarYearOption,
} from "@/packages/design-system";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  RadialBarChart,
  RadialBar,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";
import { BarChart3 } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid } from "./shared/ShowcaseCard";

// ==========================================
// MOCK DATA & DESIGN SYSTEM PALETTE CONFIGS
// ==========================================

// 1. Area Chart (Realisasi vs Target)
const revenueData = [
  { month: "Jan", target: 450, realisasi: 420 },
  { month: "Feb", target: 480, realisasi: 490 },
  { month: "Mar", target: 510, realisasi: 530 },
  { month: "Apr", target: 540, realisasi: 510 },
  { month: "Mei", target: 580, realisasi: 620 },
  { month: "Jun", target: 620, realisasi: 650 },
  { month: "Jul", target: 680, realisasi: 710 },
];

const revenueSeries = [
  { key: "target", label: "Target Anggaran", color: CHART_PALETTES.vibrant.p2, fillOpacity: 0.15 },
  { key: "realisasi", label: "Realisasi Penerimaan", color: CHART_PALETTES.vibrant.p1, fillOpacity: 0.25 },
];

// 2. Bar Chart (Kepatuhan per Wilayah)
const complianceData = [
  { region: "Yogyakarta", hotel: 92, resto: 88, hiburan: 75 },
  { region: "Sleman", hotel: 88, resto: 82, hiburan: 80 },
  { region: "Bantul", hotel: 85, resto: 80, hiburan: 70 },
  { region: "Kulon Progo", hotel: 78, resto: 75, hiburan: 65 },
  { region: "Gunungkidul", hotel: 82, resto: 78, hiburan: 60 },
];

const complianceSeries = [
  { key: "hotel", label: "Pajak Hotel (%)", color: CHART_PALETTES.vibrant.p1 },
  { key: "resto", label: "Pajak Restoran (%)", color: CHART_PALETTES.vibrant.p2 },
  { key: "hiburan", label: "Pajak Hiburan (%)", color: CHART_PALETTES.vibrant.p3 },
];

// 3. Line Chart (Proyeksi Denda Pajak)
const dendaProjectionData = [
  { month: "Jan", proyeksi: 120, realita: 110 },
  { month: "Feb", proyeksi: 140, realita: 150 },
  { month: "Mar", proyeksi: 180, realita: 175 },
  { month: "Apr", proyeksi: 160, realita: 165 },
  { month: "Mei", proyeksi: 210, realita: 220 },
  { month: "Jun", proyeksi: 250, realita: 240 },
  { month: "Jul", proyeksi: 280, realita: 295 },
];

const lineSeries = [
  { key: "proyeksi", label: "Proyeksi Tren", color: CHART_PALETTES.vibrant.p3 },
  { key: "realita", label: "Realisasi Aktual", color: CHART_PALETTES.vibrant.p4, strokeDasharray: "4 4" },
];

// 4. Pie Chart (Distribusi Pajak)
const taxContributionData = [
  { name: "Pajak Hotel", value: 350, fill: CHART_PALETTES.vibrant.p1 },
  { name: "Pajak Restoran", value: 280, fill: CHART_PALETTES.vibrant.p2 },
  { name: "Pajak Hiburan", value: 180, fill: CHART_PALETTES.vibrant.p3 },
  { name: "Pajak Parkir", value: 120, fill: CHART_PALETTES.vibrant.p4 },
  { name: "Pajak Reklame", value: 90, fill: CHART_PALETTES.vibrant.p5 },
];

// 5. Radar Chart (Kepatuhan Multi-Sektoral)
const complianceSectorsData = [
  { sector: "Pelaporan SPTD", sleman: 85, yogyakarta: 92, bantul: 78 },
  { sector: "Akurasi Nominal", sleman: 90, yogyakarta: 88, bantul: 82 },
  { sector: "Ketepatan Waktu", sleman: 75, yogyakarta: 85, bantul: 80 },
  { sector: "E-Billing Adopsi", sleman: 95, yogyakarta: 90, bantul: 75 },
  { sector: "Respon Audit", sleman: 80, yogyakarta: 94, bantul: 70 },
];

const radarSeries = [
  { key: "yogyakarta", label: "Kota Yogyakarta", color: CHART_PALETTES.vibrant.p1 },
  { key: "sleman", label: "Kab. Sleman", color: CHART_PALETTES.vibrant.p2 },
];

// 6. Radial Chart (Pencapaian Target Sektoral)
const radialProgressData = [
  { name: "hotel", value: 85, fill: CHART_PALETTES.vibrant.p1 },
  { name: "resto", value: 70, fill: CHART_PALETTES.vibrant.p2 },
  { name: "hiburan", value: 55, fill: CHART_PALETTES.vibrant.p3 },
];

// 6b. Scatter kuadran — dua garis acuan membagi bidang jadi 4 zona prioritas.
const quadrantData = [
  { name: "Umbulharjo", kepadatan: 95, potensi: 85, fill: CHART_PALETTES.vibrant.p3 },
  { name: "Kotagede", kepadatan: 80, potensi: 70, fill: CHART_PALETTES.vibrant.p3 },
  { name: "Malioboro", kepadatan: 60, potensi: 35, fill: CHART_PALETTES.vibrant.p2 },
  { name: "Jetis", kepadatan: 45, potensi: 55, fill: CHART_PALETTES.vibrant.p2 },
  { name: "Mantrijeron", kepadatan: 30, potensi: 40, fill: CHART_PALETTES.vibrant.p2 },
];

const referenceLineCode = `// 6b. Scatter + garis acuan pembagi kuadran
<ChartApp
  type="scatter"
  data={quadrantData}
  scatterXKey="kepadatan"
  scatterYKey="potensi"
  referenceLines={[
    { axis: "x", value: 60, label: "Ambang kepadatan" },
    { axis: "y", value: 60, label: "Ambang potensi" },
  ]}
/>`;

// 7. Toolbar Chart (multi-year comparison + period switcher + date range)
const toolbarYearOptions: ChartToolbarYearOption[] = [
  { value: "y2022", label: "2022", color: CHART_PALETTES.vibrant.p6 },
  { value: "y2023", label: "2023", color: CHART_PALETTES.vibrant.p2 },
  { value: "y2024", label: "2024", color: CHART_PALETTES.vibrant.p1 },
  { value: "y2025", label: "2025", color: CHART_PALETTES.vibrant.p3 },
  { value: "y2026", label: "2026", color: CHART_PALETTES.vibrant.p4 },
];

const toolbarPeriods = [
  { id: "performance", label: "Performance" },
  { id: "quarter", label: "Quarter" },
  { id: "yoy", label: "YoY" },
  { id: "qoq", label: "QoQ" },
  { id: "mom", label: "MoM" },
];

// Same underlying monthly series rendered as area (Performance/YoY) or bar
// (Quarter/QoQ/MoM) — a real page would aggregate per period; this demo only
// swaps chart `type` to keep the point (one card, several views) legible.
const toolbarMonthlyData = [
  { month: "Jan", y2022: 42, y2023: 55, y2024: 63, y2025: 70, y2026: 76 },
  { month: "Feb", y2022: 38, y2023: 50, y2024: 58, y2025: 65, y2026: 71 },
  { month: "Mar", y2022: 45, y2023: 60, y2024: 68, y2025: 74, y2026: 88 },
  { month: "Apr", y2022: 40, y2023: 52, y2024: 60, y2025: 68, y2026: 70 },
  { month: "May", y2022: 48, y2023: 58, y2024: 65, y2025: 72, y2026: 79 },
  { month: "Jun", y2022: 44, y2023: 54, y2024: 62, y2025: 69, y2026: 73 },
];

const toolbarCode = `// 7. Chart Card dengan Toolbar Filter (year toggle + period tabs + date range)
const [selectedYears, setSelectedYears] = useState(["y2025", "y2026"]);
const [period, setPeriod] = useState("performance");
const [dateRange, setDateRange] = useState({ startDate: null, endDate: null });

<CardApp id="revenue-comparison">
  <ChartToolbarApp
    id="revenue-comparison-toolbar"
    legend={[
      { label: "Target", value: "Rp 956,04 M", color: CHART_PALETTES.vibrant.p3 },
      { label: "Realisasi", value: "Rp 555,94 M", color: CHART_PALETTES.vibrant.p1 },
    ]}
    years={toolbarYearOptions}
    selectedYears={selectedYears}
    onYearsChange={setSelectedYears}
    periods={toolbarPeriods}
    selectedPeriod={period}
    onPeriodChange={setPeriod}
    dateRange={dateRange}
    onDateRangeChange={setDateRange}
  />
  <ChartApp
    type={period === "performance" || period === "yoy" ? "area" : "bar"}
    variant="vibrant"
    data={toolbarMonthlyData}
    xKey="month"
    series={toolbarYearOptions
      .filter((y) => selectedYears.includes(y.value))
      .map((y) => ({ key: y.value, label: y.label, color: y.color }))}
  />
</CardApp>`;

// ==========================================
// CODE SAMPLES FOR COPY-PASTE
// ==========================================
const areaCode = `// 1. Custom Area Chart dengan ChartApp Component
<ChartApp
  id="area-chart-preview"
  type="area"
  variant="vibrant"
  data={revenueData}
  xKey="month"
  series={[
    { key: "target", label: "Target Anggaran", color: CHART_PALETTES.vibrant.p2, fillOpacity: 0.15 },
    { key: "realisasi", label: "Realisasi Penerimaan", color: CHART_PALETTES.vibrant.p1, fillOpacity: 0.25 },
  ]}
  valueFormatter={(val) => \`Rp\${val}M\`}
/>`;

const barCode = `// 2. Custom Bar Chart dengan ChartApp Component
<ChartApp
  id="bar-chart-preview"
  type="bar"
  variant="vibrant"
  data={complianceData}
  xKey="region"
  series={[
    { key: "hotel", label: "Pajak Hotel (%)", color: CHART_PALETTES.vibrant.p1 },
    { key: "resto", label: "Pajak Restoran (%)", color: CHART_PALETTES.vibrant.p2 },
    { key: "hiburan", label: "Pajak Hiburan (%)", color: CHART_PALETTES.vibrant.p3 },
  ]}
  valueFormatter={(val) => \`\${val}%\`}
/>`;

const lineCode = `// 3. Custom Line Chart dengan ChartApp Component
<ChartApp
  id="line-chart-preview"
  type="line"
  variant="vibrant"
  data={dendaProjectionData}
  xKey="month"
  series={[
    { key: "proyeksi", label: "Proyeksi Tren", color: CHART_PALETTES.vibrant.p3 },
    { key: "realita", label: "Realisasi Aktual", color: CHART_PALETTES.vibrant.p4, strokeDasharray: "4 4" },
  ]}
  valueFormatter={(val) => \`Rp\${val}Jt\`}
/>`;

const pieCode = `// 4. Custom Pie/Donut Chart dengan ChartApp Component
<ChartApp
  id="pie-chart-preview"
  type="pie"
  variant="vibrant"
  data={taxContributionData}
  innerRadius={50}
  outerRadius={75}
/>`;

const radarCode = `// 5. Custom Radar Chart dengan ChartApp Component
<ChartApp
  id="radar-chart-preview"
  type="radar"
  variant="vibrant"
  data={complianceSectorsData}
  xKey="sector"
  series={[
    { key: "yogyakarta", label: "Kota Yogyakarta", color: CHART_PALETTES.vibrant.p1 },
    { key: "sleman", label: "Kab. Sleman", color: CHART_PALETTES.vibrant.p2 },
  ]}
/>`;

const radialCode = `// 6. Custom Radial Bar Chart dengan ChartApp Component
<ChartApp
  id="radial-chart-preview"
  type="radial"
  variant="vibrant"
  data={radialProgressData}
/>`;

export function ChartDisplayModule() {
  const [toolbarYears, setToolbarYears] = React.useState<string[]>(["y2025", "y2026"]);
  const [toolbarPeriod, setToolbarPeriod] = React.useState("performance");
  const [toolbarDateRange, setToolbarDateRange] = React.useState<{ startDate: Date | null; endDate: Date | null }>({
    startDate: null,
    endDate: null,
  });
  const toolbarSeries = toolbarYearOptions
    .filter((y) => toolbarYears.includes(y.value))
    .map((y) => ({ key: y.value, label: y.label, color: y.color }));

  return (
    <ModuleCard
      id="uikit-chart-module"
      icon={<BarChart3 className="w-5 h-5 text-vibrant-purple-dark" />}
      title="ChartApp"
      description="Visualisasi data interaktif menggunakan komponen terstruktur ChartApp yang terintegrasi langsung dengan warna palet Design System (Vibrant Purple, Blue, Amber, Emerald, Rose, Cyan) tanpa ketergantungan pada inline var(--)."
    >
      <ShowcaseGrid cols={2}>
        <ShowcaseCard
          id="chart-showcase-palette"
          title="Palet Warna Chart"
          description='Prop variant="vibrant" | "purple" | "blue" | "yellow" untuk penyesuaian visual instan'
          align="start"
          className="md:col-span-2"
          code={`<ChartApp variant="vibrant" series={[{ key: "sales", label: "Penjualan", color: CHART_PALETTES.vibrant.p1 }]} />`}
        >
          <div className="grid w-full grid-cols-2 gap-3 sm:grid-cols-6">
            {[
              { color: CHART_PALETTES.vibrant.p1, label: "Vibrant Purple", token: "CHART_PALETTES.vibrant.p1" },
              { color: CHART_PALETTES.vibrant.p2, label: "Vibrant Blue", token: "CHART_PALETTES.vibrant.p2" },
              { color: CHART_PALETTES.vibrant.p3, label: "Vibrant Amber", token: "CHART_PALETTES.vibrant.p3" },
              { color: CHART_PALETTES.vibrant.p4, label: "Emerald Green", token: "CHART_PALETTES.vibrant.p4" },
              { color: CHART_PALETTES.vibrant.p5, label: "Rose Pink", token: "CHART_PALETTES.vibrant.p5" },
              { color: CHART_PALETTES.vibrant.p6, label: "Cyan Blue", token: "CHART_PALETTES.vibrant.p6" },
            ].map((c, idx) => (
              <div key={idx} className="flex flex-col justify-between space-y-2 rounded border border-hairline bg-surface p-3 text-left shadow-xs">
                <div>
                  <div className="mb-1 flex items-center gap-1.5">
                    <div className="h-3.5 w-3.5 rounded-sm border border-hairline-soft" style={{ backgroundColor: c.color }} />
                    <span className="text-[10px] font-mono font-bold text-ink">{c.label}</span>
                  </div>
                  <p className="truncate text-[9px] font-mono text-ink-secondary">{c.color}</p>
                </div>
                <div className="border-t border-hairline-soft pt-2">
                  <span className="block truncate text-[8px] font-mono text-ink-muted">{c.token}</span>
                </div>
              </div>
            ))}
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="chart-showcase-area"
          title="Area Chart"
          description="Tren realisasi vs target dengan gradien adaptif"
          align="start"
          code={areaCode}
        >
          <div className="w-full rounded border border-hairline bg-surface p-3 shadow-inner">
            <ChartApp id="area-chart-module" type="area" variant="vibrant" data={revenueData} xKey="month" series={revenueSeries} valueFormatter={(val) => `Rp${val}M`} height={240} />
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="chart-showcase-bar"
          title="Bar Chart"
          description="Komparasi kepatuhan pajak antar wilayah"
          align="start"
          code={barCode}
        >
          <div className="w-full rounded border border-hairline bg-surface p-3 shadow-inner">
            <ChartApp id="bar-chart-module" type="bar" variant="vibrant" data={complianceData} xKey="region" series={complianceSeries} valueFormatter={(v) => `${v}%`} height={240} />
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="chart-showcase-line"
          title="Line Chart"
          description="Proyeksi tren vs realisasi aktual, garis putus-putus"
          align="start"
          code={lineCode}
        >
          <div className="w-full rounded border border-hairline bg-surface p-3 shadow-inner">
            <ChartApp id="line-chart-module" type="line" variant="vibrant" data={dendaProjectionData} xKey="month" series={lineSeries} valueFormatter={(v) => `Rp${v}Jt`} height={240} />
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="chart-showcase-pie"
          title="Donut / Pie Chart"
          description="Distribusi kontribusi pajak per segmen"
          code={pieCode}
        >
          <div className="w-full rounded border border-hairline bg-surface p-3 shadow-inner">
            <ChartApp id="pie-chart-module" type="pie" variant="vibrant" data={taxContributionData} innerRadius={55} outerRadius={85} height={240} />
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="chart-showcase-radar"
          title="Radar Chart"
          description="Perbandingan kualitatif kinerja multi-sektoral"
          code={radarCode}
        >
          <div className="w-full rounded border border-hairline bg-surface p-3 shadow-inner">
            <ChartApp id="radar-chart-module" type="radar" variant="vibrant" data={complianceSectorsData} xKey="sector" series={radarSeries} height={240} />
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="chart-showcase-radial"
          title="Radial Chart"
          description="Progress melingkar pencapaian target sektoral"
          code={radialCode}
        >
          <div className="w-full rounded border border-hairline bg-surface p-3 shadow-inner">
            <ChartApp id="radial-chart-module" type="radial" variant="vibrant" data={radialProgressData} height={240} />
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="chart-showcase-referenceline-quadrant"
          title="Reference Line Kuadran"
          description="Scatter dengan sepasang garis acuan sebagai pembagi kuadran. Warna titik ditentukan per-baris lewat field `fill` pada data."
          align="start"
          code={referenceLineCode}
        >
          <div className="w-full rounded border border-hairline bg-surface p-3 shadow-inner">
            <ChartApp
              id="scatter-quadrant-module"
              type="scatter"
              data={quadrantData}
              scatterXKey="kepadatan"
              scatterYKey="potensi"
              xAxisLabel="Kepadatan Area Tak Terdata (%)"
              yAxisLabel="Estimasi Potensi"
              referenceLines={[
                { axis: "x", value: 60, label: "Ambang kepadatan" },
                { axis: "y", value: 60, label: "Ambang potensi" },
              ]}
              showLegend={false}
              height={240}
            />
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="chart-showcase-toolbar"
          title="Chart Card + Toolbar Filter"
          description="Satu CardApp, beberapa cara membaca data yang sama — toggle tahun, tab periode (Performance/Quarter/YoY/QoQ/MoM), dan rentang tanggal. Tab periode di sini hanya menukar tipe chart sebagai contoh; agregasi per periode adalah logika halaman pemanggil."
          align="start"
          className="md:col-span-2"
          code={toolbarCode}
        >
          <div className="w-full space-y-4 rounded border border-hairline bg-surface p-4 shadow-inner">
            <ChartToolbarApp
              id="chart-toolbar-demo"
              legend={[
                { label: "Target", value: "Rp 956,04 M", color: CHART_PALETTES.vibrant.p3 },
                { label: "Realisasi", value: "Rp 555,94 M", color: CHART_PALETTES.vibrant.p1 },
              ]}
              years={toolbarYearOptions}
              selectedYears={toolbarYears}
              onYearsChange={setToolbarYears}
              periods={toolbarPeriods}
              selectedPeriod={toolbarPeriod}
              onPeriodChange={setToolbarPeriod}
              dateRange={toolbarDateRange}
              onDateRangeChange={setToolbarDateRange}
            />
            <ChartApp
              id="chart-toolbar-demo-chart"
              type={toolbarPeriod === "performance" || toolbarPeriod === "yoy" ? "area" : "bar"}
              variant="vibrant"
              data={toolbarMonthlyData}
              xKey="month"
              series={toolbarSeries}
              height={240}
            />
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="chart-showcase-usage"
          title="Cara Import & Pakai"
          description="ChartApp mendukung tipe area, bar, line, pie, radar, dan radial — tanpa raw var(--), tooltip solid background"
          align="start"
          className="md:col-span-2"
          code={`import { ChartApp, CHART_PALETTES } from "@/packages/design-system";

<ChartApp
  type="bar"
  variant="vibrant"
  data={data}
  xKey="month"
  series={[{ key: "sales", label: "Penjualan", color: CHART_PALETTES.vibrant.p1 }]}
/>`}
        >
          <ul className="w-full list-disc space-y-1.5 pl-4 text-xs leading-relaxed text-ink-secondary">
            <li>
              <strong className="text-ink">Tanpa Raw var(--):</strong> Warna diatur deklaratif melalui prop <code className="mx-1 rounded bg-vibrant-grey-bg px-1 py-0.5 text-[10px] font-mono text-ink">variant</code> atau token <code className="mx-1 rounded bg-vibrant-grey-bg px-1 py-0.5 text-[10px] font-mono text-ink">CHART_PALETTES</code>.
            </li>
            <li>
              <strong className="text-ink">Multi-Type Support:</strong> area, bar, line, pie, radar, radial.
            </li>
            <li>
              <strong className="text-ink">Solid Background Tooltips:</strong> Bebas dari transparansi yang menembus garis grid Recharts.
            </li>
          </ul>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
