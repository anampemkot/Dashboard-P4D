import * as React from "react";
import {
  FileUploadApp,
  FileUploadItem,
  TextApp,
  ButtonApp,
  CheckboxApp,
  DropdownApp,
} from "@/packages/design-system";
import { UploadCloud, Info, Code, Check } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

export function FileUploadDisplayModule() {
  // Mock files for progress and status showcase
  const [mockFileList, setMockFileList] = React.useState<FileUploadItem[]>([
    {
      id: "demo-f1",
      name: "Dokumen_Perencanaan_APBD_2026.pdf",
      size: 4850000,
      type: "application/pdf",
      progress: 100,
      status: "completed",
    },
    {
      id: "demo-f2",
      name: "Laporan_Retribusi_Pasar_Q2.xlsx",
      size: 1250000,
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      progress: 65,
      status: "uploading",
    },
    {
      id: "demo-f3",
      name: "Lampiran_Foto_Survei_Lapangan.png",
      size: 15400000,
      type: "image/png",
      progress: 30,
      status: "error",
      errorMessage: "File melebihi batas 10MB",
    },
  ]);

  const [avatarDemo] = React.useState<string>(
    "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80"
  );

  // Playground State
  const [playVariant, setPlayVariant] = React.useState<"dropzone" | "default" | "avatar">("dropzone");
  const [playSize, setPlaySize] = React.useState<"sm" | "md" | "lg">("md");
  const [playRounded, setPlayRounded] = React.useState<"none" | "sm" | "md" | "lg" | "xl" | "full">("lg");
  const [playDisabled, setPlayDisabled] = React.useState<boolean>(false);
  const [playMultiple, setPlayMultiple] = React.useState<boolean>(true);
  const [playAccept] = React.useState<string>("image/*,.pdf");
  const [copied, setCopied] = React.useState<boolean>(false);

  const codeString = `<FileUploadApp\n  id="demo-file-uploader"\n  label="Unggah Berkas Lampiran"\n  description="Pilih berkas dari perangkat Anda atau seret file ke dalam area"\n  variant="${playVariant}"\n  size="${playSize}"\n  rounded="${playRounded}"\n  accept="${playAccept}"\n  multiple={${playMultiple}}${playDisabled ? "\n  disabled" : ""}\n  onFileSelect={(files) => console.log(files)}\n/>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRemoveMock = (idToRemove: string) => {
    setMockFileList((prev) => prev.filter((f) => f.id !== idToRemove));
  };

  return (
    <ModuleCard
      id="uikit-fileupload-module"
      icon={<UploadCloud className="w-5 h-5 text-vibrant-purple-dark" />}
      title="FileUploadApp (File Upload & Dropzone)"
      description="Komponen pengunggah berkas multi-varian (Standard Dropzone, Compact Bar, dan Circular Avatar Upload) dengan dukungan drag-and-drop, indikator progress bar, serta status unggah berkas."
    >
      <ShowcaseGrid cols={2}>
        <ShowcaseCard
          id="fileupload-showcase-dropzone"
          title="Standard Dropzone Area"
          description='variant="dropzone" — seret berkas atau klik untuk memilih'
          code={`<FileUploadApp id="file-dropzone" variant="dropzone" label="Berkas Dokumen Pendukung" multiple />`}
        >
          <FileUploadApp
            id="file-demo-dropzone"
            variant="dropzone"
            label="Berkas Dokumen Pendukung"
            description="Unggah dokumen persyaratan retribusi daerah"
            helperText="Format PDF, DOCX, PNG atau JPG hingga 10MB"
            multiple
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="fileupload-showcase-default"
          title="Compact Click-to-Upload Bar"
          description='variant="default" — bar ringkas untuk satu berkas'
          code={`<FileUploadApp id="file-default" variant="default" label="Lampiran Nota Penerimaan" />`}
        >
          <FileUploadApp
            id="file-demo-default"
            variant="default"
            label="Lampiran Nota Penerimaan"
            description="Pilih file kuitansi atau bukti pembayaran"
            helperText="Format JPG atau PNG max 5MB"
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="fileupload-showcase-progress"
          title="Progress Bar & Status Items"
          description="Uploading, success, dan failed pada daftar berkas"
          code={`<FileUploadApp id="file-progress" variant="dropzone" files={fileList} onFileRemove={handleRemove} />`}
        >
          <FileUploadApp
            id="file-demo-progress"
            variant="dropzone"
            size="sm"
            label="Daftar Berkas Terunggah"
            description="Status visual pengunggahan berkas secara real-time"
            files={mockFileList}
            onFileRemove={handleRemoveMock}
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="fileupload-showcase-avatar"
          title="Avatar Upload"
          description='variant="avatar" — unggah foto profil bulat'
          code={`<FileUploadApp id="file-avatar" variant="avatar" rounded="full" avatarUrl={url} />`}
        >
          <FileUploadApp
            id="file-demo-avatar"
            variant="avatar"
            rounded="full"
            label="Foto Profil Pengguna / Petugas"
            description="Seret gambar profil baru atau klik tombol untuk memilih"
            helperText="Rasio 1:1 format JPG/PNG max 2MB"
            avatarUrl={avatarDemo}
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="fileupload-showcase-disabled"
          title="Disabled File Upload State"
          description="disabled — pengunggahan ditutup sementara"
          className="md:col-span-2"
          code={`<FileUploadApp id="file-disabled" variant="dropzone" label="Area Pengunggahan Terkunci" disabled />`}
        >
          <FileUploadApp
            id="file-demo-disabled"
            variant="dropzone"
            label="Area Pengunggahan Terkunci (Disabled)"
            description="Pengunggahan berkas ditutup sementara oleh sistem"
            disabled
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="fileupload-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap FileUploadApp dengan kode JSX yang dihasilkan"
          align="start"
          className="md:col-span-2"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            {/* Controls */}
            <div className="flex flex-col gap-4">
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Variant</span>
                <div className="flex gap-1.5">
                  {(["dropzone", "default", "avatar"] as const).map((v) => (
                    <PlaygroundChip key={v} id={`file-play-variant-${v}`} active={playVariant === v} onClick={() => setPlayVariant(v)} className="flex-1 capitalize">
                      {v}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Size</span>
                  <div className="flex gap-1">
                    {(["sm", "md", "lg"] as const).map((s) => (
                      <PlaygroundChip key={s} id={`file-play-size-${s}`} active={playSize === s} onClick={() => setPlaySize(s)} className="flex-1 uppercase">
                        {s}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Rounded</span>
                  <DropdownApp
                    id="file-play-rounded-select"
                    size="sm"
                    value={playRounded}
                    onChange={(value) => setPlayRounded(value as typeof playRounded)}
                    options={[
                      { label: "none", value: "none" },
                      { label: "sm", value: "sm" },
                      { label: "md", value: "md" },
                      { label: "lg", value: "lg" },
                      { label: "xl", value: "xl" },
                      { label: "full", value: "full" },
                    ]}
                  />
                </div>
              </div>

              <div className="space-y-2 pt-1">
                <CheckboxApp
                  id="file-play-multi-checkbox"
                  checked={playMultiple}
                  onChange={(e) => setPlayMultiple(e.target.checked)}
                  label="Multi-file Select (multiple)"
                />
                <CheckboxApp
                  id="file-play-dis-checkbox"
                  checked={playDisabled}
                  onChange={(e) => setPlayDisabled(e.target.checked)}
                  label="Non-aktifkan Control (disabled)"
                />
              </div>
            </div>

            {/* Live Output & Code */}
            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[160px] items-center justify-center rounded-lg border border-dashed border-hairline bg-surface p-4">
                  <FileUploadApp
                    id="interactive-file-uploader"
                    label="Uploader Interaktif"
                    description="Coba drag-and-drop berkas langsung ke area ini"
                    variant={playVariant}
                    size={playSize}
                    rounded={playRounded}
                    disabled={playDisabled}
                    multiple={playMultiple}
                    accept={playAccept}
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="file-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeString}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="fileupload-showcase-rules"
          title="Foundation Design System FileUpload Matrix & Rules"
          description="Aturan spacing internal komponen"
          align="start"
          className="md:col-span-2"
        >
          <div className="flex w-full items-start gap-3 rounded-card-custom border border-block-cream/80 bg-block-cream/40 p-4 text-left">
            <Info className="w-5 h-5 shrink-0 mt-0.5 text-vibrant-purple-dark" />
            <div className="space-y-1 leading-relaxed">
              <TextApp id="file-info-title" variant="body" weight="bold" className="text-ink">
                Foundation Design System FileUpload Matrix &amp; Rules
              </TextApp>
              <TextApp id="file-info-desc" variant="caption" className="block text-ink-secondary">
                Komponen <code>FileUploadApp</code> mematuhi spesifikasi Spacing Step 1.5 (6px / <code>gap-1.5</code>) antara Upload Icon dengan Text Instruksi, Step 2 (8px / <code>p-2</code>) untuk padding internal File List Item, Step 4 (16px / <code>p-4</code>) untuk padding Dropzone area standar, dan Step 6 (24px / <code>p-6</code>) untuk Large Dropzone area. Seluruh label teks dikonstruksi menggunakan <code>TextApp</code>.
              </TextApp>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
