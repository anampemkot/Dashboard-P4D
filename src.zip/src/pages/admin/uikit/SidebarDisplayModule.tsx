import * as React from "react";
import {
  SidebarApp,
  SidebarMenuGroup,
  SidebarVariant,
  SidebarSize,
  SidebarRounded,
  SidebarPosition,
  ButtonApp,
} from "@/packages/design-system";
import {
  LayoutDashboard,
  ShieldCheck,
  Settings,
  Layers,
  Code,
  Check,
  Calculator,
  MapPin,
  TrendingUp,
  Folder,
  PanelLeft,
} from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

export function SidebarDisplayModule() {
  const [isCollapsed, setIsCollapsed] = React.useState(false);
  const [position, setPosition] = React.useState<SidebarPosition>("left");
  const [variant, setVariant] = React.useState<SidebarVariant>("default");
  const [size, setSize] = React.useState<SidebarSize>("md");
  const [rounded, setRounded] = React.useState<SidebarRounded>("md");
  const [offCanvasOpen, setOffCanvasOpen] = React.useState(false);
  const [copied, setCopied] = React.useState(false);

  const sampleMenuGroups: SidebarMenuGroup[] = [
    {
      id: "grp-main",
      heading: "Utama & Ringkasan",
      items: [
        {
          id: "m-dashboard",
          label: "Dashboard Pajak P4D",
          path: "/admin",
          icon: <LayoutDashboard className="w-4 h-4" />,
          active: true,
        },
        {
          id: "m-pbb",
          label: "Pendataan & Penetapan PBB",
          path: "/pbb",
          icon: <Calculator className="w-4 h-4" />,
          badge: "12 Baru",
          badgeVariant: "solidPurple",
          children: [
            { id: "m-pbb-massal", label: "Penetapan Massal", path: "/pbb/massal" },
            { id: "m-pbb-individual", label: "Penetapan Individual", path: "/pbb/individual", active: true },
            { id: "m-pbb-njop", label: "Peta ZNT & NJOP", path: "/pbb/znt" },
          ],
        },
      ],
    },
    {
      id: "grp-audit",
      heading: "Pemeriksaan & GIS",
      items: [
        {
          id: "m-gis",
          label: "Peta Tematik GIS Jogja",
          path: "/gis",
          icon: <MapPin className="w-4 h-4" />,
        },
        {
          id: "m-audit",
          label: "Audit Kepatuhan PBJT",
          path: "/audit",
          icon: <ShieldCheck className="w-4 h-4" />,
          badge: 5,
        },
        {
          id: "m-laporan",
          label: "Laporan Potensi Pajak",
          path: "/laporan",
          icon: <TrendingUp className="w-4 h-4" />,
        },
      ],
    },
    {
      id: "grp-sys",
      heading: "Pengaturan Sistem",
      items: [
        {
          id: "m-uikit",
          label: "UI Kit Foundation",
          path: "/admin/uikit",
          icon: <Folder className="w-4 h-4" />,
        },
        {
          id: "m-settings",
          label: "Pengaturan Akun",
          path: "/settings",
          icon: <Settings className="w-4 h-4" />,
        },
      ],
    },
  ];

  const sampleUserProfile = {
    name: "Drs. Eko Prasetyo, M.Si",
    role: "Kabid Pajak Daerah BPKAD",
    onSettingsClick: () => alert("Membuka Pengaturan Profil User"),
    onLogoutClick: () => alert("Melakukan Logout..."),
  };

  const codeSnippet = `<SidebarApp
  id="app-main-sidebar"
  isCollapsed={${isCollapsed}}
  onToggleCollapse={() => setIsCollapsed(!isCollapsed)}
  position="${position}"
  variant="${variant}"
  size="${size}"
  rounded="${rounded}"
  menuGroups={menuGroups}
  userProfile={userProfile}
  embedded={true}
/>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-sidebar-module"
      icon={<Layers className="w-5 h-5 text-vibrant-purple-dark" />}
      title="SidebarApp (Sidebar / Navigation Drawer)"
      description="Organism navigasi utama admin BPKAD dengan dukungan posisi Left/Right, Mode Expanded/Mini Collapsed, Off-canvas Drawer dengan overlay, Sub-menu Accordion Tree, serta User Profile Footer."
    >
      <ShowcaseGrid cols={2}>
        <ShowcaseCard
          id="sidebar-showcase-expanded"
          title="Default Light — Expanded"
          description="Lebar penuh 260px dengan sub-menu accordion & profil user"
          previewClassName="p-2"
          code={`<SidebarApp id="sidebar" isCollapsed={false} variant="default" size="md" rounded="md" embedded menuGroups={groups} userProfile={profile} />`}
        >
          <div className="h-[420px] w-full overflow-hidden rounded-xl border border-hairline-soft bg-surface-soft/60 flex items-center justify-center">
            <SidebarApp
              id="demo-sidebar-expanded"
              isCollapsed={false}
              variant="default"
              size="md"
              rounded="md"
              embedded={true}
              menuGroups={sampleMenuGroups}
              userProfile={sampleUserProfile}
            />
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="sidebar-showcase-collapsed"
          title="Mini Collapsed"
          description="Mode icon-only 68px"
          previewClassName="p-2"
          code={`<SidebarApp id="sidebar" isCollapsed={true} variant="default" size="md" rounded="md" embedded menuGroups={groups} userProfile={profile} />`}
        >
          <div className="h-[420px] w-full overflow-hidden rounded-xl border border-hairline-soft bg-surface-soft/60 flex items-center justify-center">
            <SidebarApp
              id="demo-sidebar-collapsed"
              isCollapsed={true}
              variant="default"
              size="md"
              rounded="md"
              embedded={true}
              menuGroups={sampleMenuGroups}
              userProfile={sampleUserProfile}
            />
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="sidebar-showcase-glass"
          title="Glassmorphism"
          description='variant="glassmorphism" — backdrop blur di atas latar gradien'
          previewClassName="p-2"
          code={`<SidebarApp id="sidebar" variant="glassmorphism" size="md" rounded="xl" embedded menuGroups={groups} userProfile={profile} />`}
        >
          <div className="h-[420px] w-full overflow-hidden rounded-xl border border-purple-200 bg-gradient-to-br from-purple-100 via-indigo-50 to-purple-200 flex items-center justify-center">
            <SidebarApp
              id="demo-sidebar-glass"
              isCollapsed={false}
              variant="glassmorphism"
              size="md"
              rounded="xl"
              embedded={true}
              menuGroups={sampleMenuGroups}
              userProfile={sampleUserProfile}
            />
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="sidebar-showcase-offcanvas"
          title="Off-Canvas Navigation Drawer"
          description="Drawer di atas konten dengan backdrop overlay dismissible"
          code={`<SidebarApp id="drawer" offCanvas isOpen={open} onClose={() => setOpen(false)} position="${position}" menuGroups={groups} userProfile={profile} />`}
        >
          <ButtonApp
            id="trigger-off-canvas-btn"
            variant="vibrantPurpleDark"
            size="sm"
            leftIcon={<PanelLeft className="w-4 h-4" />}
            onClick={() => setOffCanvasOpen(true)}
          >
            Uji Off-Canvas Navigation Drawer
          </ButtonApp>
          <SidebarApp
            id="offcanvas-drawer-instance"
            position={position}
            variant={variant}
            size={size}
            rounded={rounded}
            offCanvas={true}
            isOpen={offCanvasOpen}
            onClose={() => setOffCanvasOpen(false)}
            menuGroups={sampleMenuGroups}
            userProfile={sampleUserProfile}
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="sidebar-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap SidebarApp dengan kode JSX yang dihasilkan"
          align="start"
          className="md:col-span-2"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            <div className="flex flex-col gap-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Collapse State</span>
                  <div className="flex gap-1">
                    <PlaygroundChip id="sidebar-play-mode-expanded" active={!isCollapsed} onClick={() => setIsCollapsed(false)} className="flex-1">
                      Expanded
                    </PlaygroundChip>
                    <PlaygroundChip id="sidebar-play-mode-mini" active={isCollapsed} onClick={() => setIsCollapsed(true)} className="flex-1">
                      Mini
                    </PlaygroundChip>
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Position</span>
                  <div className="flex gap-1">
                    {(["left", "right"] as const).map((pos) => (
                      <PlaygroundChip key={pos} id={`sidebar-play-pos-${pos}`} active={position === pos} onClick={() => setPosition(pos)} className="flex-1">
                        {pos}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Variant</span>
                  <div className="flex gap-1">
                    {(["default", "glassmorphism"] as const).map((v) => (
                      <PlaygroundChip key={v} id={`sidebar-play-variant-${v}`} active={variant === v} onClick={() => setVariant(v)} className="flex-1">
                        {v}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Size</span>
                  <div className="flex gap-1">
                    {(["sm", "md", "lg"] as const).map((s) => (
                      <PlaygroundChip key={s} id={`sidebar-play-size-${s}`} active={size === s} onClick={() => setSize(s)} className="flex-1">
                        {s}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Rounded</span>
                <div className="flex flex-wrap gap-1">
                  {(["none", "sm", "md", "lg", "xl", "full"] as const).map((r) => (
                    <PlaygroundChip key={r} id={`sidebar-play-rounded-${r}`} active={rounded === r} onClick={() => setRounded(r)} className="flex-1">
                      {r}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="h-[420px] overflow-hidden rounded-lg border border-dashed border-hairline bg-surface p-2 flex items-center justify-center">
                  <SidebarApp
                    id="interactive-sidebar-demo"
                    isCollapsed={isCollapsed}
                    onToggleCollapse={() => setIsCollapsed(!isCollapsed)}
                    position={position}
                    variant={variant}
                    size={size}
                    rounded={rounded}
                    embedded={true}
                    menuGroups={sampleMenuGroups}
                    userProfile={sampleUserProfile}
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="sidebar-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeSnippet}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
