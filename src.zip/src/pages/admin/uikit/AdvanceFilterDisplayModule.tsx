import * as React from "react";
import { AdvanceFilterApp, FilterFieldConfig, QuickPreset } from "@/packages/design-system";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid } from "./shared/ShowcaseCard";
import { SlidersHorizontal } from "lucide-react";

export function AdvanceFilterDisplayModule() {
  // Popover State Demo
  const [popoverValues, setPopoverValues] = React.useState<Record<string, any>>({
    jenisPajak: "pbjt",
    status: "",
  });

  // Drawer State Demo (Complex filters)
  const [drawerValues, setDrawerValues] = React.useState<Record<string, any>>({
    kecamatan: "danurejan",
    jenisPajak: ["pbb", "bphtb"],
    dateRange: { from: "2026-01-01", to: "2026-07-22" },
    statusVal: "verified",
  });

  // Field configurations for BPKAD Dashboard filters
  const simpleFields: FilterFieldConfig[] = [
    {
      id: "jenisPajak",
      label: "Jenis Pajak Daerah",
      type: "select",
      placeholder: "-- Semua Jenis Pajak --",
      options: [
        { label: "PBJT (Makanan, Hotel, Parkir)", value: "pbjt" },
        { label: "PBB-P2 (Bumi & Bangunan)", value: "pbb" },
        { label: "BPHTB (Hak Tanah & Bangunan)", value: "bphtb" },
        { label: "PAT (Air Tanah)", value: "pat" },
        { label: "Pajak Reklame", value: "reklame" },
      ],
    },
    {
      id: "status",
      label: "Status Kepatuhan",
      type: "select",
      placeholder: "-- Semua Status --",
      options: [
        { label: "Lunas / Selesai", value: "lunas" },
        { label: "Proses Verifikasi", value: "proses" },
        { label: "Tunggakan / Menunggak", value: "menunggak" },
      ],
    },
  ];

  const complexFields: FilterFieldConfig[] = [
    {
      id: "kecamatan",
      label: "Wilayah Kecamatan",
      type: "select",
      placeholder: "-- Pilih Kecamatan --",
      colSpan: 1,
      options: [
        { label: "Kec. Danurejan", value: "danurejan" },
        { label: "Kec. Gondomanan", value: "gondomanan" },
        { label: "Kec. Jetis", value: "jetis" },
        { label: "Kec. Kotagede", value: "kotagede" },
        { label: "Kec. Malioboro / Kraton", value: "kraton" },
        { label: "Kec. Umbulharjo", value: "umbulharjo" },
      ],
    },
    {
      id: "statusVal",
      label: "Status Validasi",
      type: "select",
      colSpan: 1,
      options: [
        { label: "Tervalidasi (Dukcapil/Agraria)", value: "verified" },
        { label: "Perlu Uji Petik", value: "ujipetik" },
        { label: "Data Ganda / Belum Cocok", value: "ganda" },
      ],
    },
    {
      id: "jenisPajak",
      label: "Kategori Pajak (Multi Select)",
      type: "multi-select",
      colSpan: 2,
      options: [
        { label: "PBB-P2", value: "pbb" },
        { label: "PBJT", value: "pbjt" },
        { label: "BPHTB", value: "bphtb" },
        { label: "Reklame", value: "reklame" },
        { label: "Air Tanah", value: "pat" },
      ],
    },
    {
      id: "dateRange",
      label: "Rentang Tanggal Penetapan / Pelayanan",
      type: "date-range",
      colSpan: 2,
    },
  ];

  const quickPresets: QuickPreset[] = [
    {
      label: "Hari Ini",
      values: {
        dateRange: { from: "2026-07-22", to: "2026-07-22" },
      },
    },
    {
      label: "Bulan Ini (Juli 2026)",
      values: {
        dateRange: { from: "2026-07-01", to: "2026-07-31" },
      },
    },
    {
      label: "Tahun Ini (TA 2026)",
      values: {
        dateRange: { from: "2026-01-01", to: "2026-12-31" },
      },
    },
  ];

  return (
    <ModuleCard
      id="uikit-filter-module"
      icon={<SlidersHorizontal className="w-5 h-5 text-vibrant-purple-dark" />}
      title="AdvanceFilterApp"
      description="Komponen filter pencarian multi-kriteria. Menyediakan opsi Popover (untuk filter ringkas) dan Drawer/Slide-over (untuk filter kompleks wilayah, rentang tanggal, & jenis pajak)."
    >
      <ShowcaseGrid cols={3}>
        <ShowcaseCard
          id="advfilter-showcase-popover"
          title="Mode Popover"
          description="Penyaringan cepat langsung di atas konten tanpa menutup layar"
          align="start"
          code={`<AdvanceFilterApp id="filter" displayMode="popover" triggerLabel="Filter Jenis Pajak" fields={simpleFields} values={values} onChange={setValues} />`}
        >
          <div className="w-full space-y-4">
            <AdvanceFilterApp
              id="filter-popover-demo"
              displayMode="popover"
              triggerLabel="Filter Jenis Pajak"
              triggerVariant="purple"
              triggerTheme="default"
              fields={simpleFields}
              values={popoverValues}
              onChange={setPopoverValues}
            />
            <div className="space-y-1 rounded-xl border border-hairline-soft bg-vibrant-grey-bg p-3 font-mono text-[11px]">
              <span className="block text-[10px] font-bold uppercase text-ink-muted">Active Filter State (JSON):</span>
              <pre className="overflow-x-auto font-bold text-vibrant-purple-dark dark:text-purple-300">{JSON.stringify(popoverValues, null, 2)}</pre>
            </div>
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="advfilter-showcase-drawer"
          title="Mode Drawer (DrawerApp)"
          description="DrawerApp dengan sudut rounded 3xl & tombol close, quick presets"
          align="start"
          code={`<AdvanceFilterApp id="filter" displayMode="drawer" title="Filter Lanjutan" fields={complexFields} values={values} quickPresets={presets} onChange={setValues} />`}
        >
          <div className="w-full space-y-4">
            <AdvanceFilterApp
              id="filter-drawer-demo"
              displayMode="drawer"
              title="Filter Lanjutan Dashboard BPKAD"
              triggerLabel="Filter Drawer (Kecamatan)"
              triggerVariant="purple"
              triggerTheme="default"
              triggerRounded="pill"
              fields={complexFields}
              values={drawerValues}
              quickPresets={quickPresets}
              onChange={setDrawerValues}
            />
            <div className="space-y-1 rounded-xl border border-hairline-soft bg-vibrant-grey-bg p-3 font-mono text-[11px]">
              <span className="block text-[10px] font-bold uppercase text-ink-muted">Active Filter State (JSON):</span>
              <pre className="overflow-x-auto font-bold text-vibrant-purple-dark dark:text-purple-300">{JSON.stringify(drawerValues, null, 2)}</pre>
            </div>
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="advfilter-showcase-custom-trigger"
          title="Custom Trigger Style"
          description="Gaya trigger disesuaikan via props ButtonApp (triggerVariant, triggerSize, triggerRounded)"
          align="start"
          code={`<AdvanceFilterApp id="filter" displayMode="drawer" triggerVariant="purpleDark" triggerSize="lg" triggerRounded="pill" fields={complexFields} values={values} onChange={setValues} />`}
        >
          <div className="w-full space-y-4">
            <AdvanceFilterApp
              id="filter-custom-trigger-demo"
              displayMode="drawer"
              title="Filter Kepatuhan Wajib Pajak"
              triggerLabel="Kustom Trigger (Purple Dark)"
              triggerVariant="purpleDark"
              triggerSize="lg"
              triggerRounded="pill"
              triggerClassName="w-full justify-center shadow-md hover:scale-[1.01]"
              fields={complexFields}
              values={drawerValues}
              quickPresets={quickPresets}
              onChange={setDrawerValues}
            />
            <div className="space-y-1 rounded-xl border border-hairline-soft bg-vibrant-grey-bg p-3 font-mono text-[11px]">
              <span className="block text-[10px] font-bold uppercase text-ink-muted">Props Trigger Disertakan:</span>
              <code className="block text-[10px] text-vibrant-purple-dark dark:text-purple-300">
                triggerVariant=&quot;purpleDark&quot;<br />
                triggerSize=&quot;lg&quot;<br />
                triggerRounded=&quot;pill&quot;
              </code>
            </div>
          </div>
        </ShowcaseCard>
        <ShowcaseCard
          id="advfilter-showcase-modal"
          title="Mode Modal — Dua Panel"
          description="Nav kategori kiri + panel checkbox/radio kanan, chips filter aktif di atas — acuan benchmark Dribbble (Apollo-style advanced filters)"
          align="start"
          code={`<AdvanceFilterApp id="filter" displayMode="modal" title="Filter Lanjutan" fields={complexFields} values={values} quickPresets={presets} onChange={setValues} />`}
        >
          <div className="w-full space-y-4">
            <AdvanceFilterApp
              id="filter-modal-demo"
              displayMode="modal"
              title="Filter Lanjutan Dashboard BPKAD"
              description="Pilih kategori di kiri, lalu tentukan kriterianya di kanan"
              triggerLabel="Filter Lanjutan (Modal)"
              triggerVariant="purple"
              triggerTheme="default"
              triggerRounded="pill"
              fields={complexFields}
              values={drawerValues}
              quickPresets={quickPresets}
              onChange={setDrawerValues}
            />
            <div className="space-y-1 rounded-xl border border-hairline-soft bg-vibrant-grey-bg p-3 font-mono text-[11px]">
              <span className="block text-[10px] font-bold uppercase text-ink-muted">Active Filter State (JSON):</span>
              <pre className="overflow-x-auto font-bold text-vibrant-purple-dark dark:text-purple-300">{JSON.stringify(drawerValues, null, 2)}</pre>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
