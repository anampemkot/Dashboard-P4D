import * as React from "react";
import { ButtonApp, BadgeApp, InputApp, TextApp, FormFieldApp } from "@/packages/design-system";
import { Type, Info, Code, Check } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

export function FormCompositionModule() {
  // Live Playground State
  const [playVariant, setPlayVariant] = React.useState<"default" | "inline">("default");
  const [playSize, setPlaySize] = React.useState<"sm" | "md" | "lg">("md");
  const [playLabel, setPlayLabel] = React.useState<string>("Nomor Pokok Wajib Pajak Daerah (NPWPD)");
  const [playError, setPlayError] = React.useState<string>("Format NPWPD salah! Harus diawali dengan 'P4D-'");
  const [playInputValue, setPlayInputValue] = React.useState<string>("P4D-12345");
  const [copied, setCopied] = React.useState<boolean>(false);

  const errProp = playError ? ` error="${playError}"` : "";
  const variantProp = playVariant === "default" ? "" : ` variant="inline"`;
  const codeString = `<FormFieldApp\n  id="form-field-demo"\n  label="${playLabel}"\n  size="${playSize}"${variantProp}${errProp}\n>\n  <InputApp\n    id="input-demo"\n    value="${playInputValue}"\n    placeholder="Type value..."\n  />\n</FormFieldApp>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-form-module"
      icon={<Type className="w-5 h-5 text-vibrant-purple-dark" />}
      title="FormFieldApp (CVA Component Specs)"
      description="Elemen pembungkus kontrol formulir yang mengintegrasikan label teks, pesan error, dan status penempatan masukan data secara kohesif."
    >
      <ShowcaseGrid cols={2}>
        <ShowcaseCard
          id="form-composition-showcase-vertical-default"
          title="Form vertikal default"
          description="Label ditumpuk di atas input, tanpa error"
          align="start"
          code={`<FormFieldApp id="form-username" label="Nama Lengkap Pengguna" size="sm">\n  <InputApp id="input-username" size="sm" placeholder="e.g. Sugi Wijaya" />\n</FormFieldApp>`}
        >
          <FormFieldApp id="form-composition-showcase-vertical-default-demo" label="Nama Lengkap Pengguna" size="sm">
            <InputApp id="form-composition-showcase-vertical-default-input" size="sm" placeholder="e.g. Sugi Wijaya" />
          </FormFieldApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="form-composition-showcase-vertical-error"
          title="Form vertikal error"
          description="Label ditumpuk di atas input, disertai pesan error"
          align="start"
          code={`<FormFieldApp id="form-email" label="Alamat Surat Elektronik" size="sm" error="Format e-mail harus menggunakan domain terverifikasi">\n  <InputApp id="input-email" size="sm" variant="error" />\n</FormFieldApp>`}
        >
          <FormFieldApp id="form-composition-showcase-vertical-error-demo" label="Alamat Surat Elektronik" size="sm" error="Format e-mail harus menggunakan domain terverifikasi">
            <InputApp id="form-composition-showcase-vertical-error-input" size="sm" variant="error" placeholder="e.g. sugi@bpkad.go.id" />
          </FormFieldApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="form-composition-showcase-inline"
          title="Form Baris Hemat Ruang (Inline Layout)"
          description='variant="inline" — label dan input/badge sejajar dalam satu baris'
          align="start"
          code={`<FormFieldApp id="form-sync" label="Otoritas Sinkronisasi Otomatis" variant="inline" size="sm">\n  <BadgeApp id="badge-sync" variant="success" size="sm">AKTIF SECARA REAL-TIME</BadgeApp>\n</FormFieldApp>`}
        >
          <div className="w-full space-y-3">
            <div className="rounded-card-custom border border-hairline-soft bg-surface p-3">
              <FormFieldApp id="form-ex-inline-1" label="Otoritas Sinkronisasi Otomatis" variant="inline" size="sm">
                <BadgeApp id="badge-ex-inline-1" variant="success" size="sm">
                  AKTIF SECARA REAL-TIME
                </BadgeApp>
              </FormFieldApp>
            </div>
            <div className="rounded-card-custom border border-hairline-soft bg-surface p-3">
              <FormFieldApp id="form-ex-inline-2" label="Status Akreditasi Server" variant="inline" size="sm">
                <BadgeApp id="badge-ex-inline-2" variant="brand" size="sm">
                  TERTUNDA (PENDING)
                </BadgeApp>
              </FormFieldApp>
            </div>
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="form-composition-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap FormFieldApp dengan kode JSX yang dihasilkan"
          align="start"
          className="md:col-span-2"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            {/* Controls */}
            <div className="flex flex-col gap-4">
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Custom Label Text</span>
                <InputApp
                  id="form-play-label-input"
                  size="sm"
                  value={playLabel}
                  onChange={(e) => setPlayLabel(e.target.value)}
                />
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Custom Error Message</span>
                <InputApp
                  id="form-play-error-input"
                  size="sm"
                  value={playError}
                  onChange={(e) => setPlayError(e.target.value)}
                  placeholder="Clear to hide error..."
                />
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Input Value Simulator</span>
                <InputApp
                  id="form-play-value-input"
                  size="sm"
                  value={playInputValue}
                  onChange={(e) => setPlayInputValue(e.target.value)}
                />
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Variant</span>
                  <div className="flex flex-wrap gap-1.5">
                    {(["default", "inline"] as const).map((v) => (
                      <PlaygroundChip key={v} id={`form-play-variant-${v}`} active={playVariant === v} onClick={() => setPlayVariant(v)}>
                        {v}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Size</span>
                  <div className="flex gap-1.5">
                    {(["sm", "md", "lg"] as const).map((s) => (
                      <PlaygroundChip key={s} id={`form-play-size-${s}`} active={playSize === s} onClick={() => setPlaySize(s)} className="flex-1">
                        {s.toUpperCase()}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Live Output & Code */}
            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[120px] items-center justify-center rounded-lg border border-dashed border-hairline bg-surface p-4">
                  <div className="w-full max-w-lg">
                    <FormFieldApp
                      id="playground-interactive-formfield"
                      label={playLabel}
                      variant={playVariant}
                      size={playSize}
                      error={playError || undefined}
                    >
                      <InputApp
                        id="playground-interactive-formfield-input"
                        value={playInputValue}
                        onChange={(e) => setPlayInputValue(e.target.value)}
                        variant={playError ? "error" : "default"}
                      />
                    </FormFieldApp>
                  </div>
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="form-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeString}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="form-composition-showcase-info"
          title="Compound Form Handling & Validation States"
          description="Catatan integrasi label dan state error"
          align="start"
          className="md:col-span-2"
        >
          <div className="flex w-full items-start gap-3 rounded-card-custom border border-block-cream/80 bg-block-cream/40 p-4 text-left">
            <Info className="mt-0.5 h-5 w-5 shrink-0 text-vibrant-purple-dark" />
            <div className="space-y-1 text-xs leading-relaxed">
              <TextApp id="form-info-title" variant="body" weight="bold" className="block">Compound Form Handling &amp; Validation States</TextApp>
              <TextApp id="form-info-body" variant="caption" className="block text-ink-secondary">
                Penggunaan komponen <code>FormFieldApp</code> secara otomatis mewarisi properti ukuran lencana teks pada labelnya. Memanfaatkan integrasi denda error yang beraksen merah tajam (<code>text-accent</code>) langsung meningkatkan kegunaan operasional saat data salah diinputkan.
              </TextApp>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
