import * as React from "react";
import {
  AlertApp,
  AlertIconApp,
  AlertTitleApp,
  AlertDescriptionApp,
  AlertActionApp,
  ButtonApp,
  InputApp,
  ToggleApp,
} from "@/packages/design-system";
import {
  AlertCircle,
  CheckCircle2,
  Info,
  AlertTriangle,
  Terminal,
  Code,
  Check,
} from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

const ALL_VARIANTS = ["default", "info", "success", "warning", "error", "brand"] as const;
const ALL_SIZES = ["sm", "md", "lg"] as const;
const ALL_ROUNDED = ["default", "none", "sm", "md", "lg", "full", "pill", "card"] as const;

export function AlertDisplayModule() {
  // Live Playground State
  const [playVariant, setPlayVariant] = React.useState<(typeof ALL_VARIANTS)[number]>("info");
  const [playSize, setPlaySize] = React.useState<(typeof ALL_SIZES)[number]>("md");
  const [playRounded, setPlayRounded] = React.useState<(typeof ALL_ROUNDED)[number]>("md");
  const [playTheme, setPlayTheme] = React.useState<"default" | "playful">("default");
  const [playTitle, setPlayTitle] = React.useState<string>("Sinkronisasi Data Pokok");
  const [playDesc, setPlayDesc] = React.useState<string>(
    "Sistem sedang menyelaraskan data anggaran daerah dengan SIPD Nasional secara real-time."
  );
  const [showAction, setShowAction] = React.useState<boolean>(true);
  const [copied, setCopied] = React.useState<boolean>(false);

  // Icon selector based on active variant
  const getVariantIcon = (variant: typeof playVariant) => {
    switch (variant) {
      case "success":
        return <CheckCircle2 className="w-5 h-5 text-success" />;
      case "warning":
        return <AlertTriangle className="w-5 h-5 text-warning" />;
      case "error":
        return <AlertCircle className="w-5 h-5 text-red-500" />;
      case "brand":
        return <Terminal className="w-5 h-5 text-vibrant-purple-dark" />;
      case "info":
        return <Info className="w-5 h-5 text-vibrant-blue-dark" />;
      default:
        return <Info className="w-5 h-5 text-ink-muted" />;
    }
  };

  const getVariantIconJSX = (variant: typeof playVariant) => {
    switch (variant) {
      case "success":
        return '<CheckCircle2 className="w-5 h-5 text-success" />';
      case "warning":
        return '<AlertTriangle className="w-5 h-5 text-warning" />';
      case "error":
        return '<AlertCircle className="w-5 h-5 text-red-500" />';
      case "brand":
        return '<Terminal className="w-5 h-5 text-vibrant-purple-dark" />';
      default:
        return '<Info className="w-5 h-5 text-vibrant-blue-dark" />';
    }
  };

  // Build the code string
  const sizeProp = playSize === "md" ? "" : `\n  size="${playSize}"`;
  const roundedProp = playRounded === "default" ? "" : `\n  rounded="${playRounded}"`;
  const themeProp = playTheme === "default" ? "" : `\n  theme="playful"`;
  const actionJSX = showAction
    ? `\n  <AlertActionApp id="alert-action">\n    <ButtonApp id="btn-action" size="sm" variant="secondary">Tinjau</ButtonApp>\n  </AlertActionApp>`
    : "";

  const codeString = `<AlertApp\n  id="demo-alert"\n  variant="${playVariant}"${sizeProp}${roundedProp}${themeProp}\n>\n  <AlertIconApp id="alert-icon">\n    ${getVariantIconJSX(
    playVariant
  )}\n  </AlertIconApp>\n  <div>\n    <AlertTitleApp id="alert-title">${playTitle}</AlertTitleApp>\n    <AlertDescriptionApp id="alert-desc">\n      ${playDesc}\n    </AlertDescriptionApp>\n  </div>${actionJSX}\n</AlertApp>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-alert-module"
      icon={<AlertCircle className="w-5 h-5 text-vibrant-purple-dark" />}
      title="AlertApp"
      description="Elemen banner notifikasi kontekstual untuk menyampaikan status sistem, instruksi, atau umpan balik pengguna dengan komposisi layout fleksibel."
    >
      <ShowcaseGrid cols={2}>
        {/* Preset: Denda Pajak */}
        <ShowcaseCard
          id="alert-showcase-error-preset"
          title="Denda Pajak Terlambat"
          description='variant="error" · rounded="card"'
          code={`<AlertApp id="alert" variant="error" rounded="card">\n  <AlertIconApp id="icon"><AlertCircle /></AlertIconApp>\n  <AlertTitleApp id="title">Denda Keterlambatan SPTD</AlertTitleApp>\n  <AlertActionApp id="action"><ButtonApp variant="danger" size="sm">Bayar Denda</ButtonApp></AlertActionApp>\n</AlertApp>`}
        >
          <AlertApp id="preset-alert-error" variant="error" rounded="card">
            <AlertIconApp id="preset-alert-error-icon">
              <AlertCircle className="w-5 h-5 text-red-500" />
            </AlertIconApp>
            <div className="flex-1">
              <AlertTitleApp id="preset-alert-error-title" className="text-red-700 dark:text-red-400">
                Denda Keterlambatan SPTD Terdeteksi
              </AlertTitleApp>
              <AlertDescriptionApp id="preset-alert-error-desc" className="text-red-600/90 dark:text-red-300/80">
                Wajib pajak denda sebesar Rp500.000,- dibebankan secara otomatis akibat pelaporan terlambat melewati batas tanggal 20.
              </AlertDescriptionApp>
            </div>
            <AlertActionApp id="preset-alert-error-action">
              <ButtonApp id="btn-preset-pay-error" variant="danger" size="sm">
                Bayar Denda
              </ButtonApp>
            </AlertActionApp>
          </AlertApp>
        </ShowcaseCard>

        {/* Preset: Verifikasi Sukses */}
        <ShowcaseCard
          id="alert-showcase-success-preset"
          title="Verifikasi Sukses"
          description='variant="success" · rounded="pill"'
          code={`<AlertApp id="alert" variant="success" rounded="pill">\n  <AlertIconApp id="icon"><CheckCircle2 /></AlertIconApp>\n  <AlertTitleApp id="title">NPWPD Berhasil Terverifikasi</AlertTitleApp>\n</AlertApp>`}
        >
          <AlertApp id="preset-alert-success" variant="success" rounded="pill">
            <AlertIconApp id="preset-alert-success-icon">
              <CheckCircle2 className="w-5 h-5 text-success" />
            </AlertIconApp>
            <div className="flex-1">
              <AlertTitleApp id="preset-alert-success-title">NPWPD Berhasil Terverifikasi</AlertTitleApp>
              <AlertDescriptionApp id="preset-alert-success-desc">
                Data kepemilikan objek pajak denda administrasi hotel &amp; resto telah disetujui oleh BPKAD Kota Yogyakarta.
              </AlertDescriptionApp>
            </div>
          </AlertApp>
        </ShowcaseCard>

        {/* Preset: Peringatan Keamanan */}
        <ShowcaseCard
          id="alert-showcase-warning-preset"
          title="Peringatan Keamanan"
          description='variant="warning" · rounded="default"'
          code={`<AlertApp id="alert" variant="warning">\n  <AlertIconApp id="icon"><AlertTriangle /></AlertIconApp>\n  <AlertTitleApp id="title">Sesi Aktif Segera Berakhir</AlertTitleApp>\n  <AlertActionApp id="action"><ButtonApp variant="secondary" size="sm">Perpanjang Sesi</ButtonApp></AlertActionApp>\n</AlertApp>`}
        >
          <AlertApp id="preset-alert-warning" variant="warning">
            <AlertIconApp id="preset-alert-warning-icon">
              <AlertTriangle className="w-5 h-5 text-warning" />
            </AlertIconApp>
            <div className="flex-1">
              <AlertTitleApp id="preset-alert-warning-title">Sesi Aktif Segera Berakhir</AlertTitleApp>
              <AlertDescriptionApp id="preset-alert-warning-desc">
                Anda akan keluar dari sistem admin secara otomatis dalam waktu 2 menit karena tidak ada aktivitas operasional.
              </AlertDescriptionApp>
            </div>
            <AlertActionApp id="preset-alert-warning-action">
              <ButtonApp id="btn-preset-stay-warning" variant="secondary" size="sm">
                Perpanjang Sesi
              </ButtonApp>
            </AlertActionApp>
          </AlertApp>
        </ShowcaseCard>

        {/* Preset: Playful Brand */}
        <ShowcaseCard
          id="alert-showcase-playful-preset"
          title="Gaya Playful Vibrant"
          description='variant="brand" · theme="playful" · rounded="card"'
          code={`<AlertApp id="alert" variant="brand" theme="playful" rounded="card">\n  <AlertIconApp id="icon"><Terminal /></AlertIconApp>\n  <AlertTitleApp id="title">Analisis Cerdas Model AI</AlertTitleApp>\n</AlertApp>`}
        >
          <AlertApp id="preset-alert-playful" variant="brand" theme="playful" rounded="card">
            <AlertIconApp id="preset-alert-playful-icon">
              <Terminal className="w-5 h-5 text-vibrant-purple-dark" />
            </AlertIconApp>
            <div className="flex-1">
              <AlertTitleApp id="preset-alert-playful-title">Analisis Cerdas Model AI</AlertTitleApp>
              <AlertDescriptionApp id="preset-alert-playful-desc">
                Algoritma P4D memprediksi kenaikan kepatuhan wajib pajak hotel sebesar +8.2% pada kuartal depan melalui insentif terpadu.
              </AlertDescriptionApp>
            </div>
          </AlertApp>
        </ShowcaseCard>

        {/* Playground — span penuh */}
        <ShowcaseCard
          id="alert-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap AlertApp dengan kode JSX yang dihasilkan"
          align="start"
          className="md:col-span-2"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            {/* Controls */}
            <div className="flex flex-col gap-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Judul Alert</span>
                  <InputApp
                    id="alert-play-title"
                    value={playTitle}
                    onChange={(e) => setPlayTitle(e.target.value)}
                  />
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Deskripsi Alert</span>
                  <InputApp
                    id="alert-play-desc"
                    value={playDesc}
                    onChange={(e) => setPlayDesc(e.target.value)}
                  />
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Variant</span>
                <div className="flex flex-wrap gap-1.5">
                  {ALL_VARIANTS.map((v) => (
                    <PlaygroundChip key={v} id={`alert-play-variant-${v}`} active={playVariant === v} onClick={() => setPlayVariant(v)}>
                      {v}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Size</span>
                  <div className="flex gap-1.5">
                    {ALL_SIZES.map((s) => (
                      <PlaygroundChip key={s} id={`alert-play-size-${s}`} active={playSize === s} onClick={() => setPlaySize(s)} className="flex-1">
                        {s}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Theme</span>
                  <div className="flex gap-1.5">
                    {(["default", "playful"] as const).map((tm) => (
                      <PlaygroundChip key={tm} id={`alert-play-theme-${tm}`} active={playTheme === tm} onClick={() => setPlayTheme(tm)} className="flex-1 capitalize">
                        {tm}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Corner Radius</span>
                <div className="flex flex-wrap gap-1.5">
                  {ALL_ROUNDED.map((r) => (
                    <PlaygroundChip key={r} id={`alert-play-rounded-${r}`} active={playRounded === r} onClick={() => setPlayRounded(r)}>
                      {r}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-[10px] font-bold uppercase tracking-wide text-ink">Tampilkan AlertActionApp</span>
                <ToggleApp id="alert-play-show-action" checked={showAction} onCheckedChange={setShowAction} />
              </div>
            </div>

            {/* Live Output & Code */}
            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[120px] items-center justify-center rounded-lg border border-dashed border-hairline bg-surface p-4">
                  <AlertApp
                    id="playground-interactive-alert"
                    variant={playVariant}
                    size={playSize}
                    rounded={playRounded}
                    theme={playTheme}
                  >
                    <AlertIconApp id="playground-interactive-alert-icon">
                      {getVariantIcon(playVariant)}
                    </AlertIconApp>
                    <div className="flex-1">
                      <AlertTitleApp id="playground-interactive-alert-title">{playTitle}</AlertTitleApp>
                      <AlertDescriptionApp id="playground-interactive-alert-desc">{playDesc}</AlertDescriptionApp>
                    </div>
                    {showAction && (
                      <AlertActionApp id="playground-interactive-alert-action">
                        <ButtonApp id="playground-interactive-alert-action-btn" variant="secondary" size="sm">
                          Selesaikan
                        </ButtonApp>
                      </AlertActionApp>
                    )}
                  </AlertApp>
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="alert-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeString}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
