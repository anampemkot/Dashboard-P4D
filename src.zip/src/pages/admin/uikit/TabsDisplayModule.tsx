import * as React from "react";
import {
  TabsApp,
  TabsListApp,
  TabsTriggerApp,
  TabsContentApp,
  CardApp,
  TextApp,
  ButtonApp,
  TabItem,
  TabsVariant,
  TabsOrientation,
  TabsSize,
  TabsRounded,
} from "@/packages/design-system";
import {
  Layers,
  User,
  Shield,
  Bell,
  Settings,
  CheckCircle2,
  Code,
  Check,
  Zap,
  HelpCircle,
} from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

export function TabsDisplayModule() {
  const [variant, setVariant] = React.useState<TabsVariant>("underline");
  const [size, setSize] = React.useState<TabsSize>("md");
  const [orientation, setOrientation] = React.useState<TabsOrientation>("horizontal");
  const [rounded, setRounded] = React.useState<TabsRounded>("lg");
  const [copied, setCopied] = React.useState(false);

  const sampleTabItems: TabItem[] = [
    {
      id: "account",
      label: "Akun",
      icon: <User className="w-4 h-4" />,
      badge: "Pribadi",
      badgeVariant: "neutral",
      content: (
        <CardApp id="card-tab-acc" variant="neutral" size="sm" rounded="card" className="space-y-2">
          <TextApp id="tab-acc-h" variant="h4" weight="bold" className="text-slate-900 dark:text-slate-100">
            Pengaturan Akun Pengguna
          </TextApp>
          <TextApp id="tab-acc-p" variant="body" color="secondary" className="text-xs">
            Atur nama lengkap, foto profil, zona waktu, dan preferensi bahasa aplikasi Anda di sini.
          </TextApp>
        </CardApp>
      ),
    },
    {
      id: "security",
      label: "Keamanan",
      icon: <Shield className="w-4 h-4" />,
      badge: "Aman",
      badgeVariant: "success",
      content: (
        <CardApp id="card-tab-sec" variant="neutral" size="sm" rounded="card" className="space-y-2">
          <TextApp id="tab-sec-h" variant="h4" weight="bold" className="text-slate-900 dark:text-slate-100">
            Keamanan &amp; Otentikasi
          </TextApp>
          <TextApp id="tab-sec-p" variant="body" color="secondary" className="text-xs">
            Status otentikasi 2-Langkah (2FA) aktif. Sesi login saat ini terenkripsi secara aman.
          </TextApp>
        </CardApp>
      ),
    },
    {
      id: "notifications",
      label: "Notifikasi",
      icon: <Bell className="w-4 h-4" />,
      badge: 12,
      badgeVariant: "vibrantPurple",
      content: (
        <CardApp id="card-tab-notif" variant="neutral" size="sm" rounded="card" className="space-y-2">
          <TextApp id="tab-notif-h" variant="h4" weight="bold" className="text-slate-900 dark:text-slate-100">
            Pemberitahuan Sistem
          </TextApp>
          <TextApp id="tab-notif-p" variant="body" color="secondary" className="text-xs">
            Anda memiliki 12 notifikasi baru yang belum dibaca dari aktivitas tim minggu ini.
          </TextApp>
        </CardApp>
      ),
    },
  ];

  const codeSnippet = `<TabsApp\n  id="my-navigation-tabs"\n  variant="${variant}"\n  orientation="${orientation}"\n  size="${size}"\n  rounded="${rounded}"\n  items={sampleTabItems}\n/>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-tabs-module"
      icon={<Layers className="w-5 h-5 text-vibrant-purple-dark" />}
      title="TabsApp (Tabs Navigation)"
      description="Organism/Molecule navigasi tab fleksibel dengan dukungan varian Underline, Pills, Enclosed, layout Horizontal/Vertical, Overflow Scrollable, serta animasi Motion."
    >
      <ShowcaseGrid cols={2}>
        <ShowcaseCard
          id="tabs-showcase-underline"
          title="Horizontal Underline"
          description='variant="underline" — dengan ikon & badge'
          align="start"
          className="md:col-span-2"
          code={`<TabsApp defaultValue="profile" variant="underline" size="md">\n  <TabsListApp variant="underline">...</TabsListApp>\n  <TabsContentApp value="profile">...</TabsContentApp>\n</TabsApp>`}
        >
          <TabsApp defaultValue="profile" variant="underline" size="md">
            <TabsListApp variant="underline">
              <TabsTriggerApp value="profile" variant="underline" icon={<User className="w-4 h-4" />}>
                Profil Saya
              </TabsTriggerApp>
              <TabsTriggerApp value="security" variant="underline" icon={<Shield className="w-4 h-4" />}>
                Keamanan &amp; Akses
              </TabsTriggerApp>
              <TabsTriggerApp value="notifications" variant="underline" icon={<Bell className="w-4 h-4" />} badge="Hot" badgeVariant="danger">
                Pemberitahuan
              </TabsTriggerApp>
            </TabsListApp>

            <TabsContentApp value="profile">
              <div className="p-4 bg-surface rounded-xl border border-hairline-soft text-sm text-ink-secondary">
                Kelola identitas, alamat email utama, foto profil, dan informasi kontak Anda.
              </div>
            </TabsContentApp>
            <TabsContentApp value="security">
              <div className="p-4 bg-surface rounded-xl border border-hairline-soft text-sm text-ink-secondary">
                Atur kunci 2FA, lihat riwayat sesi login aktif, dan perbarui kata sandi secara aman.
              </div>
            </TabsContentApp>
            <TabsContentApp value="notifications">
              <div className="p-4 bg-surface rounded-xl border border-hairline-soft text-sm text-ink-secondary">
                Konfigurasi preferensi email pemberitahuan dan notifikasi aplikasi instant.
              </div>
            </TabsContentApp>
          </TabsApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tabs-showcase-pills"
          title="Pills dengan Ikon & Badge"
          description='variant="pills" rounded="full" — termasuk state disabled'
          align="start"
          className="md:col-span-2"
          code={`<TabsApp defaultValue="all" variant="pills" size="md" rounded="full">\n  <TabsListApp variant="pills" rounded="full">...</TabsListApp>\n</TabsApp>`}
        >
          <TabsApp defaultValue="all" variant="pills" size="md" rounded="full">
            <TabsListApp variant="pills" rounded="full">
              <TabsTriggerApp value="all" variant="pills" rounded="full">
                Semua Item
              </TabsTriggerApp>
              <TabsTriggerApp value="active" variant="pills" rounded="full" icon={<Zap className="w-4 h-4" />} badge={12} badgeVariant="blue">
                Aktif
              </TabsTriggerApp>
              <TabsTriggerApp value="completed" variant="pills" rounded="full" icon={<CheckCircle2 className="w-4 h-4" />} badge={48} badgeVariant="success">
                Selesai
              </TabsTriggerApp>
              <TabsTriggerApp value="archived" variant="pills" rounded="full" disabled>
                Arsip
              </TabsTriggerApp>
            </TabsListApp>

            <TabsContentApp value="all">
              <div className="p-4 bg-surface-soft/80 rounded-xl border border-hairline-soft text-sm text-ink-secondary">
                Menampilkan 60 total catatan dan tugas pekerjaan tanpa filter.
              </div>
            </TabsContentApp>
            <TabsContentApp value="active">
              <div className="p-4 bg-surface-soft/80 rounded-xl border border-hairline-soft text-sm text-ink-secondary">
                Menampilkan 12 item pekerjaan yang saat ini sedang aktif berjalan.
              </div>
            </TabsContentApp>
            <TabsContentApp value="completed">
              <div className="p-4 bg-surface-soft/80 rounded-xl border border-hairline-soft text-sm text-ink-secondary">
                Menampilkan 48 proyek yang telah berhasil diselesaikan oleh tim.
              </div>
            </TabsContentApp>
          </TabsApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tabs-showcase-vertical"
          title="Vertical Sidebar Tabs"
          description='orientation="vertical" variant="enclosed"'
          align="start"
          code={`<TabsApp defaultValue="general" orientation="vertical" variant="enclosed" size="md" rounded="lg">\n  <TabsListApp orientation="vertical">...</TabsListApp>\n</TabsApp>`}
        >
          <TabsApp defaultValue="general" orientation="vertical" variant="enclosed" size="md" rounded="lg">
            {/* Hanya lebar rail yang di-override — flex-col/justify-start/
                shrink-0 sudah dari orientation="vertical", dan space-y-* tidak
                boleh dipakai karena jaraknya sudah diatur `gap` (kalau dobel,
                spasi vertikal jadi 2× spasi horizontal). */}
            <TabsListApp variant="enclosed" rounded="lg" orientation="vertical" className="sm:w-48">
              <TabsTriggerApp value="general" variant="enclosed" rounded="lg" icon={<Settings className="w-4 h-4" />} className="justify-start">
                Umum
              </TabsTriggerApp>
              <TabsTriggerApp value="billing" variant="enclosed" rounded="lg" icon={<Layers className="w-4 h-4" />} badge="Pro" className="justify-start">
                Billing
              </TabsTriggerApp>
              <TabsTriggerApp value="help" variant="enclosed" rounded="lg" icon={<HelpCircle className="w-4 h-4" />} className="justify-start">
                Bantuan
              </TabsTriggerApp>
            </TabsListApp>

            <div className="min-w-0 flex-1">
              <TabsContentApp value="general">
                <CardApp id="vert-card-gen" variant="neutral" size="sm" rounded="lg" className="space-y-2 border border-hairline-soft bg-surface p-4">
                  <TextApp id="vert-gen-h" variant="h4" weight="bold">Konfigurasi Umum</TextApp>
                  <TextApp id="vert-gen-p" variant="body" color="secondary" className="text-xs">
                    Nama organisasi, domain API, serta tema visual dashboard.
                  </TextApp>
                </CardApp>
              </TabsContentApp>
              <TabsContentApp value="billing">
                <CardApp id="vert-card-bill" variant="neutral" size="sm" rounded="lg" className="space-y-2 border border-hairline-soft bg-surface p-4">
                  <TextApp id="vert-bill-h" variant="h4" weight="bold">Status Langganan Pro</TextApp>
                  <TextApp id="vert-bill-p" variant="body" color="secondary" className="text-xs">
                    Paket aktif hingga 31 Desember 2026. Kuota API tak terbatas.
                  </TextApp>
                </CardApp>
              </TabsContentApp>
              <TabsContentApp value="help">
                <CardApp id="vert-card-help" variant="neutral" size="sm" rounded="lg" className="space-y-2 border border-hairline-soft bg-surface p-4">
                  <TextApp id="vert-help-h" variant="h4" weight="bold">Bantuan &amp; Dokumentasi</TextApp>
                  <TextApp id="vert-help-p" variant="body" color="secondary" className="text-xs">
                    Hubungi dukungan teknis BPKAD 24/7 atau baca panduan UI Kit.
                  </TextApp>
                </CardApp>
              </TabsContentApp>
            </div>
          </TabsApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="tabs-showcase-scrollable"
          title="Scrollable Overflow"
          description="Container sempit / mobile — 6 tab pills"
          code={`<TabsApp defaultValue="t1" variant="pills" size="sm" rounded="full">\n  <TabsListApp variant="pills" rounded="full">...6 tabs...</TabsListApp>\n</TabsApp>`}
        >
          <div className="w-full overflow-x-auto rounded-xl border border-hairline-soft bg-surface-soft p-3">
            <TabsApp defaultValue="t1" variant="pills" size="sm" rounded="full">
              <TabsListApp variant="pills" rounded="full">
                <TabsTriggerApp value="t1" variant="pills" rounded="full">
                  Ikhtisar
                </TabsTriggerApp>
                <TabsTriggerApp value="t2" variant="pills" rounded="full" badge="New">
                  Analitik
                </TabsTriggerApp>
                <TabsTriggerApp value="t3" variant="pills" rounded="full">
                  Transaksi
                </TabsTriggerApp>
                <TabsTriggerApp value="t4" variant="pills" rounded="full">
                  Audit Log
                </TabsTriggerApp>
              </TabsListApp>

              <TabsContentApp value="t1">
                <div className="mt-2 rounded-lg bg-surface p-3 text-xs text-ink-secondary">
                  Konten Tab 1: Ringkasan umum performa aplikasi.
                </div>
              </TabsContentApp>
              <TabsContentApp value="t2">
                <div className="mt-2 rounded-lg bg-surface p-3 text-xs text-ink-secondary">
                  Konten Tab 2: Matriks statistik real-time.
                </div>
              </TabsContentApp>
              <TabsContentApp value="t3">
                <div className="mt-2 rounded-lg bg-surface p-3 text-xs text-ink-secondary">
                  Konten Tab 3: Daftar transaksi keuangan terverifikasi.
                </div>
              </TabsContentApp>
            </TabsApp>
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="tabs-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap TabsApp dengan kode JSX yang dihasilkan"
          align="start"
          className="md:col-span-2"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            <div className="flex flex-col gap-4">
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Variant</span>
                <div className="flex flex-wrap gap-1.5">
                  {(["underline", "pills", "enclosed", "default", "vibrant"] as const).map((v) => (
                    <PlaygroundChip key={v} id={`tabs-play-variant-${v}`} active={variant === v} onClick={() => setVariant(v)}>
                      {v}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Size</span>
                  <div className="flex flex-wrap gap-1">
                    {(["sm", "md", "lg"] as const).map((s) => (
                      <PlaygroundChip key={s} id={`tabs-play-size-${s}`} active={size === s} onClick={() => setSize(s)} className="flex-1">
                        {s}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Orientation</span>
                  <div className="flex flex-wrap gap-1">
                    {(["horizontal", "vertical"] as const).map((o) => (
                      <PlaygroundChip key={o} id={`tabs-play-orient-${o}`} active={orientation === o} onClick={() => setOrientation(o)} className="flex-1">
                        {o}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Rounded</span>
                <div className="flex flex-wrap gap-1">
                  {(["none", "sm", "md", "lg", "xl", "full"] as const).map((r) => (
                    <PlaygroundChip key={r} id={`tabs-play-rounded-${r}`} active={rounded === r} onClick={() => setRounded(r)} className="flex-1">
                      {r}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="min-h-[160px] rounded-lg border border-dashed border-hairline bg-surface p-4">
                  <TabsApp
                    id="interactive-tabs-demo"
                    variant={variant}
                    size={size}
                    orientation={orientation}
                    rounded={rounded}
                    items={sampleTabItems}
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="tabs-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeSnippet}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
