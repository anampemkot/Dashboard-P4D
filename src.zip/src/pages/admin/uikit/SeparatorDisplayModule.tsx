import * as React from "react";
import {
  SeparatorApp,
  ButtonApp,
  DropdownApp,
  InputApp,
  BadgeApp,
  SeparatorOrientation,
  SeparatorStyle,
  SeparatorThickness,
  SeparatorVariant,
  SeparatorLabelAlign,
} from "@/packages/design-system";
import { Sparkles, Code, Check, Split } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid, ShowcaseGroup } from "./shared/ShowcaseCard";

export function SeparatorDisplayModule() {
  // Playground state
  const [playOrientation, setPlayOrientation] = React.useState<SeparatorOrientation>("horizontal");
  const [playStyle, setPlayStyle] = React.useState<SeparatorStyle>("solid");
  const [playThickness, setPlayThickness] = React.useState<SeparatorThickness>("1px");
  const [playVariant, setPlayVariant] = React.useState<SeparatorVariant>("vibrant");
  const [playLabel, setPlayLabel] = React.useState("ATAU (OR)");
  const [playLabelAlign, setPlayLabelAlign] = React.useState<SeparatorLabelAlign>("center");
  const [copied, setCopied] = React.useState(false);

  const labelPropStr = playLabel.trim() ? `\n  label="${playLabel}"` : "";
  const alignPropStr = playLabel.trim() && playLabelAlign !== "center" ? `\n  labelAlign="${playLabelAlign}"` : "";

  const codeSnippet = `<SeparatorApp
  id="my-separator"
  orientation="${playOrientation}"
  styleType="${playStyle}"
  thickness="${playThickness}"
  variant="${playVariant}"${labelPropStr}${alignPropStr}
/>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-separator-module"
      icon={<Split className="w-5 h-5 text-vibrant-purple-dark" />}
      title="SeparatorApp"
      description="Garis pemisah visual untuk membedakan blok konten. Mendukung orientasi horizontal/vertical, label teks & alignment, ketebalan, pola garis, dan varian warna semantik — P4D BPKAD Kota Yogyakarta."
    >
      {/*
        Kartu lama mencampur beberapa prop sekaligus per contoh. Dipecah per
        axis; "colors" flatten jadi variant-* (9 nilai, neutral+brand+
        semantic dalam satu union prop). style/thickness/colors dinormalkan
        ke thickness="1px" tanpa label supaya hanya sumbunya yang berbeda.
      */}
      <ShowcaseGroup id="separator-group-orientation" title="Orientasi" description="horizontal (default) · vertical" cols={2}>
        <ShowcaseCard
          id="separator-showcase-orientation-horizontal"
          title="Orientasi horizontal"
          description="Membagi baris konten secara mendatar"
          code={`<SeparatorApp id="s" variant="subtle" />`}
        >
          <div className="w-full max-w-sm">
            <div className="text-xs mb-2 text-ink-secondary">Elemen Konten Atas</div>
            <SeparatorApp id="separator-showcase-orientation-horizontal-demo" variant="subtle" />
            <div className="text-xs mt-2 text-ink-secondary">Elemen Konten Bawah</div>
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="separator-showcase-orientation-vertical"
          title="Orientasi vertical"
          description="Membagi kolom konten secara tegak"
          code={`<SeparatorApp id="s" orientation="vertical" className="h-10" variant="subtle" />`}
        >
          <div className="flex items-center justify-center gap-4 h-20">
            <div className="text-xs text-ink-secondary">Konten Kiri</div>
            <SeparatorApp id="separator-showcase-orientation-vertical-demo" orientation="vertical" variant="subtle" className="h-16" />
            <div className="text-xs text-ink-secondary">Konten Kanan</div>
          </div>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="separator-group-label-align" title="Text Label — Alignment" description="labelAlign: center (default) · start · end" cols={3}>
        <ShowcaseCard
          id="separator-showcase-label-align-center"
          title="labelAlign center"
          description="Label di tengah — default katalog"
          code={`<SeparatorApp id="s" label="Judul Bagian" labelAlign="center" variant="subtle" />`}
        >
          <SeparatorApp id="separator-showcase-label-align-center-demo" label="Judul Bagian" labelAlign="center" variant="subtle" />
        </ShowcaseCard>

        <ShowcaseCard
          id="separator-showcase-label-align-start"
          title="labelAlign start"
          description="Label rata kiri/atas"
          code={`<SeparatorApp id="s" label="Judul Bagian" labelAlign="start" variant="subtle" />`}
        >
          <SeparatorApp id="separator-showcase-label-align-start-demo" label="Judul Bagian" labelAlign="start" variant="subtle" />
        </ShowcaseCard>

        <ShowcaseCard
          id="separator-showcase-label-align-end"
          title="labelAlign end"
          description="Label rata kanan/bawah"
          code={`<SeparatorApp id="s" label="Judul Bagian" labelAlign="end" variant="subtle" />`}
        >
          <SeparatorApp id="separator-showcase-label-align-end-demo" label="Judul Bagian" labelAlign="end" variant="subtle" />
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGrid cols={1}>
        <ShowcaseCard
          id="separator-showcase-label-custom-node"
          title="Label custom node"
          description="label menerima ReactNode, bukan cuma teks — di sini sebuah BadgeApp"
          code={`<SeparatorApp id="s" label={<BadgeApp variant="solidPurple">Label</BadgeApp>} variant="vibrant" thickness="2px" />`}
        >
          <SeparatorApp
            id="separator-showcase-label-custom-node-demo"
            label={
              <BadgeApp id="separator-showcase-label-custom-node-badge" variant="solidPurple" size="sm" icon={<Sparkles className="w-3 h-3" />}>
                REKAPITULASI BPKAD 2026
              </BadgeApp>
            }
            variant="vibrant"
            thickness="2px"
          />
        </ShowcaseCard>

      </ShowcaseGrid>

      <ShowcaseGroup id="separator-group-style" title="Style Pola Garis" description="styleType: solid (default) · dashed · dotted — semua variant=&quot;subtle&quot; thickness=&quot;1px&quot; tanpa label agar hanya pola yang berbeda" cols={3}>
        <ShowcaseCard
          id="separator-showcase-style-solid"
          title="styleType solid"
          description="Garis penuh — default katalog"
          code={`<SeparatorApp id="s" styleType="solid" variant="subtle" />`}
        >
          <SeparatorApp id="separator-showcase-style-solid-demo" styleType="solid" variant="subtle" thickness="1px" />
        </ShowcaseCard>

        <ShowcaseCard
          id="separator-showcase-style-dashed"
          title="styleType dashed"
          description="Garis putus-putus"
          code={`<SeparatorApp id="s" styleType="dashed" variant="subtle" />`}
        >
          <SeparatorApp id="separator-showcase-style-dashed-demo" styleType="dashed" variant="subtle" thickness="1px" />
        </ShowcaseCard>

        <ShowcaseCard
          id="separator-showcase-style-dotted"
          title="styleType dotted"
          description="Garis titik-titik"
          code={`<SeparatorApp id="s" styleType="dotted" variant="subtle" />`}
        >
          <SeparatorApp id="separator-showcase-style-dotted-demo" styleType="dotted" variant="subtle" thickness="1px" />
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="separator-group-thickness" title="Skala Ketebalan" description="thickness: 1px (halus, default) · 2px (sedang) · 4px (tebal) — semua variant=&quot;subtle&quot; tanpa label" cols={3}>
        <ShowcaseCard
          id="separator-showcase-thickness-1px"
          title="thickness 1px"
          description="Garis paling halus — default katalog"
          code={`<SeparatorApp id="s" thickness="1px" variant="subtle" />`}
        >
          <SeparatorApp id="separator-showcase-thickness-1px-demo" thickness="1px" variant="subtle" />
        </ShowcaseCard>

        <ShowcaseCard
          id="separator-showcase-thickness-2px"
          title="thickness 2px"
          description="Garis sedang"
          code={`<SeparatorApp id="s" thickness="2px" variant="subtle" />`}
        >
          <SeparatorApp id="separator-showcase-thickness-2px-demo" thickness="2px" variant="subtle" />
        </ShowcaseCard>

        <ShowcaseCard
          id="separator-showcase-thickness-4px"
          title="thickness 4px"
          description="Garis paling tebal"
          code={`<SeparatorApp id="s" thickness="4px" variant="subtle" />`}
        >
          <SeparatorApp id="separator-showcase-thickness-4px-demo" thickness="4px" variant="subtle" />
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="separator-group-variant" title="Variant — Warna" description="subtle · soft · hard · vibrant · brand · success · warning · error · info — semua thickness=&quot;1px&quot; tanpa label" cols={5}>
        <ShowcaseCard
          id="separator-showcase-variant-subtle"
          title="Variant subtle"
          description="Hairline paling samar — default katalog"
          code={`<SeparatorApp id="s" variant="subtle" />`}
        >
          <SeparatorApp id="separator-showcase-variant-subtle-demo" variant="subtle" thickness="1px" />
        </ShowcaseCard>

        <ShowcaseCard
          id="separator-showcase-variant-soft"
          title="Variant soft"
          description="Neutral lembut"
          code={`<SeparatorApp id="s" variant="soft" />`}
        >
          <SeparatorApp id="separator-showcase-variant-soft-demo" variant="soft" thickness="1px" />
        </ShowcaseCard>

        <ShowcaseCard
          id="separator-showcase-variant-hard"
          title="Variant hard"
          description="Neutral tegas"
          code={`<SeparatorApp id="s" variant="hard" />`}
        >
          <SeparatorApp id="separator-showcase-variant-hard-demo" variant="hard" thickness="1px" />
        </ShowcaseCard>

        <ShowcaseCard
          id="separator-showcase-variant-vibrant"
          title="Variant vibrant"
          description="Aksen ungu brand pekat"
          code={`<SeparatorApp id="s" variant="vibrant" />`}
        >
          <SeparatorApp id="separator-showcase-variant-vibrant-demo" variant="vibrant" thickness="1px" />
        </ShowcaseCard>

        <ShowcaseCard
          id="separator-showcase-variant-brand"
          title="Variant brand"
          description="Aksen ungu brand"
          code={`<SeparatorApp id="s" variant="brand" />`}
        >
          <SeparatorApp id="separator-showcase-variant-brand-demo" variant="brand" thickness="1px" />
        </ShowcaseCard>

        <ShowcaseCard
          id="separator-showcase-variant-success"
          title="Variant success"
          description="Semantik berhasil"
          code={`<SeparatorApp id="s" variant="success" />`}
        >
          <SeparatorApp id="separator-showcase-variant-success-demo" variant="success" thickness="1px" />
        </ShowcaseCard>

        <ShowcaseCard
          id="separator-showcase-variant-warning"
          title="Variant warning"
          description="Semantik peringatan"
          code={`<SeparatorApp id="s" variant="warning" />`}
        >
          <SeparatorApp id="separator-showcase-variant-warning-demo" variant="warning" thickness="1px" />
        </ShowcaseCard>

        <ShowcaseCard
          id="separator-showcase-variant-error"
          title="Variant error"
          description="Semantik gagal"
          code={`<SeparatorApp id="s" variant="error" />`}
        >
          <SeparatorApp id="separator-showcase-variant-error-demo" variant="error" thickness="1px" />
        </ShowcaseCard>

        <ShowcaseCard
          id="separator-showcase-variant-info"
          title="Variant info"
          description="Semantik informasi"
          code={`<SeparatorApp id="s" variant="info" />`}
        >
          <SeparatorApp id="separator-showcase-variant-info-demo" variant="info" thickness="1px" />
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGrid cols={1}>
        {/* Playground — span penuh */}
        <ShowcaseCard
          id="separator-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap SeparatorApp dengan kode JSX yang dihasilkan"
          align="start"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            {/* Controls */}
            <div className="flex flex-col gap-4">
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Teks Label (Opsional)</span>
                <InputApp id="sep-play-label" value={playLabel} onChange={(e) => setPlayLabel(e.target.value)} placeholder="Kosongkan jika tanpa label..." />
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Orientasi</span>
                  <DropdownApp
                    id="sep-play-orientation"
                    value={playOrientation}
                    onChange={(value) => setPlayOrientation(value as SeparatorOrientation)}
                    options={[
                      { value: "horizontal", label: "Horizontal (Baris)" },
                      { value: "vertical", label: "Vertical (Kolom)" },
                    ]}
                  />
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Posisi Label</span>
                  <DropdownApp
                    id="sep-play-align"
                    value={playLabelAlign}
                    onChange={(value) => setPlayLabelAlign(value as SeparatorLabelAlign)}
                    options={[
                      { value: "center", label: "Center (Tengah)" },
                      { value: "start", label: "Start (Kiri / Atas)" },
                      { value: "end", label: "End (Kanan / Bawah)" },
                    ]}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Pola Garis</span>
                  <DropdownApp
                    id="sep-play-style"
                    value={playStyle}
                    onChange={(value) => setPlayStyle(value as SeparatorStyle)}
                    options={[
                      { value: "solid", label: "Solid" },
                      { value: "dashed", label: "Dashed" },
                      { value: "dotted", label: "Dotted" },
                    ]}
                  />
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Ketebalan</span>
                  <DropdownApp
                    id="sep-play-thick"
                    value={playThickness}
                    onChange={(value) => setPlayThickness(value as SeparatorThickness)}
                    options={[
                      { value: "1px", label: "1px (Halus)" },
                      { value: "2px", label: "2px (Sedang)" },
                      { value: "4px", label: "4px (Tebal)" },
                    ]}
                  />
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Warna Line</span>
                  <DropdownApp
                    id="sep-play-variant"
                    value={playVariant}
                    onChange={(value) => setPlayVariant(value as SeparatorVariant)}
                    options={[
                      { value: "vibrant", label: "Vibrant Purple" },
                      { value: "brand", label: "Brand Purple" },
                      { value: "subtle", label: "Subtle Hairline" },
                      { value: "soft", label: "Soft Neutral" },
                      { value: "hard", label: "Hard Neutral" },
                      { value: "success", label: "Success Green" },
                      { value: "warning", label: "Warning Amber" },
                      { value: "error", label: "Error Red" },
                      { value: "info", label: "Info Sky" },
                    ]}
                  />
                </div>
              </div>
            </div>

            {/* Live Output & Code */}
            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[120px] items-center justify-center rounded-lg border border-dashed border-hairline bg-surface p-4">
                  {playOrientation === "horizontal" ? (
                    <div className="w-full max-w-lg">
                      <div className="text-xs mb-2 text-center text-ink-secondary">Elemen Konten Atas</div>
                      <SeparatorApp
                        id="playground-interactive-separator"
                        orientation={playOrientation}
                        styleType={playStyle}
                        thickness={playThickness}
                        variant={playVariant}
                        label={playLabel || undefined}
                        labelAlign={playLabelAlign}
                      />
                      <div className="text-xs mt-2 text-center text-ink-secondary">Elemen Konten Bawah</div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center gap-4 h-32">
                      <div className="text-xs text-ink-secondary">Konten Kiri</div>
                      <SeparatorApp
                        id="playground-interactive-separator-v"
                        orientation={playOrientation}
                        styleType={playStyle}
                        thickness={playThickness}
                        variant={playVariant}
                        label={playLabel || undefined}
                        labelAlign={playLabelAlign}
                        className="h-28"
                      />
                      <div className="text-xs text-ink-secondary">Konten Kanan</div>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="copy-sep-code"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeSnippet}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
