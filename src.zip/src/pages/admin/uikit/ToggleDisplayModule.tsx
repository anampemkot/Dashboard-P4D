import * as React from "react";
import {
  ToggleApp,
  ButtonApp,
  InputApp,
  ToggleSize,
  ToggleActiveColor,
  ToggleInactiveColor,
  ToggleLabelPosition,
} from "@/packages/design-system";
import { ToggleLeft, Code, Check, X, Sun, Moon, Lock } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid, ShowcaseGroup } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

const SIZES: ToggleSize[] = ["sm", "md", "lg"];
const ACTIVE_COLORS: ToggleActiveColor[] = ["vibrantPurple", "brand", "success", "danger", "warning", "info", "sky", "dark"];
const INACTIVE_COLORS: ToggleInactiveColor[] = ["neutral", "slate", "muted"];
const THUMB_COLORS = ["white", "neutral", "dark"] as const;

export function ToggleDisplayModule() {
  // Playground state
  const [playChecked, setPlayChecked] = React.useState(true);
  const [playSize, setPlaySize] = React.useState<ToggleSize>("md");
  const [playActiveColor, setPlayActiveColor] = React.useState<ToggleActiveColor>("vibrantPurple");
  const [playInactiveColor, setPlayInactiveColor] = React.useState<ToggleInactiveColor>("neutral");
  const [playThumbColor, setPlayThumbColor] = React.useState<(typeof THUMB_COLORS)[number]>("white");
  const [playHasIcon, setPlayHasIcon] = React.useState(true);
  const [playHasText, setPlayHasText] = React.useState(false);
  const [playTextOn, setPlayTextOn] = React.useState("ON");
  const [playTextOff, setPlayTextOff] = React.useState("OFF");
  const [playLabel, setPlayLabel] = React.useState("Notifikasi Real-time PBB");
  const [playSublabel, setPlaySublabel] = React.useState("Kirim pemberitahuan otomatis saat penetapan SPPT terbit.");
  const [playLabelPos, setPlayLabelPos] = React.useState<ToggleLabelPosition>("right");
  const [playDisabled, setPlayDisabled] = React.useState(false);
  const [copied, setCopied] = React.useState(false);

  // Individual demo states for interactive sections
  const [themeDark, setThemeDark] = React.useState(true);
  const [notifyOn, setNotifyOn] = React.useState(true);
  const [textToggle, setTextToggle] = React.useState(true);

  // Generate code snippet string
  const iconStr = playHasIcon
    ? `\n  iconOn={<Check className="w-3.5 h-3.5 text-emerald-600" />}\n  iconOff={<X className="w-3.5 h-3.5 text-rose-500" />}`
    : "";
  const textStr = playHasText ? `\n  textOn="${playTextOn}"\n  textOff="${playTextOff}"` : "";
  const labelStr = playLabel.trim() ? `\n  label="${playLabel}"` : "";
  const sublabelStr = playSublabel.trim() ? `\n  sublabel="${playSublabel}"` : "";
  const labelPosStr = playLabelPos !== "right" ? `\n  labelPosition="${playLabelPos}"` : "";
  const disabledStr = playDisabled ? `\n  disabled` : "";
  const sizeStr = playSize !== "md" ? `\n  size="${playSize}"` : "";
  const activeColorStr = playActiveColor !== "vibrantPurple" ? `\n  activeColor="${playActiveColor}"` : "";
  const inactiveColorStr = playInactiveColor !== "neutral" ? `\n  inactiveColor="${playInactiveColor}"` : "";
  const thumbColorStr = playThumbColor !== "white" ? `\n  thumbColor="${playThumbColor}"` : "";

  const codeSnippet = `<ToggleApp
  id="my-toggle"
  checked={${playChecked}}
  onCheckedChange={(checked) => console.log(checked)}${sizeStr}${activeColorStr}${inactiveColorStr}${thumbColorStr}${iconStr}${textStr}${labelStr}${sublabelStr}${labelPosStr}${disabledStr}
/>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-toggle-module"
      icon={<ToggleLeft className="w-5 h-5 text-vibrant-purple-dark" />}
      title="ToggleApp"
      description="Saklar ON/OFF interaktif untuk mengubah opsi konfigurasi dan preferensi sistem secara instan — mendukung ikon, teks track, palet warna, ukuran, posisi label, dan status disabled."
    >
      {/*
        "Varian Inti" mencampur 3 kapabilitas berbeda (default, iconOn/
        iconOff, textOn/textOff) dalam satu kartu. Dipecah per kapabilitas.
      */}
      <ShowcaseGrid cols={2}>
        <ShowcaseCard
          id="toggle-showcase-default"
          title="Default"
          description="Saklar polos tanpa ikon/teks tambahan"
          code={`<ToggleApp id="tg" checked={v} onCheckedChange={setV} />`}
        >
          <div className="flex w-full items-center justify-between rounded-lg bg-surface-soft/60 p-3 text-left">
            <span className="text-xs font-medium text-ink">Fitur Otomatisasi</span>
            <ToggleApp id="toggle-showcase-default-demo" checked={notifyOn} onCheckedChange={setNotifyOn} activeColor="vibrantPurple" />
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="toggle-showcase-icon"
          title="Icon On/Off"
          description="Ikon berbeda di setiap state track"
          code={`<ToggleApp id="tg" iconOn={<Moon />} iconOff={<Sun />} />`}
        >
          <div className="flex w-full items-center justify-between rounded-lg bg-surface-soft/60 p-3 text-left">
            <span className="text-xs font-medium text-ink">Mode Gelap / Terang</span>
            <ToggleApp
              id="toggle-showcase-icon-demo"
              checked={themeDark}
              onCheckedChange={setThemeDark}
              activeColor="dark"
              iconOn={<Moon className="w-3.5 h-3.5 text-amber-300 fill-amber-300" />}
              iconOff={<Sun className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />}
            />
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="toggle-showcase-track-text"
          title="Track Text"
          description="Label teks singkat di dalam track"
          code={`<ToggleApp id="tg" textOn="YA" textOff="TDK" />`}
        >
          <div className="flex w-full items-center justify-between rounded-lg bg-surface-soft/60 p-3 text-left">
            <span className="text-xs font-medium text-ink">Status Verifikasi</span>
            <ToggleApp id="toggle-showcase-track-text-demo" checked={textToggle} onCheckedChange={setTextToggle} size="lg" activeColor="success" textOn="YA" textOff="TDK" />
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>

      <ShowcaseGroup id="toggle-group-size" title="Ukuran" description="sm 36×20 · md (default) · lg 60×32" cols={3}>
        <ShowcaseCard
          id="toggle-showcase-size-sm"
          title="Ukuran sm"
          description='label="Opsi Kompak"'
          code={`<ToggleApp id="tg" size="sm" defaultChecked label="..." />`}
        >
          <ToggleApp id="toggle-showcase-size-sm-demo" size="sm" defaultChecked activeColor="vibrantPurple" label="Opsi Kompak" />
        </ShowcaseCard>

        <ShowcaseCard
          id="toggle-showcase-size-md"
          title="Ukuran md"
          description='label="Opsi Standar"'
          code={`<ToggleApp id="tg" size="md" defaultChecked label="..." />`}
        >
          <ToggleApp id="toggle-showcase-size-md-demo" size="md" defaultChecked activeColor="vibrantPurple" label="Opsi Standar" />
        </ShowcaseCard>

        <ShowcaseCard
          id="toggle-showcase-size-lg"
          title="Ukuran lg"
          description='label="Opsi Menonjol"'
          code={`<ToggleApp id="tg" size="lg" defaultChecked label="..." />`}
        >
          <ToggleApp id="toggle-showcase-size-lg-demo" size="lg" defaultChecked activeColor="vibrantPurple" label="Opsi Menonjol" />
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="toggle-group-active-color" title="Active Track Color" description="vibrantPurple · brand · success · danger · warning · info · sky · dark" cols={4}>
        <ShowcaseCard
          id="toggle-showcase-active-color-vibrant-purple"
          title="Active color vibrantPurple"
          description='activeColor="vibrantPurple"'
          code={`<ToggleApp id="tg" activeColor="vibrantPurple" defaultChecked />`}
        >
          <ToggleApp id="toggle-showcase-active-color-vibrant-purple-demo" activeColor="vibrantPurple" defaultChecked size="sm" />
        </ShowcaseCard>

        <ShowcaseCard
          id="toggle-showcase-active-color-brand"
          title="Active color brand"
          description='activeColor="brand"'
          code={`<ToggleApp id="tg" activeColor="brand" defaultChecked />`}
        >
          <ToggleApp id="toggle-showcase-active-color-brand-demo" activeColor="brand" defaultChecked size="sm" />
        </ShowcaseCard>

        <ShowcaseCard
          id="toggle-showcase-active-color-success"
          title="Active color success"
          description='activeColor="success"'
          code={`<ToggleApp id="tg" activeColor="success" defaultChecked />`}
        >
          <ToggleApp id="toggle-showcase-active-color-success-demo" activeColor="success" defaultChecked size="sm" />
        </ShowcaseCard>

        <ShowcaseCard
          id="toggle-showcase-active-color-danger"
          title="Active color danger"
          description='activeColor="danger"'
          code={`<ToggleApp id="tg" activeColor="danger" defaultChecked />`}
        >
          <ToggleApp id="toggle-showcase-active-color-danger-demo" activeColor="danger" defaultChecked size="sm" />
        </ShowcaseCard>

        <ShowcaseCard
          id="toggle-showcase-active-color-warning"
          title="Active color warning"
          description='activeColor="warning"'
          code={`<ToggleApp id="tg" activeColor="warning" defaultChecked />`}
        >
          <ToggleApp id="toggle-showcase-active-color-warning-demo" activeColor="warning" defaultChecked size="sm" />
        </ShowcaseCard>

        <ShowcaseCard
          id="toggle-showcase-active-color-info"
          title="Active color info"
          description='activeColor="info"'
          code={`<ToggleApp id="tg" activeColor="info" defaultChecked />`}
        >
          <ToggleApp id="toggle-showcase-active-color-info-demo" activeColor="info" defaultChecked size="sm" />
        </ShowcaseCard>

        <ShowcaseCard
          id="toggle-showcase-active-color-sky"
          title="Active color sky"
          description='activeColor="sky"'
          code={`<ToggleApp id="tg" activeColor="sky" defaultChecked />`}
        >
          <ToggleApp id="toggle-showcase-active-color-sky-demo" activeColor="sky" defaultChecked size="sm" />
        </ShowcaseCard>

        <ShowcaseCard
          id="toggle-showcase-active-color-dark"
          title="Active color dark"
          description='activeColor="dark"'
          code={`<ToggleApp id="tg" activeColor="dark" defaultChecked />`}
        >
          <ToggleApp id="toggle-showcase-active-color-dark-demo" activeColor="dark" defaultChecked size="sm" />
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="toggle-group-inactive-color" title="Inactive Track Color" description="neutral (default) · slate · muted" cols={3}>
        <ShowcaseCard
          id="toggle-showcase-inactive-color-neutral"
          title="Inactive color neutral"
          description='inactiveColor="neutral"'
          code={`<ToggleApp id="tg" inactiveColor="neutral" checked={false} />`}
        >
          <ToggleApp id="toggle-showcase-inactive-color-neutral-demo" inactiveColor="neutral" checked={false} size="sm" />
        </ShowcaseCard>

        <ShowcaseCard
          id="toggle-showcase-inactive-color-slate"
          title="Inactive color slate"
          description='inactiveColor="slate"'
          code={`<ToggleApp id="tg" inactiveColor="slate" checked={false} />`}
        >
          <ToggleApp id="toggle-showcase-inactive-color-slate-demo" inactiveColor="slate" checked={false} size="sm" />
        </ShowcaseCard>

        <ShowcaseCard
          id="toggle-showcase-inactive-color-muted"
          title="Inactive color muted"
          description='inactiveColor="muted"'
          code={`<ToggleApp id="tg" inactiveColor="muted" checked={false} />`}
        >
          <ToggleApp id="toggle-showcase-inactive-color-muted-demo" inactiveColor="muted" checked={false} size="sm" />
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="toggle-group-label-position" title="Posisi Label" description="right (default) · left" cols={2}>
        <ShowcaseCard
          id="toggle-showcase-label-position-right"
          title="labelPosition right"
          description="Label di sisi kanan saklar — default katalog"
          code={`<ToggleApp id="tg" labelPosition="right" defaultChecked label="..." sublabel="..." />`}
        >
          <ToggleApp id="toggle-showcase-label-position-right-demo" labelPosition="right" defaultChecked label="Label di Kanan (Default)" sublabel="Posisi standar untuk formulir bertingkat." />
        </ShowcaseCard>

        <ShowcaseCard
          id="toggle-showcase-label-position-left"
          title="labelPosition left"
          description="Label di sisi kiri, saklar rata kanan"
          code={`<ToggleApp id="tg" labelPosition="left" defaultChecked label="..." />`}
        >
          <ToggleApp
            id="toggle-showcase-label-position-left-demo"
            labelPosition="left"
            defaultChecked
            containerClassName="w-full justify-between"
            label="Label di Kiri (Justified)"
            sublabel="Memberikan ruang rata kanan untuk saklar."
          />
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="toggle-group-disabled" title="Disabled" description="disabled ON · disabled OFF" cols={2}>
        <ShowcaseCard
          id="toggle-showcase-disabled-on"
          title="Disabled ON"
          description="Terkunci dalam keadaan aktif"
          code={`<ToggleApp id="tg" disabled defaultChecked label="..." />`}
        >
          <ToggleApp
            id="toggle-showcase-disabled-on-demo"
            disabled
            defaultChecked
            label="Fitur Terkunci (Disabled ON)"
            sublabel="Opsi ini diaktifkan secara permanen oleh admin."
            iconOn={<Lock className="w-3 h-3 text-zinc-500" />}
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="toggle-showcase-disabled-off"
          title="Disabled OFF"
          description="Terkunci dalam keadaan nonaktif"
          code={`<ToggleApp id="tg" disabled checked={false} label="..." />`}
        >
          <ToggleApp id="toggle-showcase-disabled-off-demo" disabled checked={false} label="Akses Nonaktif (Disabled OFF)" sublabel="Anda memerlukan izin tambahan untuk mengaktifkan ini." />
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGrid cols={1}>
        <ShowcaseCard
          id="toggle-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap ToggleApp dengan kode JSX yang dihasilkan"
          align="start"
          className="md:col-span-2"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            <div className="flex flex-col gap-4">
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Label Text</span>
                <InputApp id="tg-play-lbl" size="sm" rounded="lg" value={playLabel} onChange={(e) => setPlayLabel(e.target.value)} placeholder="Teks label saklar..." />
              </div>
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Sublabel / Description</span>
                <InputApp id="tg-play-sublbl" size="sm" rounded="lg" value={playSublabel} onChange={(e) => setPlaySublabel(e.target.value)} placeholder="Penjelasan subteks..." />
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Size</span>
                <div className="flex gap-1.5">
                  {SIZES.map((s) => (
                    <PlaygroundChip key={s} id={`tg-play-size-${s}`} active={playSize === s} onClick={() => setPlaySize(s)} className="flex-1">
                      {s}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Label Position</span>
                <div className="flex gap-1.5">
                  {(["right", "left"] as const).map((p) => (
                    <PlaygroundChip key={p} id={`tg-play-pos-${p}`} active={playLabelPos === p} onClick={() => setPlayLabelPos(p)} className="flex-1">
                      {p}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Active Color</span>
                <div className="flex flex-wrap gap-1.5">
                  {ACTIVE_COLORS.map((c) => (
                    <PlaygroundChip key={c} id={`tg-play-actcol-${c}`} active={playActiveColor === c} onClick={() => setPlayActiveColor(c)}>
                      {c}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Inactive Color</span>
                  <div className="flex flex-wrap gap-1.5">
                    {INACTIVE_COLORS.map((c) => (
                      <PlaygroundChip key={c} id={`tg-play-inactcol-${c}`} active={playInactiveColor === c} onClick={() => setPlayInactiveColor(c)}>
                        {c}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Thumb Color</span>
                  <div className="flex flex-wrap gap-1.5">
                    {THUMB_COLORS.map((c) => (
                      <PlaygroundChip key={c} id={`tg-play-thumbcol-${c}`} active={playThumbColor === c} onClick={() => setPlayThumbColor(c)}>
                        {c}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                {playHasText && (
                  <>
                    <InputApp id="tg-play-txton" size="sm" rounded="lg" value={playTextOn} onChange={(e) => setPlayTextOn(e.target.value)} placeholder="Text ON" />
                    <InputApp id="tg-play-txtoff" size="sm" rounded="lg" value={playTextOff} onChange={(e) => setPlayTextOff(e.target.value)} placeholder="Text OFF" />
                  </>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Checked</span>
                  <PlaygroundChip id="tg-play-checked-toggle" active={playChecked} onClick={() => setPlayChecked((v) => !v)}>
                    {playChecked ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Icon</span>
                  <PlaygroundChip id="tg-play-hasicon-toggle" active={playHasIcon} onClick={() => setPlayHasIcon((v) => !v)}>
                    {playHasIcon ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Track Text</span>
                  <PlaygroundChip id="tg-play-hastext-toggle" active={playHasText} onClick={() => setPlayHasText((v) => !v)}>
                    {playHasText ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Disabled</span>
                  <PlaygroundChip id="tg-play-disabled-toggle" active={playDisabled} onClick={() => setPlayDisabled((v) => !v)}>
                    {playDisabled ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
              </div>
            </div>

            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[120px] items-center justify-center rounded-lg border border-dashed border-hairline bg-surface p-4">
                  <ToggleApp
                    id="playground-interactive-toggle"
                    checked={playChecked}
                    onCheckedChange={setPlayChecked}
                    size={playSize}
                    activeColor={playActiveColor}
                    inactiveColor={playInactiveColor}
                    thumbColor={playThumbColor}
                    iconOn={playHasIcon ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : undefined}
                    iconOff={playHasIcon ? <X className="w-3.5 h-3.5 text-rose-500" /> : undefined}
                    textOn={playHasText ? playTextOn : undefined}
                    textOff={playHasText ? playTextOff : undefined}
                    label={playLabel || undefined}
                    sublabel={playSublabel || undefined}
                    labelPosition={playLabelPos}
                    disabled={playDisabled}
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="tg-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeSnippet}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
