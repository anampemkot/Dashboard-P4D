import * as React from "react";
import { ButtonApp, SliderApp } from "@/packages/design-system";
import { Sliders, Code, Check } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

const VARIANTS = ["default", "brand", "vibrant", "success", "warning", "error"] as const;
const SIZES = ["sm", "md", "lg"] as const;
const ROUNDED = ["none", "sm", "md", "lg", "xl", "full"] as const;

export function SliderDisplayModule() {
  // Showcase state
  const [singleValue, setSingleValue] = React.useState<number>(45);
  const [dualValue, setDualValue] = React.useState<[number, number]>([20, 75]);
  const [ticksValue, setTicksValue] = React.useState<number>(60);
  const [volumeValue, setVolumeValue] = React.useState<number>(80);

  // Playground state
  const [playIsRange, setPlayIsRange] = React.useState<boolean>(false);
  const [playValueSingle, setPlayValueSingle] = React.useState<number>(50);
  const [playValueDual, setPlayValueDual] = React.useState<[number, number]>([30, 80]);
  const [playVariant, setPlayVariant] = React.useState<(typeof VARIANTS)[number]>("default");
  const [playSize, setPlaySize] = React.useState<(typeof SIZES)[number]>("md");
  const [playRounded, setPlayRounded] = React.useState<(typeof ROUNDED)[number]>("full");
  const [playShowTooltip] = React.useState<boolean | "always" | "hover">("always");
  const [playShowMarks, setPlayShowMarks] = React.useState<boolean>(true);
  const [playShowMinMax, setPlayShowMinMax] = React.useState<boolean>(true);
  const [playDisabled, setPlayDisabled] = React.useState<boolean>(false);
  const [copied, setCopied] = React.useState<boolean>(false);

  const valuePropStr = playIsRange ? `[${playValueDual[0]}, ${playValueDual[1]}]` : `${playValueSingle}`;

  const codeString = `<SliderApp\n  id="demo-slider"\n  label="${playIsRange ? "Rentang Anggaran Retribusi" : "Kapasitas Server SKPD"}"\n  value={${valuePropStr}}\n  min={0}\n  max={100}\n  variant="${playVariant}"\n  size="${playSize}"\n  rounded="${playRounded}"\n  showTooltip={${typeof playShowTooltip === "string" ? `"${playShowTooltip}"` : playShowTooltip}}\n  showMarks={${playShowMarks}}\n  showMinMax={${playShowMinMax}}${playDisabled ? "\n  disabled" : ""}\n/>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-slider-module"
      icon={<Sliders className="w-5 h-5 text-vibrant-purple-dark" />}
      title="SliderApp"
      description="Komponen pengatur nilai numerik diskrit/kontinu dengan track pengisi aktif, thumb drag handle, floating value tooltip, step marks indicator, serta mode single & dual range."
    >
      <ShowcaseGrid cols={2}>
        <ShowcaseCard
          id="slider-showcase-single"
          title="Single Value Slider"
          description="Default variant, showMinMax, showTooltip always"
          code={`<SliderApp id="sld" value={value} onChange={setValue} min={0} max={100} showMinMax showTooltip="always" />`}
        >
          <SliderApp
            id="sld-demo-single"
            label="Batas Maksimal Penggunaan Memori (RAM)"
            description="Geser untuk menentukan kuota alokasi memori server"
            value={singleValue}
            onChange={(v) => setSingleValue(v as number)}
            min={0}
            max={100}
            showMinMax
            showTooltip="always"
            formatValue={(v) => `${v}%`}
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="slider-showcase-dual"
          title="Dual Range Slider"
          description="2 thumb handles (min - max), variant vibrant"
          code={`<SliderApp id="sld" value={[min, max]} onChange={setRange} variant="vibrant" showMinMax />`}
        >
          <SliderApp
            id="sld-demo-dual"
            label="Rentang Nilai Penetapan Tax Rate (% Pajak)"
            description="Pilih batas bawah dan batas atas toleransi penyesuaian tarif"
            value={dualValue}
            onChange={(v) => setDualValue(v as [number, number])}
            min={0}
            max={100}
            variant="vibrant"
            showMinMax
            showTooltip="always"
            formatValue={(v) => `${v}%`}
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="slider-showcase-marks"
          title="Discrete Step Marks"
          description="step=20, variant success, showTooltip hover"
          code={`<SliderApp id="sld" step={20} variant="success" showMarks showMinMax showTooltip="hover" />`}
        >
          <SliderApp
            id="sld-demo-ticks"
            label="Interval Pelaporan Otomatis Retribusi"
            description="Penanda diskrit per interval 20 unit"
            value={ticksValue}
            onChange={(v) => setTicksValue(v as number)}
            min={0}
            max={100}
            step={20}
            variant="success"
            showMarks
            showMinMax
            showTooltip="hover"
            formatValue={(v) => `${v} Menit`}
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="slider-showcase-warning-lg"
          title="Warning Variant & Ukuran Besar"
          description='variant="warning" · size="lg" · rounded="md"'
          code={`<SliderApp id="sld" variant="warning" size="lg" rounded="md" showMinMax />`}
        >
          <SliderApp
            id="sld-demo-volume"
            label="Ambang Batas Peringatan Notifikasi"
            description="Ketebalan track besar (lg) dengan sudut rounded-md"
            value={volumeValue}
            onChange={(v) => setVolumeValue(v as number)}
            min={0}
            max={100}
            variant="warning"
            size="lg"
            rounded="md"
            showMinMax
            showTooltip="always"
            formatValue={(v) => `${v} dB`}
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="slider-showcase-disabled-single"
          title="Disabled single"
          description="Single handle terkunci"
          code={`<SliderApp id="sld" value={30} disabled showMinMax />`}
        >
          <SliderApp
            id="slider-showcase-disabled-single-demo"
            label="Kapasitas Penyimpanan Terkunci (Disabled)"
            description="Fitur hanya dapat diubah oleh Administrator Utama"
            value={30}
            disabled
            showMinMax
            showTooltip="always"
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="slider-showcase-disabled-dual"
          title="Disabled dual"
          description="Dual range terkunci"
          code={`<SliderApp id="sld" value={[15, 65]} disabled showMinMax />`}
        >
          <SliderApp
            id="slider-showcase-disabled-dual-demo"
            label="Rentang Anggaran Terkunci (Disabled Dual)"
            description="Batas anggaran statis yang sudah disahkan APBD"
            value={[15, 65]}
            disabled
            showMinMax
            showTooltip="always"
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="slider-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap SliderApp dengan kode JSX yang dihasilkan"
          align="start"
          className="md:col-span-2"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            <div className="flex flex-col gap-4">
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Mode</span>
                <div className="flex gap-1.5">
                  <PlaygroundChip id="sld-play-mode-single" active={!playIsRange} onClick={() => setPlayIsRange(false)} className="flex-1">
                    Single Handle
                  </PlaygroundChip>
                  <PlaygroundChip id="sld-play-mode-dual" active={playIsRange} onClick={() => setPlayIsRange(true)} className="flex-1">
                    Dual Range
                  </PlaygroundChip>
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Variant</span>
                <div className="flex flex-wrap gap-1.5">
                  {VARIANTS.map((v) => (
                    <PlaygroundChip key={v} id={`sld-play-variant-${v}`} active={playVariant === v} onClick={() => setPlayVariant(v)}>
                      {v}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Size</span>
                  <div className="flex gap-1">
                    {SIZES.map((s) => (
                      <PlaygroundChip key={s} id={`sld-play-size-${s}`} active={playSize === s} onClick={() => setPlaySize(s)} className="flex-1">
                        {s}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Corner Radius</span>
                  <div className="flex flex-wrap gap-1">
                    {ROUNDED.map((r) => (
                      <PlaygroundChip key={r} id={`sld-play-rounded-${r}`} active={playRounded === r} onClick={() => setPlayRounded(r)}>
                        {r}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Tick Marks</span>
                  <PlaygroundChip id="sld-play-marks-toggle" active={playShowMarks} onClick={() => setPlayShowMarks((v) => !v)}>
                    {playShowMarks ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Min/Max Label</span>
                  <PlaygroundChip id="sld-play-minmax-toggle" active={playShowMinMax} onClick={() => setPlayShowMinMax((v) => !v)}>
                    {playShowMinMax ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Disabled</span>
                  <PlaygroundChip id="sld-play-disabled-toggle" active={playDisabled} onClick={() => setPlayDisabled((v) => !v)}>
                    {playDisabled ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
              </div>
            </div>

            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[140px] items-center justify-center rounded-lg border border-dashed border-hairline bg-surface p-6">
                  {playIsRange ? (
                    <SliderApp
                      id="interactive-slider-dual"
                      label="Interaktif Range Slider (Dual)"
                      description="Seret thumb kiri atau kanan untuk melihat perubahan"
                      value={playValueDual}
                      onChange={(v) => setPlayValueDual(v as [number, number])}
                      min={0}
                      max={100}
                      variant={playVariant}
                      size={playSize}
                      rounded={playRounded}
                      showTooltip={playShowTooltip}
                      showMarks={playShowMarks}
                      showMinMax={playShowMinMax}
                      disabled={playDisabled}
                    />
                  ) : (
                    <SliderApp
                      id="interactive-slider-single"
                      label="Interaktif Single Slider"
                      description="Seret pegangan untuk melihat tooltip bergerak"
                      value={playValueSingle}
                      onChange={(v) => setPlayValueSingle(v as number)}
                      min={0}
                      max={100}
                      variant={playVariant}
                      size={playSize}
                      rounded={playRounded}
                      showTooltip={playShowTooltip}
                      showMarks={playShowMarks}
                      showMinMax={playShowMinMax}
                      disabled={playDisabled}
                    />
                  )}
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="sld-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeString}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
