import * as React from "react";
import { ButtonApp, InputApp, TextAreaApp } from "@/packages/design-system";
import { Code, Check, FileText } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

const VARIANTS = ["default", "filled", "error", "success"] as const;
const SIZES = ["sm", "md", "lg"] as const;
const ROUNDED = ["none", "sm", "md", "lg", "xl"] as const;

export function TextAreaDisplayModule() {
  // Live Playground State
  const [playVariant, setPlayVariant] = React.useState<(typeof VARIANTS)[number]>("default");
  const [playSize, setPlaySize] = React.useState<(typeof SIZES)[number]>("md");
  const [playRounded, setPlayRounded] = React.useState<(typeof ROUNDED)[number]>("md");
  const [playAutoResize, setPlayAutoResize] = React.useState<boolean>(false);
  const [playShowMaxLength, setPlayShowMaxLength] = React.useState<boolean>(true);
  const [playDisabled, setPlayDisabled] = React.useState<boolean>(false);
  const [playPlaceholder, setPlayPlaceholder] = React.useState<string>("Ketikkan deskripsi lengkap atau catatan pelaporan di sini...");
  const [copied, setCopied] = React.useState<boolean>(false);

  const playMaxLength = 250;

  const codeString = `<TextAreaApp\n  id="my-textarea"\n  label="Catatan Pelaporan"\n  variant="${playVariant}"\n  size="${playSize}"\n  rounded="${playRounded}"${playAutoResize ? "\n  autoResize" : ""}${playShowMaxLength ? `\n  maxLength={${playMaxLength}}\n  showMaxLength` : ""}\n  placeholder="${playPlaceholder}"${playDisabled ? "\n  disabled" : ""}\n/>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-textarea-module"
      icon={<FileText className="w-5 h-5 text-vibrant-purple-dark" />}
      title="TextAreaApp"
      description="Elemen area masukan teks multibaris — auto-resize otomatis, kontrol resize handle, status validasi error/success, serta indikator hitungan karakter maksimum."
    >
      <ShowcaseGrid cols={2}>
        <ShowcaseCard
          id="textarea-showcase-standard"
          title="Standard Text Area"
          description="Tinggi tetap (fixed height) dengan clear button"
          code={`<TextAreaApp id="uraian" minRows={3} showClear />`}
        >
          <TextAreaApp
            id="textarea-demo-standard"
            label="Uraian Singkat Keberatan Pajak"
            placeholder="Jelaskan alasan pengajuan keberatan atau banding pajak..."
            helperText="Jelaskan kronologi singkat dalam 2-3 kalimat"
            minRows={3}
            showClear
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="textarea-showcase-autoresize"
          title="Auto-Resize Height"
          description="Tinggi menyesuaikan otomatis saat mengetik"
          code={`<TextAreaApp id="catatan" autoResize minRows={2} maxRows={6} />`}
        >
          <TextAreaApp
            id="textarea-demo-autoresize"
            label="Catatan Lapangan Petugas (Auto-Expand)"
            placeholder="Tinggi kolom akan menyesuaikan secara otomatis saat Anda mengetik baris baru..."
            helperText="Tinggi bertambah otomatis tanpa scrollbar internal"
            autoResize
            minRows={2}
            maxRows={6}
            defaultValue={"Baris 1: Pemeriksaan fisik lokasi objek pajak.\nBaris 2: Pemotretan denah dan batas tanah."}
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="textarea-showcase-counter"
          title="Character Counter & Max Length"
          description="Indikator jumlah karakter (120/300)"
          code={`<TextAreaApp id="alasan" maxLength={300} showMaxLength showClear />`}
        >
          <TextAreaApp
            id="textarea-demo-counter"
            label="Alasan Rekonsiliasi Piutang"
            defaultValue="Ditemukan selisih perhitungan akibat perbedaan tanggal posting transaksi kas daerah dengan bank persepsi pada triwulan II."
            maxLength={300}
            showMaxLength
            helperText="Batas karakter maksimal yang diizinkan untuk catatan"
            showClear
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="textarea-showcase-resize"
          title="Resizable Handle"
          description='resize="none" — tinggi dikunci, handle disembunyikan'
          code={`<TextAreaApp id="lampiran" resize="none" minRows={3} />`}
        >
          <TextAreaApp
            id="textarea-demo-resize"
            label="Lampiran Keterangan Tambahan (Fixed Resize)"
            placeholder="Kotak masukan ini memiliki tinggi yang dikunci (resize-none)..."
            resize="none"
            minRows={3}
            helperText="Resize handle disembunyikan menggunakan prop resize='none'"
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="textarea-showcase-variant-error"
          title="Variant error"
          description="Validasi gagal, disertai errorMessage"
          code={`<TextAreaApp id="pbb" variant="error" errorMessage="..." maxLength={200} showMaxLength />`}
        >
          <TextAreaApp
            id="textarea-showcase-variant-error-demo"
            label="Alasan Pengurangan PBB"
            defaultValue="Terjadi bencana alam"
            variant="error"
            errorMessage="Alasan wajib diisi minimal 50 karakter penjelasan detail bencana"
            maxLength={200}
            showMaxLength
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="textarea-showcase-variant-success"
          title="Variant success"
          description="Validasi berhasil, disertai successMessage"
          code={`<TextAreaApp id="restoran" variant="success" successMessage="..." />`}
        >
          <TextAreaApp
            id="textarea-showcase-variant-success-demo"
            label="Justifikasi Penetapan Pajak Restoran"
            defaultValue="Hasil verifikasi omset bulanan usaha kuliner dari data POS kasir terintegrasi sudah sesuai dengan Surat Pemberitahuan Pajak Daerah (SPTPD)."
            variant="success"
            successMessage="Justifikasi penyesuaian tarif telah diverifikasi oleh Kasie Pendaftaran"
            maxLength={500}
            showMaxLength
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="textarea-showcase-disabled"
          title="Disabled State"
          description="Read-only / terkunci saat dokumen difinalisasi"
          code={`<TextAreaApp id="sk" disabled minRows={2} />`}
        >
          <TextAreaApp
            id="textarea-demo-disabled"
            label="Ketentuan Surat Keputusan Kepala BPKAD (Terkunci)"
            defaultValue="Sesuai Peraturan Walikota Nomor 45 Tahun 2024 tentang Tata Cara Pemungutan Pajak Daerah dan Retribusi Daerah Kota Bandung."
            disabled
            minRows={2}
            helperText="Tampilan non-aktif saat dokumen telah difinalisasi dan tidak dapat diedit"
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="textarea-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap TextAreaApp dengan kode JSX yang dihasilkan"
          align="start"
          className="md:col-span-2"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            <div className="flex flex-col gap-4">
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Placeholder</span>
                <InputApp
                  id="textarea-play-placeholder"
                  size="sm"
                  value={playPlaceholder}
                  onChange={(e) => setPlayPlaceholder(e.target.value)}
                />
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Variant</span>
                <div className="flex flex-wrap gap-1.5">
                  {VARIANTS.map((v) => (
                    <PlaygroundChip key={v} id={`textarea-play-variant-${v}`} active={playVariant === v} onClick={() => setPlayVariant(v)}>
                      {v}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Size</span>
                  <div className="flex gap-1.5">
                    {SIZES.map((s) => (
                      <PlaygroundChip key={s} id={`textarea-play-size-${s}`} active={playSize === s} onClick={() => setPlaySize(s)} className="flex-1">
                        {s}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Corner Radius</span>
                  <div className="flex flex-wrap gap-1">
                    {ROUNDED.map((r) => (
                      <PlaygroundChip key={r} id={`textarea-play-rounded-${r}`} active={playRounded === r} onClick={() => setPlayRounded(r)}>
                        {r}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Auto-Resize</span>
                  <PlaygroundChip id="textarea-play-autoresize-toggle" active={playAutoResize} onClick={() => setPlayAutoResize((v) => !v)}>
                    {playAutoResize ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Max Length</span>
                  <PlaygroundChip id="textarea-play-showmax-toggle" active={playShowMaxLength} onClick={() => setPlayShowMaxLength((v) => !v)}>
                    {playShowMaxLength ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Disabled</span>
                  <PlaygroundChip id="textarea-play-disabled-toggle" active={playDisabled} onClick={() => setPlayDisabled((v) => !v)}>
                    {playDisabled ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
              </div>
            </div>

            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[140px] items-center justify-center rounded-lg border border-dashed border-hairline bg-surface p-4">
                  <TextAreaApp
                    id="interactive-textarea-output"
                    label="Catatan Lapangan Wajib Pajak"
                    variant={playVariant}
                    size={playSize}
                    rounded={playRounded}
                    autoResize={playAutoResize}
                    showMaxLength={playShowMaxLength}
                    maxLength={playShowMaxLength ? playMaxLength : undefined}
                    disabled={playDisabled}
                    placeholder={playPlaceholder}
                    helperText="Pratinjau langsung interaksi area masukan teks"
                    showClear
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="textarea-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeString}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
