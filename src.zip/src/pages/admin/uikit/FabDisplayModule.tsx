import * as React from "react";
import {
  Plus,
  Edit,
  Send,
  Sparkles,
  Download,
  FileSpreadsheet,
  QrCode,
  Layers,
  Check,
  ShieldAlert,
  Code,
} from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { FabApp, SpeedDialApp, SpeedDialAction, ButtonApp } from "@/packages/design-system";
import { ShowcaseCard, ShowcaseGrid, ShowcaseGroup } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

export function FabDisplayModule() {
  // Playground State
  const [playVariant, setPlayVariant] = React.useState<
    "primary" | "secondary" | "danger" | "yellow" | "blue" | "purpleDark"
  >("primary");
  const [playSize, setPlaySize] = React.useState<"sm" | "md" | "lg">("md");
  const [playElevation, setPlayElevation] = React.useState<"normal" | "high" | "vibrant">("vibrant");
  const [playRounded, setPlayRounded] = React.useState<"none" | "sm" | "md" | "lg" | "full">("full");
  const [isExtended, setIsExtended] = React.useState<boolean>(false);
  const [isSpeedDialMode, setIsSpeedDialMode] = React.useState<boolean>(false);
  const [speedDirection, setSpeedDirection] = React.useState<"top" | "left" | "right" | "bottom">("top");
  const [showBackdrop, setShowBackdrop] = React.useState<boolean>(false);
  const [lastActionText, setLastActionText] = React.useState<string | null>(null);
  const [copied, setCopied] = React.useState<boolean>(false);

  // Demo Speed Dial Actions
  const sampleActions: SpeedDialAction[] = [
    {
      id: "action-add",
      icon: <Plus className="w-4 h-4" />,
      label: "Buat Objek Pajak Baru",
      variant: "primary",
      onClick: () => setLastActionText("Memilih: Buat Objek Pajak Baru"),
    },
    {
      id: "action-export",
      icon: <FileSpreadsheet className="w-4 h-4" />,
      label: "Export Rekap Excel",
      variant: "blue",
      badge: "XLSX",
      onClick: () => setLastActionText("Memilih: Export Rekap Excel"),
    },
    {
      id: "action-qr",
      icon: <QrCode className="w-4 h-4" />,
      label: "Pindai Kode QR SKRD",
      variant: "yellow",
      onClick: () => setLastActionText("Memilih: Pindai Kode QR SKRD"),
    },
    {
      id: "action-delete",
      icon: <ShieldAlert className="w-4 h-4" />,
      label: "Tandai Anomali / Alert",
      variant: "danger",
      onClick: () => setLastActionText("Memilih: Tandai Anomali / Alert"),
    },
  ];

  // Code Generator
  const codeString = isSpeedDialMode
    ? `<SpeedDialApp
  id="uikit-speed-dial"
  variant="${playVariant}"
  size="${playSize}"
  elevation="${playElevation}"
  direction="${speedDirection}"
  showBackdrop={${showBackdrop}}
  actions={[
    { id: "add", icon: <Plus />, label: "Buat Laporan", onClick: () => {} },
    { id: "export", icon: <FileSpreadsheet />, label: "Export XLSX", variant: "blue" },
    { id: "qr", icon: <QrCode />, label: "Pindai QR", variant: "yellow" }
  ]}
/>`
    : `<FabApp
  id="uikit-fab-single"
  variant="${playVariant}"
  size="${playSize}"
  elevation="${playElevation}"
  rounded="${playRounded}"
  icon={<Plus className="w-5 h-5" />}
${isExtended ? '  label="Buat Laporan Baru"\n' : ""}  onClick={() => console.log("FAB Clicked")}
/>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-fab-module"
      icon={<Layers className="w-5 h-5 text-vibrant-purple-dark" />}
      title="Floating Action Button (FAB) & Speed Dial"
      description="Spesifikasi resmi komponen FAB Single Action dan Speed Dial (Expandable Action Stack) BPKAD Kota Yogyakarta. Mendukung elevation shadow sangat menonjol, posisi melayang, hover state presisi, dan opsi ekspansi multi-aksi."
    >
      {/*
        "Ukuran" dulu menyilangkan size x extended (6 instance icon berbeda
        pula). Dipecah jadi dua axis asli: size (icon-only, icon=Plus
        seragam) dan extended (boolean label, size="md" seragam).
      */}
      <ShowcaseGroup id="fab-group-variant" title="Variant" description="primary · secondary · danger · yellow · blue · purpleDark — semua icon={<Plus />} agar hanya warna yang berbeda" cols={3}>
        <ShowcaseCard
          id="fab-showcase-variant-primary"
          title="Variant primary"
          description="Aksi utama — default katalog"
          code={`<FabApp id="fab" variant="primary" icon={<Plus />} />`}
        >
          <FabApp id="fab-showcase-variant-primary-demo" variant="primary" size="md" icon={<Plus className="w-5 h-5" />} />
        </ShowcaseCard>

        <ShowcaseCard
          id="fab-showcase-variant-secondary"
          title="Variant secondary"
          description="Aksi pendamping"
          code={`<FabApp id="fab" variant="secondary" icon={<Plus />} />`}
        >
          <FabApp id="fab-showcase-variant-secondary-demo" variant="secondary" size="md" icon={<Plus className="w-5 h-5" />} />
        </ShowcaseCard>

        <ShowcaseCard
          id="fab-showcase-variant-danger"
          title="Variant danger"
          description="Aksi merusak"
          code={`<FabApp id="fab" variant="danger" icon={<Plus />} />`}
        >
          <FabApp id="fab-showcase-variant-danger-demo" variant="danger" size="md" icon={<Plus className="w-5 h-5" />} />
        </ShowcaseCard>

        <ShowcaseCard
          id="fab-showcase-variant-yellow"
          title="Variant yellow"
          description="Aksen kuning brand"
          code={`<FabApp id="fab" variant="yellow" icon={<Plus />} />`}
        >
          <FabApp id="fab-showcase-variant-yellow-demo" variant="yellow" size="md" icon={<Plus className="w-5 h-5" />} />
        </ShowcaseCard>

        <ShowcaseCard
          id="fab-showcase-variant-blue"
          title="Variant blue"
          description="Aksen biru brand"
          code={`<FabApp id="fab" variant="blue" icon={<Plus />} />`}
        >
          <FabApp id="fab-showcase-variant-blue-demo" variant="blue" size="md" icon={<Plus className="w-5 h-5" />} />
        </ShowcaseCard>

        <ShowcaseCard
          id="fab-showcase-variant-purple-dark"
          title="Variant purpleDark"
          description="Ungu gelap, kontras tertinggi"
          code={`<FabApp id="fab" variant="purpleDark" icon={<Plus />} />`}
        >
          <FabApp id="fab-showcase-variant-purple-dark-demo" variant="purpleDark" size="md" icon={<Plus className="w-5 h-5" />} />
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="fab-group-size" title="Ukuran" description="sm 40px · md 48px (default) · lg 56px — icon-only, variant=&quot;primary&quot;" cols={3}>
        <ShowcaseCard
          id="fab-showcase-size-sm"
          title="Ukuran sm"
          description="Diameter 40px"
          code={`<FabApp id="fab" size="sm" icon={<Plus />} />`}
        >
          <FabApp id="fab-showcase-size-sm-demo" variant="primary" size="sm" icon={<Plus className="w-4 h-4" />} />
        </ShowcaseCard>

        <ShowcaseCard
          id="fab-showcase-size-md"
          title="Ukuran md"
          description="Diameter 48px"
          code={`<FabApp id="fab" size="md" icon={<Plus />} />`}
        >
          <FabApp id="fab-showcase-size-md-demo" variant="primary" size="md" icon={<Plus className="w-5 h-5" />} />
        </ShowcaseCard>

        <ShowcaseCard
          id="fab-showcase-size-lg"
          title="Ukuran lg"
          description="Diameter 56px"
          code={`<FabApp id="fab" size="lg" icon={<Plus />} />`}
        >
          <FabApp id="fab-showcase-size-lg-demo" variant="primary" size="lg" icon={<Plus className="w-6 h-6" />} />
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="fab-group-extended" title="Extended Label" description="false (icon-only, circle) · true (icon + teks label)" cols={2}>
        <ShowcaseCard
          id="fab-showcase-extended-false"
          title="Extended false"
          description="FAB bulat, ikon saja tanpa label"
          code={`<FabApp id="fab" size="md" icon={<Plus />} />`}
        >
          <FabApp id="fab-showcase-extended-false-demo" variant="primary" size="md" icon={<Plus className="w-5 h-5" />} />
        </ShowcaseCard>

        <ShowcaseCard
          id="fab-showcase-extended-true"
          title="Extended true"
          description="FAB melebar, ikon disertai label teks"
          code={`<FabApp id="fab" size="md" icon={<Plus />} label="Buat Rekam Pajak" />`}
        >
          <FabApp id="fab-showcase-extended-true-demo" variant="primary" size="md" icon={<Plus className="w-5 h-5" />} label="Buat Rekam Pajak" />
        </ShowcaseCard>

      </ShowcaseGroup>

      {/*
        SpeedDialApp menerima koleksi actions secara native -- satu instance
        = satu UI (kriteria group-component KEEP). direction adalah axis
        nyata SpeedDialApp sendiri, jadi tetap dipecah per nilainya.
      */}
      <ShowcaseGroup id="fab-group-speed-dial-direction" title="Speed Dial — Direction" description="top · left · right · bottom — rotasi ikon 45° saat expand" cols={4}>
        <ShowcaseCard
          id="fab-showcase-speed-dial-top"
          title="Speed Dial direction top"
          description="Tumpukan aksi membuka ke arah top"
          code={`<SpeedDialApp id="sd" direction="top" variant="primary" actions={sampleActions} />`}
        >
          <SpeedDialApp id="fab-showcase-speed-dial-top-demo" direction="top" variant="primary" size="md" actions={sampleActions} />
        </ShowcaseCard>

        <ShowcaseCard
          id="fab-showcase-speed-dial-left"
          title="Speed Dial direction left"
          description="Tumpukan aksi membuka ke arah left"
          code={`<SpeedDialApp id="sd" direction="left" variant="purpleDark" actions={sampleActions} />`}
        >
          <SpeedDialApp id="fab-showcase-speed-dial-left-demo" direction="left" variant="purpleDark" size="md" actions={sampleActions.slice(0, 3)} />
        </ShowcaseCard>

        <ShowcaseCard
          id="fab-showcase-speed-dial-right"
          title="Speed Dial direction right"
          description="Tumpukan aksi membuka ke arah right"
          code={`<SpeedDialApp id="sd" direction="right" variant="yellow" actions={sampleActions} />`}
        >
          <SpeedDialApp id="fab-showcase-speed-dial-right-demo" direction="right" variant="yellow" size="md" actions={sampleActions.slice(0, 3)} />
        </ShowcaseCard>

        <ShowcaseCard
          id="fab-showcase-speed-dial-bottom"
          title="Speed Dial direction bottom"
          description="Tumpukan aksi membuka ke arah bottom"
          code={`<SpeedDialApp id="sd" direction="bottom" variant="blue" actions={sampleActions} />`}
        >
          <SpeedDialApp id="fab-showcase-speed-dial-bottom-demo" direction="bottom" variant="blue" size="md" actions={sampleActions.slice(0, 3)} />
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGrid cols={1}>
        {/* Playground — span penuh */}
        <ShowcaseCard
          id="fab-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap FabApp / SpeedDialApp dengan kode JSX yang dihasilkan"
          align="start"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            {/* Controls */}
            <div className="flex flex-col gap-4">
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Tipe Komponen</span>
                <div className="flex gap-1.5">
                  <PlaygroundChip id="fab-play-mode-single" active={!isSpeedDialMode} onClick={() => setIsSpeedDialMode(false)}>
                    Single FAB
                  </PlaygroundChip>
                  <PlaygroundChip id="fab-play-mode-speeddial" active={isSpeedDialMode} onClick={() => setIsSpeedDialMode(true)}>
                    Speed Dial Stack
                  </PlaygroundChip>
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Variant</span>
                <div className="flex flex-wrap gap-1.5">
                  {(["primary", "secondary", "danger", "yellow", "blue", "purpleDark"] as const).map((v) => (
                    <PlaygroundChip key={v} id={`fab-play-variant-${v}`} active={playVariant === v} onClick={() => setPlayVariant(v)}>
                      {v}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Size</span>
                  <div className="flex gap-1">
                    {(["sm", "md", "lg"] as const).map((s) => (
                      <PlaygroundChip key={s} id={`fab-play-size-${s}`} active={playSize === s} onClick={() => setPlaySize(s)} className="flex-1">
                        {s}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Elevation</span>
                  <div className="flex gap-1">
                    {(["normal", "high", "vibrant"] as const).map((el) => (
                      <PlaygroundChip key={el} id={`fab-play-elevation-${el}`} active={playElevation === el} onClick={() => setPlayElevation(el)} className="flex-1">
                        {el}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
              </div>

              {!isSpeedDialMode ? (
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Extended Label</span>
                    <PlaygroundChip id="fab-play-extended" active={isExtended} onClick={() => setIsExtended(!isExtended)} className="w-full">
                      {isExtended ? "Extended (Label + Icon)" : "Icon Only (Circle)"}
                    </PlaygroundChip>
                  </div>
                  <div>
                    <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Corner Radius</span>
                    <div className="flex gap-1">
                      {(["none", "sm", "md", "lg", "full"] as const).map((r) => (
                        <PlaygroundChip key={r} id={`fab-play-rounded-${r}`} active={playRounded === r} onClick={() => setPlayRounded(r)} className="flex-1">
                          {r}
                        </PlaygroundChip>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Direction Stack</span>
                    <div className="flex gap-1">
                      {(["top", "left", "right", "bottom"] as const).map((d) => (
                        <PlaygroundChip key={d} id={`fab-play-direction-${d}`} active={speedDirection === d} onClick={() => setSpeedDirection(d)} className="flex-1">
                          {d}
                        </PlaygroundChip>
                      ))}
                    </div>
                  </div>
                  <div>
                    <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Overlay Backdrop</span>
                    <PlaygroundChip id="fab-play-backdrop" active={showBackdrop} onClick={() => setShowBackdrop(!showBackdrop)} className="w-full">
                      {showBackdrop ? "Backdrop Aktif (Dim Bg)" : "Tanpa Backdrop"}
                    </PlaygroundChip>
                  </div>
                </div>
              )}
            </div>

            {/* Live Output & Code */}
            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[160px] items-center justify-center rounded-lg border border-dashed border-hairline bg-surface p-4 overflow-visible">
                  {isSpeedDialMode ? (
                    <SpeedDialApp
                      id="uikit-playground-speeddial"
                      variant={playVariant}
                      size={playSize}
                      elevation={playElevation}
                      direction={speedDirection}
                      showBackdrop={showBackdrop}
                      actions={sampleActions}
                    />
                  ) : (
                    <FabApp
                      id="uikit-playground-fab"
                      variant={playVariant}
                      size={playSize}
                      elevation={playElevation}
                      rounded={playRounded}
                      icon={<Plus className="w-5 h-5" />}
                      label={isExtended ? "Buat Laporan Baru" : undefined}
                    />
                  )}
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="fab-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeString}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>

        {/* Tabel Spesifikasi — span penuh */}
        <ShowcaseCard
          id="fab-showcase-spec-table"
          title="Tabel Spesifikasi & Aturan Penggunaan"
          description="Standar API FabApp & SpeedDialApp di lingkungan P4D BPKAD"
          align="start"
        >
          <div className="w-full overflow-x-auto">
            <table className="w-full border-collapse text-left text-xs">
              <thead>
                <tr className="border-b border-hairline bg-surface-soft text-ink">
                  <th className="px-3 py-2.5 font-bold">Prop</th>
                  <th className="px-3 py-2.5 font-bold">Tipe Data</th>
                  <th className="px-3 py-2.5 font-bold">Default</th>
                  <th className="px-3 py-2.5 font-bold">Keterangan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-hairline-soft text-[11px] text-ink-secondary">
                {[
                  ["variant", `"primary" | "secondary" | "danger" | "yellow" | "blue" | "purpleDark"`, '"primary"', "Warna aksen latar & ring focus yang disesuaikan secara dinamis."],
                  ["size", `"sm" | "md" | "lg"`, '"md"', "Dimensi FAB circle (sm: 40px, md: 48px, lg: 56px)."],
                  ["elevation", `"normal" | "high" | "vibrant"`, '"vibrant"', "Tingkat kedalaman bayangan melayang (shadow-lg, shadow-xl, ambient glow)."],
                  ["label", "ReactNode / string", "undefined", "Teks label opsional untuk mengubah FAB menjadi Extended FAB."],
                  ["direction (SpeedDial)", `"top" | "bottom" | "left" | "right"`, '"top"', "Arah pembukaan tumpukan daftar opsi aksi Speed Dial."],
                  ["actions (SpeedDial)", "SpeedDialAction[]", "[]", "Daftar item aksi dengan ikon, label, handler click, dan badge opsional."],
                ].map(([name, type, def, rule]) => (
                  <tr key={name}>
                    <td className="px-3 py-2 font-mono font-bold text-ink">{name}</td>
                    <td className="px-3 py-2 font-mono text-vibrant-purple-dark">{type}</td>
                    <td className="px-3 py-2 font-mono">{def}</td>
                    <td className="px-3 py-2">{rule}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
