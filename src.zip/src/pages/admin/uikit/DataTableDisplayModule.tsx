import * as React from "react";
import { ColumnDef } from "@tanstack/react-table";
import {
  DataTableApp,
  DataTableColumnHeader,
  dataTableFilterFn,
  AdvanceFilterApp,
  FilterChipToolbarApp,
  FilterFieldConfig,
  BadgeApp,
  ButtonApp,
  PaginationApp,
  AlertApp,
  AlertIconApp,
  AlertTitleApp,
  AlertDescriptionApp,
  SearchBarApp,
  useRealtimeRows,
} from "@/packages/design-system";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid, ShowcaseGroup } from "./shared/ShowcaseCard";
import {
  TableProperties,
  Building2,
  CheckCircle2,
  Clock,
  AlertTriangle,
  RefreshCw,
  FileSpreadsheet,
  Plus,
} from "lucide-react";

export interface BpkadAssetItem {
  id: string;
  kodeBarang: string;
  namaBarang: string;
  kategori: string;
  skpd: string;
  tahunPerolehan: number;
  nilaiAset: number;
  kondisi: "Baik" | "Rusak Ringan" | "Rusak Berat";
  status: "Aktif" | "Proses Penghapusan" | "Dipinjamkan";
}

const INITIAL_ASSETS: BpkadAssetItem[] = [
  { id: "AST-001", kodeBarang: "1.3.1.01.01", namaBarang: "Tanah Kantor Gedung Utama BPKAD", kategori: "Tanah", skpd: "BPKAD", tahunPerolehan: 2018, nilaiAset: 12500000000, kondisi: "Baik", status: "Aktif" },
  { id: "AST-002", kodeBarang: "1.3.2.02.01", namaBarang: "Server Mainframe Data Center", kategori: "Peralatan & Mesin", skpd: "Dinas Kominfo", tahunPerolehan: 2022, nilaiAset: 850000000, kondisi: "Baik", status: "Aktif" },
  { id: "AST-003", kodeBarang: "1.3.2.04.02", namaBarang: "Mobil Dinas Jabatan SUV 2.5L", kategori: "Kendaraan", skpd: "Secretariat Daerah", tahunPerolehan: 2020, nilaiAset: 480000000, kondisi: "Baik", status: "Aktif" },
  { id: "AST-004", kodeBarang: "1.3.3.01.01", namaBarang: "Gedung Balai Kota Yogyakarta Block A", kategori: "Gedung & Bangunan", skpd: "BPKAD", tahunPerolehan: 2015, nilaiAset: 34000000000, kondisi: "Baik", status: "Aktif" },
  { id: "AST-005", kodeBarang: "1.3.2.02.05", namaBarang: "Laptop Workstation i9 64GB (10 Unit)", kategori: "Peralatan & Mesin", skpd: "BPKAD", tahunPerolehan: 2023, nilaiAset: 350000000, kondisi: "Baik", status: "Aktif" },
  { id: "AST-006", kodeBarang: "1.3.2.03.01", namaBarang: "Kendaraan Operasional Bus Mini", kategori: "Kendaraan", skpd: "Dinas Perhubungan", tahunPerolehan: 2017, nilaiAset: 320000000, kondisi: "Rusak Ringan", status: "Dipinjamkan" },
  { id: "AST-007", kodeBarang: "1.3.5.01.03", namaBarang: "Sistem Informasi Manajemen Aset Daerah (SIMDA)", kategori: "Aset Tak Berwujud", skpd: "BPKAD", tahunPerolehan: 2021, nilaiAset: 600000000, kondisi: "Baik", status: "Aktif" },
  { id: "AST-008", kodeBarang: "1.3.2.02.12", namaBarang: "Genset Industri 500 KVA Data Center", kategori: "Peralatan & Mesin", skpd: "Dinas Kominfo", tahunPerolehan: 2016, nilaiAset: 420000000, kondisi: "Rusak Berat", status: "Proses Penghapusan" },
  { id: "AST-009", kodeBarang: "1.3.4.01.01", namaBarang: "Jaringan Irigasi Primer Malioboro", kategori: "Jalan, Irigasi & Jaringan", skpd: "Dinas PUPR", tahunPerolehan: 2019, nilaiAset: 8900000000, kondisi: "Baik", status: "Aktif" },
  { id: "AST-010", kodeBarang: "1.3.2.02.08", namaBarang: "Printer Laser Heavy Duty Office (5 Unit)", kategori: "Peralatan & Mesin", skpd: "Dinas Pendidikan", tahunPerolehan: 2019, nilaiAset: 75000000, kondisi: "Rusak Ringan", status: "Proses Penghapusan" },
  { id: "AST-011", kodeBarang: "1.3.2.04.05", namaBarang: "Motor Operasional Lapangan (15 Unit)", kategori: "Kendaraan", skpd: "Satpol PP", tahunPerolehan: 2022, nilaiAset: 375000000, kondisi: "Baik", status: "Aktif" },
  { id: "AST-012", kodeBarang: "1.3.3.02.01", namaBarang: "Gedung Puskesmas Danurejan II", kategori: "Gedung & Bangunan", skpd: "Dinas Kesehatan", tahunPerolehan: 2014, nilaiAset: 6800000000, kondisi: "Baik", status: "Aktif" },
  { id: "AST-013", kodeBarang: "1.3.2.02.20", namaBarang: "Proyektor Laser High Lumens", kategori: "Peralatan & Mesin", skpd: "Dinas Pariwisata", tahunPerolehan: 2021, nilaiAset: 95000000, kondisi: "Baik", status: "Dipinjamkan" },
  { id: "AST-014", kodeBarang: "1.3.1.02.01", namaBarang: "Tanah Fasilitas Umum Kotabaru", kategori: "Tanah", skpd: "BPKAD", tahunPerolehan: 2012, nilaiAset: 18500000000, kondisi: "Baik", status: "Aktif" },
  { id: "AST-015", kodeBarang: "1.3.2.02.33", namaBarang: "AC Precision 10 PK Server Room", kategori: "Peralatan & Mesin", skpd: "Dinas Kominfo", tahunPerolehan: 2020, nilaiAset: 180000000, kondisi: "Rusak Ringan", status: "Aktif" },
  { id: "AST-016", kodeBarang: "1.3.2.01.07", namaBarang: "Kursi Kerja Ergonomis Executive (50 Set)", kategori: "Peralatan & Mesin", skpd: "BPKAD", tahunPerolehan: 2023, nilaiAset: 250000000, kondisi: "Baik", status: "Aktif" },
  { id: "AST-017", kodeBarang: "1.3.3.03.01", namaBarang: "Gedung Sekolah SDN Mergangsan III", kategori: "Gedung & Bangunan", skpd: "Dinas Pendidikan", tahunPerolehan: 2010, nilaiAset: 4500000000, kondisi: "Baik", status: "Aktif" },
  { id: "AST-018", kodeBarang: "1.3.2.04.09", namaBarang: "Ambulance Jenazah 4WD", kategori: "Kendaraan", skpd: "Dinas Kesehatan", tahunPerolehan: 2019, nilaiAset: 550000000, kondisi: "Baik", status: "Aktif" },
];

// --- Realtime feed demo (useRealtimeRows + DataTableApp newRowIds) ---
interface RealtimeTxnItem {
  id: string;
  wpName: string;
  nominal: string;
  waktu: string;
}
const REALTIME_WP_POOL = ["PT Sumber Makmur", "CV Jaya Abadi", "Bpk. Untung Santoso", "Toko Elektronik Merapi"];
const REALTIME_INITIAL: RealtimeTxnItem[] = [
  { id: "TXN-0001", wpName: "PT Contoh Awal", nominal: "Rp 12.500.000", waktu: "10:00" },
  { id: "TXN-0002", wpName: "CV Contoh Dua", nominal: "Rp 4.200.000", waktu: "09:55" },
];
function generateRealtimeTxn(): RealtimeTxnItem {
  const now = new Date();
  return {
    id: `TXN-${now.getTime().toString().slice(-6)}`,
    wpName: REALTIME_WP_POOL[Math.floor(Math.random() * REALTIME_WP_POOL.length)],
    nominal: `Rp ${new Intl.NumberFormat("id-ID").format((Math.floor(Math.random() * 150) + 5) * 100_000)}`,
    waktu: now.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" }),
  };
}
const realtimeColumns: ColumnDef<RealtimeTxnItem>[] = [
  { accessorKey: "id", header: ({ column }) => <DataTableColumnHeader column={column} title="ID Transaksi" /> },
  { accessorKey: "wpName", header: ({ column }) => <DataTableColumnHeader column={column} title="Wajib Pajak" /> },
  { accessorKey: "nominal", header: ({ column }) => <DataTableColumnHeader column={column} title="Nominal" /> },
  { accessorKey: "waktu", header: ({ column }) => <DataTableColumnHeader column={column} title="Waktu" /> },
];

export function DataTableDisplayModule() {
  const { rows: realtimeRows, newRowIds: realtimeNewIds } = useRealtimeRows({
    initialRows: REALTIME_INITIAL,
    getId: (row) => row.id,
    generate: generateRealtimeTxn,
    intervalMs: 4000,
    maxRows: 12,
  });

  const [assetData, setAssetData] = React.useState<BpkadAssetItem[]>(INITIAL_ASSETS);
  const [filterValues, setFilterValues] = React.useState<Record<string, any>>({});
  const [toolbarSearch, setToolbarSearch] = React.useState("");
  const [isLoading, setIsLoading] = React.useState(false);
  const [actionAlert, setActionAlert] = React.useState<string | null>(null);

  // Standalone PaginationApp demo state
  const [demoPage, setDemoPage] = React.useState(1);
  const [demoPageSize, setDemoPageSize] = React.useState(5);
  const DEMO_TOTAL = 87;

  const clearAllFilters = () => { setFilterValues({}); setToolbarSearch(""); };

  // Filter fields config
  const filterFields: FilterFieldConfig[] = [
    {
      id: "kategori",
      label: "Kategori Aset",
      type: "select",
      options: [
        { label: "Tanah", value: "Tanah" },
        { label: "Peralatan & Mesin", value: "Peralatan & Mesin" },
        { label: "Kendaraan", value: "Kendaraan" },
        { label: "Gedung & Bangunan", value: "Gedung & Bangunan" },
        { label: "Jalan, Irigasi & Jaringan", value: "Jalan, Irigasi & Jaringan" },
        { label: "Aset Tak Berwujud", value: "Aset Tak Berwujud" },
      ],
    },
    {
      id: "skpd",
      label: "SKPD Pengelola",
      type: "select",
      options: [
        { label: "BPKAD", value: "BPKAD" },
        { label: "Dinas Kominfo", value: "Dinas Kominfo" },
        { label: "Secretariat Daerah", value: "Secretariat Daerah" },
        { label: "Dinas Perhubungan", value: "Dinas Perhubungan" },
        { label: "Dinas PUPR", value: "Dinas PUPR" },
        { label: "Dinas Kesehatan", value: "Dinas Kesehatan" },
      ],
    },
    {
      id: "kondisi",
      label: "Kondisi Aset",
      type: "select",
      options: [
        { label: "Baik", value: "Baik" },
        { label: "Rusak Ringan", value: "Rusak Ringan" },
        { label: "Rusak Berat", value: "Rusak Berat" },
      ],
    },
    {
      id: "status",
      label: "Status Aset",
      type: "select",
      options: [
        { label: "Aktif", value: "Aktif" },
        { label: "Proses Penghapusan", value: "Proses Penghapusan" },
        { label: "Dipinjamkan", value: "Dipinjamkan" },
      ],
    },
    {
      id: "nilaiAset",
      label: "Rentang Nilai Aset",
      type: "number-range",
      colSpan: 2,
    },
  ];

  const filteredData = React.useMemo(() => {
    return assetData.filter((item) => {
      if (filterValues.kategori && item.kategori !== filterValues.kategori) return false;
      if (filterValues.skpd && item.skpd !== filterValues.skpd) return false;
      if (filterValues.kondisi && item.kondisi !== filterValues.kondisi) return false;
      if (filterValues.status && item.status !== filterValues.status) return false;
      if (filterValues.nilaiAset?.min && item.nilaiAset < Number(filterValues.nilaiAset.min)) return false;
      if (filterValues.nilaiAset?.max && item.nilaiAset > Number(filterValues.nilaiAset.max)) return false;
      if (toolbarSearch.trim()) {
        const q = toolbarSearch.trim().toLowerCase();
        if (!item.namaBarang.toLowerCase().includes(q) && !item.kodeBarang.toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [assetData, filterValues, toolbarSearch]);

  const formatCurrency = (amount: number) =>
    new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(amount);

  const columns: ColumnDef<BpkadAssetItem>[] = [
    {
      accessorKey: "kodeBarang",
      header: ({ column }) => (
        <DataTableColumnHeader
          column={column}
          title="Kode Barang"
          filter={{ type: "text", placeholder: "Contoh: 1.3.2" }}
        />
      ),
      filterFn: dataTableFilterFn,
      cell: ({ row }) => (
        <span className="font-mono text-xs font-bold text-vibrant-purple-dark bg-vibrant-purple/10 px-2 py-1 rounded-md">
          {row.getValue("kodeBarang")}
        </span>
      ),
    },
    {
      accessorKey: "namaBarang",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Nama Barang / Aset" filter={{ type: "text" }} />
      ),
      filterFn: dataTableFilterFn,
      cell: ({ row }) => (
        <div className="flex flex-col min-w-0">
          <span className="font-bold text-ink text-sm leading-tight truncate max-w-[220px]">
            {row.getValue("namaBarang")}
          </span>
          <span className="text-[11px] text-ink-muted">
            {row.original.id} · {row.original.tahunPerolehan}
          </span>
        </div>
      ),
    },
    {
      accessorKey: "kategori",
      header: ({ column }) => (
        <DataTableColumnHeader
          column={column}
          title="Kategori"
          filter={{ type: "select", operators: ["equals", "notEquals"], options: filterFields[0].options }}
        />
      ),
      filterFn: dataTableFilterFn,
      cell: ({ row }) => (
        <BadgeApp id={`badge-kat-${row.id}`} variant="neutral" size="sm">
          {row.getValue("kategori")}
        </BadgeApp>
      ),
    },
    {
      accessorKey: "skpd",
      header: ({ column }) => <DataTableColumnHeader column={column} title="SKPD" />,
      cell: ({ row }) => (
        <div className="flex items-center gap-1.5 text-xs text-ink-secondary">
          <Building2 className="w-3.5 h-3.5 text-ink-muted shrink-0" />
          <span>{row.getValue("skpd")}</span>
        </div>
      ),
    },
    {
      accessorKey: "nilaiAset",
      header: ({ column }) => (
        <div className="text-right">
          <DataTableColumnHeader
            column={column}
            title="Nilai Aset"
            className="justify-end"
            filter={{ type: "number", placeholder: "Nilai dalam rupiah" }}
          />
        </div>
      ),
      filterFn: dataTableFilterFn,
      cell: ({ row }) => (
        // Right-aligned for numbers — best practice
        <div className="text-right">
          <span className="font-mono font-bold text-ink text-xs tabular-nums">
            {formatCurrency(row.getValue("nilaiAset"))}
          </span>
        </div>
      ),
    },
    {
      accessorKey: "kondisi",
      header: ({ column }) => <DataTableColumnHeader column={column} title="Kondisi" />,
      cell: ({ row }) => {
        const val = row.getValue("kondisi") as string;
        if (val === "Baik") return <BadgeApp id={`badge-k-${row.id}`} variant="success" size="sm" className="gap-1"><CheckCircle2 className="w-3 h-3" /> Baik</BadgeApp>;
        if (val === "Rusak Ringan") return <BadgeApp id={`badge-k-${row.id}`} variant="yellow" size="sm" className="gap-1"><Clock className="w-3 h-3" /> Rusak Ringan</BadgeApp>;
        return <BadgeApp id={`badge-k-${row.id}`} variant="danger" size="sm" className="gap-1"><AlertTriangle className="w-3 h-3" /> Rusak Berat</BadgeApp>;
      },
    },
    {
      accessorKey: "status",
      header: ({ column }) => <DataTableColumnHeader column={column} title="Status" />,
      cell: ({ row }) => {
        const val = row.getValue("status") as string;
        if (val === "Aktif") return <span className="text-xs font-semibold text-success">● Aktif</span>;
        if (val === "Dipinjamkan") return <span className="text-xs font-semibold text-info">● Dipinjamkan</span>;
        return <span className="text-xs font-semibold text-error">● Penghapusan</span>;
      },
    },
  ];

  const basicColumns: ColumnDef<BpkadAssetItem>[] = [
    { accessorKey: "kodeBarang", header: ({ column }) => <DataTableColumnHeader column={column} title="Kode Barang" /> },
    { accessorKey: "namaBarang", header: ({ column }) => <DataTableColumnHeader column={column} title="Nama Aset" /> },
    { accessorKey: "kategori", header: ({ column }) => <DataTableColumnHeader column={column} title="Kategori" /> },
    {
      accessorKey: "nilaiAset",
      header: ({ column }) => (
        <div className="text-right">
          <DataTableColumnHeader column={column} title="Nilai Aset" className="justify-end" />
        </div>
      ),
      cell: ({ row }) => <div className="text-right font-mono tabular-nums">{formatCurrency(row.getValue("nilaiAset"))}</div>,
    },
  ];

  const handleDeleteSelected = (selectedRows: BpkadAssetItem[], clearSelection: () => void) => {
    const idsToDelete = new Set(selectedRows.map((item) => item.id));
    setAssetData((prev) => prev.filter((item) => !idsToDelete.has(item.id)));
    clearSelection();
    setActionAlert(`Berhasil menghapus ${selectedRows.length} aset secara massal.`);
    setTimeout(() => setActionAlert(null), 4000);
  };

  const handleExportSelected = (selectedRows: BpkadAssetItem[]) => {
    setActionAlert(`Mengekspor ${selectedRows.length} data aset terpilih ke format CSV/Excel.`);
    setTimeout(() => setActionAlert(null), 4000);
  };

  // Resets the demo dataset (undoes the destructive bulk-delete action from
  // the row-selection showcase below) — surfaced there via onDeleteSelected.
  const handleResetData = () => {
    setIsLoading(true);
    setTimeout(() => {
      setAssetData(INITIAL_ASSETS);
      clearAllFilters();
      setIsLoading(false);
      setActionAlert("Data aset berhasil direset ke keadaan semula.");
      setTimeout(() => setActionAlert(null), 3000);
    }, 400);
  };

  return (
    <ModuleCard
      id="uikit-datatable-module"
      icon={<TableProperties className="w-5 h-5 text-vibrant-purple-dark" />}
      title="DataTableApp + AdvanceFilter + PaginationApp"
      description="Tabel data lengkap: Sortable columns, AdvanceFilter with dismissible chips, Empty State, Row Selection, dan PaginationApp terintegrasi."
    >
      <div className="space-y-6">
        {/* Action Alert */}
        {actionAlert && (
          <AlertApp id="datatable-action-alert" variant="success" className="items-center">
            <AlertIconApp id="datatable-alert-icon">
              <CheckCircle2 className="w-5 h-5 text-success shrink-0" />
            </AlertIconApp>
            <div className="flex-1 text-left">
              <AlertTitleApp id="datatable-alert-title">Aksi Berhasil</AlertTitleApp>
              <AlertDescriptionApp id="datatable-alert-desc" className="mt-0.5">{actionAlert}</AlertDescriptionApp>
            </div>
          </AlertApp>
        )}

        <ShowcaseGrid cols={1}>
          <ShowcaseCard
            id="datatable-showcase-basic"
            title="Tabel Dasar"
            description="Kolom sortable (klik header) — tanpa filtering, selection, atau pagination — striped rows"
            align="start"
            code={`<DataTableApp id="tbl" data={assets} columns={basicColumns} enableSearch={false} enablePagination={false} striped />

// basicColumns — header pakai DataTableColumnHeader agar bisa di-sort
{ accessorKey: "kodeBarang", header: ({ column }) => <DataTableColumnHeader column={column} title="Kode Barang" /> }`}
          >
            <DataTableApp
              id="bpkad-basic-datatable"
              title="Ringkasan Aset"
              description="Tabel dasar dengan sorting per kolom — tanpa filtering, selection, atau pagination."
              data={INITIAL_ASSETS.slice(0, 5)}
              columns={basicColumns}
              enableSearch={false}
              enablePagination={false}
              enableRowSelection={false}
              striped
              getRowId={(row) => row.id}
            />
          </ShowcaseCard>

          <ShowcaseCard
            id="datatable-showcase-realtime"
            title="Feed Real-time"
            description="useRealtimeRows + prop newRowIds — baris baru masuk dari atas tiap beberapa detik, di-highlight sebentar, jumlah baris dibatasi (maxRows). Generator bisa diganti poll/websocket sungguhan tanpa mengubah DataTableApp."
            align="start"
            code={`const { rows, newRowIds } = useRealtimeRows({
  initialRows,
  getId: (row) => row.id,
  generate: generateNextRow, // panggil poll/websocket di sini pada produksi
  intervalMs: 4000,
  maxRows: 12,
});

<DataTableApp id="tbl" data={rows} newRowIds={newRowIds} columns={columns} getRowId={(row) => row.id} />`}
          >
            <DataTableApp
              id="realtime-feed-datatable"
              title="Transaksi Masuk"
              description="Simulasi feed real-time — baris baru otomatis di atas."
              data={realtimeRows}
              newRowIds={realtimeNewIds}
              columns={realtimeColumns}
              enableSearch={false}
              enablePagination={false}
              enableRowSelection={false}
              getRowId={(row) => row.id}
            />
          </ShowcaseCard>

          <ShowcaseCard
            id="datatable-showcase-advance-filter"
            title="Toolbar Tabel: Search + Filter + Actions"
            description="Susunan standar: search di kiri, diikuti dropdown filter, lalu Reset Filters — aksi utama (Export, Add) menempel di ujung kanan"
            align="start"
            code={`<div className="flex flex-wrap items-center gap-2">
  <SearchBarApp id="search" value={search} onSearchChange={setSearch} placeholder="Cari aset..." containerClassName="w-full sm:w-64" />
  <FilterChipToolbarApp id="quick" fields={quickFields} values={filterValues} onChange={setFilterValues} />
  <ButtonApp variant="ghost" size="sm" onClick={clearAllFilters}>Reset Filters</ButtonApp>
  <div className="ml-auto flex items-center gap-2">
    <ButtonApp variant="secondary" size="sm">Export</ButtonApp>
    <ButtonApp variant="primary" size="sm">+ Tambah Aset</ButtonApp>
  </div>
</div>`}
          >
            <div className="flex w-full min-w-0 flex-col gap-4">
              {/* flex-nowrap + overflow-x-auto instead of flex-wrap: with
                  wrap, the whole ml-auto action group (Filter Lanjutan /
                  Export / Tambah Aset) drops to a second line as soon as the
                  row runs out of width, which looks broken. A single
                  horizontally-scrollable row is the standard enterprise
                  data-table toolbar pattern and keeps every control visible
                  and reachable regardless of container width.
                  px-1/py-1: overflow-x-auto clips its focus rings on every
                  edge — vertically because setting overflow-x without
                  overflow-y makes the browser compute overflow-y as `auto`
                  too (CSS spec quirk), and horizontally because the
                  leftmost (search box) and rightmost (Tambah Aset) controls'
                  rings extend past the scroll container's own edge. Padding
                  on all sides gives every ring room regardless of scroll
                  position. */}
              <div className="flex w-full min-w-0 flex-nowrap items-center gap-2 overflow-x-auto px-1 py-1">
                <SearchBarApp
                  id="datatable-toolbar-search"
                  value={toolbarSearch}
                  onSearchChange={setToolbarSearch}
                  placeholder="Cari kode / nama aset..."
                  size="sm"
                  containerClassName="w-56 shrink-0 sm:w-64"
                />

                <div className="shrink-0">
                  <FilterChipToolbarApp
                    id="datatable-quick-filter"
                    fields={filterFields.filter((f) => ["kategori", "kondisi", "status"].includes(f.id))}
                    values={filterValues}
                    onChange={setFilterValues}
                  />
                </div>

                {(toolbarSearch || Object.keys(filterValues).length > 0) && (
                  <ButtonApp
                    id="datatable-reset-all"
                    variant="ghost"
                    size="sm"
                    onClick={clearAllFilters}
                    className="shrink-0 whitespace-nowrap text-ink-muted hover:text-rose-500"
                  >
                    Reset Filters
                  </ButtonApp>
                )}

                <div className="ml-auto flex shrink-0 items-center gap-2">
                  <AdvanceFilterApp
                    id="datatable-advance-filter"
                    fields={filterFields}
                    values={filterValues}
                    onChange={setFilterValues}
                    onReset={clearAllFilters}
                    displayMode="modal"
                    title="Filter Lanjutan Aset BPKAD"
                    description="Pilih kategori di kiri, lalu tentukan kriterianya di kanan"
                    triggerLabel="Filter Lanjutan"
                    triggerVariant="secondary"
                    triggerSize="sm"
                    // The quick-filter chips + "Reset Filters" above already
                    // surface active criteria — AdvanceFilterApp's own
                    // active-pills row would duplicate that (and, sitting
                    // inside this ml-auto group instead of spanning the full
                    // toolbar width, wraps into a cramped, layout-breaking
                    // extra row). The trigger's own active-count badge is
                    // enough of a signal here.
                    showActivePills={false}
                    // AdvanceFilterApp's root defaults to w-full, which is
                    // right for a standalone toolbar but forces it onto its
                    // own line when it's just one item among several inside
                    // this shared flex-wrap action group — shrink it back to
                    // its content width so it wraps together with Export/
                    // Tambah Aset instead of alone.
                    className="w-auto"
                  />
                  <ButtonApp
                    id="datatable-export-all"
                    variant="secondary"
                    size="sm"
                    onClick={() => handleExportSelected(filteredData)}
                    leftIcon={<FileSpreadsheet className="w-3.5 h-3.5 text-success" />}
                  >
                    Export
                  </ButtonApp>
                  <ButtonApp
                    id="datatable-add-asset"
                    variant="primary"
                    size="sm"
                    onClick={() => {
                      setActionAlert("Form tambah aset baru akan terbuka di sini (demo).");
                      setTimeout(() => setActionAlert(null), 4000);
                    }}
                    leftIcon={<Plus className="w-3.5 h-3.5" />}
                  >
                    Tambah Aset
                  </ButtonApp>
                </div>
              </div>

              <DataTableApp
                id="bpkad-toolbar-datatable"
                data={filteredData}
                columns={columns}
                pageSize={5}
                enablePagination
                enableSearch={false}
                enableRowSelection={false}
                isLoading={isLoading}
                emptyMessage="Tidak ada aset yang cocok dengan pencarian/filter ini."
                getRowId={(row) => row.id}
              />
            </div>
          </ShowcaseCard>

          <ShowcaseCard
            id="datatable-showcase-sortable"
            title="Tabel Sortable + Filterable"
            description="Kolom Nilai Aset rata kanan · header sortable · row selection + pagination"
            align="start"
            code={`<DataTableApp id="tbl" data={filteredData} columns={columns} pageSize={5} enableSearch enableRowSelection onDeleteSelected={handleDelete} />`}
          >
            <DataTableApp
              id="bpkad-asset-datatable"
              title="Daftar Aset & Barang Daerah"
              description="Aset Terdaftar pada BPKAD Kota Yogyakarta · PaginationApp terintegrasi di bawah"
              data={filteredData}
              columns={columns}
              pageSize={5}
              enablePagination={true}
              enableSearch={true}
              enableRowSelection={true}
              isLoading={isLoading}
              onDeleteSelected={handleDeleteSelected}
              onExportSelected={handleExportSelected}
              getRowId={(row) => row.id}
              toolbarLayout="singleRow"
              rightHeaderAction={
                <ButtonApp
                  id="datatable-reset-data"
                  variant="ghost"
                  size="sm"
                  onClick={handleResetData}
                  leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
                >
                  Reset Data
                </ButtonApp>
              }
            />
          </ShowcaseCard>

          <ShowcaseCard
            id="datatable-showcase-empty"
            title="Empty State"
            description='"Tidak ada data" ketika kombinasi filter tidak menghasilkan hasil'
            align="start"
            code={`<DataTableApp id="tbl" data={[]} columns={columns} enablePagination />`}
          >
            <DataTableApp
              id="bpkad-asset-datatable-empty"
              title="Daftar Aset (Filter: Kondisi = Rusak Berat + Status = Aktif)"
              description="Kombinasi filter ini tidak menghasilkan data — demonstrasi empty state"
              data={[]}
              columns={columns}
              pageSize={5}
              enablePagination={true}
              enableSearch={false}
              enableRowSelection={false}
              isLoading={false}
            />
          </ShowcaseCard>

        </ShowcaseGrid>

        {/*
          "PaginationApp — Semua Varian" mencampur 4 kombinasi berbeda
          (variant+size+rounded+type sekaligus) dalam satu kartu. Dipecah
          per kombinasi, masing-masing tetap dalam konteks toolbar
          DataTableApp (bukan duplikat murni dari PaginationDisplayModule
          kategori 04 — di sana enumerasi per prop tunggal, di sini
          menunjukkan preset pemakaian nyata di bawah tabel).
        */}
        <ShowcaseGroup id="datatable-group-pagination-preset" title="PaginationApp — Preset Pemakaian" description="Kombinasi variant+size+rounded+type yang umum dipakai di bawah DataTableApp" cols={1}>
          <ShowcaseCard
            id="datatable-showcase-pagination-default"
            title="Preset default"
            description='variant="default" · size="md" · rounded="lg" — rows-per-page & item summary'
            align="start"
            code={`<PaginationApp id="pg" type="standard" variant="default" size="md" rounded="lg" showRowsPerPage showItemSummary currentPage={page} totalPages={total} onPageChange={setPage} />`}
          >
            <PaginationApp
              id="datatable-showcase-pagination-default-demo"
              type="standard"
              variant="default"
              size="md"
              rounded="lg"
              currentPage={demoPage}
              totalPages={Math.ceil(DEMO_TOTAL / demoPageSize)}
              totalItems={DEMO_TOTAL}
              pageSize={demoPageSize}
              pageSizeOptions={[5, 10, 20]}
              showFirstLast={true}
              showRowsPerPage={true}
              showItemSummary={true}
              onPageChange={setDemoPage}
              onPageSizeChange={(s) => { setDemoPageSize(s); setDemoPage(1); }}
            />
          </ShowcaseCard>

          <ShowcaseCard
            id="datatable-showcase-pagination-vibrant"
            title="Preset vibrant"
            description='variant="vibrant" · size="md" · rounded="full" — ringkas tanpa rows-per-page'
            align="start"
            code={`<PaginationApp id="pg" type="standard" variant="vibrant" size="md" rounded="full" currentPage={page} totalPages={total} onPageChange={setPage} />`}
          >
            <PaginationApp
              id="datatable-showcase-pagination-vibrant-demo"
              type="standard"
              variant="vibrant"
              size="md"
              rounded="full"
              currentPage={demoPage}
              totalPages={Math.ceil(DEMO_TOTAL / demoPageSize)}
              totalItems={DEMO_TOTAL}
              pageSize={demoPageSize}
              showFirstLast={false}
              showRowsPerPage={false}
              showItemSummary={false}
              onPageChange={setDemoPage}
              onPageSizeChange={(s) => { setDemoPageSize(s); setDemoPage(1); }}
            />
          </ShowcaseCard>

          <ShowcaseCard
            id="datatable-showcase-pagination-outline"
            title="Preset outline"
            description='variant="outline" · size="sm" · rounded="md"'
            align="start"
            code={`<PaginationApp id="pg" type="standard" variant="outline" size="sm" rounded="md" currentPage={page} totalPages={total} onPageChange={setPage} />`}
          >
            <PaginationApp
              id="datatable-showcase-pagination-outline-demo"
              type="standard"
              variant="outline"
              size="sm"
              rounded="md"
              currentPage={demoPage}
              totalPages={Math.ceil(DEMO_TOTAL / demoPageSize)}
              totalItems={DEMO_TOTAL}
              pageSize={demoPageSize}
              showFirstLast={true}
              showRowsPerPage={false}
              showItemSummary={true}
              onPageChange={setDemoPage}
              onPageSizeChange={(s) => { setDemoPageSize(s); setDemoPage(1); }}
            />
          </ShowcaseCard>

          <ShowcaseCard
            id="datatable-showcase-pagination-simple"
            title="Type simple"
            description='type="simple" — Prev / Next only'
            align="start"
            code={`<PaginationApp id="pg" type="simple" currentPage={page} totalPages={total} onPageChange={setPage} />`}
          >
            <PaginationApp
              id="datatable-showcase-pagination-simple-demo"
              type="simple"
              variant="default"
              size="md"
              currentPage={demoPage}
              totalPages={Math.ceil(DEMO_TOTAL / demoPageSize)}
              totalItems={DEMO_TOTAL}
              pageSize={demoPageSize}
              showItemSummary={true}
              onPageChange={setDemoPage}
              onPageSizeChange={setDemoPageSize}
            />
          </ShowcaseCard>
        </ShowcaseGroup>
      </div>
    </ModuleCard>
  );
}
