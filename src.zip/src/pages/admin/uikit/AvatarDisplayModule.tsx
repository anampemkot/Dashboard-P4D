import * as React from "react";
import {
  AvatarApp,
  AvatarGroupApp,
  ButtonApp,
  DropdownApp,
  InputApp,
  ToggleApp,
  AvatarSize,
  AvatarStatus,
  AvatarShape,
} from "@/packages/design-system";
import { Users, Code, Check, Bot, Shield, Square, Circle, User } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid, ShowcaseGroup } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

const sampleUsers = [
  {
    id: "u1",
    name: "Siti Rahma",
    src: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=256&q=80",
    status: "online" as AvatarStatus,
    variant: "vibrant" as const,
  },
  {
    id: "u2",
    name: "Budi Santoso",
    src: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=256&q=80",
    status: "busy" as AvatarStatus,
    variant: "brand" as const,
  },
  {
    id: "u3",
    name: "Dian Permata",
    src: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80",
    status: "away" as AvatarStatus,
    variant: "success" as const,
  },
  { id: "u4", name: "Eko Wijaya", status: "offline" as AvatarStatus, variant: "warning" as const },
  { id: "u5", name: "Farah Nabila", variant: "danger" as const },
];

export function AvatarDisplayModule() {
  const [avatarMode, setAvatarMode] = React.useState<"image" | "initials" | "icon">("image");
  const [name, setName] = React.useState("Ahmad Fauzi");
  const [imageUrl, setImageUrl] = React.useState(
    "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80"
  );
  const [size, setSize] = React.useState<AvatarSize>("lg");
  const [shape, setShape] = React.useState<AvatarShape>("circle");
  const [status, setStatus] = React.useState<AvatarStatus>("online");
  const [showStatus, setShowStatus] = React.useState(true);
  const [variant, setVariant] = React.useState<any>("vibrant");
  const [copied, setCopied] = React.useState(false);

  const currentSrc = avatarMode === "image" ? imageUrl : undefined;
  const currentName = avatarMode === "initials" || avatarMode === "image" ? name : undefined;
  const currentIcon = avatarMode === "icon" ? <Bot className="w-1/2 h-1/2 text-vibrant-purple-dark" /> : undefined;

  const codeSnippet = `<AvatarApp
  name="${currentName || ""}"
  ${currentSrc ? `src="${currentSrc}"\n  ` : ""}${currentIcon ? `icon={<Bot />}\n  ` : ""}size="${size}"
  shape="${shape}"
  status="${status}"
  showStatus={${showStatus}}
/>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-avatar-module"
      icon={<Users className="w-5 h-5 text-vibrant-purple-dark" />}
      title="AvatarApp & AvatarGroupApp"
      description="Komponen profil pengguna dengan opsi image, initials, dan placeholder/icon, skala ukuran, bentuk, status badge, serta tumpukan grup — P4D BPKAD Kota Yogyakarta."
    >
      {/*
        "Content Types" mencampur 3 mode (src/name/icon) dan 2 icon berbeda
        (Bot, Shield) dalam satu kartu. Dipecah per mode; icon Bot dipakai
        sebagai representatif satu-satunya varian icon (Shield dibuang,
        duplikat konsep).
      */}
      <ShowcaseGroup id="avatar-group-content" title="Content Type" description="src (foto) · name (inisial otomatis) · icon (fallback kustom)" cols={3}>
        <ShowcaseCard
          id="avatar-showcase-content-image"
          title="Content type src"
          description="Foto asli dari URL"
          code={`<AvatarApp id="a" src="..." size="lg" status="online" showStatus />`}
        >
          <AvatarApp id="avatar-showcase-content-image-demo" src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80" alt="Ahmad Fauzi" size="lg" status="online" showStatus />
        </ShowcaseCard>

        <ShowcaseCard
          id="avatar-showcase-content-initials"
          title="Content type name"
          description="Inisial dua huruf dari nama, otomatis"
          code={`<AvatarApp id="a" name="Ahmad Fauzi" variant="vibrant" size="lg" status="busy" showStatus />`}
        >
          <AvatarApp id="avatar-showcase-content-initials-demo" name="Ahmad Fauzi" variant="vibrant" size="lg" status="busy" showStatus />
        </ShowcaseCard>

        <ShowcaseCard
          id="avatar-showcase-content-icon"
          title="Content type icon"
          description="Ikon fallback kustom pengganti foto/inisial"
          code={`<AvatarApp id="a" icon={<Bot />} variant="vibrant" size="lg" />`}
        >
          <AvatarApp id="avatar-showcase-content-icon-demo" icon={<Bot className="w-5 h-5 text-vibrant-purple-dark" />} variant="vibrant" size="lg" />
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="avatar-group-size" title="Ukuran" description="sm 32px · md 40px · lg 48px · xl 64px" cols={4}>
        <ShowcaseCard
          id="avatar-showcase-size-sm"
          title="Ukuran sm"
          description="Diameter 32px"
          code={`<AvatarApp id="a" size="sm" name="Ahmad Fauzi" src="..." status="online" showStatus />`}
        >
          <AvatarApp id="avatar-showcase-size-sm-demo" size="sm" name="Ahmad Fauzi" src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80" status="online" showStatus />
        </ShowcaseCard>

        <ShowcaseCard
          id="avatar-showcase-size-md"
          title="Ukuran md"
          description="Diameter 40px"
          code={`<AvatarApp id="a" size="md" name="Ahmad Fauzi" src="..." status="online" showStatus />`}
        >
          <AvatarApp id="avatar-showcase-size-md-demo" size="md" name="Ahmad Fauzi" src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80" status="online" showStatus />
        </ShowcaseCard>

        <ShowcaseCard
          id="avatar-showcase-size-lg"
          title="Ukuran lg"
          description="Diameter 48px"
          code={`<AvatarApp id="a" size="lg" name="Ahmad Fauzi" src="..." status="busy" showStatus />`}
        >
          <AvatarApp id="avatar-showcase-size-lg-demo" size="lg" name="Ahmad Fauzi" src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80" status="busy" showStatus />
        </ShowcaseCard>

        <ShowcaseCard
          id="avatar-showcase-size-xl"
          title="Ukuran xl"
          description="Diameter 64px"
          code={`<AvatarApp id="a" size="xl" name="Ahmad Fauzi" src="..." status="offline" showStatus />`}
        >
          <AvatarApp id="avatar-showcase-size-xl-demo" size="xl" name="Ahmad Fauzi" src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80" status="offline" showStatus />
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="avatar-group-shape" title="Shape" description="circle (default) · square (rounded)" cols={2}>
        <ShowcaseCard
          id="avatar-showcase-shape-circle"
          title="Shape circle"
          description="Bentuk bulat penuh — default katalog"
          code={`<AvatarApp id="a" shape="circle" name="Ahmad Fauzi" variant="vibrant" />`}
        >
          <AvatarApp id="avatar-showcase-shape-circle-demo" shape="circle" name="Ahmad Fauzi" size="xl" variant="vibrant" status="online" showStatus />
        </ShowcaseCard>

        <ShowcaseCard
          id="avatar-showcase-shape-square"
          title="Shape square"
          description="Bentuk kotak dengan radius"
          code={`<AvatarApp id="a" shape="square" name="Ahmad Fauzi" variant="brand" />`}
        >
          <AvatarApp id="avatar-showcase-shape-square-demo" shape="square" name="Ahmad Fauzi" size="xl" variant="brand" status="online" showStatus />
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="avatar-group-status" title="Status Badge" description="online · offline · busy — indikator titik status ketersediaan pengguna" cols={3}>
        <ShowcaseCard
          id="avatar-showcase-status-online"
          title="Status online"
          description="Titik status online"
          code={`<AvatarApp id="a" name="Siti Rahma" status="online" showStatus />`}
        >
          <AvatarApp id="avatar-showcase-status-online-demo" name="Siti Rahma" size="lg" status="online" showStatus />
        </ShowcaseCard>

        <ShowcaseCard
          id="avatar-showcase-status-offline"
          title="Status offline"
          description="Titik status offline"
          code={`<AvatarApp id="a" name="Eko Wijaya" status="offline" showStatus />`}
        >
          <AvatarApp id="avatar-showcase-status-offline-demo" name="Eko Wijaya" size="lg" status="offline" showStatus />
        </ShowcaseCard>

        <ShowcaseCard
          id="avatar-showcase-status-busy"
          title="Status busy"
          description="Titik status busy"
          code={`<AvatarApp id="a" name="Budi Santoso" status="busy" showStatus />`}
        >
          <AvatarApp id="avatar-showcase-status-busy-demo" name="Budi Santoso" size="lg" status="busy" showStatus />
        </ShowcaseCard>

      </ShowcaseGroup>

      {/*
        AvatarGroupApp menerima koleksi (items) secara native — satu
        instance = satu UI (kriteria group-component KEEP). Dua kartu lama
        berbeda `size`, jadi tetap dipecah per nilai size itu.
      */}
      <ShowcaseGroup id="avatar-group-group-size" title="AvatarGroupApp — Ukuran" description="Tumpukan tim dengan badge +N; size mengikuti skala AvatarApp" cols={2}>
        <ShowcaseCard
          id="avatar-showcase-group-lg"
          title="AvatarGroupApp size lg"
          description="max=3 membatasi tampilan, sisanya masuk badge +N"
          code={`<AvatarGroupApp id="ag" max={3} size="lg" items={sampleUsers} />`}
        >
          <AvatarGroupApp id="avatar-showcase-group-lg-demo" max={3} size="lg" items={sampleUsers} />
        </ShowcaseCard>

        <ShowcaseCard
          id="avatar-showcase-group-sm"
          title="AvatarGroupApp size sm"
          description="max=4, ukuran ringkas untuk daftar komentar/diskusi"
          code={`<AvatarGroupApp id="ag" max={4} size="sm" items={sampleUsers} />`}
        >
          <AvatarGroupApp id="avatar-showcase-group-sm-demo" max={4} size="sm" items={sampleUsers} />
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGrid cols={1}>
        {/* Playground — span penuh */}
        <ShowcaseCard
          id="avatar-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap AvatarApp dengan kode JSX yang dihasilkan"
          align="start"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            {/* Controls */}
            <div className="flex flex-col gap-4">
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Tipe Konten Avatar</span>
                <div className="flex gap-1.5">
                  <PlaygroundChip id="av-mode-image" active={avatarMode === "image"} onClick={() => setAvatarMode("image")}>Image</PlaygroundChip>
                  <PlaygroundChip id="av-mode-initials" active={avatarMode === "initials"} onClick={() => setAvatarMode("initials")}>Initials</PlaygroundChip>
                  <PlaygroundChip id="av-mode-icon" active={avatarMode === "icon"} onClick={() => setAvatarMode("icon")}>Icon</PlaygroundChip>
                </div>
              </div>

              {avatarMode === "image" && (
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">URL Foto (Src)</span>
                  <InputApp id="av-input-src" value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} placeholder="URL Foto..." />
                </div>
              )}

              {(avatarMode === "initials" || avatarMode === "image") && (
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Nama Pengguna</span>
                  <InputApp id="av-input-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Masukkan nama pengguna..." />
                </div>
              )}

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Ukuran</span>
                  <DropdownApp
                    id="av-select-size"
                    value={size}
                    onChange={(value) => setSize(value as AvatarSize)}
                    options={[
                      { value: "sm", label: "Small (sm)" },
                      { value: "md", label: "Medium (md)" },
                      { value: "lg", label: "Large (lg)" },
                      { value: "xl", label: "XL (xl)" },
                    ]}
                  />
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Bentuk</span>
                  <DropdownApp
                    id="av-select-shape"
                    value={shape}
                    onChange={(value) => setShape(value as AvatarShape)}
                    options={[
                      { value: "circle", label: "Circle" },
                      { value: "square", label: "Square (Rounded)" },
                    ]}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Status Badge</span>
                  <DropdownApp
                    id="av-select-status"
                    value={status}
                    onChange={(value) => setStatus(value as AvatarStatus)}
                    options={[
                      { value: "online", label: "Online" },
                      { value: "offline", label: "Offline" },
                      { value: "busy", label: "Busy" },
                    ]}
                  />
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Varian Warna</span>
                  <DropdownApp
                    id="av-select-variant"
                    value={variant}
                    onChange={(value) => setVariant(value)}
                    options={[
                      { value: "vibrant", label: "Vibrant Purple" },
                      { value: "brand", label: "Brand Purple" },
                      { value: "default", label: "Default Neutral" },
                      { value: "success", label: "Success Green" },
                      { value: "warning", label: "Warning Amber" },
                      { value: "danger", label: "Danger Red" },
                      { value: "info", label: "Info Blue" },
                    ]}
                  />
                </div>
              </div>

              <div className="border-t border-hairline-soft pt-3">
                <ToggleApp id="av-toggle-status" checked={showStatus} onCheckedChange={setShowStatus} size="sm" label="Tampilkan Status Badge" />
              </div>
            </div>

            {/* Live Output & Code */}
            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[120px] items-center gap-4 rounded-lg border border-dashed border-hairline bg-surface p-4">
                  <AvatarApp id="av-live-demo" name={currentName} src={currentSrc} icon={currentIcon} size={size} shape={shape} variant={variant} status={status} showStatus={showStatus} />
                  <div className="space-y-1">
                    <div className="text-sm font-bold text-ink">{avatarMode === "icon" ? "Ikon Fallback Bot" : name || "Tanpa Nama"}</div>
                    <div className="text-xs text-ink-muted flex items-center gap-1">
                      <User className="w-3 h-3" /> Mode: <strong className="text-vibrant-purple-dark capitalize">{avatarMode}</strong>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="copy-av-code"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeSnippet}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
