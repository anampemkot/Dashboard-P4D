import * as React from "react";
import { TradingInputApp, ButtonApp, InputApp } from "@/packages/design-system";
import { TrendingUp, Code, Check } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

const VARIANTS = ["stock", "crypto", "default"] as const;
const SIZES = ["sm", "md", "lg"] as const;
const ROUNDED = ["none", "sm", "md", "lg", "xl", "full"] as const;

export function TradingInputDisplayModule() {
  // Demo states for Showcase
  const [stockLots, setStockLots] = React.useState<number>(10);
  const [cryptoShares, setCryptoShares] = React.useState<number>(0.5);
  const [errorLots, setErrorLots] = React.useState<number>(300);

  // Playground Interactive State
  const [playVariant, setPlayVariant] = React.useState<(typeof VARIANTS)[number]>("stock");
  const [playUnit, setPlayUnit] = React.useState<string>("Lot");
  const [playSize, setPlaySize] = React.useState<(typeof SIZES)[number]>("md");
  const [playRounded, setPlayRounded] = React.useState<(typeof ROUNDED)[number]>("md");
  const [playDisabled, setPlayDisabled] = React.useState<boolean>(false);
  const [playValue, setPlayValue] = React.useState<number>(5);
  const [playPrice, setPlayPrice] = React.useState<number>(50000);
  const [playBalance, setPlayBalance] = React.useState<number>(10000000);
  const [copied, setCopied] = React.useState<boolean>(false);

  const codeString = `<TradingInputApp\n  id="demo-trading-input"\n  variant="${playVariant}"\n  unit="${playUnit}"\n  value={${playValue}}\n  pricePerUnit={${playPrice}}\n  availableBalance={${playBalance}}\n  size="${playSize}"\n  rounded="${playRounded}"${playDisabled ? "\n  disabled" : ""}\n  onChange={(val) => setQuantity(val)}\n/>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const selectVariant = (v: (typeof VARIANTS)[number]) => {
    setPlayVariant(v);
    if (v === "crypto") setPlayUnit("USDT");
    else if (v === "stock") setPlayUnit("Lot");
    else setPlayUnit("Shares");
  };

  return (
    <ModuleCard
      id="uikit-tradinginput-module"
      icon={<TrendingUp className="w-5 h-5 text-vibrant-purple-dark" />}
      title="TradingInputApp"
      description="Komponen masukan jumlah Lot saham, Crypto share, atau komoditas trading — dilengkapi tombol persentase instan, stepper increment/decrement, serta kalkulasi otomatis total estimasi transaksi & batas saldo."
    >
      <ShowcaseGrid cols={2}>
        <ShowcaseCard
          id="trading-showcase-stock"
          title="Stock Trading Input"
          description='variant="stock" — 1 Lot = 100 lembar saham'
          align="start"
          code={`<TradingInputApp id="ti" variant="stock" unit="Lot" pricePerUnit={850000} availableBalance={25000000} />`}
        >
          <TradingInputApp
            id="trading-demo-stock"
            variant="stock"
            unit="Lot"
            label="Jumlah Pembelian Saham BBCA"
            description="1 Lot = 100 Lembar Saham"
            value={stockLots}
            onChange={setStockLots}
            pricePerUnit={850000}
            availableBalance={25000000}
            rounded="md"
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="trading-showcase-crypto"
          title="Crypto / Coin Share Input"
          description='variant="crypto" — pecahan desimal koin'
          align="start"
          code={`<TradingInputApp id="ti" variant="crypto" unit="BTC" currencySymbol="$" step={0.05} min={0.01} pricePerUnit={65000} />`}
        >
          <TradingInputApp
            id="trading-demo-crypto"
            variant="crypto"
            unit="BTC"
            currencySymbol="$"
            label="Beli Bitcoin (BTC)"
            description="Masukkan pecahan desimal koin"
            value={cryptoShares}
            onChange={setCryptoShares}
            step={0.05}
            min={0.01}
            pricePerUnit={65000}
            availableBalance={100000}
            rounded="lg"
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="trading-showcase-error"
          title="Insufficient Balance Error"
          description="Peringatan saat estimasi melebihi saldo tersedia"
          align="start"
          className="md:col-span-2"
          code={`<TradingInputApp id="ti" variant="stock" value={300} pricePerUnit={100000} availableBalance={5000000} />`}
        >
          <TradingInputApp
            id="trading-demo-error"
            variant="stock"
            unit="Lot"
            label="Pembelian Saham GOTO"
            description="Contoh peringatan saat estimasi melebihi saldo"
            value={errorLots}
            onChange={setErrorLots}
            pricePerUnit={100000}
            availableBalance={5000000}
            rounded="md"
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="trading-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap TradingInputApp dengan kode JSX yang dihasilkan"
          align="start"
          className="md:col-span-2"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            <div className="flex flex-col gap-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Variant</span>
                  <div className="flex gap-1">
                    {VARIANTS.map((v) => (
                      <PlaygroundChip key={v} id={`trading-play-var-${v}`} active={playVariant === v} onClick={() => selectVariant(v)} className="flex-1">
                        {v}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Unit</span>
                  <InputApp id="trading-play-unit" size="sm" rounded="lg" value={playUnit} onChange={(e) => setPlayUnit(e.target.value)} />
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Size</span>
                  <div className="flex gap-1">
                    {SIZES.map((s) => (
                      <PlaygroundChip key={s} id={`trading-play-size-${s}`} active={playSize === s} onClick={() => setPlaySize(s)} className="flex-1">
                        {s}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Corner Radius</span>
                  <div className="flex flex-wrap gap-1">
                    {ROUNDED.map((r) => (
                      <PlaygroundChip key={r} id={`trading-play-rounded-${r}`} active={playRounded === r} onClick={() => setPlayRounded(r)}>
                        {r}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Harga / Unit</span>
                  <InputApp
                    id="trading-play-price"
                    type="number"
                    size="sm"
                    rounded="lg"
                    value={String(playPrice)}
                    onChange={(e) => setPlayPrice(Number(e.target.value))}
                  />
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Saldo Available</span>
                  <InputApp
                    id="trading-play-balance"
                    type="number"
                    size="sm"
                    rounded="lg"
                    value={String(playBalance)}
                    onChange={(e) => setPlayBalance(Number(e.target.value))}
                  />
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Disabled</span>
                <PlaygroundChip id="trading-play-disabled-toggle" active={playDisabled} onClick={() => setPlayDisabled((v) => !v)}>
                  {playDisabled ? "ON" : "OFF"}
                </PlaygroundChip>
              </div>
            </div>

            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[140px] items-center justify-center rounded-lg border border-dashed border-hairline bg-surface p-4">
                  <TradingInputApp
                    id="interactive-trading-input"
                    label="Input Order Pembelian Interaktif"
                    description="Gunakan tombol persentase atau tombol +/- stepper"
                    variant={playVariant}
                    unit={playUnit}
                    size={playSize}
                    rounded={playRounded}
                    disabled={playDisabled}
                    value={playValue}
                    onChange={setPlayValue}
                    pricePerUnit={playPrice}
                    availableBalance={playBalance}
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="trading-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeString}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
