import * as React from "react";
import {
  ChipsApp,
  ButtonApp,
  DropdownApp,
  InputApp,
  ToggleApp,
  ChipType,
  ChipVariant,
  ChipSize,
  ChipRounded,
} from "@/packages/design-system";
import {
  Tag,
  Sparkles,
  Code,
  Check,
  X,
  Filter,
  Star,
  CheckCircle2,
  Calendar,
  Layers,
  Square,
  Plus,
  RotateCcw,
} from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid, ShowcaseGroup } from "./shared/ShowcaseCard";

const DEFAULT_TAGS = ["PBB-P2 2026", "Kecamatan Danurejan", "Lunas Pajak", "Sudah Diverifikasi"];

export function ChipsDisplayModule() {
  // Demo: Input Chips (Filter tags state)
  const [inputTags, setInputTags] = React.useState<string[]>(DEFAULT_TAGS);
  const [newTagText, setNewTagText] = React.useState("");

  // Demo: Choice Chips (Single & Multi selection)
  const [singleChoice, setSingleChoice] = React.useState<string>("Semua Pajak");
  const [multiChoices, setMultiChoices] = React.useState<string[]>(["Hotel", "Restoran"]);

  // Playground state
  const [playLabel, setPlayLabel] = React.useState("Danurejan");
  const [playType, setPlayType] = React.useState<ChipType>("choice");
  const [playVariant, setPlayVariant] = React.useState<ChipVariant>("vibrant");
  const [playSize, setPlaySize] = React.useState<ChipSize>("md");
  const [playRounded, setPlayRounded] = React.useState<ChipRounded>("pill");
  const [playSelected, setPlaySelected] = React.useState(true);
  const [playRemovable, setPlayRemovable] = React.useState(false);
  const [playLeadingOption, setPlayLeadingOption] = React.useState<"none" | "icon" | "avatar">("icon");
  const [copied, setCopied] = React.useState(false);

  const handleAddTag = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!newTagText.trim()) return;
    if (!inputTags.includes(newTagText.trim())) {
      setInputTags([...inputTags, newTagText.trim()]);
    }
    setNewTagText("");
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setInputTags(inputTags.filter((t) => t !== tagToRemove));
  };

  const toggleMultiChoice = (val: string) => {
    if (multiChoices.includes(val)) {
      setMultiChoices(multiChoices.filter((item) => item !== val));
    } else {
      setMultiChoices([...multiChoices, val]);
    }
  };

  const codeSnippet = `<ChipsApp
  id="my-chip"
  chipType="${playType}" // input | choice | action
  variant="${playVariant}"
  size="${playSize}"
  rounded="${playRounded}" // Foundation: pill | card | circle | square
  selected={${playSelected}}${playRemovable ? `\n  removable\n  onRemove={() => handleRemove()}` : ""}${
    playLeadingOption === "avatar"
      ? `\n  avatar={<img src="https://..." alt="Avatar" />}`
      : playLeadingOption === "icon"
      ? `\n  icon={<Tag />}`
      : ""
  }
>
  ${playLabel}
</ChipsApp>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-chips-module"
      icon={<Layers className="w-5 h-5 text-vibrant-purple-dark" />}
      title="ChipsApp"
      description="Komponen tag interaktif dengan tiga tipe utama (Input, Choice, Action), Foundation Container Radius, leading icon/avatar, trailing remove, status selected, dan varian warna — P4D BPKAD Kota Yogyakarta."
    >
      {/*
        `chipType` dulu tercampur dengan `variant` dan icon dalam satu
        kartu "types" (5 kombinasi berbeda sekaligus). Dipecah per nilai
        chipType, semua dinormalkan ke variant="vibrant" tanpa leading
        element supaya hanya chipType yang berbeda.
      */}
      <ShowcaseGroup id="chips-group-type" title="Chip Type" description="input (removable) · choice (selectable) · action (clickable, seperti button)" cols={3}>
        <ShowcaseCard
          id="chips-showcase-type-input"
          title="Chip Type input"
          description="Tag yang bisa dihapus lewat tombol X"
          code={`<ChipsApp id="c" chipType="input" variant="vibrant" onRemove={fn}>Yogyakarta</ChipsApp>`}
        >
          <ChipsApp id="chips-showcase-type-input-demo" chipType="input" variant="vibrant" onRemove={() => alert("Tag Dihapus")}>Yogyakarta</ChipsApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="chips-showcase-type-choice"
          title="Chip Type choice"
          description="Chip yang bisa dipilih/di-toggle, punya state selected"
          code={`<ChipsApp id="c" chipType="choice" variant="vibrant" selected>Dipilih</ChipsApp>`}
        >
          <ChipsApp id="chips-showcase-type-choice-demo" chipType="choice" variant="vibrant" selected>Dipilih</ChipsApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="chips-showcase-type-action"
          title="Chip Type action"
          description="Chip yang berperilaku seperti tombol aksi"
          code={`<ChipsApp id="c" chipType="action" variant="vibrant" icon={<Filter />} onClick={fn}>Filter</ChipsApp>`}
        >
          <ChipsApp id="chips-showcase-type-action-demo" chipType="action" variant="vibrant" icon={<Filter className="w-3.5 h-3.5" />} onClick={() => alert("Filter Ditekan")}>Filter</ChipsApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      {/*
        Interactive Input / Choice Single / Choice Multi tetap 1 kartu
        masing-masing (KEEP) — ini pola group-component: satu state bersama
        (daftar tag, pilihan tunggal/banyak) yang direpresentasikan oleh
        kumpulan ChipsApp. Memecahnya per chip akan merusak interaksinya.
      */}
      <ShowcaseGrid cols={2}>
        <ShowcaseCard
          id="chips-showcase-interactive-input"
          title="Interactive Input Chips"
          description="Demo hapus/tambah tag filter secara dinamis"
          align="start"
          code={`<ChipsApp id="c" chipType="input" onRemove={() => handleRemoveTag(tag)}>{tag}</ChipsApp>`}
        >
          <div className="w-full space-y-4">
            <form onSubmit={handleAddTag} className="flex items-center gap-2 max-w-md">
              <InputApp id="input-chip-new" placeholder="Ketik tag filter baru..." value={newTagText} onChange={(e) => setNewTagText(e.target.value)} />
              <ButtonApp id="btn-add-chip" variant="primary" size="sm" type="submit" leftIcon={<Plus className="w-4 h-4" />} className="shrink-0">
                Tambah
              </ButtonApp>
            </form>
            <div className="p-4 bg-surface-soft/60 rounded-xl border border-hairline-soft space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-ink">Daftar Filter Aktif ({inputTags.length})</span>
                {inputTags.length < 4 && (
                  <ButtonApp
                    id="btn-reset-chip-sample"
                    variant="ghost"
                    size="sm"
                    onClick={() => setInputTags(DEFAULT_TAGS)}
                    leftIcon={<RotateCcw className="w-3 h-3" />}
                    className="h-6 min-h-6 px-2 text-[11px]"
                  >
                    Reset Filter Sample
                  </ButtonApp>
                )}
              </div>
              {inputTags.length === 0 ? (
                <p className="text-xs text-ink-muted italic py-2">Tidak ada filter aktif. Ketik di atas untuk menambahkan tag baru.</p>
              ) : (
                <div className="flex flex-wrap items-center gap-2">
                  {inputTags.map((tag, idx) => (
                    <ChipsApp key={tag} id={`input-chip-${idx}`} chipType="input" variant={idx % 2 === 0 ? "vibrant" : "neutral"} size="md" onRemove={() => handleRemoveTag(tag)}>
                      {tag}
                    </ChipsApp>
                  ))}
                </div>
              )}
            </div>
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="chips-showcase-choice-single"
          title="Choice Chips — Seleksi Tunggal"
          description="Grup chip pilihan tunggal (radio-like)"
          align="start"
          code={`<ChipsApp id="c" chipType="choice" selected={isSel} onClick={() => setSingleChoice(cat)}>{cat}</ChipsApp>`}
        >
          <div className="w-full space-y-2">
            <div className="flex flex-wrap gap-2">
              {["Semua Pajak", "PBB-P2", "PBJT Kuliner", "BPHTB", "Reklame"].map((cat) => (
                <ChipsApp key={cat} id={`choice-single-${cat}`} chipType="choice" variant="vibrant" selected={singleChoice === cat} onClick={() => setSingleChoice(cat)}>
                  {cat}
                </ChipsApp>
              ))}
            </div>
            <p className="text-[11px] text-ink-muted">
              Pilihan terpilih: <strong className="text-vibrant-purple-dark">{singleChoice}</strong>
            </p>
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="chips-showcase-choice-multi"
          title="Choice Chips — Seleksi Banyak"
          description="Grup chip multi-filter (checkbox-like)"
          align="start"
          code={`<ChipsApp id="c" chipType="choice" selected={isSel} onClick={() => toggleMultiChoice(type)}>{type}</ChipsApp>`}
        >
          <div className="w-full space-y-2">
            <div className="flex flex-wrap gap-2">
              {["Hotel", "Restoran", "Hiburan", "Parkir", "Listrik"].map((type) => (
                <ChipsApp key={type} id={`choice-multi-${type}`} chipType="choice" variant="neutral" selected={multiChoices.includes(type)} onClick={() => toggleMultiChoice(type)}>
                  {type}
                </ChipsApp>
              ))}
            </div>
            <p className="text-[11px] text-ink-muted">
              Filter aktif: <strong className="text-vibrant-purple-dark">{multiChoices.join(", ") || "Tidak Ada"}</strong>
            </p>
          </div>
        </ShowcaseCard>

      </ShowcaseGrid>

      {/*
        "Leading Elements" mencampur avatar (2, satu removable) dan icon (3
        variant warna berbeda) dalam satu kartu. Dipecah per jenis leading
        element; enumerasi warna icon naik ke description grup icon.
      */}
      <ShowcaseGroup id="chips-group-leading" title="Leading Element — Avatar" description="Foto profil di posisi awal chip" cols={2}>
        <ShowcaseCard
          id="chips-showcase-leading-avatar"
          title="Leading avatar"
          description="Foto profil polos tanpa aksi tambahan"
          code={`<ChipsApp id="c" avatar={<img src="..." />}>Ahmad Fauzi</ChipsApp>`}
        >
          <ChipsApp id="chips-showcase-leading-avatar-demo" variant="vibrant" avatar={<img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=128&q=80" alt="Ahmad Fauzi" className="w-full h-full object-cover" />}>Ahmad Fauzi</ChipsApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="chips-showcase-leading-avatar-removable"
          title="Leading avatar + removable"
          description="Foto profil dengan tombol hapus — kombinasi avatar dan removable"
          code={`<ChipsApp id="c" avatar={<img src="..." />} removable onRemove={fn}>Siti Rahma</ChipsApp>`}
        >
          <ChipsApp id="chips-showcase-leading-avatar-removable-demo" variant="neutral" avatar={<img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=128&q=80" alt="Siti Rahma" className="w-full h-full object-cover" />} removable onRemove={() => alert("Hapus Staf")}>Siti Rahma</ChipsApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="chips-group-leading-icon" title="Leading Element — Icon" description="success · warning · info — ikon kategori di posisi awal chip" cols={3}>
        <ShowcaseCard
          id="chips-showcase-leading-icon-success"
          title="Icon variant success"
          description="Status telah lunas/selesai"
          code={`<ChipsApp id="c" variant="success" icon={<CheckCircle2 />}>Status Lunas</ChipsApp>`}
        >
          <ChipsApp id="chips-showcase-leading-icon-success-demo" variant="success" icon={<CheckCircle2 className="w-3.5 h-3.5" />}>Status Lunas</ChipsApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="chips-showcase-leading-icon-warning"
          title="Icon variant warning"
          description="Menandai prioritas yang perlu perhatian"
          code={`<ChipsApp id="c" variant="warning" icon={<Star />}>Prioritas Utama</ChipsApp>`}
        >
          <ChipsApp id="chips-showcase-leading-icon-warning-demo" variant="warning" icon={<Star className="w-3.5 h-3.5" />}>Prioritas Utama</ChipsApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="chips-showcase-leading-icon-info"
          title="Icon variant info"
          description="Menandai kategori wajib/informasi"
          code={`<ChipsApp id="c" variant="info" icon={<Tag />}>Kategori Wajib</ChipsApp>`}
        >
          <ChipsApp id="chips-showcase-leading-icon-info-demo" variant="info" icon={<Tag className="w-3.5 h-3.5" />}>Kategori Wajib</ChipsApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="chips-group-rounded" title="Foundation Container Radius" description="pill (default) · sm · md · lg · none — semua variant=&quot;vibrant&quot; dan selected agar hanya radius yang berbeda" cols={5}>
        <ShowcaseCard
          id="chips-showcase-rounded-pill"
          title="Rounded pill"
          description="Pill penuh — default katalog"
          code={`<ChipsApp id="c" rounded="pill" variant="vibrant" selected>Label</ChipsApp>`}
        >
          <ChipsApp id="chips-showcase-rounded-pill-demo" rounded="pill" variant="vibrant" selected>9999px</ChipsApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="chips-showcase-rounded-sm"
          title="Rounded sm"
          description="Radius kecil"
          code={`<ChipsApp id="c" rounded="sm" variant="vibrant" selected>Label</ChipsApp>`}
        >
          <ChipsApp id="chips-showcase-rounded-sm-demo" rounded="sm" variant="vibrant" selected>4px</ChipsApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="chips-showcase-rounded-md"
          title="Rounded md"
          description="Radius sedang"
          code={`<ChipsApp id="c" rounded="md" variant="vibrant" selected>Label</ChipsApp>`}
        >
          <ChipsApp id="chips-showcase-rounded-md-demo" rounded="md" variant="vibrant" selected>8px</ChipsApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="chips-showcase-rounded-lg"
          title="Rounded lg"
          description="Radius besar"
          code={`<ChipsApp id="c" rounded="lg" variant="vibrant" selected>Label</ChipsApp>`}
        >
          <ChipsApp id="chips-showcase-rounded-lg-demo" rounded="lg" variant="vibrant" selected>16px</ChipsApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="chips-showcase-rounded-none"
          title="Rounded none"
          description="Sudut siku, tanpa radius"
          code={`<ChipsApp id="c" rounded="none" variant="vibrant" selected>Label</ChipsApp>`}
        >
          <ChipsApp id="chips-showcase-rounded-none-demo" rounded="none" variant="vibrant" selected>0px</ChipsApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGrid cols={1}>
        {/* Playground — span penuh */}
        <ShowcaseCard
          id="chips-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap ChipsApp dengan kode JSX yang dihasilkan"
          align="start"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            {/* Controls */}
            <div className="flex flex-col gap-4">
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Teks Label Chip</span>
                <InputApp id="c-play-label" value={playLabel} onChange={(e) => setPlayLabel(e.target.value)} placeholder="Label chip..." />
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Tipe Chip</span>
                  <DropdownApp
                    id="c-play-type"
                    value={playType}
                    onChange={(value) => setPlayType(value as ChipType)}
                    options={[
                      { value: "input", label: "Input Chip (Removable)" },
                      { value: "choice", label: "Choice Chip (Selectable)" },
                      { value: "action", label: "Action Chip (Button)" },
                    ]}
                  />
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Warna Background</span>
                  <DropdownApp
                    id="c-play-variant"
                    value={playVariant}
                    onChange={(value) => setPlayVariant(value as ChipVariant)}
                    options={[
                      { value: "vibrant", label: "Vibrant Purple" },
                      { value: "brand", label: "Brand Purple" },
                      { value: "neutral", label: "Neutral Gray" },
                      { value: "success", label: "Success Green" },
                      { value: "warning", label: "Warning Amber" },
                      { value: "error", label: "Error Red" },
                      { value: "info", label: "Info Sky" },
                      { value: "outline", label: "Outline" },
                    ]}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Ukuran</span>
                  <DropdownApp
                    id="c-play-size"
                    value={playSize}
                    onChange={(value) => setPlaySize(value as ChipSize)}
                    options={[
                      { value: "sm", label: "Small (sm - 24px)" },
                      { value: "md", label: "Medium (md - 32px)" },
                      { value: "lg", label: "Large (lg - 40px)" },
                    ]}
                  />
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Foundation Radius</span>
                  <DropdownApp
                    id="c-play-rounded"
                    value={playRounded}
                    onChange={(value) => setPlayRounded(value as ChipRounded)}
                    options={[
                      { value: "pill", label: "Pill / Full (9999px)" },
                      { value: "sm", label: "Small (sm - 4px)" },
                      { value: "md", label: "Medium (md - 8px)" },
                      { value: "lg", label: "Large (lg - 16px)" },
                      { value: "none", label: "Sharp / None (0px)" },
                    ]}
                  />
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Leading Element</span>
                <DropdownApp
                  id="c-play-leading"
                  value={playLeadingOption}
                  onChange={(value) => setPlayLeadingOption(value as any)}
                  options={[
                    { value: "none", label: "Tanpa Leading Element" },
                    { value: "icon", label: "Tag / Filter Icon" },
                    { value: "avatar", label: "User Avatar Photo" },
                  ]}
                />
              </div>

              <div className="flex flex-wrap items-center gap-5 border-t border-hairline-soft pt-3">
                <ToggleApp id="c-toggle-selected" checked={playSelected} onCheckedChange={setPlaySelected} size="sm" label="Selected State" />
                <ToggleApp id="c-toggle-removable" checked={playRemovable} onCheckedChange={setPlayRemovable} size="sm" label="Remove 'X' Button" />
              </div>
            </div>

            {/* Live Output & Code */}
            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[120px] items-center justify-center rounded-lg border border-dashed border-hairline bg-surface p-4">
                  <ChipsApp
                    id="playground-interactive-chip"
                    chipType={playType}
                    variant={playVariant}
                    size={playSize}
                    rounded={playRounded}
                    selected={playSelected}
                    removable={playRemovable}
                    onRemove={playRemovable ? () => alert("Chip dihapus!") : undefined}
                    icon={playLeadingOption === "icon" ? <Tag className="w-3.5 h-3.5" /> : undefined}
                    avatar={
                      playLeadingOption === "avatar" ? (
                        <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=128&q=80" alt="User" className="w-full h-full object-cover" />
                      ) : undefined
                    }
                    onClick={() => setPlaySelected(!playSelected)}
                  >
                    {playLabel || "Chip Label"}
                  </ChipsApp>
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="copy-c-code"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeSnippet}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
