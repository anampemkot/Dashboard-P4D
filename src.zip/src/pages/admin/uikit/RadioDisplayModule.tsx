import * as React from "react";
import { ButtonApp, RadioApp, RadioGroupApp } from "@/packages/design-system";
import { CircleDot, Code, Check } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid, ShowcaseGroup } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

const VARIANTS = ["default", "brand", "vibrant", "success", "error"] as const;
const SIZES = ["sm", "md", "lg"] as const;

export function RadioDisplayModule() {
  // Demo states for single radios
  const [uncheckedState, setUncheckedState] = React.useState(false);
  const [checkedState, setCheckedState] = React.useState(true);
  const [errorState, setErrorState] = React.useState(false);

  // Group states
  const [verticalGroupValue, setVerticalGroupValue] = React.useState<string>("bank_transfer");
  const [horizontalGroupValue, setHorizontalGroupValue] = React.useState<string>("bulanan");

  // Playground state
  const [playVariant, setPlayVariant] = React.useState<(typeof VARIANTS)[number]>("default");
  const [playSize, setPlaySize] = React.useState<(typeof SIZES)[number]>("md");
  const [playDisabled, setPlayDisabled] = React.useState<boolean>(false);
  const [playChecked, setPlayChecked] = React.useState<boolean>(true);
  const [copied, setCopied] = React.useState<boolean>(false);

  const codeString = `<RadioApp\n  id="demo-radio"\n  label="Pilih Opsi Pembayaran"\n  description="Keterangan deskripsi metode pembayaran"\n  variant="${playVariant}"\n  size="${playSize}"${playDisabled ? "\n  disabled" : ""}\n  checked={${playChecked}}\n/>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-radio-module"
      icon={<CircleDot className="w-5 h-5 text-vibrant-purple-dark" />}
      title="RadioApp & RadioGroupApp"
      description="Elemen pilihan tunggal (radio button) berbentuk lingkaran dengan inner dot indicator — status unchecked, checked, disabled, error validation, serta kelompok bertata letak vertikal & horizontal."
    >
      <ShowcaseGrid cols={2}>
        <ShowcaseGroup id="radio-group-state" title="Radio State" description="unchecked · checked" cols={2}>
          <ShowcaseCard
            id="radio-showcase-state-unchecked"
            title="State unchecked"
            description="Belum dipilih"
            code={`<RadioApp id="rad" label="..." checked={false} />`}
          >
            <RadioApp
              id="radio-showcase-state-unchecked-demo"
              name="demo-single"
              label="Metode Pemulihan Akun via SMS"
              description="Kirim kode verifikasi OTP ke nomor seluler terdaftar"
              checked={uncheckedState}
              onCheckedChange={(c) => setUncheckedState(c)}
            />
          </ShowcaseCard>

          <ShowcaseCard
            id="radio-showcase-state-checked"
            title="State checked"
            description="Sudah dipilih"
            code={`<RadioApp id="rad" label="..." checked />`}
          >
            <RadioApp
              id="radio-showcase-state-checked-demo"
              name="demo-single-checked"
              label="Metode Pemulihan Akun via Email SKPD"
              description="Kirim tautan konfirmasi reset kata sandi ke email resmi"
              checked={checkedState}
              onCheckedChange={(c) => setCheckedState(c)}
            />
          </ShowcaseCard>
        </ShowcaseGroup>

        <ShowcaseGroup id="radio-group-disabled" title="Disabled" description="unchecked · checked" cols={2}>
          <ShowcaseCard
            id="radio-showcase-disabled-unchecked"
            title="Disabled unchecked"
            description="Terkunci, belum dipilih"
            code={`<RadioApp id="rad" disabled checked={false} label="..." />`}
          >
            <RadioApp
              id="radio-showcase-disabled-unchecked-demo"
              name="demo-disabled-1"
              label="Opsi Pengiriman Instant Kurir (Terkunci)"
              description="Layanan pengiriman tidak tersedia untuk wilayah terpilih"
              disabled
              checked={false}
            />
          </ShowcaseCard>

          <ShowcaseCard
            id="radio-showcase-disabled-checked"
            title="Disabled checked"
            description="Terkunci, sudah dipilih"
            code={`<RadioApp id="rad" disabled checked label="..." />`}
          >
            <RadioApp
              id="radio-showcase-disabled-checked-demo"
              name="demo-disabled-2"
              label="Pengiriman Standar Pos Indonesia (Default Aktif)"
              description="Metode standar bawaan aplikasi yang tidak dapat diubah"
              disabled
              checked={true}
            />
          </ShowcaseCard>
        </ShowcaseGroup>

        <ShowcaseGroup id="radio-group-variant" title="Status Validasi" description="error · success" cols={2}>
          <ShowcaseCard
            id="radio-showcase-variant-error"
            title="Variant error"
            description="Validasi gagal, disertai errorMessage"
            code={`<RadioApp id="rad" errorMessage="..." checked={false} label="..." />`}
          >
            <RadioApp
              id="radio-showcase-variant-error-demo"
              name="demo-error"
              label="Metode Pembayaran Kas Daerah"
              errorMessage={!errorState ? "Metode pembayaran ini memerlukan otorisasi bendahara penerimaan" : undefined}
              checked={errorState}
              onCheckedChange={(c) => setErrorState(c)}
            />
          </ShowcaseCard>

          <ShowcaseCard
            id="radio-showcase-variant-success"
            title="Variant success"
            description="Validasi berhasil"
            code={`<RadioApp id="rad" variant="success" checked label="..." />`}
          >
            <RadioApp
              id="radio-showcase-variant-success-demo"
              variant="success"
              label="Status Dokumen Persetujuan Terverifikasi"
              description="Menandakan pilihan opsi telah disetujui sistem"
              checked={true}
            />
          </ShowcaseCard>
        </ShowcaseGroup>

        <ShowcaseGroup id="radio-group-size" title="Size Variants" description="sm · md · lg" cols={3}>
          <ShowcaseCard
            id="radio-showcase-size-sm"
            title="Ukuran sm"
            description="Radio paling ringkas"
            code={`<RadioApp id="rad" size="sm" label="..." checked={false} />`}
          >
            <RadioApp id="radio-showcase-size-sm-demo" name="demo-size-sm" size="sm" label="Radio Ukuran Kecil (size='sm')" checked={false} />
          </ShowcaseCard>

          <ShowcaseCard
            id="radio-showcase-size-md"
            title="Ukuran md"
            description="Ukuran default"
            code={`<RadioApp id="rad" size="md" label="..." checked />`}
          >
            <RadioApp id="radio-showcase-size-md-demo" name="demo-size-md" size="md" label="Radio Ukuran Sedang (size='md')" checked={true} />
          </ShowcaseCard>

          <ShowcaseCard
            id="radio-showcase-size-lg"
            title="Ukuran lg"
            description="Radio paling besar"
            code={`<RadioApp id="rad" size="lg" label="..." checked={false} />`}
          >
            <RadioApp id="radio-showcase-size-lg-demo" name="demo-size-lg" size="lg" label="Radio Ukuran Besar (size='lg')" checked={false} />
          </ShowcaseCard>
        </ShowcaseGroup>

        <ShowcaseCard
          id="radio-showcase-group-vertical"
          title="RadioGroupApp Vertical"
          description="Tata letak kolom dengan opsi disabled"
          code={`<RadioGroupApp id="grp" direction="vertical" options={[...]} value={value} onChange={setValue} />`}
        >
          <RadioGroupApp
            id="rad-group-vert"
            name="kanal_pembayaran"
            label="Kanal Pembayaran Pajak Daerah"
            direction="vertical"
            value={verticalGroupValue}
            onChange={setVerticalGroupValue}
            options={[
              { value: "bank_transfer", label: "Transfer Bank Daerah (Virtual Account)", description: "Bebas biaya admin untuk bank mitra daerah" },
              { value: "qris", label: "QRIS Standar Nasional", description: "Pindai kode QR dari aplikasi e-wallet apa saja" },
              { value: "gerai", label: "Gerai Minimarket / Loket POS", description: "Pembayaran tunai di kasir jaringan terdekat", disabled: true },
            ]}
            helperText="Pilih salah satu metode pembayaran yang Anda inginkan"
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="radio-showcase-group-horizontal"
          title="RadioGroupApp Horizontal"
          description="Tata letak baris (flex-wrap)"
          code={`<RadioGroupApp id="grp" direction="horizontal" options={[...]} value={value} onChange={setValue} />`}
        >
          <RadioGroupApp
            id="rad-group-horiz"
            name="periode_laporan"
            label="Periode Pelaporan Retribusi"
            direction="horizontal"
            value={horizontalGroupValue}
            onChange={setHorizontalGroupValue}
            options={[
              { value: "bulanan", label: "Bulanan" },
              { value: "triwulan", label: "Triwulan" },
              { value: "semester", label: "Semester" },
              { value: "tahunan", label: "Tahunan" },
            ]}
            helperText="Pilihan siklus laporan dalam susunan baris horizontal"
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="radio-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap RadioApp dengan kode JSX yang dihasilkan"
          align="start"
          className="md:col-span-2"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            <div className="flex flex-col gap-4">
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Variant</span>
                <div className="flex flex-wrap gap-1.5">
                  {VARIANTS.map((v) => (
                    <PlaygroundChip key={v} id={`rad-play-variant-${v}`} active={playVariant === v} onClick={() => setPlayVariant(v)}>
                      {v}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Size</span>
                <div className="flex gap-1.5">
                  {SIZES.map((s) => (
                    <PlaygroundChip key={s} id={`rad-play-size-${s}`} active={playSize === s} onClick={() => setPlaySize(s)} className="flex-1">
                      {s}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Checked</span>
                  <PlaygroundChip id="rad-play-checked-toggle" active={playChecked} onClick={() => setPlayChecked((v) => !v)}>
                    {playChecked ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Disabled</span>
                  <PlaygroundChip id="rad-play-disabled-toggle" active={playDisabled} onClick={() => setPlayDisabled((v) => !v)}>
                    {playDisabled ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
              </div>
            </div>

            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[120px] items-center justify-center rounded-lg border border-dashed border-hairline bg-surface p-4">
                  <RadioApp
                    id="interactive-radio-output"
                    name="interactive-radio-group"
                    label="Opsi Pilihan Utama Sistem"
                    description="Status interaktif langsung dari panel kontrol"
                    variant={playVariant}
                    size={playSize}
                    disabled={playDisabled}
                    checked={playChecked}
                    onCheckedChange={(c) => setPlayChecked(c)}
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="rad-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeString}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
