import * as React from "react";
import { ButtonApp, ScorecardApp, TextApp } from "@/packages/design-system";
import { AlertTriangle, Building2, CheckCircle2, Clock, DollarSign, TrendingUp, Users } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid } from "./shared/ShowcaseCard";

export function ScorecardDisplayModule() {
  const [lastInfoClicked, setLastInfoClicked] = React.useState<string | null>(null);

  return (
    <ModuleCard
      id="uikit-scorecard-module"
      icon={<TrendingUp className="h-5 w-5 text-vibrant-purple-dark" />}
      title="ScorecardApp"
      description="Komponen kartu KPI ringkas dengan title, value, optional icon, background variant, dan trend indicator."
    >
      {lastInfoClicked && (
        <div className="mb-4 flex items-center justify-between gap-3 rounded-lg border border-vibrant-purple/30 bg-vibrant-purple/10 p-3 text-xs text-vibrant-purple-dark">
          <TextApp id="scorecard-info-result" variant="caption">
            Info metric dipilih: <strong>{lastInfoClicked}</strong>
          </TextApp>
          <ButtonApp id="scorecard-info-close" variant="ghost" size="sm" onClick={() => setLastInfoClicked(null)}>
            Tutup
          </ButtonApp>
        </div>
      )}

      <ShowcaseGrid cols={3}>
        <ShowcaseCard
          id="scorecard-showcase-purple"
          title="Variant Purple"
          description="Tanpa trend indicator"
          code={`<ScorecardApp id="sc" title="Target Pendapatan" value="Rp 450,0 M" variant="purple" icon={<DollarSign />} />`}
        >
          <ScorecardApp
            id="sc-target"
            title="Target Pendapatan"
            value="Rp 450,0 M"
            unit="TA 2026"
            description="Target penetapan APBD Murni 2026"
            variant="purple"
            badge="BR-01"
            icon={<DollarSign className="h-5 w-5" />}
            infoTooltip="Informasi detail perhitungan target Pendapatan Asli Daerah."
            onInfoClick={() => setLastInfoClicked("Target Pendapatan")}
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="scorecard-showcase-blue"
          title="Variant Blue"
          description="Dengan trend positif"
          code={`<ScorecardApp id="sc" title="Jumlah Wajib Pajak" value="24.850" variant="blue" trend={{ value: "+1.240", isPositive: true }} />`}
        >
          <ScorecardApp
            id="sc-wp-aktif"
            title="Jumlah Wajib Pajak"
            value={24850}
            unit="WP Aktif"
            description="Terdaftar resmi di database BPKAD"
            variant="blue"
            badge="BR-04"
            icon={<Users className="h-5 w-5" />}
            infoTooltip="Klik untuk melihat sebaran per kecamatan."
            onInfoClick={() => setLastInfoClicked("Jumlah Wajib Pajak")}
            trend={{ value: "+1.240", label: "WP baru bulan ini", isPositive: true }}
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="scorecard-showcase-emerald"
          title="Variant Emerald"
          description="Dengan trend positif"
          code={`<ScorecardApp id="sc" title="SLA Pelayanan" value="98,4%" variant="emerald" trend={{ value: "+2,1%", isPositive: true }} />`}
        >
          <ScorecardApp
            id="sc-sla"
            title="SLA Pelayanan"
            value="98,4%"
            unit="Tepat Waktu"
            description="Rata-rata durasi 12 menit per pemohon"
            variant="emerald"
            badge="BR-02"
            icon={<Clock className="h-5 w-5 text-success" />}
            infoTooltip="SLA diukur dari pemanggilan loket hingga pencetakan SKPD."
            onInfoClick={() => setLastInfoClicked("SLA Pelayanan")}
            trend={{ value: "+2,1%", label: "Efisiensi meningkat", isPositive: true }}
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="scorecard-showcase-alert"
          title="Variant Alert"
          description="Dengan trend negatif"
          code={`<ScorecardApp id="sc" title="Permohonan Menumpuk" value="142" variant="alert" trend={{ value: "+38", isPositive: false }} />`}
        >
          <ScorecardApp
            id="sc-alert"
            title="Permohonan Menumpuk"
            value="142"
            unit="Berkas"
            description="Melebihi ambang batas toleransi"
            variant="alert"
            badge="BR-12"
            icon={<AlertTriangle className="h-5 w-5 text-error" />}
            infoTooltip="Daftar berkas yang perlu diverifikasi segera."
            onInfoClick={() => setLastInfoClicked("Permohonan Menumpuk")}
            trend={{ value: "+38", label: "vs kemarin", isPositive: false }}
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="scorecard-showcase-yellow"
          title="Variant Yellow"
          description="Tanpa trend indicator"
          code={`<ScorecardApp id="sc" title="Survei Pendataan OP" value="850" variant="yellow" icon={<Building2 />} />`}
        >
          <ScorecardApp
            id="sc-op-baru"
            title="Survei Pendataan OP"
            value="850"
            unit="Lokasi"
            description="Hasil pendataan survei lapangan"
            variant="yellow"
            badge="BR-03"
            icon={<Building2 className="h-5 w-5" />}
            infoTooltip="Pendataan tim lapangan BPKAD Kota Yogyakarta."
            onInfoClick={() => setLastInfoClicked("Survei Pendataan OP")}
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="scorecard-showcase-clay"
          title="Variant Clay"
          description="Dengan trend positif"
          code={`<ScorecardApp id="sc" title="Data Quality Index" value="94,8" variant="clay" trend={{ value: "+1,4", isPositive: true }} />`}
        >
          <ScorecardApp
            id="sc-data-quality"
            title="Data Quality Index"
            value="94,8"
            unit="/ 100"
            description="Keabsahan basis data NIK dan NOP"
            variant="clay"
            badge="BR-06"
            icon={<CheckCircle2 className="h-5 w-5 text-vibrant-purple-dark" />}
            infoTooltip="Dihitung otomatis dari validasi Dukcapil dan Agraria."
            onInfoClick={() => setLastInfoClicked("Data Quality Index")}
            trend={{ value: "+1,4", label: "vs bulan lalu", isPositive: true }}
          />
        </ShowcaseCard>
        <ShowcaseCard
          id="scorecard-showcase-info-popover-active"
          title="Info Popover — State Aktif"
          description="Trigger: klik ikon info (ⓘ) di sebelah judul. Popover menampilkan formula, periode, sumber data, dan waktu update — dipinjam terbuka di sini untuk dokumentasi."
          align="start"
          className="md:col-span-3"
          code={`<ScorecardApp\n  id="sc"\n  title="Realisasi PBB-P2"\n  value={2840500000}\n  unit="Rp"\n  infoContent={{\n    formula: "Total setoran tervalidasi ÷ target pokok ketetapan × 100%",\n    period: "Bulanan (per tanggal 1)",\n    source: "SIMDA Keuangan Daerah",\n    lastUpdated: "2 menit lalu",\n  }}\n/>`}
        >
          <div className="w-full max-w-xs">
            <ScorecardApp
              id="sc-info-demo"
              title="Realisasi PBB-P2"
              value={2840500000}
              unit="Rp"
              description="Setoran tervalidasi tahun berjalan"
              variant="purple"
              badge="BR-01"
              icon={<DollarSign className="h-5 w-5" />}
              infoContent={{
                formula: "Total setoran tervalidasi ÷ target pokok ketetapan × 100%",
                period: "Bulanan (per tanggal 1)",
                source: "SIMDA Keuangan Daerah",
                lastUpdated: "2 menit lalu",
              }}
              infoOpenForShowcase
              trend={{ value: "+8,2%", label: "vs bulan lalu", isPositive: true }}
            />
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="scorecard-showcase-insight-dialog"
          title="Insight Dialog"
          description="Prop insight (InsightContent) — trigger ikon bohlam di samping ikon info, membuka dialog analisis lengkap (Ringkasan/Kondisi/Insight/Rekomendasi Taktis &amp; Strategis/Smart Glosarium/Catatan Data). Beda dari infoContent (formula/periode/sumber singkat), dan additive — keduanya boleh dipakai bersamaan."
          align="start"
          className="md:col-span-3"
          code={`<ScorecardApp
  id="sc-npl"
  title="NPL Gross"
  value="14,64%"
  variant="alert"
  insight={{
    title: "Non Performing Loan Gross (NPL Gross)",
    value: "14,64%",
    status: "kritis",
    meta: ["Indikator", "NPL Gross", "Jan – Agustus 2026"],
    summary: "NPL Gross mengukur seluruh kredit bermasalah (Kol 3-5) terhadap baki debet. Ambang batas regulator OJK adalah 5%.",
    current: ["Realisasi terkini 14,64%.", "Target tahunan 11,03%."],
    insights: ["Setiap kenaikan 100 bps NPL Gross berdampak pada CKPN dan ATMR — laba & CAR ikut tertekan.", "Pergeseran komposisi (Kol 2 → 3) adalah leading indicator 30-60 hari."],
    tacticalRecs: ["...", "..."],
    strategicRecs: ["...", "..."],
    glossary: [{ term: "NPL", expansion: "Non Performing Loan", definition: "kredit bermasalah (Kol 3-5)." }],
    dataNotes: ["Snapshot per 02 Agustus 2026."],
  }}
/>`}
        >
          <div className="w-full max-w-xs">
            <ScorecardApp
              id="sc-insight-demo"
              title="NPL Gross"
              value="14,64%"
              description="Kredit bermasalah terhadap baki debet"
              variant="alert"
              badge="Kritis"
              icon={<AlertTriangle className="h-5 w-5" />}
              trend={{ value: "+1,8pp", label: "vs bulan lalu", isPositive: false }}
              insight={{
                title: "Non Performing Loan Gross (NPL Gross)",
                value: "14,64%",
                status: "kritis",
                meta: ["Indikator", "NPL Gross", "Jan – Agustus 2026"],
                summary:
                  "NPL Gross mengukur seluruh kredit bermasalah (Kol 3–5) terhadap baki debet. Ambang batas regulator OJK adalah 5%.",
                current: ["Realisasi terkini 14,64%.", "Target tahunan 11,03%."],
                insights: [
                  "Setiap kenaikan 100 basis points (bps) NPL Gross berdampak pada Cadangan Kerugian Penurunan Nilai (CKPN) dan Aset Tertimbang Menurut Risiko (ATMR) — laba & Capital Adequacy Ratio (CAR) ikut tertekan.",
                  "Pergeseran komposisi (Kol 2 → 3) adalah leading indicator 30–60 hari.",
                  "Dampak ke Laporan Laba Rugi: kenaikan NPL memaksa tambahan CKPN sehingga beban pencadangan naik dan laba bersih turun.",
                ],
                tacticalRecs: [
                  "Percepat restrukturisasi kredit Kol 2 berpotensi turun ke Kol 3 dalam 30 hari ke depan.",
                  "Intensifkan penagihan lapangan untuk debitur Kol 3–4 bernilai tinggi.",
                ],
                strategicRecs: [
                  "Perketat kebijakan underwriting sektor dengan kontribusi NPL tertinggi.",
                  "Bangun early-warning system berbasis pergeseran kolektibilitas bulanan.",
                ],
                glossary: [
                  { term: "NPL", expansion: "Non Performing Loan", definition: "kredit bermasalah (Kol 3–5)." },
                  { term: "CKPN", expansion: "Cadangan Kerugian Penurunan Nilai", definition: "cadangan yang wajib dibentuk atas potensi kerugian kredit." },
                  { term: "ATMR", expansion: "Aset Tertimbang Menurut Risiko", definition: "dasar perhitungan kecukupan modal (CAR)." },
                  { term: "CAR", expansion: "Capital Adequacy Ratio", definition: "rasio kecukupan modal terhadap ATMR." },
                ],
                dataNotes: [
                  "Snapshot per 02 Agustus 2026.",
                  "Angka realisasi mengikuti snapshot harian terakhir yang berhasil diimpor.",
                ],
              }}
            />
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
