import * as React from "react";
import { ButtonApp, InputApp } from "@/packages/design-system";
import { Settings, Code, Check, Search, Lock, User, Hash, FileText } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

const VARIANTS = ["default", "filled", "error", "success"] as const;
const SIZES = ["sm", "md", "lg"] as const;
const ROUNDED = ["none", "sm", "md", "lg", "xl", "full"] as const;

export function InputDisplayModule() {
  // Live Playground State
  const [playVariant, setPlayVariant] = React.useState<(typeof VARIANTS)[number]>("default");
  const [playSize, setPlaySize] = React.useState<(typeof SIZES)[number]>("md");
  const [playRounded, setPlayRounded] = React.useState<(typeof ROUNDED)[number]>("md");
  const [playDisabled, setPlayDisabled] = React.useState<boolean>(false);
  const [playPlaceholder, setPlayPlaceholder] = React.useState<string>("Masukkan nama lengkap wajib pajak...");
  const [copied, setCopied] = React.useState<boolean>(false);

  const codeString = `<InputApp\n  id="my-input"\n  variant="${playVariant}"\n  size="${playSize}"\n  rounded="${playRounded}"\n  placeholder="${playPlaceholder}"${playDisabled ? "\n  disabled" : ""}\n/>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-input-module"
      icon={<Settings className="w-5 h-5 text-vibrant-purple-dark" />}
      title="InputApp"
      description="Elemen masukan teks utama formulir P4D BPKAD — variasi varian, ikon, stepper number, password toggle, max-length counter, dan status validasi interaktif."
    >
      <ShowcaseGrid cols={2}>
        <ShowcaseCard
          id="input-showcase-standard"
          title="Standard Text Input"
          description="Label, helper text, leading icon, dan clear button"
          code={`<InputApp\n  id="nama"\n  label="Nama Lengkap Wajib Pajak"\n  leadingIcon={<User />}\n  showClear\n/>`}
        >
          <InputApp
            id="input-demo-standard"
            label="Nama Lengkap Wajib Pajak"
            placeholder="Masukkan nama lengkap sesuai KTP..."
            helperText="Harus sesuai dengan KTP / NPWP wajib pajak"
            leadingIcon={<User className="w-4 h-4" />}
            showClear
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="input-showcase-password"
          title="Password Input"
          description="Toggle show/hide password"
          code={`<InputApp\n  id="pwd"\n  type="password"\n  leadingIcon={<Lock />}\n  showPasswordToggle\n/>`}
        >
          <InputApp
            id="input-demo-password"
            type="password"
            label="Kata Sandi Akun BPKAD"
            placeholder="Masukkan kata sandi..."
            helperText="Minimal 8 karakter campuran huruf dan angka"
            leadingIcon={<Lock className="w-4 h-4" />}
            showPasswordToggle
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="input-showcase-number"
          title="Number Input dengan Stepper"
          description="Tombol stepper untuk menyesuaikan nominal"
          code={`<InputApp\n  id="jumlah"\n  type="number"\n  step={50000}\n  showStepper\n/>`}
        >
          <InputApp
            id="input-demo-number"
            type="number"
            label="Jumlah Setoran Pajak (Rp)"
            defaultValue="500000"
            step={50000}
            leadingIcon={<Hash className="w-4 h-4" />}
            showStepper
            helperText="Gunakan ikon stepper di sebelah kanan untuk menyesuaikan nominal"
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="input-showcase-dual-icons"
          title="Dual Icons (Leading & Trailing)"
          description="Ikon di kedua sisi untuk navigasi pencarian"
          code={`<InputApp\n  id="nop"\n  leadingIcon={<Search />}\n  trailingIcon={<Check />}\n  showClear\n/>`}
        >
          <InputApp
            id="input-demo-icons"
            label="Pencarian Nomor Objek Pajak (NOP)"
            placeholder="Contoh: 32.73.010..."
            leadingIcon={<Search className="w-4 h-4" />}
            trailingIcon={<Check className="w-4 h-4 text-vibrant-purple-dark" />}
            showClear
            helperText="Ikon di kedua sisi memudahkan navigasi pencarian cepat"
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="input-showcase-disabled"
          title="Disabled State"
          description="Input terkunci dan tidak dapat disunting"
          code={`<InputApp id="npwp" disabled leadingIcon={<Lock />} />`}
        >
          <InputApp
            id="input-demo-disabled"
            label="Nomor Pokok Wajib Pajak (Terkunci)"
            defaultValue="NPWP: 01.234.567.8-901.000"
            disabled
            leadingIcon={<Lock className="w-4 h-4" />}
            helperText="Input terkunci dan tidak dapat disunting oleh pengguna"
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="input-showcase-variant-error"
          title="Variant error"
          description="Validasi gagal, disertai errorMessage"
          code={`<InputApp id="email" variant="error" errorMessage="..." />`}
        >
          <InputApp
            id="input-showcase-variant-error-demo"
            label="Email Resmi Dinas / Perusahaan"
            defaultValue="budi.santoso@"
            variant="error"
            errorMessage="Format alamat email tidak valid (harus menggunakan domain .com / .go.id)"
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="input-showcase-variant-success"
          title="Variant success"
          description="Validasi berhasil, disertai successMessage"
          code={`<InputApp id="nik" variant="success" successMessage="..." />`}
        >
          <InputApp
            id="input-showcase-variant-success-demo"
            label="Nomor Induk Kependudukan (NIK)"
            defaultValue="3273012903940001"
            variant="success"
            successMessage="NIK terverifikasi valid dengan database Dukcapil daerah"
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="input-showcase-maxlength"
          title="Max Length Counter"
          description="Indikator jumlah karakter (45/50)"
          code={`<InputApp id="catatan" maxLength={50} showMaxLength />`}
        >
          <InputApp
            id="input-demo-maxlength"
            label="Catatan Pelaporan Tambahan"
            defaultValue="Laporan pajak bumi dan bangunan tahunan 2026"
            maxLength={50}
            showMaxLength
            leadingIcon={<FileText className="w-4 h-4" />}
            helperText="Batas maksimum karakter yang diizinkan sistem"
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="input-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap InputApp dengan kode JSX yang dihasilkan"
          align="start"
          className="md:col-span-2"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            <div className="flex flex-col gap-4">
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Placeholder</span>
                <InputApp
                  id="input-play-placeholder"
                  size="sm"
                  value={playPlaceholder}
                  onChange={(e) => setPlayPlaceholder(e.target.value)}
                />
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Variant</span>
                <div className="flex flex-wrap gap-1.5">
                  {VARIANTS.map((v) => (
                    <PlaygroundChip key={v} id={`input-play-variant-${v}`} active={playVariant === v} onClick={() => setPlayVariant(v)}>
                      {v}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Size</span>
                  <div className="flex gap-1.5">
                    {SIZES.map((s) => (
                      <PlaygroundChip key={s} id={`input-play-size-${s}`} active={playSize === s} onClick={() => setPlaySize(s)} className="flex-1">
                        {s}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Corner Radius</span>
                  <div className="flex flex-wrap gap-1">
                    {ROUNDED.map((r) => (
                      <PlaygroundChip key={r} id={`input-play-rounded-${r}`} active={playRounded === r} onClick={() => setPlayRounded(r)}>
                        {r}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Disabled</span>
                <PlaygroundChip id="input-play-disabled-toggle" active={playDisabled} onClick={() => setPlayDisabled((d) => !d)}>
                  {playDisabled ? "Disabled: ON" : "Disabled: OFF"}
                </PlaygroundChip>
              </div>
            </div>

            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[120px] items-center justify-center rounded-lg border border-dashed border-hairline bg-surface p-4">
                  <InputApp
                    id="interactive-input-output"
                    label="Nama Wajib Pajak"
                    variant={playVariant}
                    size={playSize}
                    rounded={playRounded}
                    disabled={playDisabled}
                    placeholder={playPlaceholder}
                    helperText="Pratinjau langsung interaksi input"
                    showClear
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="input-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeString}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
