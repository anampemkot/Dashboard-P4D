import * as React from "react";
import { SkeletonApp } from "@/packages/design-system";
import { Eye } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGroup } from "./shared/ShowcaseCard";

export function SkeletonDisplayModule() {
  return (
    <ModuleCard
      id="uikit-skeleton-module"
      icon={<Eye className="w-5 h-5 text-accent" />}
      title="SkeletonApp"
      description="Indikator pemuatan asynchronous dengan warna soft slate yang terlihat solid di mode terang maupun gelap — P4D BPKAD Kota Yogyakarta."
    >
      <ShowcaseGroup id="skeleton-group-variant" title="Variant" description="text · rect · circle — untuk kartu list, avatar, dan blok konten" cols={3}>
        <ShowcaseCard
          id="skeleton-showcase-variant-text"
          title="Variant text"
          description="Garis tipis untuk placeholder baris teks"
          code={`<SkeletonApp id="s" variant="text" className="w-1/3" />`}
        >
          <SkeletonApp id="skeleton-showcase-variant-text-demo" variant="text" className="w-2/3" />
        </ShowcaseCard>

        <ShowcaseCard
          id="skeleton-showcase-variant-rect"
          title="Variant rect"
          description="Blok persegi untuk placeholder gambar/kartu"
          code={`<SkeletonApp id="s" variant="rect" className="w-16 h-12" />`}
        >
          <SkeletonApp id="skeleton-showcase-variant-rect-demo" variant="rect" className="w-16 h-12" />
        </ShowcaseCard>

        <ShowcaseCard
          id="skeleton-showcase-variant-circle"
          title="Variant circle"
          description="Lingkaran untuk placeholder avatar"
          code={`<SkeletonApp id="s" variant="circle" className="w-10 h-10" />`}
        >
          <SkeletonApp id="skeleton-showcase-variant-circle-demo" variant="circle" className="w-10 h-10" />
        </ShowcaseCard>
      </ShowcaseGroup>

      <ShowcaseGroup id="skeleton-group-size" title="Ketinggian Baris" description="sm · md (default) · lg — semua variant=&quot;rect&quot; agar hanya ketinggian yang berbeda" cols={3}>
        <ShowcaseCard
          id="skeleton-showcase-size-sm"
          title="Ukuran sm"
          description="Baris paling tipis"
          code={`<SkeletonApp id="s" variant="rect" size="sm" className="w-full" />`}
        >
          <SkeletonApp id="skeleton-showcase-size-sm-demo" variant="rect" size="sm" className="w-full" />
        </ShowcaseCard>

        <ShowcaseCard
          id="skeleton-showcase-size-md"
          title="Ukuran md"
          description="Ketinggian standar katalog"
          code={`<SkeletonApp id="s" variant="rect" size="md" className="w-full" />`}
        >
          <SkeletonApp id="skeleton-showcase-size-md-demo" variant="rect" size="md" className="w-full" />
        </ShowcaseCard>

        <ShowcaseCard
          id="skeleton-showcase-size-lg"
          title="Ukuran lg"
          description="Baris paling tebal"
          code={`<SkeletonApp id="s" variant="rect" size="lg" className="w-full" />`}
        >
          <SkeletonApp id="skeleton-showcase-size-lg-demo" variant="rect" size="lg" className="w-full" />
        </ShowcaseCard>
      </ShowcaseGroup>
    </ModuleCard>
  );
}
