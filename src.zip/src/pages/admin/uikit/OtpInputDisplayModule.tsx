import * as React from "react";
import { OtpInputApp, ButtonApp } from "@/packages/design-system";
import { KeyRound, Code, Check, RefreshCw } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

const LENGTHS = [4, 6] as const;
const VARIANTS = ["default", "error", "success"] as const;
const SIZES = ["sm", "md", "lg"] as const;
const ROUNDED = ["none", "sm", "md", "lg", "xl", "full"] as const;

export function OtpInputDisplayModule() {
  // Playground State
  const [playLength, setPlayLength] = React.useState<(typeof LENGTHS)[number]>(6);
  const [playMasked, setPlayMasked] = React.useState<boolean>(false);
  const [playVariant, setPlayVariant] = React.useState<(typeof VARIANTS)[number]>("default");
  const [playSize, setPlaySize] = React.useState<(typeof SIZES)[number]>("md");
  const [playRounded, setPlayRounded] = React.useState<(typeof ROUNDED)[number]>("lg");
  const [playDisabled, setPlayDisabled] = React.useState<boolean>(false);
  const [playValue, setPlayValue] = React.useState<string>("");
  const [completedCode, setCompletedCode] = React.useState<string>("");

  // Demo interactive states
  const [resendTimer, setResendTimer] = React.useState<number>(30);
  const [canResend, setCanResend] = React.useState<boolean>(false);
  const [copied, setCopied] = React.useState<boolean>(false);

  React.useEffect(() => {
    let timer: any;
    if (resendTimer > 0) {
      timer = setInterval(() => setResendTimer((prev) => prev - 1), 1000);
    } else {
      setCanResend(true);
    }
    return () => clearInterval(timer);
  }, [resendTimer]);

  const handleResend = () => {
    setResendTimer(30);
    setCanResend(false);
  };

  const codeString = `<OtpInputApp\n  id="demo-otp-input"\n  length={${playLength}}\n  variant="${playVariant}"\n  size="${playSize}"\n  rounded="${playRounded}"${playMasked ? "\n  masked" : ""}${playDisabled ? "\n  disabled" : ""}\n  onChange={(val) => console.log(val)}\n  onComplete={(val) => alert("Complete: " + val)}\n/>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-otpinput-module"
      icon={<KeyRound className="w-5 h-5 text-vibrant-purple-dark" />}
      title="OtpInputApp"
      description="Komponen masukan OTP/PIN multi-digit dengan dukungan auto-advance, backspace-advance, paste 4/6 digit, mode tersembunyi (masked PIN), serta indikator state error/success."
    >
      <ShowcaseGrid cols={2}>
        <ShowcaseCard
          id="otp-showcase-4digit"
          title="4-Digit Standard Input"
          description="length={4}"
          code={`<OtpInputApp id="otp" length={4} label="..." defaultValue="74" />`}
        >
          <OtpInputApp id="otp-demo-4digit" length={4} label="Kode Verifikasi 4-Digit" description="Masukkan 4 digit kode OTP yang dikirim melalui SMS" defaultValue="74" />
        </ShowcaseCard>

        <ShowcaseCard
          id="otp-showcase-masked"
          title="6-Digit Masked PIN"
          description="masked — digit disembunyikan untuk keamanan"
          code={`<OtpInputApp id="otp" length={6} masked label="..." defaultValue="123456" />`}
        >
          <OtpInputApp id="otp-demo-masked" length={6} masked label="PIN Transaksi Keuangan" description="Digit tersembunyi untuk keamanan transaksi" defaultValue="123456" />
        </ShowcaseCard>

        <ShowcaseCard
          id="otp-showcase-error"
          title="Error State"
          description="error / variant=&quot;error&quot;"
          code={`<OtpInputApp id="otp" length={6} error errorMessage="..." defaultValue="982104" />`}
        >
          <OtpInputApp
            id="otp-demo-error"
            length={6}
            error
            label="Kode OTP Kadaluarsa"
            description="Contoh tampilan ketika kode salah atau expired"
            defaultValue="982104"
            errorMessage="Kode OTP tidak valid atau telah kadaluarsa. Silakan minta kode baru."
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="otp-showcase-success"
          title="Success State"
          description="success / variant=&quot;success&quot;"
          code={`<OtpInputApp id="otp" length={6} success successMessage="..." defaultValue="882190" />`}
        >
          <OtpInputApp
            id="otp-demo-success"
            length={6}
            success
            label="Verifikasi Berhasil"
            description="Contoh tampilan ketika kode OTP telah sesuai"
            defaultValue="882190"
            successMessage="Kode verifikasi cocok! Melanjutkan ke halaman dashboard..."
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="otp-showcase-resend"
          title="Resend Timer & Action Utility"
          description="Integrasi penghitung waktu mundur kirim ulang OTP"
          align="start"
          className="md:col-span-2"
          code={`<OtpInputApp id="otp" length={6} label="..." />\n// countdown timer + ButtonApp "Kirim Ulang Kode" saat waktu habis`}
        >
          <div className="flex w-full flex-col gap-3 text-left">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-ink-muted">Kirim Ulang Kode</span>
              {!canResend ? (
                <span className="font-mono text-xs text-ink-muted">Kirim ulang dalam 00:{resendTimer < 10 ? `0${resendTimer}` : resendTimer}</span>
              ) : (
                <ButtonApp id="otp-resend-btn" type="button" variant="outline" size="sm" leftIcon={<RefreshCw className="w-3.5 h-3.5" />} onClick={handleResend}>
                  Kirim Ulang Kode
                </ButtonApp>
              )}
            </div>
            <OtpInputApp id="otp-demo-timer" length={6} label="Kirim Ulang OTP Demo" description="Integrasi penghitung waktu mundur kirim ulang OTP" />
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="otp-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap OtpInputApp dengan kode JSX yang dihasilkan"
          align="start"
          className="md:col-span-2"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            <div className="flex flex-col gap-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Length</span>
                  <div className="flex gap-1">
                    {LENGTHS.map((l) => (
                      <PlaygroundChip key={l} id={`otp-play-len-${l}`} active={playLength === l} onClick={() => setPlayLength(l)} className="flex-1">
                        {l} Digits
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Variant</span>
                  <div className="flex gap-1">
                    {VARIANTS.map((v) => (
                      <PlaygroundChip key={v} id={`otp-play-var-${v}`} active={playVariant === v} onClick={() => setPlayVariant(v)} className="flex-1">
                        {v}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Size</span>
                  <div className="flex gap-1">
                    {SIZES.map((s) => (
                      <PlaygroundChip key={s} id={`otp-play-size-${s}`} active={playSize === s} onClick={() => setPlaySize(s)} className="flex-1">
                        {s}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Corner Radius</span>
                  <div className="flex flex-wrap gap-1">
                    {ROUNDED.map((r) => (
                      <PlaygroundChip key={r} id={`otp-play-rounded-${r}`} active={playRounded === r} onClick={() => setPlayRounded(r)}>
                        {r}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Masked PIN</span>
                  <PlaygroundChip id="otp-play-mask-toggle" active={playMasked} onClick={() => setPlayMasked((v) => !v)}>
                    {playMasked ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Disabled</span>
                  <PlaygroundChip id="otp-play-disabled-toggle" active={playDisabled} onClick={() => setPlayDisabled((v) => !v)}>
                    {playDisabled ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
              </div>
            </div>

            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[150px] flex-col items-center justify-center gap-3 rounded-lg border border-dashed border-hairline bg-surface p-4">
                  <OtpInputApp
                    id="interactive-otp-input"
                    label="Uji Coba Masukan OTP Interaktif"
                    description="Ketik angka atau tempel (paste) kode OTP ke kotak digit"
                    length={playLength}
                    variant={playVariant}
                    size={playSize}
                    rounded={playRounded}
                    masked={playMasked}
                    disabled={playDisabled}
                    value={playValue}
                    onChange={setPlayValue}
                    onComplete={(val) => setCompletedCode(val)}
                    errorMessage={playVariant === "error" ? "Kode OTP salah!" : undefined}
                    successMessage={playVariant === "success" ? "Verifikasi sukses!" : undefined}
                  />
                  {completedCode && (
                    <div className="w-full rounded-lg border border-emerald-200 bg-emerald-50 p-2 text-center dark:border-emerald-800 dark:bg-emerald-950/30">
                      <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-300">
                        Callback `onComplete` Dipicu: <strong>{completedCode}</strong>
                      </span>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="otp-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeString}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
