import * as React from "react";
import { ButtonApp } from "@/packages/design-system";
import {
  Layers,
  Settings,
  Code,
  Check,
  Plus,
  ArrowRight,
  Download,
  Search,
  CheckCircle2,
} from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid, ShowcaseGroup } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

const CORE_VARIANTS = ["primary", "secondary", "ghost", "icon", "danger", "outline"] as const;
const SEMANTIC_VARIANTS = ["success", "warning", "error", "info"] as const;
const ACCENT_VARIANTS = ["yellow", "blue", "purple", "purpleDark", "white"] as const;

export function ButtonDisplayModule() {
  // Live Playground State
  const [playVariant, setPlayVariant] = React.useState<
    (typeof CORE_VARIANTS)[number] | (typeof SEMANTIC_VARIANTS)[number] | (typeof ACCENT_VARIANTS)[number]
  >("primary");
  const [playSize, setPlaySize] = React.useState<"sm" | "md" | "lg" | "iconSm" | "iconMd" | "iconLg">("md");
  const [playRounded, setPlayRounded] = React.useState<"none" | "sm" | "md" | "lg" | "full">("md");
  const [playTheme, setPlayTheme] = React.useState<"default" | "playful">("default");
  const [playState, setPlayState] = React.useState<"default" | "disabled" | "loading">("default");
  const [playIconConfig, setPlayIconConfig] = React.useState<"none" | "left" | "right" | "both">("left");
  const [copied, setCopied] = React.useState<boolean>(false);

  const isIconOnly = playVariant === "icon" || playSize.toString().startsWith("icon");
  const themeCode = playTheme === "playful" ? `\n  theme="playful"` : "";
  const leftIconCode = !isIconOnly && (playIconConfig === "left" || playIconConfig === "both") ? `\n  leftIcon={<Plus className="w-4 h-4" />}` : "";
  const rightIconCode = !isIconOnly && (playIconConfig === "right" || playIconConfig === "both") ? `\n  rightIcon={<ArrowRight className="w-4 h-4" />}` : "";
  const disabledCode = playState === "disabled" ? `\n  disabled` : "";
  const loadingCode = playState === "loading" ? `\n  isLoading` : "";

  const codeString = `<ButtonApp
  id="my-action-btn"
  variant="${playVariant}"
  size="${playSize}"
  rounded="${playRounded}"${themeCode}${leftIconCode}${rightIconCode}${disabledCode}${loadingCode}
>
  ${isIconOnly ? "" : "Simpan Data"}
</ButtonApp>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const playIconSizeClass = playSize === "sm" || playSize === "iconSm" ? "w-3.5 h-3.5" : playSize === "lg" || playSize === "iconLg" ? "w-5 h-5" : "w-4 h-4";

  return (
    <ModuleCard
      id="uikit-button-module"
      icon={<Layers className="w-5 h-5 text-vibrant-purple-dark" />}
      title="ButtonApp"
      description="Tombol aksi utama design system P4D BPKAD Kota Yogyakarta — seluruh varian, ukuran, state interaktif, dan corner radius selaras Foundation System."
    >
      {/*
        Kartu di modul ini atomik: satu ShowcaseCard = satu ButtonApp.
        Pengelompokan "core / semantic / accent" hanya judul ShowcaseGroup —
        ketiganya bucket editorial di atas SATU prop (`variant`), jadi id-nya
        satu namespace datar `variant-*` (lihat aturan penamaan di AGENTS.md).
      */}
      <ShowcaseGroup
        id="button-group-variant-core"
        title="Variant — Inti"
        description="primary · secondary · ghost · icon · danger · outline"
        cols={4}
      >
        <ShowcaseCard
          id="button-showcase-variant-primary"
          title="Variant primary"
          description="Aksi utama, satu per layar"
          code={`<ButtonApp id="btn" variant="primary" size="sm">Simpan Data</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-variant-primary-demo" variant="primary" size="sm">Simpan Data</ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-variant-secondary"
          title="Variant secondary"
          description="Aksi pendamping di samping primary"
          code={`<ButtonApp id="btn" variant="secondary" size="sm">Batal</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-variant-secondary-demo" variant="secondary" size="sm">Batal</ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-variant-ghost"
          title="Variant ghost"
          description="Tanpa latar, untuk aksi tersier"
          code={`<ButtonApp id="btn" variant="ghost" size="sm">Lewati</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-variant-ghost-demo" variant="ghost" size="sm">Lewati</ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-variant-icon"
          title="Variant icon"
          description="Ikon saja, tanpa label teks"
          code={`<ButtonApp id="btn" variant="icon" size="sm"><Settings /></ButtonApp>`}
        >
          <ButtonApp id="button-showcase-variant-icon-demo" variant="icon" size="sm"><Settings className="w-3.5 h-3.5" /></ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-variant-danger"
          title="Variant danger"
          description="Aksi merusak yang tidak bisa dibatalkan"
          code={`<ButtonApp id="btn" variant="danger" size="sm">Hapus</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-variant-danger-demo" variant="danger" size="sm">Hapus</ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-variant-outline"
          title="Variant outline"
          description="Bergaris, kontras rendah"
          code={`<ButtonApp id="btn" variant="outline" size="sm">Detail</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-variant-outline-demo" variant="outline" size="sm">Detail</ButtonApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup
        id="button-group-variant-semantic"
        title="Variant — Semantic"
        description="success · warning · error · info — mewarnai tombol sesuai hasil aksi"
        cols={4}
      >
        <ShowcaseCard
          id="button-showcase-variant-success"
          title="Variant success"
          description="Konfirmasi aksi yang berhasil"
          code={`<ButtonApp id="btn" variant="success" size="sm">Berhasil</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-variant-success-demo" variant="success" size="sm">Berhasil</ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-variant-warning"
          title="Variant warning"
          description="Aksi yang perlu perhatian ekstra"
          code={`<ButtonApp id="btn" variant="warning" size="sm">Perhatian</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-variant-warning-demo" variant="warning" size="sm">Perhatian</ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-variant-error"
          title="Variant error"
          description="Aksi gagal yang bisa diulang"
          code={`<ButtonApp id="btn" variant="error" size="sm">Coba Lagi</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-variant-error-demo" variant="error" size="sm">Coba Lagi</ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-variant-info"
          title="Variant info"
          description="Aksi informatif, netral"
          code={`<ButtonApp id="btn" variant="info" size="sm">Detail</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-variant-info-demo" variant="info" size="sm">Detail</ButtonApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup
        id="button-group-variant-accent"
        title="Variant — Aksen Warna"
        description="yellow · blue · purple · purpleDark · white — aksen brand di luar skala semantic"
        cols={5}
      >
        <ShowcaseCard
          id="button-showcase-variant-yellow"
          title="Variant yellow"
          description="Aksen kuning brand"
          code={`<ButtonApp id="btn" variant="yellow" size="sm">Aksi</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-variant-yellow-demo" variant="yellow" size="sm">Aksi</ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-variant-blue"
          title="Variant blue"
          description="Aksen biru brand"
          code={`<ButtonApp id="btn" variant="blue" size="sm">Aksi</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-variant-blue-demo" variant="blue" size="sm">Aksi</ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-variant-purple"
          title="Variant purple"
          description="Aksen ungu brand"
          code={`<ButtonApp id="btn" variant="purple" size="sm">Aksi</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-variant-purple-demo" variant="purple" size="sm">Aksi</ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-variant-purple-dark"
          title="Variant purpleDark"
          description="Ungu gelap, kontras tertinggi"
          code={`<ButtonApp id="btn" variant="purpleDark" size="sm">Aksi</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-variant-purple-dark-demo" variant="purpleDark" size="sm">Aksi</ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-variant-white"
          title="Variant white"
          description="Di atas latar berwarna atau gambar"
          code={`<ButtonApp id="btn" variant="white" size="sm">Aksi</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-variant-white-demo" variant="white" size="sm">Aksi</ButtonApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup
        id="button-group-size"
        title="Ukuran"
        description="sm 32px · md 40px · lg 48px, plus tiga kontainer ikon-saja. Semua variant=&quot;primary&quot; agar hanya ukuran yang berbeda"
        cols={3}
      >
        <ShowcaseCard
          id="button-showcase-size-sm"
          title="Ukuran sm"
          description="Tinggi 32px — default katalog"
          code={`<ButtonApp id="btn" variant="primary" size="sm">Kecil</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-size-sm-demo" variant="primary" size="sm">Kecil</ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-size-md"
          title="Ukuran md"
          description="Tinggi 40px"
          code={`<ButtonApp id="btn" variant="primary" size="md">Sedang</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-size-md-demo" variant="primary" size="md">Sedang</ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-size-lg"
          title="Ukuran lg"
          description="Tinggi 48px"
          code={`<ButtonApp id="btn" variant="primary" size="lg">Besar</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-size-lg-demo" variant="primary" size="lg">Besar</ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-size-icon-sm"
          title="Ukuran iconSm"
          description="Kontainer ikon 32px persegi"
          code={`<ButtonApp id="btn" variant="primary" size="iconSm"><Settings /></ButtonApp>`}
        >
          <ButtonApp id="button-showcase-size-icon-sm-demo" variant="primary" size="iconSm"><Settings /></ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-size-icon-md"
          title="Ukuran iconMd"
          description="Kontainer ikon 40px persegi"
          code={`<ButtonApp id="btn" variant="primary" size="iconMd"><Settings /></ButtonApp>`}
        >
          <ButtonApp id="button-showcase-size-icon-md-demo" variant="primary" size="iconMd"><Settings /></ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-size-icon-lg"
          title="Ukuran iconLg"
          description="Kontainer ikon 48px persegi"
          code={`<ButtonApp id="btn" variant="primary" size="iconLg"><Settings /></ButtonApp>`}
        >
          <ButtonApp id="button-showcase-size-icon-lg-demo" variant="primary" size="iconLg"><Settings /></ButtonApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup
        id="button-group-rounded"
        title="Corner Radius"
        description="none 0px · sm 4px · md 8px · lg 16px (default) · full pill — skala Foundation"
        cols={5}
      >
        <ShowcaseCard
          id="button-showcase-rounded-none"
          title="Rounded none"
          description="Sudut siku, 0px"
          code={`<ButtonApp id="btn" variant="primary" size="sm" rounded="none">Aksi</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-rounded-none-demo" variant="primary" size="sm" rounded="none">Aksi</ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-rounded-sm"
          title="Rounded sm"
          description="Radius 4px"
          code={`<ButtonApp id="btn" variant="primary" size="sm" rounded="sm">Aksi</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-rounded-sm-demo" variant="primary" size="sm" rounded="sm">Aksi</ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-rounded-md"
          title="Rounded md"
          description="Radius 8px"
          code={`<ButtonApp id="btn" variant="primary" size="sm" rounded="md">Aksi</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-rounded-md-demo" variant="primary" size="sm" rounded="md">Aksi</ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-rounded-lg"
          title="Rounded lg"
          description="Radius 16px — default katalog"
          code={`<ButtonApp id="btn" variant="primary" size="sm" rounded="lg">Aksi</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-rounded-lg-demo" variant="primary" size="sm" rounded="lg">Aksi</ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-rounded-full"
          title="Rounded full"
          description="Pill penuh"
          code={`<ButtonApp id="btn" variant="primary" size="sm" rounded="full">Aksi</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-rounded-full-demo" variant="primary" size="sm" rounded="full">Aksi</ButtonApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup
        id="button-group-theme"
        title="Theme"
        description="default · playful — playful memakai font display dan bayangan claymorphic"
        cols={2}
      >
        <ShowcaseCard
          id="button-showcase-theme-default"
          title="Theme default"
          description="Gaya standar katalog"
          code={`<ButtonApp id="btn" variant="primary" size="sm" theme="default">Aksi</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-theme-default-demo" variant="primary" size="sm" theme="default">Primary Standard</ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-theme-playful"
          title="Theme playful"
          description="Font display dan bayangan claymorphic"
          code={`<ButtonApp id="btn" variant="primary" size="sm" theme="playful">Aksi</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-theme-playful-demo" variant="primary" size="sm" theme="playful">Primary Playful ✨</ButtonApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      {/*
        Tidak ada prop `state` di ButtonApp — dulu satu kartu "Interactive States"
        memvariasikan dua boolean berbeda. Dipecah jadi nama flag aslinya; anak
        "default" dibuang karena prop-nya identik dengan variant-primary.
      */}
      <ShowcaseGroup
        id="button-group-state"
        title="State"
        description="Dua prop boolean terpisah — hover, active, dan focus dicoba langsung di tombol mana pun"
        cols={2}
      >
        <ShowcaseCard
          id="button-showcase-disabled"
          title="Disabled"
          description="Tombol terkunci dan tidak menerima pointer"
          code={`<ButtonApp id="btn" variant="primary" size="sm" disabled>Terkunci</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-disabled-demo" variant="primary" size="sm" disabled>Terkunci</ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="button-showcase-loading"
          title="Loading"
          description="Spinner plus loadingText menggantikan label"
          code={`<ButtonApp id="btn" variant="primary" size="sm" isLoading loadingText="Memproses...">Simpan</ButtonApp>`}
        >
          <ButtonApp id="button-showcase-loading-demo" variant="primary" size="sm" isLoading loadingText="Memproses...">Simpan</ButtonApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGrid cols={1}>
        {/* Playground — span penuh */}
        <ShowcaseCard
          id="button-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap ButtonApp dengan kode JSX yang dihasilkan"
          align="start"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            {/* Controls */}
            <div className="flex flex-col gap-4">
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Variant</span>
                <div className="flex flex-wrap gap-1.5">
                  {[...CORE_VARIANTS, ...SEMANTIC_VARIANTS, ...ACCENT_VARIANTS].map((v) => (
                    <PlaygroundChip key={v} id={`btn-play-variant-${v}`} active={playVariant === v} onClick={() => setPlayVariant(v)}>
                      {v}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Size</span>
                  <div className="flex flex-wrap gap-1">
                    {(["sm", "md", "lg", "iconSm", "iconMd", "iconLg"] as const).map((s) => (
                      <PlaygroundChip key={s} id={`btn-play-size-${s}`} active={playSize === s} onClick={() => setPlaySize(s)}>
                        {s}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Corner Radius</span>
                  <div className="flex gap-1">
                    {(["none", "sm", "md", "lg", "full"] as const).map((r) => (
                      <PlaygroundChip key={r} id={`btn-play-rounded-${r}`} active={playRounded === r} onClick={() => setPlayRounded(r)} className="flex-1">
                        {r}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Theme</span>
                  <div className="flex gap-1">
                    {(["default", "playful"] as const).map((tm) => (
                      <PlaygroundChip key={tm} id={`btn-play-theme-${tm}`} active={playTheme === tm} onClick={() => setPlayTheme(tm)} className="flex-1 capitalize">
                        {tm}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">State</span>
                  <div className="flex gap-1">
                    {(["default", "disabled", "loading"] as const).map((st) => (
                      <PlaygroundChip key={st} id={`btn-play-state-${st}`} active={playState === st} onClick={() => setPlayState(st)} className="flex-1 capitalize">
                        {st}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Icon</span>
                  <div className="flex gap-1">
                    {(["none", "left", "right", "both"] as const).map((ic) => (
                      <PlaygroundChip key={ic} id={`btn-play-icon-${ic}`} active={playIconConfig === ic} onClick={() => setPlayIconConfig(ic)} className="flex-1 capitalize">
                        {ic}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Live Output & Code */}
            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[120px] items-center justify-center rounded-lg border border-dashed border-hairline bg-surface p-4">
                  <ButtonApp
                    id="playground-button-output"
                    variant={playVariant}
                    size={playSize}
                    rounded={playRounded}
                    theme={playTheme}
                    disabled={playState === "disabled"}
                    isLoading={playState === "loading"}
                    loadingText="Memproses..."
                    leftIcon={!isIconOnly && (playIconConfig === "left" || playIconConfig === "both") ? <Plus className={playIconSizeClass} /> : undefined}
                    rightIcon={!isIconOnly && (playIconConfig === "right" || playIconConfig === "both") ? <ArrowRight className={playIconSizeClass} /> : undefined}
                  >
                    {isIconOnly ? <Settings className={playIconSizeClass} /> : "Simpan Data"}
                  </ButtonApp>
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="btn-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeString}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>

        {/* Tabel Spesifikasi — span penuh */}
        <ShowcaseCard
          id="button-showcase-spec-table"
          title="Tabel Spesifikasi & Aturan Penggunaan"
          description="Standar pemakaian tiap varian di lingkungan P4D BPKAD"
          align="start"
        >
          <div className="w-full overflow-x-auto">
            <table className="w-full border-collapse text-left text-xs">
              <thead>
                <tr className="border-b border-hairline bg-surface-soft text-ink">
                  <th className="px-3 py-2.5 font-bold">Varian</th>
                  <th className="px-3 py-2.5 font-bold">Min-Height</th>
                  <th className="px-3 py-2.5 font-bold">Radius Default</th>
                  <th className="px-3 py-2.5 font-bold">Aturan Penggunaan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-hairline-soft text-[11px] text-ink-secondary">
                {[
                  ["Primary", "Aksi utama tunggal (Submit, Simpan, Konfirmasi Utama)"],
                  ["Secondary", "Aksi pendamping (Batal, Reset, Filter Data, Export)"],
                  ["Ghost / Text", "Aksi ringan tanpa gangguan visual (Detail, Lihat Lebih)"],
                  ["Icon Button", "Kontrol khusus ikon (Pengaturan, Tutup, Search, Notif)"],
                  ["Danger", "Aksi berisiko tinggi (Hapus Data, Batalkan Transaksi)"],
                  ["Outline", "Garis luar tanpa latar solid"],
                  ["Success", "Konfirmasi berhasil (Simpan Sukses, Verifikasi Diterima)"],
                  ["Warning", "Aksi butuh perhatian (Konfirmasi Berisiko Sedang)"],
                  ["Error", "Status gagal pada aksi (Coba Lagi, Retry Upload)"],
                  ["Info", "Aksi informatif netral (Lihat Detail, Pelajari)"],
                ].map(([name, rule]) => (
                  <tr key={name}>
                    <td className="px-3 py-2 font-semibold text-ink">{name}</td>
                    <td className="px-3 py-2 font-mono">32px (sm) / 40px (md) / 48px (lg)</td>
                    <td className="px-3 py-2 font-mono">rounded=&quot;lg&quot; (16px)</td>
                    <td className="px-3 py-2">{rule}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
