import * as React from "react";
import { DropdownApp, DropdownOption, DropdownSize, DropdownVariant, ButtonApp, InputApp } from "@/packages/design-system";
import { ListFilter, Check, Building2, UserCheck, ShieldCheck, CreditCard, Layers, Tag, Code } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

const SAMPLE_TAX_TYPES: DropdownOption[] = [
  { label: "PBB-P2 (Pajak Bumi & Bangunan Perdesaan dan Perkotaan)", value: "pbb", badge: "Utama", icon: Building2, description: "Objek Pajak Tanah & Bangunan" },
  { label: "PBJT Makanan dan/atau Minuman (Restoran)", value: "pbjt_resto", badge: "Resto", icon: CreditCard, description: "Usaha Kuliner & Restoran" },
  { label: "PBJT Tenaga Listrik (PPJ)", value: "pbjt_listrik", icon: CreditCard, description: "Penggunaan Listrik Daerah" },
  { label: "PBJT Jasa Perhotelan", value: "pbjt_hotel", icon: CreditCard, description: "Hotel & Penginapan" },
  { label: "PBJT Jasa Parkir", value: "pbjt_parkir", icon: CreditCard, description: "Penyelenggara Lokasi Parkir" },
  { label: "PBJT Jasa Kesenian dan Hiburan", value: "pbjt_hiburan", icon: CreditCard, description: "Bioskop, Rekreasi, & Konser" },
  { label: "Pajak Reklame", value: "reklame", badge: "Tinggi", icon: Tag, description: "Baliho, Spanduk, & Videotron" },
  { label: "PAT (Pajak Air Tanah)", value: "pat", icon: Layers, description: "Pengambilan Air Tanah" },
];

const SAMPLE_DISTRICTS: DropdownOption[] = [
  { label: "Kecamatan Bandung Wetan", value: "bdg_wetan", badge: "Pusat" },
  { label: "Kecamatan Sumur Bandung", value: "smr_bdg" },
  { label: "Kecamatan Coblong", value: "coblong", badge: "Ramai" },
  { label: "Kecamatan Lengkong", value: "lengkong" },
  { label: "Kecamatan Cicendo", value: "cicendo" },
  { label: "Kecamatan Sukajadi", value: "sukajadi" },
  { label: "Kecamatan Regol", value: "regol" },
  { label: "Kecamatan Cibeunying Kaler", value: "cib_kaler" },
];

const SAMPLE_ROLES: DropdownOption[] = [
  { label: "Administrator Utama (BPKAD)", value: "admin", icon: ShieldCheck, description: "Akses Penuh Semua Fitur Sistem" },
  { label: "Petugas Verifikasi Pajak", value: "verifier", icon: UserCheck, description: "Pemeriksa Berkas SPT & SKPD" },
  { label: "Petugas Lapangan / Pendataan", value: "collector", icon: Building2, description: "Pendata Potensi Baru & Geotagging" },
  { label: "Auditor Internal BPKAD", value: "auditor", icon: Layers, description: "Akses Laporan & Log Transaksi" },
];

const SIZES: DropdownSize[] = ["sm", "md", "lg"];
const VARIANTS: DropdownVariant[] = ["default", "error", "success"];

export function DropdownDisplayModule() {
  // Playground state
  const [playIsMulti, setPlayIsMulti] = React.useState(false);
  const [playSearchable, setPlaySearchable] = React.useState(true);
  const [playShowClear, setPlayShowClear] = React.useState(true);
  const [playDisabled, setPlayDisabled] = React.useState(false);
  const [playSize, setPlaySize] = React.useState<DropdownSize>("md");
  const [playVariant, setPlayVariant] = React.useState<DropdownVariant>("default");
  const [playLabel, setPlayLabel] = React.useState("Pilih Jenis Pajak Daerah");
  const [playValue, setPlayValue] = React.useState<string | string[]>("pbb");

  // Controlled values for showcase sections
  const [singleVal, setSingleVal] = React.useState<string>("pbb");
  const [multiVal, setMultiVal] = React.useState<string[]>(["pbb", "pbjt_resto", "reklame"]);
  const [iconVal, setIconVal] = React.useState<string>("admin");
  const [searchVal, setSearchVal] = React.useState<string>("bdg_wetan");

  const [copied, setCopied] = React.useState(false);

  const codeSnippet = `<DropdownApp
  id="dropdown-demo"
  label="${playLabel}"
  placeholder="Pilih opsi..."
  options={SAMPLE_OPTIONS}
  value={${JSON.stringify(playValue)}}
  onChange={(val) => setValue(val)}
  isMulti={${playIsMulti}}
  searchable={${playSearchable}}
  showClear={${playShowClear}}
  disabled={${playDisabled}}
  size="${playSize}"
  variant="${playVariant}"
/>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-dropdown-module"
      icon={<ListFilter className="w-5 h-5 text-vibrant-purple-dark" />}
      title="DropdownApp"
      description="Komponen pemilih item tunggal (Single Select) dan multi (Multi Select) dengan pencarian terintegrasi, tag interaktif, icon & deskripsi opsional, indikator status, serta navigasi keyboard lengkap."
    >
      <ShowcaseGrid cols={2}>
        <ShowcaseCard
          id="dropdown-showcase-single"
          title="Single Select"
          description="Pencarian & tombol hapus 'X'"
          align="start"
          code={`<DropdownApp id="dp" options={options} value={value} onChange={setValue} searchable showClear />`}
        >
          <div className="w-full space-y-2">
            <DropdownApp
              id="dp-single-mode"
              label="Jenis Pajak Utama"
              placeholder="Pilih jenis pajak..."
              options={SAMPLE_TAX_TYPES}
              value={singleVal}
              onChange={(val) => setSingleVal(val as string)}
              searchable
              showClear
            />
            <p className="text-[11px] text-ink-muted">
              Terpilih: <span className="font-semibold text-vibrant-purple-dark">{singleVal || "Belum ada"}</span>
            </p>
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="dropdown-showcase-multi"
          title="Multi Select"
          description="isMulti dengan tag BadgeApp & hapus cepat"
          align="start"
          code={`<DropdownApp id="dp" isMulti options={options} value={values} onChange={setValues} searchable showClear />`}
        >
          <div className="w-full space-y-2">
            <DropdownApp
              id="dp-multi-mode"
              label="Kategori Pajak Terpilih"
              placeholder="Pilih satu atau lebih..."
              options={SAMPLE_TAX_TYPES}
              value={multiVal}
              onChange={(val) => setMultiVal(val as string[])}
              isMulti
              searchable
              showClear
            />
            <p className="text-[11px] text-ink-muted">
              Jumlah Tag: <span className="font-semibold text-vibrant-purple-dark">{multiVal.length} Opsi</span>
            </p>
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="dropdown-showcase-icon"
          title="Icon & Sub-label"
          description="Opsi kaya visual dengan icon & deskripsi tambahan"
          align="start"
          code={`<DropdownApp id="dp" options={rolesWithIcons} value={value} onChange={setValue} showClear />`}
        >
          <div className="w-full space-y-2">
            <DropdownApp
              id="dp-icon-mode"
              label="Hak Akses Petugas"
              placeholder="Pilih peranan..."
              options={SAMPLE_ROLES}
              value={iconVal}
              onChange={(val) => setIconVal(val as string)}
              showClear
            />
            <p className="text-[11px] text-ink-muted">
              Role: <span className="font-semibold text-vibrant-purple-dark">{iconVal}</span>
            </p>
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="dropdown-showcase-search-highlight"
          title="Filter Real-time & Highlight"
          description="Teks yang cocok di-highlight otomatis saat mengetik"
          align="start"
          code={`<DropdownApp id="dp" options={options} searchable showClear searchPlaceholder="Cari..." />`}
        >
          <DropdownApp
            id="dp-searchable-districts"
            label="Pilih Kecamatan"
            placeholder="Ketik untuk mencari kecamatan..."
            options={SAMPLE_DISTRICTS}
            value={searchVal}
            onChange={(val) => setSearchVal(val as string)}
            searchable
            showClear
            searchPlaceholder="Cari nama kecamatan..."
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="dropdown-showcase-chip-tag"
          title="Multi-Select Tag Chip"
          description='tagType="chip" — atom ChipsApp dengan onDelete'
          align="start"
          code={`<DropdownApp id="dp" isMulti tagType="chip" options={options} defaultValue={[...]} searchable showClear />`}
        >
          <DropdownApp
            id="dp-chip-tags-demo"
            label="Tag Pajak (tagType='chip')"
            placeholder="Pilih tag..."
            options={SAMPLE_TAX_TYPES}
            defaultValue={["pbb", "pbjt_resto"]}
            isMulti
            tagType="chip"
            searchable
            showClear
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="dropdown-showcase-creatable"
          title="Opsi Baru On-the-fly"
          description="isCreatable — ketik & tekan Enter untuk buat opsi baru"
          align="start"
          code={`<DropdownApp id="dp" isMulti isCreatable searchable options={options} showClear />`}
        >
          <DropdownApp
            id="dp-creatable-demo"
            label="Tambah Kategori Pajak Baru"
            placeholder="Ketik nama kategori baru..."
            options={SAMPLE_TAX_TYPES}
            isMulti
            searchable
            isCreatable
            showClear
            searchPlaceholder="Cari atau ketik opsi baru..."
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="dropdown-showcase-size-sm"
          title="Ukuran sm"
          description="Dropdown paling ringkas"
          align="start"
          code={`<DropdownApp id="dp" size="sm" options={options} defaultValue="..." />`}
        >
          <DropdownApp id="dropdown-showcase-size-sm-demo" size="sm" placeholder="Size SM..." options={SAMPLE_DISTRICTS} defaultValue="bdg_wetan" />
        </ShowcaseCard>

        <ShowcaseCard
          id="dropdown-showcase-variant-success"
          title="Variant success"
          description="Validasi berhasil, disertai helperText"
          align="start"
          code={`<DropdownApp id="dp" variant="success" helperText="Data valid" options={options} />`}
        >
          <DropdownApp id="dropdown-showcase-variant-success-demo" variant="success" helperText="Data pajak valid" options={SAMPLE_TAX_TYPES} defaultValue="pbb" />
        </ShowcaseCard>

        <ShowcaseCard
          id="dropdown-showcase-variant-error"
          title="Variant error"
          description="Validasi gagal, disertai helperText"
          align="start"
          code={`<DropdownApp id="dp" variant="error" helperText="Wajib memilih" options={options} />`}
        >
          <DropdownApp id="dropdown-showcase-variant-error-demo" variant="error" helperText="Wajib memilih jenis pajak" options={SAMPLE_TAX_TYPES} />
        </ShowcaseCard>

        <ShowcaseCard
          id="dropdown-showcase-disabled"
          title="Disabled"
          description="Dropdown terkunci dan tidak dapat dibuka"
          align="start"
          code={`<DropdownApp id="dp" disabled helperText="Formulir terkunci" options={options} />`}
        >
          <DropdownApp id="dropdown-showcase-disabled-demo" disabled helperText="Formulir terkunci" options={SAMPLE_TAX_TYPES} defaultValue="pbb" />
        </ShowcaseCard>

        <ShowcaseCard
          id="dropdown-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap DropdownApp dengan kode JSX yang dihasilkan"
          align="start"
          className="md:col-span-2"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            <div className="flex flex-col gap-4">
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Teks Label</span>
                <InputApp id="dp-play-label" size="sm" rounded="lg" value={playLabel} onChange={(e) => setPlayLabel(e.target.value)} placeholder="Label dropdown..." />
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Ukuran</span>
                  <div className="flex gap-1">
                    {SIZES.map((s) => (
                      <PlaygroundChip key={s} id={`dp-play-size-${s}`} active={playSize === s} onClick={() => setPlaySize(s)} className="flex-1">
                        {s}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Status</span>
                  <div className="flex gap-1">
                    {VARIANTS.map((v) => (
                      <PlaygroundChip key={v} id={`dp-play-variant-${v}`} active={playVariant === v} onClick={() => setPlayVariant(v)} className="flex-1">
                        {v}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Multi Select</span>
                  <PlaygroundChip
                    id="dp-play-multi-toggle"
                    active={playIsMulti}
                    onClick={() => {
                      setPlayIsMulti(!playIsMulti);
                      setPlayValue(!playIsMulti ? ["pbb"] : "pbb");
                    }}
                  >
                    {playIsMulti ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Searchable</span>
                  <PlaygroundChip id="dp-play-searchable-toggle" active={playSearchable} onClick={() => setPlaySearchable((v) => !v)}>
                    {playSearchable ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Clear Button</span>
                  <PlaygroundChip id="dp-play-clear-toggle" active={playShowClear} onClick={() => setPlayShowClear((v) => !v)}>
                    {playShowClear ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Disabled</span>
                  <PlaygroundChip id="dp-play-disabled-toggle" active={playDisabled} onClick={() => setPlayDisabled((v) => !v)}>
                    {playDisabled ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
              </div>
            </div>

            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[160px] items-center justify-center rounded-lg border border-dashed border-hairline bg-surface p-4">
                  <DropdownApp
                    id="dp-playground-component"
                    label={playLabel}
                    placeholder="Pilih opsi..."
                    options={SAMPLE_TAX_TYPES}
                    value={playValue}
                    onChange={(val) => setPlayValue(val)}
                    isMulti={playIsMulti}
                    searchable={playSearchable}
                    showClear={playShowClear}
                    disabled={playDisabled}
                    size={playSize}
                    variant={playVariant}
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="dp-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeSnippet}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
