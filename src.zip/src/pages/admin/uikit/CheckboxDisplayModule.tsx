import * as React from "react";
import { ButtonApp, CheckboxApp, CheckboxGroupApp } from "@/packages/design-system";
import { CheckSquare, Code, Check } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid, ShowcaseGroup } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

const VARIANTS = ["default", "brand", "vibrant", "success", "error"] as const;
const SIZES = ["sm", "md", "lg"] as const;

export function CheckboxDisplayModule() {
  // Demo states for single checkboxes
  const [uncheckedState, setUncheckedState] = React.useState(false);
  const [checkedState, setCheckedState] = React.useState(true);
  const [indeterminateState, setIndeterminateState] = React.useState(true);
  const [errorState, setErrorState] = React.useState(false);

  // Group states
  const [verticalGroupValues, setVerticalGroupValues] = React.useState<string[]>(["email", "whatsapp"]);
  const [horizontalGroupValues, setHorizontalGroupValues] = React.useState<string[]>(["pbb", "bphtb"]);

  // Playground state
  const [playVariant, setPlayVariant] = React.useState<(typeof VARIANTS)[number]>("default");
  const [playSize, setPlaySize] = React.useState<(typeof SIZES)[number]>("md");
  const [playIndeterminate, setPlayIndeterminate] = React.useState<boolean>(false);
  const [playDisabled, setPlayDisabled] = React.useState<boolean>(false);
  const [playChecked, setPlayChecked] = React.useState<boolean>(true);
  const [copied, setCopied] = React.useState<boolean>(false);

  const codeString = `<CheckboxApp\n  id="demo-checkbox"\n  label="Pilih Opsi Verifikasi"\n  description="Keterangan deskripsi tambahan"\n  variant="${playVariant}"\n  size="${playSize}"${playIndeterminate ? "\n  indeterminate" : ""}${playDisabled ? "\n  disabled" : ""}\n  checked={${playChecked}}\n/>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-checkbox-module"
      icon={<CheckSquare className="w-5 h-5 text-vibrant-purple-dark" />}
      title="CheckboxApp & CheckboxGroupApp"
      description="Elemen masukan centang tunggal dan kelompok — status unchecked, checked, indeterminate, disabled, error message, serta tata letak vertikal & horizontal."
    >
      <ShowcaseGrid cols={2}>
        <ShowcaseGroup id="checkbox-group-state" title="Checkbox State" description="unchecked · checked" cols={2}>
          <ShowcaseCard
            id="checkbox-showcase-state-unchecked"
            title="State unchecked"
            description="Belum dicentang"
            code={`<CheckboxApp id="chk" label="..." checked={false} />`}
          >
            <CheckboxApp
              id="checkbox-showcase-state-unchecked-demo"
              label="Ingat Sesi Perangkat Ini"
              description="Sesi Anda akan tetap terhubung selama 30 hari ke depan"
              checked={uncheckedState}
              onCheckedChange={(c) => setUncheckedState(c)}
            />
          </ShowcaseCard>

          <ShowcaseCard
            id="checkbox-showcase-state-checked"
            title="State checked"
            description="Sudah dicentang"
            code={`<CheckboxApp id="chk" label="..." checked />`}
          >
            <CheckboxApp
              id="checkbox-showcase-state-checked-demo"
              label="Langganan Warta Pajak & Retribusi Daerah"
              description="Terima pembaruan regulasi dan tanggal jatuh tempo bulanan"
              checked={checkedState}
              onCheckedChange={(c) => setCheckedState(c)}
            />
          </ShowcaseCard>
        </ShowcaseGroup>

        <ShowcaseCard
          id="checkbox-showcase-indeterminate"
          title="Indeterminate State"
          description="Ikon garis untuk status select-all sebagian"
          code={`<CheckboxApp id="chk" indeterminate checked={false} label="Pilih Semua" />`}
        >
          <CheckboxApp
            id="chk-demo-indeterminate"
            label="Pilih Semua Aset Daerah (Status Sebagian)"
            description="Ikon garis horizontal menunjukkan sebagian item dalam daftar terpilih"
            indeterminate={indeterminateState}
            checked={false}
            onCheckedChange={() => setIndeterminateState(!indeterminateState)}
          />
        </ShowcaseCard>

        <ShowcaseGroup id="checkbox-group-disabled" title="Disabled" description="unchecked · checked" cols={2}>
          <ShowcaseCard
            id="checkbox-showcase-disabled-unchecked"
            title="Disabled unchecked"
            description="Terkunci, belum dicentang"
            code={`<CheckboxApp id="chk" disabled checked={false} label="..." />`}
          >
            <CheckboxApp
              id="checkbox-showcase-disabled-unchecked-demo"
              label="Opsi Otomasi Laporan (Terkunci)"
              description="Fitur memerlukan izin level Administrator SKPD"
              disabled
              checked={false}
            />
          </ShowcaseCard>

          <ShowcaseCard
            id="checkbox-showcase-disabled-checked"
            title="Disabled checked"
            description="Terkunci, sudah dicentang"
            code={`<CheckboxApp id="chk" disabled checked label="..." />`}
          >
            <CheckboxApp
              id="checkbox-showcase-disabled-checked-demo"
              label="Protokol Keamanan SSL 256-bit (Aktif & Terkunci)"
              description="Syarat wajib sistem terenkripsi dan tidak dapat dimatikan"
              disabled
              checked={true}
            />
          </ShowcaseCard>
        </ShowcaseGroup>

        <ShowcaseGroup id="checkbox-group-variant" title="Status Validasi" description="error · success" cols={2}>
          <ShowcaseCard
            id="checkbox-showcase-variant-error"
            title="Variant error"
            description="Validasi gagal, disertai errorMessage"
            code={`<CheckboxApp id="chk" errorMessage="..." checked={false} label="..." />`}
          >
            <CheckboxApp
              id="checkbox-showcase-variant-error-demo"
              label="Saya menyetujui Pakta Integritas dan Kebijakan Privasi"
              errorMessage={!errorState ? "Anda wajib menyetujui pakta integritas sebelum mengirimkan berkas" : undefined}
              checked={errorState}
              onCheckedChange={(c) => setErrorState(c)}
            />
          </ShowcaseCard>

          <ShowcaseCard
            id="checkbox-showcase-variant-success"
            title="Variant success"
            description="Validasi berhasil"
            code={`<CheckboxApp id="chk" variant="success" checked label="..." />`}
          >
            <CheckboxApp
              id="checkbox-showcase-variant-success-demo"
              variant="success"
              label="Berkas Verifikasi Lapangan Validated"
              description="Tanda centang hijau menunjukkan verifikasi instansi sukses"
              checked={true}
            />
          </ShowcaseCard>
        </ShowcaseGroup>

        <ShowcaseCard
          id="checkbox-showcase-group-vertical"
          title="CheckboxGroupApp Vertical"
          description="Tata letak kolom dengan opsi disabled"
          code={`<CheckboxGroupApp id="grp" direction="vertical" options={[...]} value={value} onChange={setValue} />`}
        >
          <CheckboxGroupApp
            id="chk-group-vert"
            label="Saluran Notifikasi Penagihan Pajak"
            direction="vertical"
            value={verticalGroupValues}
            onChange={setVerticalGroupValues}
            options={[
              { value: "email", label: "Surat Elektronik (Email)", description: "Pemberitahuan resmi via inbox email SKPD" },
              { value: "whatsapp", label: "WhatsApp Gateway Service", description: "Notifikasi pesan instan nomor WhatsApp" },
              { value: "sms", label: "Layanan SMS Kritis (Non-aktif)", description: "Fitur SMS saat ini sedang dipelihara", disabled: true },
            ]}
            helperText="Pilih satu atau beberapa saluran pengiriman notifikasi"
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="checkbox-showcase-group-horizontal"
          title="CheckboxGroupApp Horizontal"
          description="Tata letak baris (flex-wrap)"
          code={`<CheckboxGroupApp id="grp" direction="horizontal" options={[...]} value={value} onChange={setValue} />`}
        >
          <CheckboxGroupApp
            id="chk-group-horiz"
            label="Kategori Pajak Daerah Pilihan"
            direction="horizontal"
            value={horizontalGroupValues}
            onChange={setHorizontalGroupValues}
            options={[
              { value: "pbb", label: "PBB-P2" },
              { value: "bphtb", label: "BPHTB" },
              { value: "reklame", label: "Pajak Reklame" },
              { value: "air", label: "Pajak Air Tanah" },
            ]}
            helperText="Pilihan dalam susunan horizontal (flex-wrap gap-3)"
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="checkbox-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap CheckboxApp dengan kode JSX yang dihasilkan"
          align="start"
          className="md:col-span-2"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            <div className="flex flex-col gap-4">
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Variant</span>
                <div className="flex flex-wrap gap-1.5">
                  {VARIANTS.map((v) => (
                    <PlaygroundChip key={v} id={`chk-play-variant-${v}`} active={playVariant === v} onClick={() => setPlayVariant(v)}>
                      {v}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Size</span>
                <div className="flex gap-1.5">
                  {SIZES.map((s) => (
                    <PlaygroundChip key={s} id={`chk-play-size-${s}`} active={playSize === s} onClick={() => setPlaySize(s)} className="flex-1">
                      {s}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Checked</span>
                  <PlaygroundChip id="chk-play-checked-toggle" active={playChecked} onClick={() => setPlayChecked((v) => !v)}>
                    {playChecked ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Indeterminate</span>
                  <PlaygroundChip id="chk-play-indeterminate-toggle" active={playIndeterminate} onClick={() => setPlayIndeterminate((v) => !v)}>
                    {playIndeterminate ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Disabled</span>
                  <PlaygroundChip id="chk-play-disabled-toggle" active={playDisabled} onClick={() => setPlayDisabled((v) => !v)}>
                    {playDisabled ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
              </div>
            </div>

            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[120px] items-center justify-center rounded-lg border border-dashed border-hairline bg-surface p-4">
                  <CheckboxApp
                    id="interactive-checkbox-output"
                    label="Konfirmasi Persetujuan Laporan"
                    description="Status interaktif langsung dari panel kontrol"
                    variant={playVariant}
                    size={playSize}
                    indeterminate={playIndeterminate}
                    disabled={playDisabled}
                    checked={playChecked}
                    onCheckedChange={(c) => setPlayChecked(c)}
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="chk-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeString}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
