import * as React from "react";
import { ButtonApp, TextApp, DialogApp, InputApp } from "@/packages/design-system";
import { AlertTriangle, Info, Code, Check, CheckCircle2 } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";
import { cn } from "@/lib/utils";

const allVariants = [
  { id: "default", name: "Default (Outlined)" },
  { id: "brand", name: "Brand (Colored Inset)" },
] as const;

const allSizes = [
  { id: "sm", name: "Small", maxW: "max-w-md", desc: "Konfirmasi tunggal / alert singkat" },
  { id: "md", name: "Medium", maxW: "max-w-lg", desc: "Layout detail standar" },
  { id: "lg", name: "Large", maxW: "max-w-2xl", desc: "Data analitik & form medium" },
  { id: "xl", name: "Extra Large", maxW: "max-w-4xl", desc: "Tabel kompleks / preview dokumen" },
] as const;

const allRounded = [
  { id: "default", name: "Default (md · 6px)" },
  { id: "none", name: "None" },
  { id: "sm", name: "sm (4px)" },
  { id: "md", name: "md (6px)" },
  { id: "lg", name: "lg (12px)" },
] as const;

export function DialogDisplayModule() {
  const [isOpen, setIsOpen] = React.useState<boolean>(false);
  const [playVariant, setPlayVariant] = React.useState<"default" | "brand">("default");
  const [playSize, setPlaySize] = React.useState<"sm" | "md" | "lg" | "xl">("md");
  const [playTheme, setPlayTheme] = React.useState<"default" | "playful">("default");
  const [playRounded, setPlayRounded] = React.useState<"default" | "none" | "sm" | "md" | "lg">("md");
  const [playTitle, setPlayTitle] = React.useState<string>("Audit Objek Pajak Yogyakarta");
  const [playDesc, setPlayDesc] = React.useState<string>("Tinjauan status kepatuhan wajib pajak daerah DIY");
  const [actionConfirmed, setActionConfirmed] = React.useState<boolean>(false);
  const [copied, setCopied] = React.useState<boolean>(false);

  const themeProp = playTheme === "default" ? "" : ` theme="playful"`;
  const roundedProp = playRounded === "default" ? "" : ` rounded="${playRounded}"`;
  const codeString = `<DialogApp\n  id="my-dialog"\n  isOpen={isOpen}\n  onClose={() => setIsOpen(false)}\n  title="${playTitle}"\n  description="${playDesc}"\n  variant="${playVariant}"\n  size="${playSize}"${roundedProp}${themeProp}\n>\n  <div className="space-y-4">Konten dialog...</div>\n</DialogApp>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleConfirm = () => {
    setActionConfirmed(true);
    setTimeout(() => {
      setActionConfirmed(false);
      setIsOpen(false);
    }, 1500);
  };

  return (
    <ModuleCard
      id="uikit-dialog-module"
      icon={<AlertTriangle className="w-5 h-5 text-vibrant-purple-dark" />}
      title="DialogApp"
      description="Elemen portal dialog overlay interaktif dengan dynamic body scrolling lock, transisi memudar premium, dan variasi ukuran CVA."
    >
      <ShowcaseGrid cols={2}>
        <ShowcaseCard
          id="dialog-showcase-sizes"
          title="Klasifikasi Ukuran"
          description='size="sm" · "md" · "lg" · "xl" — max-width menyesuaikan otomatis'
          className="md:col-span-2"
          code={`<DialogApp id="d" size="sm" title="..." isOpen={open} onClose={...} />\n<DialogApp id="d" size="xl" title="..." isOpen={open} onClose={...} />`}
        >
          <div className="grid w-full grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {allSizes.map((s) => (
              <div key={s.id} className="flex flex-col justify-between gap-3 rounded-xl border border-hairline-soft bg-surface p-4 text-center">
                <div className="space-y-1">
                  <span className="block text-xs font-bold uppercase tracking-wider text-ink">{s.name}</span>
                  <span className="inline-block rounded bg-vibrant-purple/5 px-2 py-0.5 font-mono text-[10px] text-vibrant-purple-dark">{s.maxW}</span>
                </div>
                <span className="text-[9px] text-ink-secondary">{s.desc}</span>
                <ButtonApp
                  id={`btn-open-size-${s.id}`}
                  variant="secondary"
                  size="sm"
                  onClick={() => {
                    setPlaySize(s.id);
                    setIsOpen(true);
                  }}
                >
                  Tinjau Lebar
                </ButtonApp>
              </div>
            ))}
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="dialog-showcase-info"
          title="Scroll Locking & Accessibility"
          description="Body scroll dikunci otomatis saat dialog aktif"
        >
          <div className="flex w-full items-start gap-3 rounded-xl border border-hairline-soft bg-block-cream/40 p-4">
            <Info className="mt-0.5 h-5 w-5 flex-shrink-0 text-vibrant-purple-dark" />
            <TextApp id="dialog-info-text" variant="caption" className="text-ink-secondary">
              DialogApp mengunci scroll body saat modal aktif untuk menghindari double-scroll. Portal transparan dengan filter blur memberi efek kedalaman visual premium.
            </TextApp>
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="dialog-showcase-variant"
          title="Variant"
          description="default (outlined) · brand (colored inset header)"
        >
          {allVariants.map((v) => (
            <ButtonApp
              key={v.id}
              id={`btn-open-variant-${v.id}`}
              variant="secondary"
              size="sm"
              onClick={() => {
                setPlayVariant(v.id);
                setIsOpen(true);
              }}
            >
              {v.name}
            </ButtonApp>
          ))}
        </ShowcaseCard>

        <ShowcaseCard
          id="dialog-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap DialogApp dengan kode JSX yang dihasilkan"
          align="start"
          className="md:col-span-2"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            <div className="flex flex-col gap-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Dialog Title</span>
                  <InputApp id="dialog-play-title" value={playTitle} onChange={(e) => setPlayTitle(e.target.value)} />
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Dialog Description</span>
                  <InputApp id="dialog-play-desc" value={playDesc} onChange={(e) => setPlayDesc(e.target.value)} />
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Variant</span>
                <div className="flex flex-wrap gap-1.5">
                  {allVariants.map((v) => (
                    <PlaygroundChip key={v.id} id={`dialog-play-variant-${v.id}`} active={playVariant === v.id} onClick={() => setPlayVariant(v.id)}>
                      {v.id}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Size</span>
                  <div className="flex flex-wrap gap-1.5">
                    {allSizes.map((s) => (
                      <PlaygroundChip key={s.id} id={`dialog-play-size-${s.id}`} active={playSize === s.id} onClick={() => setPlaySize(s.id)} className="flex-1 min-w-[70px]">
                        {s.id.toUpperCase()}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Theme</span>
                  <div className="flex gap-1.5">
                    <PlaygroundChip id="dialog-play-theme-default" active={playTheme === "default"} onClick={() => setPlayTheme("default")} className="flex-1">
                      default
                    </PlaygroundChip>
                    <PlaygroundChip id="dialog-play-theme-playful" active={playTheme === "playful"} onClick={() => setPlayTheme("playful")} className="flex-1 font-display">
                      playful ✨
                    </PlaygroundChip>
                  </div>
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Corner Radius</span>
                <div className="flex flex-wrap gap-1.5">
                  {allRounded.map((r) => (
                    <PlaygroundChip key={r.id} id={`dialog-play-rounded-${r.id}`} active={playRounded === r.id} onClick={() => setPlayRounded(r.id)}>
                      {r.id}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <ButtonApp
                id="trigger-playground-dialog-btn"
                variant={playTheme === "playful" ? "purpleDark" : "primary"}
                size="md"
                theme={playTheme}
                onClick={() => setIsOpen(true)}
              >
                Buka Dialog ({playSize.toUpperCase()})
              </ButtonApp>
            </div>

            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[120px] items-center justify-center rounded-lg border border-dashed border-hairline bg-surface p-4 text-center text-xs text-ink-secondary">
                  Klik &quot;Buka Dialog&quot; untuk melihat pratinjau langsung.
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="dialog-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeString}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>

      <DialogApp
        id="playground-dialog-instance"
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        title={playTitle}
        description={playDesc}
        variant={playVariant}
        size={playSize}
        rounded={playRounded}
        theme={playTheme}
      >
        <div className="space-y-5 text-left">
          {actionConfirmed ? (
            <div className="flex items-center gap-3 rounded-lg border border-success/20 bg-success/10 p-4 text-sm">
              <CheckCircle2 className="h-5 w-5 flex-shrink-0 text-success" />
              <span className="font-bold font-display text-success">Tindakan Berhasil Disetujui!</span>
            </div>
          ) : (
            <div className="flex items-center gap-3 rounded-lg border border-vibrant-purple-dark/20 bg-vibrant-purple/10 p-4 text-sm">
              <Info className="h-5 w-5 flex-shrink-0 text-vibrant-purple-dark" />
              <span className="font-bold font-display text-vibrant-purple-ink">Data Siap Ditinjau Secara Real-time</span>
            </div>
          )}

          <div className="space-y-1.5">
            <span className={cn("block text-[10px] font-semibold uppercase tracking-wider text-ink-muted", playTheme === "playful" && "font-display text-vibrant-purple-dark")}>
              Statistik Audit Pajak
            </span>
            <div className="grid grid-cols-2 gap-4">
              <div className={cn("border p-3", playTheme === "playful" ? "rounded-xl border-vibrant-purple-dark/10 bg-vibrant-grey-bg/50" : "rounded-sm border-hairline-soft bg-surface-soft")}>
                <span className="block text-[10px] text-ink-secondary">Kepatuhan Omzet</span>
                <span className={cn("text-lg font-bold text-ink", playTheme === "playful" && "font-display text-2xl")}>94.8%</span>
              </div>
              <div className={cn("border p-3", playTheme === "playful" ? "rounded-xl border-vibrant-purple-dark/10 bg-vibrant-grey-bg/50" : "rounded-sm border-hairline-soft bg-surface-soft")}>
                <span className="block text-[10px] text-ink-secondary">Skor Resiko</span>
                <span className={cn("text-lg font-bold text-accent", playTheme === "playful" && "font-display text-2xl text-vibrant-purple-dark")}>Rendah</span>
              </div>
            </div>
          </div>

          <p className={cn("text-xs leading-relaxed text-ink-secondary", playTheme === "playful" && "font-display text-sm")}>
            Contoh konten dialog dinamis. Komponen ini menerima props <code>children</code> bebas sehingga siap digunakan untuk formulir detail, tabel, atau pesan verifikasi audit denda.
          </p>

          <div className={cn("flex justify-end gap-3 border-t pt-4", playTheme === "playful" ? "border-vibrant-purple-dark/10" : "border-hairline-soft")}>
            <ButtonApp
              id="playground-dialog-cancel-action"
              variant={playTheme === "playful" ? "white" : "secondary"}
              size={playTheme === "playful" ? "md" : "sm"}
              theme={playTheme}
              onClick={() => setIsOpen(false)}
            >
              Batal
            </ButtonApp>
            <ButtonApp
              id="playground-dialog-confirm-action"
              variant={playTheme === "playful" ? "purpleDark" : "primary"}
              size={playTheme === "playful" ? "md" : "sm"}
              theme={playTheme}
              onClick={handleConfirm}
            >
              Setujui Hasil Audit
            </ButtonApp>
          </div>
        </div>
      </DialogApp>
    </ModuleCard>
  );
}
