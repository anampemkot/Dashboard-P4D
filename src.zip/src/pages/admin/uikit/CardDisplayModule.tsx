import * as React from "react";
import { CardApp, CarouselApp, TextApp, BadgeApp, ButtonApp, AvatarApp, AlertApp, AlertIconApp, AlertTitleApp, AlertDescriptionApp } from "@/packages/design-system";
import { CreditCard, ChevronRight, ShoppingBag, Info } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid, ShowcaseGroup } from "./shared/ShowcaseCard";

export function CardDisplayModule() {
  return (
    <ModuleCard
      id="uikit-card-module"
      icon={<CreditCard className="w-5 h-5 text-vibrant-purple-dark" />}
      title="CardApp (Semua 13 Varian Warna & Layout)"
      description="Daftar lengkap 13 varian warna CardApp (Neutral, Primary, Brand, Secondary, Danger, Purple, PurpleDark, Yellow, Blue, Clay, ClayPurple, ClayYellow, ClayBlue) dan layout fungsional."
    >
      <AlertApp id="card-badge-dev-note" variant="info" className="items-start">
        <AlertIconApp id="card-badge-dev-note-icon">
          <Info className="h-5 w-5 text-info shrink-0" />
        </AlertIconApp>
        <div className="flex-1 text-left">
          <AlertTitleApp id="card-badge-dev-note-title">Catatan: warna badge di prop `badge` bukan dari variant BadgeApp</AlertTitleApp>
          <AlertDescriptionApp id="card-badge-dev-note-desc" className="mt-0.5">
            Saat pakai prop <code className="rounded bg-info/10 px-1 py-0.5 font-mono text-[11px]">badge</code> pada CardApp, warnanya otomatis dipilih berdasarkan <code className="rounded bg-info/10 px-1 py-0.5 font-mono text-[11px]">variant</code> card-nya — bukan varian tema BadgeApp seperti <code className="rounded bg-info/10 px-1 py-0.5 font-mono text-[11px]">purple</code>/<code className="rounded bg-info/10 px-1 py-0.5 font-mono text-[11px]">yellow</code>/<code className="rounded bg-info/10 px-1 py-0.5 font-mono text-[11px]">blue</code>. Ini disengaja: varian tema BadgeApp ikut berubah di dark mode mengikuti fill card-nya sendiri, jadi kalau dipakai langsung untuk badge sudut CardApp, warnanya bisa nyaris sama dengan card (badge jadi tak terlihat). Kalau butuh pasangan warna spesifik, override lewat prop <code className="rounded bg-info/10 px-1 py-0.5 font-mono text-[11px]">badgeColors={"{"}background, color{"}"}</code>.
          </AlertDescriptionApp>
        </div>
      </AlertApp>

      <ShowcaseGroup
        id="card-group-variant-core"
        title="Variant · Core & Brand"
        description="neutral · primary · brand · secondary"
        cols={4}
      >
        <ShowcaseCard
          id="card-showcase-variant-neutral"
          title="Variant neutral"
          description="Surface putih dengan hairline-soft border — default katalog"
          code={`<CardApp id="card" variant="neutral" size="sm" rounded="card">...</CardApp>`}
        >
          <CardApp id="card-showcase-variant-neutral-demo" variant="neutral" size="sm" rounded="card" badge="neutral" className="w-full space-y-1 p-4 pt-9">
            <TextApp id="c-neu-h" variant="h4" weight="bold" className="text-sm">Neutral Card</TextApp>
            <TextApp id="c-neu-p" variant="body" className="text-xs text-ink-secondary">Surface white dengan hairline-soft border.</TextApp>
          </CardApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="card-showcase-variant-primary"
          title="Variant primary"
          description="Kontainer solid PurpleDark, teks putih"
          code={`<CardApp id="card" variant="primary" size="sm" rounded="card">...</CardApp>`}
        >
          <CardApp id="card-showcase-variant-primary-demo" variant="primary" size="sm" rounded="card" badge="primary" className="w-full space-y-1 p-4 pt-9">
            <TextApp id="c-pri-h" variant="h4" weight="bold" className="text-sm text-white">Primary Card</TextApp>
            <TextApp id="c-pri-p" variant="body" className="text-xs text-white/80">PurpleDark solid container.</TextApp>
          </CardApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="card-showcase-variant-brand"
          title="Variant brand"
          description="Tema brand Vibrant Purple"
          code={`<CardApp id="card" variant="brand" size="sm" rounded="card">...</CardApp>`}
        >
          <CardApp id="card-showcase-variant-brand-demo" variant="brand" size="sm" rounded="card" badge="brand" className="w-full space-y-1 p-4 pt-9">
            <TextApp id="c-brd-h" variant="h4" weight="bold" className="text-sm text-vibrant-purple-ink">Brand Card</TextApp>
            <TextApp id="c-brd-p" variant="body" className="text-xs text-vibrant-purple-ink/80">Vibrant purple brand theme.</TextApp>
          </CardApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="card-showcase-variant-secondary"
          title="Variant secondary"
          description="Surface abu muted untuk konten pendukung"
          code={`<CardApp id="card" variant="secondary" size="sm" rounded="card">...</CardApp>`}
        >
          <CardApp id="card-showcase-variant-secondary-demo" variant="secondary" size="sm" rounded="card" badge="secondary" className="w-full space-y-1 p-4 pt-9">
            <TextApp id="c-sec-h" variant="h4" weight="bold" className="text-sm">Secondary Card</TextApp>
            <TextApp id="c-sec-p" variant="body" className="text-xs text-ink-secondary">Muted grey surface container.</TextApp>
          </CardApp>
        </ShowcaseCard>
      </ShowcaseGroup>

      <ShowcaseGroup
        id="card-group-variant-vibrant"
        title="Variant · Vibrant & Status"
        description="purple · purpleDark · yellow · blue · danger"
        cols={5}
      >
        <ShowcaseCard
          id="card-showcase-variant-purple"
          title="Variant purple"
          description="Fill Vibrant Purple terang"
          code={`<CardApp id="card" variant="purple" size="sm" rounded="card">...</CardApp>`}
        >
          <CardApp id="card-showcase-variant-purple-demo" variant="purple" size="sm" rounded="card" badge="purple" className="w-full p-3 pt-8">
            <TextApp id="t-pur-h" variant="body" weight="bold" className="text-xs text-vibrant-purple-ink">Purple</TextApp>
          </CardApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="card-showcase-variant-purple-dark"
          title="Variant purpleDark"
          description="Fill Vibrant Purple gelap, teks putih"
          code={`<CardApp id="card" variant="purpleDark" size="sm" rounded="card">...</CardApp>`}
        >
          <CardApp id="card-showcase-variant-purple-dark-demo" variant="purpleDark" size="sm" rounded="card" badge="purpleDark" className="w-full p-3 pt-8">
            <TextApp id="t-purdark-h" variant="body" weight="bold" className="text-xs text-white">PurpleDark</TextApp>
          </CardApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="card-showcase-variant-yellow"
          title="Variant yellow"
          description="Fill Vibrant Yellow — aksen peringatan lunak"
          code={`<CardApp id="card" variant="yellow" size="sm" rounded="card">...</CardApp>`}
        >
          <CardApp id="card-showcase-variant-yellow-demo" variant="yellow" size="sm" rounded="card" badge="yellow" className="w-full p-3 pt-8">
            <TextApp id="t-yel-h" variant="body" weight="bold" className="text-xs text-vibrant-yellow-ink">Yellow</TextApp>
          </CardApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="card-showcase-variant-blue"
          title="Variant blue"
          description="Fill Vibrant Blue — aksen informatif"
          code={`<CardApp id="card" variant="blue" size="sm" rounded="card">...</CardApp>`}
        >
          <CardApp id="card-showcase-variant-blue-demo" variant="blue" size="sm" rounded="card" badge="blue" className="w-full p-3 pt-8">
            <TextApp id="t-blu-h" variant="body" weight="bold" className="text-xs text-vibrant-blue-ink">Blue</TextApp>
          </CardApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="card-showcase-variant-danger"
          title="Variant danger"
          description="Fill accent merah untuk kondisi kritis"
          code={`<CardApp id="card" variant="danger" size="sm" rounded="card">...</CardApp>`}
        >
          <CardApp id="card-showcase-variant-danger-demo" variant="danger" size="sm" rounded="card" badge="danger" className="w-full p-3 pt-8">
            <TextApp id="t-dng-h" variant="body" weight="bold" className="text-xs text-white">Danger</TextApp>
          </CardApp>
        </ShowcaseCard>
      </ShowcaseGroup>

      <ShowcaseGroup
        id="card-group-variant-clay"
        title="Variant · Clay 3D"
        description="clay · clayPurple · clayYellow · clayBlue — efek claymorphic dengan inner shadow"
        cols={4}
      >
        <ShowcaseCard
          id="card-showcase-variant-clay"
          title="Variant clay"
          description="Clay netral di atas surface terang"
          code={`<CardApp id="card" variant="clay" size="sm" rounded="card">...</CardApp>`}
        >
          <CardApp id="card-showcase-variant-clay-demo" variant="clay" size="sm" rounded="card" badge="clay" className="w-full p-4 pt-9">
            <TextApp id="t-clay-h" variant="body" weight="bold" className="text-xs">Clay Standard</TextApp>
          </CardApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="card-showcase-variant-clay-purple"
          title="Variant clayPurple"
          description="Clay ungu, teks putih"
          code={`<CardApp id="card" variant="clayPurple" size="sm" rounded="card">...</CardApp>`}
        >
          <CardApp id="card-showcase-variant-clay-purple-demo" variant="clayPurple" size="sm" rounded="card" badge="clayPurple" className="w-full p-4 pt-9">
            <TextApp id="t-claypur-h" variant="body" weight="bold" className="text-xs text-white">Clay Purple</TextApp>
          </CardApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="card-showcase-variant-clay-yellow"
          title="Variant clayYellow"
          description="Clay kuning — ink menyesuaikan di dark mode"
          code={`<CardApp id="card" variant="clayYellow" size="sm" rounded="card">...</CardApp>`}
        >
          <CardApp id="card-showcase-variant-clay-yellow-demo" variant="clayYellow" size="sm" rounded="card" badge="clayYellow" className="w-full p-4 pt-9">
            <TextApp id="t-clayyel-h" variant="body" weight="bold" className="text-xs text-[#6f5100] dark:text-amber-100">Clay Yellow</TextApp>
          </CardApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="card-showcase-variant-clay-blue"
          title="Variant clayBlue"
          description="Clay biru — ink menyesuaikan di dark mode"
          code={`<CardApp id="card" variant="clayBlue" size="sm" rounded="card">...</CardApp>`}
        >
          <CardApp id="card-showcase-variant-clay-blue-demo" variant="clayBlue" size="sm" rounded="card" badge="clayBlue" className="w-full p-4 pt-9">
            <TextApp id="t-clayblu-h" variant="body" weight="bold" className="text-xs text-[#674bb5] dark:text-blue-100">Clay Blue</TextApp>
          </CardApp>
        </ShowcaseCard>
      </ShowcaseGroup>

      <ShowcaseGroup
        id="card-group-badge-position"
        title="Badge Position"
        description="top-left (default) · top-center"
        cols={2}
      >
        <ShowcaseCard
          id="card-showcase-badge-position-top-left"
          title="Badge position top-left"
          description="Anchor default — sejajar kiri atas card"
          code={`<CardApp id="card" badge="Top Left" badgePosition="top-left">...</CardApp>`}
        >
          <CardApp
            id="card-showcase-badge-position-top-left-demo"
            variant="neutral"
            size="sm"
            rounded="card"
            badge="Top Left"
            badgePosition="top-left"
            className="min-h-[140px] w-full justify-end space-y-1 p-4 pt-10"
          >
            <TextApp id="c-badge-tl-h" variant="h4" weight="bold" className="text-sm">badgePosition="top-left"</TextApp>
            <TextApp id="c-badge-tl-p" variant="body" className="text-xs text-ink-secondary">Default anchor — sejajar kiri atas card.</TextApp>
          </CardApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="card-showcase-badge-position-top-center"
          title="Badge position top-center"
          description="Badge auto-contrast dan center-anchored"
          code={`<CardApp id="card" badge="Top Center" badgePosition="top-center">...</CardApp>`}
        >
          <CardApp
            id="card-showcase-badge-position-top-center-demo"
            variant="neutral"
            size="sm"
            rounded="card"
            badge="Top Center"
            badgePosition="top-center"
            className="min-h-[140px] w-full justify-end space-y-1 p-4 pt-10"
          >
            <TextApp id="c-badge-tc-h" variant="h4" weight="bold" className="text-sm">badgePosition="top-center"</TextApp>
            <TextApp id="c-badge-tc-p" variant="body" className="text-xs text-ink-secondary">Badge auto-contrast &amp; center-anchored.</TextApp>
          </CardApp>
        </ShowcaseCard>
      </ShowcaseGroup>

      <ShowcaseGroup
        id="card-group-insight"
        title="Insight"
        description="insightContent (popover ringkas) · insight (dialog terstruktur) · frame + carousel"
        cols={2}
      >
        <ShowcaseCard
          id="card-showcase-insight-content"
          title="Insight content"
          description="Prop insightContent — ikon bohlam membuka PopoverApp berisi catatan singkat"
          code={`<CardApp id="card" insightContent={<>Realisasi naik 8.4%...</>}>...</CardApp>`}
        >
          <CardApp
            id="card-showcase-insight-content-demo"
            variant="primary"
            size="sm"
            rounded="card"
            badge="Insight"
            badgePosition="top-left"
            insightContent={
              <>
                <TextApp id="c-insight-title" variant="body" weight="bold" className="mb-1 block">Insight Realisasi PAD</TextApp>
                Realisasi bulan ini naik 8.4% dibanding bulan lalu, didorong oleh sektor pajak restoran.
              </>
            }
            className="min-h-[140px] w-full justify-end space-y-1 p-4 pt-10"
          >
            <TextApp id="c-insight-h" variant="h4" weight="bold" className="text-sm text-white">Card + Insight</TextApp>
            <TextApp id="c-insight-p" variant="body" className="text-xs text-white/80">Klik ikon bohlam di pojok kanan atas.</TextApp>
          </CardApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="card-showcase-insight-dialog"
          title="Insight dialog"
          description="Prop insight (InsightContent) — dialog analisis terstruktur, bukan popover ringkas. Keduanya boleh dipakai bersamaan."
          code={`<CardApp
  id="card-piutang"
  variant="yellow"
  insight={{
    title: "Total Piutang Pajak",
    value: "Rp 45,2 M",
    status: "waspada",
    summary: "...",
    current: ["..."],
    insights: ["..."],
    tacticalRecs: ["..."],
    strategicRecs: ["..."],
    glossary: [{ term: "...", definition: "..." }],
    dataNotes: ["..."],
  }}
>
  ...
</CardApp>`}
        >
          <CardApp
            id="card-showcase-insight-dialog-demo"
            variant="yellow"
            size="sm"
            rounded="card"
            badge="Waspada"
            badgePosition="top-left"
            insight={{
              title: "Total Piutang Pajak",
              value: "Rp 45,2 M",
              status: "waspada",
              meta: ["Indikator", "Piutang Pajak", "Juli 2026"],
              summary:
                "Total Piutang Pajak mengukur seluruh tagihan pajak daerah yang sudah ditetapkan (SKPD/STPD) namun belum dilunasi wajib pajak.",
              current: ["Realisasi terkini Rp 45,2 M.", "128 WP menunggak dalam proses penagihan aktif."],
              insights: [
                "Penurunan 5,2% bulan ini didorong oleh percepatan penagihan piutang BPHTB — leading indicator perbaikan cash flow PAD 30–60 hari ke depan.",
                "Konsentrasi piutang masih didominasi WP Badan (62%), bukan WP Pribadi.",
              ],
              tacticalRecs: ["Kirim Surat Teguran ke 20 WP dengan piutang terbesar minggu ini.", "Jadwalkan rekonsiliasi data piutang dengan Bank Persepsi."],
              strategicRecs: ["Evaluasi kebijakan write-off untuk piutang macet > 5 tahun.", "Integrasikan sistem penagihan dengan SIMPATDA agar notifikasi jatuh tempo otomatis."],
              glossary: [
                { term: "SKPD", expansion: "Surat Ketetapan Pajak Daerah", definition: "dokumen penetapan jumlah pajak terutang." },
                { term: "STPD", expansion: "Surat Tagihan Pajak Daerah", definition: "dokumen tagihan atas pajak yang belum/kurang dibayar." },
              ],
              dataNotes: ["Snapshot per 27 Juli 2026.", "Angka mengikuti rekonsiliasi harian terakhir dari Bank Persepsi."],
            }}
            className="min-h-[140px] w-full justify-end space-y-1 p-4 pt-10"
          >
            <TextApp id="c-insight-dialog-h" variant="h4" weight="bold" className="text-sm">Total Piutang Pajak</TextApp>
            <TextApp id="c-insight-dialog-p" variant="body" className="text-xs text-ink-secondary">Klik ikon bohlam untuk dialog analisis lengkap.</TextApp>
          </CardApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="card-showcase-insight-carousel"
          title="Insight carousel"
          description="Badge & ikon insight menempel pada frame card, konten di dalamnya berganti lewat carousel"
          align="start"
          className="md:col-span-2"
          code={`<CardApp id="card" badge="Insight Carousel" insightContent={<>...</>}>\n  <CarouselApp id="inner" slides={slides} showDots showArrows />\n</CardApp>`}
        >
          <CardApp
            id="card-showcase-insight-carousel-demo"
            variant="primary"
            size="sm"
            rounded="card"
            badge="Insight Carousel"
            badgePosition="top-left"
            insightContent={
              <>
                <TextApp id="card-insight-carousel-popover-title" variant="body" weight="bold" className="mb-1 block">
                  Cara Kerja
                </TextApp>
                Badge dan ikon bohlam ini menempel pada frame card, bukan pada slide — jadi posisinya tidak ikut berganti saat carousel di dalam berpindah slide.
              </>
            }
            className="w-full space-y-2 p-4 pt-10"
          >
            <CarouselApp
              id="card-insight-inner-carousel"
              variant="default"
              rounded="lg"
              showDots
              showArrows
              className="!border-0 !bg-transparent !shadow-none"
              slides={[
                {
                  id: "slide-pajak",
                  content: (
                    <div id="carousel-slide-pajak" className="flex min-w-0 flex-col gap-1 px-1 py-2 text-white">
                      <TextApp id="carousel-slide-pajak-h" variant="h4" weight="bold" className="text-sm text-white">Pajak Daerah</TextApp>
                      <TextApp id="carousel-slide-pajak-p" variant="body" className="text-xs text-white/80">
                        Kontribusi pajak daerah mencapai 62% dari total PAD tahun berjalan.
                      </TextApp>
                    </div>
                  ),
                },
                {
                  id: "slide-retribusi",
                  content: (
                    <div id="carousel-slide-retribusi" className="flex min-w-0 flex-col gap-1 px-1 py-2 text-white">
                      <TextApp id="carousel-slide-retribusi-h" variant="h4" weight="bold" className="text-sm text-white">Retribusi</TextApp>
                      <TextApp id="carousel-slide-retribusi-p" variant="body" className="text-xs text-white/80">
                        Retribusi parkir naik 12% seiring aktifnya sistem tapping box baru.
                      </TextApp>
                    </div>
                  ),
                },
                {
                  id: "slide-dana-transfer",
                  content: (
                    <div id="carousel-slide-dana-transfer" className="flex min-w-0 flex-col gap-1 px-1 py-2 text-white">
                      <TextApp id="carousel-slide-dana-transfer-h" variant="h4" weight="bold" className="text-sm text-white">Dana Transfer</TextApp>
                      <TextApp id="carousel-slide-dana-transfer-p" variant="body" className="text-xs text-white/80">
                        Realisasi DAU/DAK triwulan ini sudah 96% dari pagu yang dialokasikan.
                      </TextApp>
                    </div>
                  ),
                },
              ]}
            />
          </CardApp>
        </ShowcaseCard>
      </ShowcaseGroup>

      <ShowcaseGroup
        id="card-group-layout"
        title="Layout Fungsional"
        description="Tiga komposisi utuh — masing-masing satu UI siap salin, bukan kumpulan varian"
        cols={3}
      >
        <ShowcaseCard
          id="card-showcase-basic-info"
          title="Layout Basic Info"
          description="Badge + tanggal, judul, ringkasan, footer avatar + aksi"
          align="start"
          code={`<CardApp id="card" variant="neutral" size="sm" rounded="card">\n  {/* badge + tanggal */}\n  {/* judul + ringkasan */}\n  {/* footer: avatar + tombol Detail */}\n</CardApp>`}
        >
          <CardApp id="card-showcase-basic-info-demo" variant="neutral" size="sm" rounded="card" className="flex w-full flex-col justify-between space-y-3 p-4">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <BadgeApp id="c-basic-tag" variant="purple" size="sm" rounded="pill">Basic Info</BadgeApp>
                <TextApp id="c-basic-date" variant="caption" className="text-xs text-ink-muted">31 Juli 2026</TextApp>
              </div>
              <TextApp id="c-basic-h" variant="h4" weight="bold">Ringkasan Anggaran PAD</TextApp>
              <TextApp id="c-basic-p" variant="body" className="text-xs text-ink-secondary">
                Total target anggaran penerimaan daerah tahun 2026 ditetapkan sebesar Rp 450 Miliar.
              </TextApp>
            </div>
            <div className="flex items-center justify-between border-t border-hairline/60 pt-2">
              <AvatarApp id="c-basic-av" name="Admin BPKAD" size="xs" />
              <ButtonApp id="c-basic-btn" variant="ghost" size="sm" className="text-xs">
                Detail <ChevronRight className="ml-1 h-3.5 w-3.5" />
              </ButtonApp>
            </div>
          </CardApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="card-showcase-media-header"
          title="Layout Media Header"
          description="Header gambar dengan badge overlay, body teks, footer tombol lebar penuh"
          align="start"
          code={`<CardApp id="card" className="p-0 overflow-hidden">\n  {/* header: <img /> + BadgeApp absolute */}\n  {/* body: judul + ringkasan */}\n  {/* footer: <ButtonApp className="w-full" /> */}\n</CardApp>`}
        >
          <CardApp id="card-showcase-media-header-demo" variant="neutral" size="sm" rounded="card" className="flex w-full flex-col justify-between overflow-hidden p-0">
            <div className="relative h-28 overflow-hidden bg-slate-900">
              <img
                src="https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&w=600&q=80"
                alt="BPKAD Header"
                className="h-full w-full object-cover opacity-80"
              />
              <BadgeApp id="c-media-badge" variant="solidPurple" size="sm" className="absolute left-3 top-3">Berita BPKAD</BadgeApp>
            </div>
            <div className="flex-1 space-y-2 p-4">
              <TextApp id="c-media-h" variant="h4" weight="bold">Inovasi Layanan Pajak Digital</TextApp>
              <TextApp id="c-media-p" variant="body" className="text-xs text-ink-secondary">
                Peluncuran portal pembayaran pajak online secara mandiri untuk kemudahan wajib pajak.
              </TextApp>
            </div>
            <div className="p-4 pt-0">
              <ButtonApp id="c-media-btn" variant="secondary" size="sm" className="w-full">Baca Selengkapnya</ButtonApp>
            </div>
          </CardApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="card-showcase-ecommerce"
          title="Layout E-Commerce"
          description="Ikon produk + judul, blok harga & spesifikasi, tombol aksi utama"
          align="start"
          code={`<CardApp id="card" variant="neutral" size="sm" rounded="card">\n  {/* ikon + nama produk */}\n  {/* blok harga + spesifikasi */}\n  {/* <ButtonApp variant="primary" leftIcon={<ShoppingBag />} /> */}\n</CardApp>`}
        >
          <CardApp id="card-showcase-ecommerce-demo" variant="neutral" size="sm" rounded="card" className="flex w-full flex-col justify-between space-y-3 p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-vibrant-purple/10 font-bold text-vibrant-purple-dark">
                <CreditCard className="h-5 w-5" />
              </div>
              <div className="min-w-0">
                <TextApp id="c-ecom-h" variant="h4" weight="bold" className="truncate text-sm">Paket Tapping Box Pro</TextApp>
                <TextApp id="c-ecom-sub" variant="caption" className="text-xs text-ink-muted">Perangkat Perekam Transaksi</TextApp>
              </div>
            </div>
            <div className="space-y-1 rounded-xl border border-hairline-soft bg-surface-soft p-3">
              <TextApp id="c-ecom-price" variant="h3" weight="bold" className="text-vibrant-purple-dark">
                Rp 2.500.000 <span className="text-xs font-normal text-ink-muted">/ unit</span>
              </TextApp>
              <TextApp id="c-ecom-spec" variant="caption" className="text-[11px] text-ink-secondary">
                Termasuk garansi 2 tahun &amp; integrasi SIMPAD.
              </TextApp>
            </div>
            <ButtonApp id="c-ecom-btn" variant="primary" size="sm" leftIcon={<ShoppingBag className="h-4 w-4" />}>
              Pesan Alat
            </ButtonApp>
          </CardApp>
        </ShowcaseCard>
      </ShowcaseGroup>

      <ShowcaseGrid cols={1}>
        <ShowcaseCard
          id="card-showcase-anatomy"
          title="Anatomi Card"
          description="Container · Header · Body · Footer — 4 zona utama"
          align="start"
          code={`<CardApp id="card">\n  {/* Header: image + avatar */}\n  {/* Body: title, description, badges */}\n  {/* Footer: date + action buttons */}\n</CardApp>`}
        >
          <div className="grid w-full grid-cols-1 gap-6 lg:grid-cols-2">
            <div className="overflow-hidden rounded-2xl border-2 border-vibrant-purple/30 bg-surface shadow-sm">
              <div className="relative h-28 overflow-hidden bg-slate-900">
                <img
                  src="https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&w=600&q=80"
                  alt="Card Header"
                  className="h-full w-full object-cover opacity-70"
                />
                <div className="absolute bottom-3 left-3 flex items-center gap-2">
                  <AvatarApp id="anat-av" name="Kepala BPKAD" size="xs" />
                  <TextApp id="anat-av-name" variant="caption" className="text-xs font-semibold text-white">Kepala BPKAD</TextApp>
                </div>
              </div>
              <div className="space-y-2.5 border-b border-t border-dashed border-vibrant-purple/30 p-4">
                <TextApp id="anat-title" variant="h4" weight="bold" className="text-sm">Laporan Monitoring PAD Bulanan</TextApp>
                <TextApp id="anat-desc" variant="body" className="text-xs leading-relaxed text-ink-secondary">
                  Realisasi penerimaan PAD Kota Yogyakarta bulan Juli 2026 telah mencapai 104.2% dari target anggaran.
                </TextApp>
                <div className="flex flex-wrap items-center gap-1.5">
                  <BadgeApp id="anat-b1" variant="solidPurple" size="sm">PAD 2026</BadgeApp>
                  <BadgeApp id="anat-b2" variant="solidSuccess" size="sm">Tercapai</BadgeApp>
                  <BadgeApp id="anat-b3" variant="neutral" size="sm">Bulanan</BadgeApp>
                </div>
              </div>
              <div className="flex items-center justify-between gap-3 p-4">
                <TextApp id="anat-date" variant="caption" className="text-xs text-ink-muted">31 Juli 2026</TextApp>
                <div className="flex items-center gap-2">
                  <ButtonApp id="anat-link-btn" variant="ghost" size="sm" className="text-xs text-vibrant-purple-dark">Lihat Detail</ButtonApp>
                  <ButtonApp id="anat-action-btn" variant="primary" size="sm" className="text-xs">Ekspor</ButtonApp>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              {[
                { color: "bg-amber-500", label: "Container", desc: "Pembungkus utama — Border, Shadow/Elevation, Radius. Props: variant, size, rounded." },
                { color: "bg-vibrant-purple-dark", label: "Header", desc: "Zona atas — Image, Avatar + Nama, atau Title. Opsional." },
                { color: "bg-blue-600", label: "Body", desc: "Konten utama — Title, Description, Badges." },
                { color: "bg-emerald-600", label: "Footer", desc: "Zona aksi — Action Buttons, Link teks, atau metadata." },
              ].map((zone) => (
                <div key={zone.label} className="flex items-start gap-3 rounded-xl border border-hairline-soft bg-surface-soft p-3">
                  <span className={`${zone.color} mt-0.5 h-2.5 w-2.5 shrink-0 rounded-full`} />
                  <div className="min-w-0">
                    <TextApp id={`legend-${zone.label}`} variant="body" weight="bold" className="block text-xs text-ink">{zone.label}</TextApp>
                    <TextApp id={`legend-d-${zone.label}`} variant="caption" className="text-[11px] leading-relaxed text-ink-secondary">{zone.desc}</TextApp>
                  </div>
                </div>
              ))}

              <div className="space-y-2 pt-1">
                <TextApp id="anat-shadow-h" variant="body" weight="semibold" className="text-xs uppercase tracking-wider text-ink">Shadow / Elevation Options</TextApp>
                <div className="flex flex-wrap gap-2">
                  {["shadow-2xs", "shadow-xs", "shadow-sm", "shadow-md", "shadow-lg"].map((s) => (
                    <div key={s} className={`rounded-xl border border-hairline-soft bg-surface px-3 py-2 ${s}`}>
                      <TextApp id={`sh-${s}`} variant="caption" className="font-mono text-[10px] text-vibrant-purple-dark">{s}</TextApp>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
