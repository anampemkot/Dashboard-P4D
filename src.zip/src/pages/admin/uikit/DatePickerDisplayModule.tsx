import * as React from "react";
import {
  DatePickerApp,
  ButtonApp,
  InputApp,
  DatePickerMode,
  DatePickerSize,
  DatePickerFormat,
  DateRangeValue,
} from "@/packages/design-system";
import { Calendar, Code, Check } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid, ShowcaseGroup } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

const MODES: { value: DatePickerMode; label: string }[] = [
  { value: "single", label: "Single" },
  { value: "range", label: "Range" },
  { value: "monthYear", label: "Month/Year" },
];
const FORMATS: DatePickerFormat[] = ["DD/MM/YYYY", "YYYY-MM-DD", "DD MMMM YYYY", "MM/YYYY"];
const SIZES: DatePickerSize[] = ["sm", "md", "lg"];

export function DatePickerDisplayModule() {
  // Playground state
  const [playMode, setPlayMode] = React.useState<DatePickerMode>("single");
  const [playSingleDate, setPlaySingleDate] = React.useState<Date | null>(new Date());
  const [playRangeDate, setPlayRangeDate] = React.useState<DateRangeValue>({
    startDate: new Date(),
    endDate: new Date(new Date().setDate(new Date().getDate() + 7)),
  });
  const [playFormat, setPlayFormat] = React.useState<DatePickerFormat>("DD/MM/YYYY");
  const [playSize, setPlaySize] = React.useState<DatePickerSize>("md");
  const [playShowPresets, setPlayShowPresets] = React.useState(true);
  const [playShowActions, setPlayShowActions] = React.useState(true);
  const [playDisabled, setPlayDisabled] = React.useState(false);
  const [playErrorState, setPlayErrorState] = React.useState(false);
  const [playErrorMsg, setPlayErrorMsg] = React.useState("Tanggal jatuh tempo tidak boleh sebelum periode berjalan.");

  const [copied, setCopied] = React.useState(false);

  // Demo standalone states
  const [singleDemo, setSingleDemo] = React.useState<Date | null>(new Date("2026-08-17"));
  const [rangeDemo, setRangeDemo] = React.useState<DateRangeValue>({
    startDate: new Date("2026-08-01"),
    endDate: new Date("2026-08-31"),
  });
  const [monthYearDemo, setMonthYearDemo] = React.useState<Date | null>(new Date("2026-08-01"));

  // Generate code snippet string
  const modeStr = playMode !== "single" ? `\n  mode="${playMode}"` : "";
  const formatStr = playFormat !== "DD/MM/YYYY" ? `\n  format="${playFormat}"` : "";
  const sizeStr = playSize !== "md" ? `\n  size="${playSize}"` : "";
  const presetsStr = !playShowPresets ? `\n  showPresets={false}` : "";
  const actionsStr = !playShowActions ? `\n  showActions={false}` : "";
  const disabledStr = playDisabled ? `\n  disabled` : "";
  const errorStr = playErrorState ? `\n  error="${playErrorMsg}"` : "";

  const valueBindingStr =
    playMode === "range"
      ? `\n  rangeValue={dateRange}\n  onRangeChange={(range) => setDateRange(range)}`
      : `\n  value={selectedDate}\n  onChange={(date) => setSelectedDate(date)}`;

  const codeSnippet = `<DatePickerApp
  id="tax-period-picker"${modeStr}${formatStr}${sizeStr}${valueBindingStr}${presetsStr}${actionsStr}${errorStr}${disabledStr}
/>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-datepicker-module"
      icon={<Calendar className="w-5 h-5 text-vibrant-purple-dark" />}
      title="DatePickerApp"
      description="Pemilih tanggal dan periode masa pajak responsif — mendukung Single Date, Date Range, dan Month/Year dengan kalender interaktif, min/max boundary, tombol aksi, preset rentang cepat, serta status validasi."
    >
      <ShowcaseGrid cols={2}>
        <ShowcaseCard
          id="datepicker-showcase-single"
          title="Single Date"
          description="Pemilih tanggal tunggal untuk SPT, SKPD, atau batas pembayaran"
          align="start"
          code={`<DatePickerApp id="dp" mode="single" value={date} onChange={setDate} />`}
        >
          <DatePickerApp id="dp-demo-single" mode="single" value={singleDemo} onChange={setSingleDemo} placeholder="Pilih tanggal penetapan..." />
        </ShowcaseCard>

        <ShowcaseCard
          id="datepicker-showcase-range"
          title="Date Range"
          description="Rentang periode laporan dengan preset tombol cepat"
          align="start"
          code={`<DatePickerApp id="dp" mode="range" rangeValue={range} onRangeChange={setRange} />`}
        >
          <DatePickerApp id="dp-demo-range" mode="range" rangeValue={rangeDemo} onRangeChange={setRangeDemo} placeholder="Pilih periode laporan..." />
        </ShowcaseCard>

        <ShowcaseCard
          id="datepicker-showcase-monthyear"
          title="Month & Year Picker"
          description='Masa pajak bulanan (misal: "Agustus 2026")'
          align="start"
          code={`<DatePickerApp id="dp" mode="monthYear" value={date} onChange={setDate} />`}
        >
          <DatePickerApp id="dp-demo-my" mode="monthYear" value={monthYearDemo} onChange={setMonthYearDemo} placeholder="Pilih masa pajak bulanan..." />
        </ShowcaseCard>

        <ShowcaseGroup id="datepicker-group-state" title="Component States" description="default · filled · disabled · error" cols={2}>
          <ShowcaseCard
            id="datepicker-showcase-state-default"
            title="State default"
            description="Kosong, belum dipilih"
            align="start"
            code={`<DatePickerApp id="dp" placeholder="..." helperText="..." />`}
          >
            <DatePickerApp id="datepicker-showcase-state-default-demo" placeholder="Ketik atau klik untuk memilih tanggal..." helperText="Format tanggal otomatis disesuaikan dengan aturan BPKAD." />
          </ShowcaseCard>

          <ShowcaseCard
            id="datepicker-showcase-state-filled"
            title="State filled"
            description="Sudah memiliki nilai terpilih"
            align="start"
            code={`<DatePickerApp id="dp" defaultValue={date} helperText="..." />`}
          >
            <DatePickerApp id="datepicker-showcase-state-filled-demo" defaultValue={new Date("2026-08-17")} helperText="Tanggal penetapan sudah dipilih." />
          </ShowcaseCard>

          <ShowcaseCard
            id="datepicker-showcase-state-disabled"
            title="State disabled"
            description="Terkunci, tidak dapat diubah"
            align="start"
            code={`<DatePickerApp id="dp" disabled defaultValue={date} />`}
          >
            <DatePickerApp id="datepicker-showcase-state-disabled-demo" disabled defaultValue={new Date()} helperText="Tanggal dikunci untuk transaksi yang telah dibukukan." />
          </ShowcaseCard>

          <ShowcaseCard
            id="datepicker-showcase-state-error"
            title="State error"
            description="Validasi gagal"
            align="start"
            code={`<DatePickerApp id="dp" defaultValue={date} error="..." />`}
          >
            <DatePickerApp id="datepicker-showcase-state-error-demo" defaultValue={new Date("2025-01-01")} error="Tanggal yang dipilih berada di luar tahun anggaran aktif 2026." />
          </ShowcaseCard>
        </ShowcaseGroup>

        <ShowcaseGroup id="datepicker-group-format" title="Display Formats" description="DD/MM/YYYY · YYYY-MM-DD · DD MMMM YYYY" cols={3}>
          <ShowcaseCard
            id="datepicker-showcase-format-ddmmyyyy"
            title="Format DD/MM/YYYY"
            description="Format standar Indonesia"
            align="start"
            code={`<DatePickerApp id="dp" format="DD/MM/YYYY" defaultValue={date} />`}
          >
            <DatePickerApp id="datepicker-showcase-format-ddmmyyyy-demo" format="DD/MM/YYYY" defaultValue={new Date("2026-08-17")} />
          </ShowcaseCard>

          <ShowcaseCard
            id="datepicker-showcase-format-isodate"
            title="Format YYYY-MM-DD"
            description="Format ISO"
            align="start"
            code={`<DatePickerApp id="dp" format="YYYY-MM-DD" defaultValue={date} />`}
          >
            <DatePickerApp id="datepicker-showcase-format-isodate-demo" format="YYYY-MM-DD" defaultValue={new Date("2026-08-17")} />
          </ShowcaseCard>

          <ShowcaseCard
            id="datepicker-showcase-format-longdate"
            title="Format DD MMMM YYYY"
            description="Format panjang"
            align="start"
            code={`<DatePickerApp id="dp" format="DD MMMM YYYY" defaultValue={date} />`}
          >
            <DatePickerApp id="datepicker-showcase-format-longdate-demo" format="DD MMMM YYYY" defaultValue={new Date("2026-08-17")} />
          </ShowcaseCard>
        </ShowcaseGroup>

        <ShowcaseGroup id="datepicker-group-size" title="Input Sizes" description="sm · md · lg" cols={3}>
          <ShowcaseCard
            id="datepicker-showcase-size-sm"
            title="Ukuran sm"
            description="34px"
            align="start"
            code={`<DatePickerApp id="dp" size="sm" defaultValue={date} />`}
          >
            <DatePickerApp id="datepicker-showcase-size-sm-demo" size="sm" defaultValue={new Date()} />
          </ShowcaseCard>

          <ShowcaseCard
            id="datepicker-showcase-size-md"
            title="Ukuran md"
            description="40px"
            align="start"
            code={`<DatePickerApp id="dp" size="md" defaultValue={date} />`}
          >
            <DatePickerApp id="datepicker-showcase-size-md-demo" size="md" defaultValue={new Date()} />
          </ShowcaseCard>

          <ShowcaseCard
            id="datepicker-showcase-size-lg"
            title="Ukuran lg"
            description="48px"
            align="start"
            code={`<DatePickerApp id="dp" size="lg" defaultValue={date} />`}
          >
            <DatePickerApp id="datepicker-showcase-size-lg-demo" size="lg" defaultValue={new Date()} />
          </ShowcaseCard>
        </ShowcaseGroup>

        <ShowcaseCard
          id="datepicker-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap DatePickerApp dengan kode JSX yang dihasilkan"
          align="start"
          className="md:col-span-2"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            <div className="flex flex-col gap-4">
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Selection Mode</span>
                <div className="flex gap-1.5">
                  {MODES.map((m) => (
                    <PlaygroundChip key={m.value} id={`dp-play-mode-${m.value}`} active={playMode === m.value} onClick={() => setPlayMode(m.value)} className="flex-1">
                      {m.label}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Display Format</span>
                <div className="flex flex-wrap gap-1.5">
                  {FORMATS.map((f) => (
                    <PlaygroundChip key={f} id={`dp-play-fmt-${f}`} active={playFormat === f} onClick={() => setPlayFormat(f)}>
                      {f}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Input Size</span>
                <div className="flex gap-1">
                  {SIZES.map((s) => (
                    <PlaygroundChip key={s} id={`dp-play-size-${s}`} active={playSize === s} onClick={() => setPlaySize(s)} className="flex-1">
                      {s}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Presets</span>
                  <PlaygroundChip id="dp-play-preset-toggle" active={playShowPresets} onClick={() => setPlayShowPresets((v) => !v)}>
                    {playShowPresets ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Action Buttons</span>
                  <PlaygroundChip id="dp-play-actions-toggle" active={playShowActions} onClick={() => setPlayShowActions((v) => !v)}>
                    {playShowActions ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Error State</span>
                  <PlaygroundChip id="dp-play-error-toggle" active={playErrorState} onClick={() => setPlayErrorState((v) => !v)}>
                    {playErrorState ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Disabled</span>
                  <PlaygroundChip id="dp-play-disabled-toggle" active={playDisabled} onClick={() => setPlayDisabled((v) => !v)}>
                    {playDisabled ? "ON" : "OFF"}
                  </PlaygroundChip>
                </div>
              </div>

              {playErrorState && (
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Pesan Error</span>
                  <InputApp id="dp-play-errmsg" size="sm" rounded="lg" value={playErrorMsg} onChange={(e) => setPlayErrorMsg(e.target.value)} placeholder="Pesan error..." />
                </div>
              )}
            </div>

            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex flex-col items-center justify-center gap-4 rounded-lg border border-dashed border-hairline bg-surface p-4">
                  <DatePickerApp
                    id="playground-interactive-datepicker"
                    mode={playMode}
                    value={playSingleDate}
                    onChange={setPlaySingleDate}
                    rangeValue={playRangeDate}
                    onRangeChange={setPlayRangeDate}
                    format={playFormat}
                    size={playSize}
                    showPresets={playShowPresets}
                    showActions={playShowActions}
                    disabled={playDisabled}
                    error={playErrorState ? playErrorMsg : undefined}
                    label="Masa / Tanggal Laporan Tax Dashboard"
                  />
                  <div className="flex w-full items-center justify-between rounded-lg bg-surface-soft p-3 font-mono text-xs text-ink-secondary">
                    <span>
                      Selected Value:{" "}
                      <strong className="text-vibrant-purple-dark">
                        {playMode === "range"
                          ? `${playRangeDate.startDate ? playRangeDate.startDate.toLocaleDateString("id-ID") : "-"} s/d ${playRangeDate.endDate ? playRangeDate.endDate.toLocaleDateString("id-ID") : "-"}`
                          : playSingleDate
                          ? playSingleDate.toLocaleDateString("id-ID")
                          : "Belum dipilih"}
                      </strong>
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="dp-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeSnippet}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
