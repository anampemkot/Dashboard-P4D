import * as React from "react";
import {
  BadgeApp,
  ButtonApp,
  DropdownApp,
  InputApp,
  ToggleApp,
  BadgeVariant,
  BadgeSize,
  BadgeRounded,
} from "@/packages/design-system";
import {
  Sparkles,
  Info,
  Code,
  Check,
  Bell,
  AlertTriangle,
  XCircle,
  ShieldCheck,
  Star,
  Layers,
} from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid, ShowcaseGroup } from "./shared/ShowcaseCard";

export function BadgeDisplayModule() {
  // Playground state
  const [playText, setPlayText] = React.useState("Active Order");
  const [playVariant, setPlayVariant] = React.useState<BadgeVariant>("solidPurple");
  const [playSize, setPlaySize] = React.useState<BadgeSize>("md");
  const [playRounded, setPlayRounded] = React.useState<BadgeRounded>("pill");
  const [playTheme] = React.useState<"default" | "playful">("default");
  const [playWithBorder, setPlayWithBorder] = React.useState(false);
  const [playDot, setPlayDot] = React.useState(true);
  const [playDotPulse, setPlayDotPulse] = React.useState(true);
  const [playIconOption, setPlayIconOption] = React.useState<"none" | "check" | "warning" | "bell" | "star">("none");
  const [copied, setCopied] = React.useState(false);

  const getPlaygroundIcon = () => {
    switch (playIconOption) {
      case "check":
        return <Check className="w-3.5 h-3.5" />;
      case "warning":
        return <AlertTriangle className="w-3.5 h-3.5" />;
      case "bell":
        return <Bell className="w-3.5 h-3.5" />;
      case "star":
        return <Star className="w-3.5 h-3.5" />;
      default:
        return undefined;
    }
  };

  const roundedPropStr = playRounded !== "default" ? `\n  rounded="${playRounded}"` : "";
  const borderPropStr = playWithBorder ? `\n  withBorder` : "";
  const themePropStr = playTheme === "playful" ? `\n  theme="playful"` : "";
  const dotPropStr = playDot ? `\n  dot` : "";
  const pulsePropStr = playDot && playDotPulse ? `\n  dotPulse` : "";
  const iconPropStr = playIconOption !== "none" ? `\n  icon={<Icon />}` : "";

  const codeSnippet = `<BadgeApp
  id="my-badge"
  variant="${playVariant}"
  size="${playSize}"${roundedPropStr}${borderPropStr}${themePropStr}${dotPropStr}${pulsePropStr}${iconPropStr}
>
  ${playText}
</BadgeApp>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-badge-module"
      icon={<Layers className="w-5 h-5 text-vibrant-purple-dark" />}
      title="BadgeApp"
      description="Elemen lencana visual untuk status, notification counter, solid/outline/soft, ikon opsional, ukuran, dan Foundation Rounded (pill, card, circle, square) — P4D BPKAD Kota Yogyakarta."
    >
      {/*
        `variant` BadgeApp punya 4 bucket editorial (solid/outline/soft/
        contrast) di atas satu union prop — semuanya masuk namespace datar
        `variant-*`. "Status" & "Notification" di versi lama bukan prop asli:
        keduanya mencampur variant + dot + icon dalam satu kartu contoh
        pemakaian, jadi dibongkar jadi sumbu aslinya (variant, dot, icon).
      */}
      <ShowcaseGroup id="badge-group-variant-solid" title="Variant — Solid" description="solidSuccess · solidWarning · solidError · solidInfo · solidPurple — latar belakang pekat" cols={5}>
        <ShowcaseCard
          id="badge-showcase-variant-solid-success"
          title="Variant solidSuccess"
          description="Konfirmasi berhasil, kontras tinggi"
          code={`<BadgeApp id="b" variant="solidSuccess">Success</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-variant-solid-success-demo" variant="solidSuccess">Success</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-variant-solid-warning"
          title="Variant solidWarning"
          description="Perlu perhatian, kontras tinggi"
          code={`<BadgeApp id="b" variant="solidWarning">Warning</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-variant-solid-warning-demo" variant="solidWarning">Warning</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-variant-solid-error"
          title="Variant solidError"
          description="Gagal / ditolak, kontras tinggi"
          code={`<BadgeApp id="b" variant="solidError">Error</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-variant-solid-error-demo" variant="solidError">Error</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-variant-solid-info"
          title="Variant solidInfo"
          description="Informasi netral, kontras tinggi"
          code={`<BadgeApp id="b" variant="solidInfo">Info</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-variant-solid-info-demo" variant="solidInfo">Info</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-variant-solid-purple"
          title="Variant solidPurple"
          description="Aksen brand, kontras tinggi"
          code={`<BadgeApp id="b" variant="solidPurple">Brand Purple</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-variant-solid-purple-demo" variant="solidPurple">Brand Purple</BadgeApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="badge-group-variant-outline" title="Variant — Outline" description="Garis tepi transparan — outlineSuccess · outlineWarning · outlineError · outlineInfo · outlineBrand · outlineNeutral" cols={5}>
        <ShowcaseCard
          id="badge-showcase-variant-outline-success"
          title="Variant outlineSuccess"
          description="Garis tepi transparan, latar tanpa fill pekat"
          code={`<BadgeApp id="b" variant="outlineSuccess">Success Outline</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-variant-outline-success-demo" variant="outlineSuccess">Success Outline</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-variant-outline-warning"
          title="Variant outlineWarning"
          description="Garis tepi transparan, latar tanpa fill pekat"
          code={`<BadgeApp id="b" variant="outlineWarning">Warning Outline</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-variant-outline-warning-demo" variant="outlineWarning">Warning Outline</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-variant-outline-error"
          title="Variant outlineError"
          description="Garis tepi transparan, latar tanpa fill pekat"
          code={`<BadgeApp id="b" variant="outlineError">Error Outline</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-variant-outline-error-demo" variant="outlineError">Error Outline</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-variant-outline-info"
          title="Variant outlineInfo"
          description="Garis tepi transparan, latar tanpa fill pekat"
          code={`<BadgeApp id="b" variant="outlineInfo">Info Outline</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-variant-outline-info-demo" variant="outlineInfo">Info Outline</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-variant-outline-brand"
          title="Variant outlineBrand"
          description="Garis tepi transparan, latar tanpa fill pekat"
          code={`<BadgeApp id="b" variant="outlineBrand">Brand Outline</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-variant-outline-brand-demo" variant="outlineBrand">Brand Outline</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-variant-outline-neutral"
          title="Variant outlineNeutral"
          description="Garis tepi transparan, latar tanpa fill pekat"
          code={`<BadgeApp id="b" variant="outlineNeutral">Neutral Outline</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-variant-outline-neutral-demo" variant="outlineNeutral">Neutral Outline</BadgeApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="badge-group-variant-soft" title="Variant — Soft Tint" description="Latar belakang subtle — success · warning · error · info · brand · neutral" cols={5}>
        <ShowcaseCard
          id="badge-showcase-variant-soft-success"
          title="Variant success"
          description="Latar belakang subtle, kontras rendah"
          code={`<BadgeApp id="b" variant="success">Success Soft</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-variant-soft-success-demo" variant="success">Success Soft</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-variant-soft-warning"
          title="Variant warning"
          description="Latar belakang subtle, kontras rendah"
          code={`<BadgeApp id="b" variant="warning">Warning Soft</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-variant-soft-warning-demo" variant="warning">Warning Soft</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-variant-soft-error"
          title="Variant error"
          description="Latar belakang subtle, kontras rendah"
          code={`<BadgeApp id="b" variant="error">Error Soft</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-variant-soft-error-demo" variant="error">Error Soft</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-variant-soft-info"
          title="Variant info"
          description="Latar belakang subtle, kontras rendah"
          code={`<BadgeApp id="b" variant="info">Info Soft</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-variant-soft-info-demo" variant="info">Info Soft</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-variant-soft-brand"
          title="Variant brand"
          description="Latar belakang subtle, kontras rendah"
          code={`<BadgeApp id="b" variant="brand">Brand Soft</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-variant-soft-brand-demo" variant="brand">Brand Soft</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-variant-soft-neutral"
          title="Variant neutral"
          description="Latar belakang subtle, kontras rendah"
          code={`<BadgeApp id="b" variant="neutral">Neutral Soft</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-variant-soft-neutral-demo" variant="neutral">Neutral Soft</BadgeApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="badge-group-variant-contrast" title="Variant — Contrast (Theme-Independent)" description="contrastLight (putih solid) · contrastDark (nyaris hitam solid) — warna tetap, tidak ikut berubah di dark mode, dipakai untuk badge di atas fill sewarna apa pun" cols={2}>
        <ShowcaseCard
          id="badge-showcase-variant-contrast-light"
          title="Variant contrastLight"
          description="Putih solid untuk dipakai di atas fill gelap/vibrant apa pun"
          code={`<BadgeApp id="b" variant="contrastLight">Di atas fill gelap</BadgeApp>`}
        >
          <div className="flex flex-wrap items-center gap-3 rounded-xl bg-vibrant-purple-dark p-3">
            <BadgeApp id="badge-showcase-variant-contrast-light-demo" variant="contrastLight" size="sm">contrastLight</BadgeApp>
            <span className="text-[11px] text-white/70">di atas fill gelap/vibrant</span>
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-variant-contrast-dark"
          title="Variant contrastDark"
          description="Nyaris hitam solid untuk dipakai di atas fill terang/pastel apa pun. CardApp mem-render prop badge lewat contrastLight tapi warnanya di-override inline sesuai variant card — lihat halaman CardApp."
          code={`<BadgeApp id="b" variant="contrastDark">Di atas fill terang</BadgeApp>`}
        >
          <div className="flex flex-wrap items-center gap-3 rounded-xl bg-vibrant-grey-bg p-3">
            <BadgeApp id="badge-showcase-variant-contrast-dark-demo" variant="contrastDark" size="sm">contrastDark</BadgeApp>
            <span className="text-[11px] text-ink-muted">di atas fill terang/pastel</span>
          </div>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="badge-group-dot" title="Status Dot" description="dot · dotPulse — indikator titik status real-time, terlepas dari variant" cols={2}>
        <ShowcaseCard
          id="badge-showcase-dot"
          title="Dot"
          description="Titik status statis di samping label"
          code={`<BadgeApp id="b" variant="success" dot>Online</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-dot-demo" variant="success" dot size="sm">Online</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-dot-pulse"
          title="Dot Pulse"
          description="Titik status berdenyut — status real-time yang aktif"
          code={`<BadgeApp id="b" variant="error" dot dotPulse>Busy</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-dot-pulse-demo" variant="error" dot dotPulse size="sm">Busy</BadgeApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="badge-group-icon" title="Icon" description="icon di posisi kiri (default) atau kanan via iconPosition" cols={2}>
        <ShowcaseCard
          id="badge-showcase-icon-left"
          title="Icon posisi kiri"
          description="iconPosition default — ikon mendahului label"
          code={`<BadgeApp id="b" variant="warning" icon={<AlertTriangle />}>Perhatian</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-icon-left-demo" variant="warning" icon={<AlertTriangle className="w-3.5 h-3.5" />}>Perhatian</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-icon-right"
          title="Icon posisi kanan"
          description='iconPosition="right" — ikon mengikuti label'
          code={`<BadgeApp id="b" variant="solidPurple" icon={<ShieldCheck />} iconPosition="right">Secure Lock</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-icon-right-demo" variant="solidPurple" icon={<ShieldCheck className="w-3.5 h-3.5" />} iconPosition="right">Secure Lock</BadgeApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="badge-group-size" title="Ukuran" description="sm · md (default) · lg — semua variant=&quot;solidPurple&quot; agar hanya ukuran yang berbeda" cols={3}>
        <ShowcaseCard
          id="badge-showcase-size-sm"
          title="Ukuran sm"
          description="Badge paling ringkas"
          code={`<BadgeApp id="b" size="sm" variant="solidPurple">Label</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-size-sm-demo" size="sm" variant="solidPurple">Label</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-size-md"
          title="Ukuran md"
          description="Ukuran standar katalog"
          code={`<BadgeApp id="b" size="md" variant="solidPurple">Label</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-size-md-demo" size="md" variant="solidPurple">Label</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-size-lg"
          title="Ukuran lg"
          description="Badge paling menonjol"
          code={`<BadgeApp id="b" size="lg" variant="solidPurple">Label</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-size-lg-demo" size="lg" variant="solidPurple">Label</BadgeApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGroup id="badge-group-rounded" title="Foundation Rounded" description="pill · card · circle · square — semua variant=&quot;solidPurple&quot; agar hanya radius yang berbeda" cols={4}>
        <ShowcaseCard
          id="badge-showcase-rounded-pill"
          title="Rounded pill"
          description="Pill penuh — default katalog"
          code={`<BadgeApp id="b" rounded="pill" variant="solidPurple">Label</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-rounded-pill-demo" rounded="pill" variant="solidPurple">Label</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-rounded-card"
          title="Rounded card"
          description="Radius Foundation sedang"
          code={`<BadgeApp id="b" rounded="card" variant="solidPurple">Label</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-rounded-card-demo" rounded="card" variant="solidPurple">Label</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-rounded-circle"
          title="Rounded circle"
          description="Lingkaran penuh — cocok untuk badge angka"
          code={`<BadgeApp id="b" rounded="circle" variant="solidPurple">Label</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-rounded-circle-demo" rounded="circle" variant="solidPurple">Label</BadgeApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="badge-showcase-rounded-square"
          title="Rounded square"
          description="Sudut siku, tanpa radius"
          code={`<BadgeApp id="b" rounded="square" variant="solidPurple">Label</BadgeApp>`}
        >
          <BadgeApp id="badge-showcase-rounded-square-demo" rounded="square" variant="solidPurple">Label</BadgeApp>
        </ShowcaseCard>

      </ShowcaseGroup>

      <ShowcaseGrid cols={1}>
        {/* Playground — span penuh */}
        <ShowcaseCard
          id="badge-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap BadgeApp dengan kode JSX yang dihasilkan"
          align="start"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            {/* Controls */}
            <div className="flex flex-col gap-4">
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Label Badge</span>
                <InputApp id="bg-input-text" value={playText} onChange={(e) => setPlayText(e.target.value)} placeholder="Label teks atau angka..." />
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Warna & Style</span>
                  <DropdownApp
                    id="bg-select-variant"
                    value={playVariant}
                    onChange={(value) => setPlayVariant(value as BadgeVariant)}
                    options={[
                      { value: "solidSuccess", label: "Solid Success" },
                      { value: "solidWarning", label: "Solid Warning" },
                      { value: "solidError", label: "Solid Error" },
                      { value: "solidInfo", label: "Solid Info" },
                      { value: "solidPurple", label: "Solid Purple" },
                      { value: "outlineSuccess", label: "Outline Success" },
                      { value: "outlineBrand", label: "Outline Brand" },
                      { value: "success", label: "Soft Success" },
                      { value: "neutral", label: "Soft Neutral" },
                      { value: "contrastLight", label: "Contrast Light (putih solid)" },
                      { value: "contrastDark", label: "Contrast Dark (nyaris hitam solid)" },
                    ]}
                  />
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Ukuran</span>
                  <DropdownApp
                    id="bg-select-size"
                    value={playSize}
                    onChange={(value) => setPlaySize(value as BadgeSize)}
                    options={[
                      { value: "sm", label: "Small (sm)" },
                      { value: "md", label: "Medium (md)" },
                      { value: "lg", label: "Large (lg)" },
                    ]}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Foundation Rounded</span>
                  <DropdownApp
                    id="bg-select-rounded"
                    value={playRounded}
                    onChange={(value) => setPlayRounded(value as BadgeRounded)}
                    options={[
                      { value: "pill", label: "Pill (Foundation)" },
                      { value: "card", label: "Card (Foundation)" },
                      { value: "circle", label: "Circle / Full" },
                      { value: "square", label: "Square / None" },
                    ]}
                  />
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Pilihan Icon</span>
                  <DropdownApp
                    id="bg-select-icon"
                    value={playIconOption}
                    onChange={(value) => setPlayIconOption(value as any)}
                    options={[
                      { value: "none", label: "Tanpa Icon" },
                      { value: "check", label: "Checkmark Icon" },
                      { value: "warning", label: "Warning Icon" },
                      { value: "bell", label: "Bell Icon" },
                      { value: "star", label: "Star Icon" },
                    ]}
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-5 border-t border-hairline-soft pt-3">
                <ToggleApp id="bg-toggle-dot" checked={playDot} onCheckedChange={setPlayDot} size="sm" label="Status Dot" />
                {playDot && <ToggleApp id="bg-toggle-pulse" checked={playDotPulse} onCheckedChange={setPlayDotPulse} size="sm" label="Dot Pulse" />}
                <ToggleApp id="bg-toggle-border" checked={playWithBorder} onCheckedChange={setPlayWithBorder} size="sm" label="Border Extra" />
              </div>
            </div>

            {/* Live Output & Code */}
            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[120px] items-center justify-center rounded-lg border border-dashed border-hairline bg-surface p-4">
                  <BadgeApp
                    id="playground-interactive-badge"
                    variant={playVariant}
                    size={playSize}
                    rounded={playRounded}
                    theme={playTheme}
                    withBorder={playWithBorder}
                    dot={playDot}
                    dotPulse={playDotPulse}
                    icon={getPlaygroundIcon()}
                  >
                    {playText || "Empty"}
                  </BadgeApp>
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="copy-bg-code"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeSnippet}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
