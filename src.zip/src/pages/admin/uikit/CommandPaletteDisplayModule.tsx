import * as React from "react";
import {
  CommandPaletteApp,
  DEFAULT_COMMAND_GROUPS,
  ButtonApp,
  InputApp,
  CommandGroup,
} from "@/packages/design-system";
import { Command, Code, Check, Sparkles, Terminal } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

export function CommandPaletteDisplayModule() {
  const [isModalOpen, setIsModalOpen] = React.useState<boolean>(false);

  const [playVariant, setPlayVariant] = React.useState<"default" | "purple" | "dark">("default");
  const [playSize, setPlaySize] = React.useState<"sm" | "md" | "lg">("md");
  const [playRounded, setPlayRounded] = React.useState<"none" | "sm" | "md" | "lg" | "xl" | "full">("xl");
  const [playQuery, setPlayQuery] = React.useState<string>("");
  const [copied, setCopied] = React.useState<boolean>(false);

  const customGroups: CommandGroup[] = [
    ...DEFAULT_COMMAND_GROUPS,
    {
      id: "ai-tools",
      heading: "AI Studio Commands",
      items: [
        {
          id: "ai-gen",
          label: "Generate UI Component",
          description: "Prompt Gemini AI to craft layout",
          icon: <Sparkles className="w-4 h-4 text-purple-600" />,
          shortcut: ["⌘", "G"],
          badge: "AI",
          onSelect: () => alert("Triggered AI Generator!"),
        },
        {
          id: "ai-cli",
          label: "Run Terminal Command",
          description: "Execute package installation",
          icon: <Terminal className="w-4 h-4 text-emerald-600" />,
          shortcut: ["⌘", "T"],
          onSelect: () => alert("Triggered Terminal Command!"),
        },
      ],
    },
  ];

  const codeString = `<CommandPaletteApp\n  id="app-global-search"\n  isOpen={isOpen}\n  onClose={() => setIsOpen(false)}\n  onOpen={() => setIsOpen(true)}\n  variant="${playVariant}"\n  size="${playSize}"\n  rounded="${playRounded}"\n  placeholder="Type a command or search..."\n  groups={customGroups}\n/>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-commandpalette-module"
      icon={<Command className="w-5 h-5 text-vibrant-purple-dark" />}
      title="CommandPaletteApp (Cmd+K Global Search & Actions)"
      description="Organism pencarian global dan eksekusi shortcut keyboard instant dengan modal overlay scrim, navigasi panah keyboard, visual KBD badges, dan pengelompokan hasil terstruktur."
    >
      <ShowcaseGrid cols={2}>
        <ShowcaseCard
          id="commandpalette-showcase-default"
          title="Varian Default (Inline)"
          description='variant="default" — grouped command list bawaan'
          code={`<CommandPaletteApp id="cmd" isInline variant="default" size="md" rounded="xl" groups={DEFAULT_COMMAND_GROUPS} />`}
        >
          <div className="w-full p-3 bg-surface-soft rounded-2xl border border-hairline-soft">
            <CommandPaletteApp
              id="cmd-inline-default"
              isInline={true}
              variant="default"
              size="md"
              rounded="xl"
              placeholder="Type 'dashboard' or 'settings'..."
              groups={DEFAULT_COMMAND_GROUPS}
            />
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="commandpalette-showcase-purple"
          title="Varian Purple Brand (Inline)"
          description='variant="purple" — dengan grup AI Studio custom'
          code={`<CommandPaletteApp id="cmd" isInline variant="purple" size="md" rounded="xl" groups={customGroups} />`}
        >
          <div className="w-full p-3 bg-vibrant-purple/5 rounded-2xl border border-vibrant-purple/20">
            <CommandPaletteApp
              id="cmd-inline-purple"
              isInline={true}
              variant="purple"
              size="md"
              rounded="xl"
              placeholder="Search quick actions or AI tools..."
              groups={customGroups}
            />
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="commandpalette-showcase-modal"
          title="Modal Overlay (⌘K Trigger)"
          description="Instance modal penuh dengan scrim & navigasi keyboard"
          code={`<ButtonApp onClick={() => setIsOpen(true)}>Buka Modal (⌘K)</ButtonApp>\n<CommandPaletteApp id="cmd-modal" isOpen={isOpen} onClose={...} groups={customGroups} />`}
          align="start"
          className="md:col-span-2"
        >
          <ButtonApp
            id="trigger-modal-cmd-k"
            variant="primary"
            size="sm"
            rounded="lg"
            onClick={() => setIsModalOpen(true)}
            leftIcon={<Command className="w-4 h-4" />}
          >
            Buka Modal (⌘K)
          </ButtonApp>
          <CommandPaletteApp
            id="cmd-modal-instance"
            isOpen={isModalOpen}
            onClose={() => setIsModalOpen(false)}
            onOpen={() => setIsModalOpen(true)}
            variant={playVariant}
            size={playSize}
            rounded={playRounded}
            placeholder="Global Command Palette (Press ESC to exit)..."
            groups={customGroups}
          />
        </ShowcaseCard>

        <ShowcaseCard
          id="commandpalette-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap CommandPaletteApp dengan kode JSX yang dihasilkan"
          align="start"
          className="md:col-span-2"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            <div className="flex flex-col gap-4">
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Variant</span>
                <div className="flex flex-wrap gap-1.5">
                  {(["default", "purple", "dark"] as const).map((v) => (
                    <PlaygroundChip key={v} id={`command-play-variant-${v}`} active={playVariant === v} onClick={() => setPlayVariant(v)}>
                      {v}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Size</span>
                  <div className="flex flex-wrap gap-1">
                    {(["sm", "md", "lg"] as const).map((s) => (
                      <PlaygroundChip key={s} id={`command-play-size-${s}`} active={playSize === s} onClick={() => setPlaySize(s)} className="flex-1">
                        {s}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Rounded</span>
                  <div className="flex flex-wrap gap-1">
                    {(["none", "sm", "md", "lg", "xl", "full"] as const).map((r) => (
                      <PlaygroundChip key={r} id={`command-play-rounded-${r}`} active={playRounded === r} onClick={() => setPlayRounded(r)} className="flex-1">
                        {r}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Simulasi Query Pencarian</span>
                <InputApp
                  id="command-play-search-input"
                  size="sm"
                  rounded="lg"
                  value={playQuery}
                  onChange={(e) => setPlayQuery(e.target.value)}
                  placeholder="Ketik kata kunci untuk menguji Empty State atau Filter..."
                />
              </div>

              <ButtonApp
                id="play-open-btn"
                variant="secondary"
                size="sm"
                rounded="md"
                onClick={() => setIsModalOpen(true)}
              >
                Buka Modal Overlay
              </ButtonApp>
            </div>

            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="p-3 bg-surface rounded-xl border border-dashed border-hairline">
                  <CommandPaletteApp
                    id="interactive-command-palette"
                    isInline={true}
                    variant={playVariant}
                    size={playSize}
                    rounded={playRounded}
                    value={playQuery}
                    onValueChange={setPlayQuery}
                    placeholder="Ketik perintah atau navigasi halaman..."
                    groups={customGroups}
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="command-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeString}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
