import * as React from "react";
import {
  BreadcrumbApp,
  BreadcrumbItem,
  BreadcrumbVariant,
  BreadcrumbSize,
  BreadcrumbRounded,
  ButtonApp,
} from "@/packages/design-system";
import {
  Home,
  ChevronRight,
  Slash,
  Minus,
  Layers,
  Code,
  Check,
  Folder,
  FileText,
  Building2,
  Database,
  ShieldCheck,
} from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

export function BreadcrumbDisplayModule() {
  const [variant, setVariant] = React.useState<BreadcrumbVariant>("default");
  const [size, setSize] = React.useState<BreadcrumbSize>("md");
  const [rounded, setRounded] = React.useState<BreadcrumbRounded>("md");
  const [maxItems, setMaxItems] = React.useState<number | undefined>(3);
  const [separatorType, setSeparatorType] = React.useState<"chevron" | "slash" | "dash">("chevron");
  const [copied, setCopied] = React.useState(false);

  const standardItems: BreadcrumbItem[] = [
    { label: "Beranda", href: "#", icon: <Home className="w-4 h-4" /> },
    { label: "Manajemen Pajak", href: "#" },
    { label: "PBB-P2", href: "#" },
    { label: "Detail Penetapan Massal", isCurrentPage: true },
  ];

  const longPathItems: BreadcrumbItem[] = [
    { label: "Dashboard", href: "#", icon: <Home className="w-4 h-4" /> },
    { label: "BPKAD Jogja", href: "#", icon: <Building2 className="w-4 h-4" /> },
    { label: "Modul Keuangan", href: "#", icon: <Database className="w-4 h-4" /> },
    { label: "Sub-Modul Anggaran", href: "#", icon: <Folder className="w-4 h-4" /> },
    { label: "Verifikasi Audit", href: "#", icon: <ShieldCheck className="w-4 h-4" /> },
    { label: "Laporan Realisasi Q3 2026.pdf", isCurrentPage: true, icon: <FileText className="w-4 h-4" /> },
  ];

  const separatorElement = React.useMemo(() => {
    if (separatorType === "slash") return "/";
    if (separatorType === "dash") return "-";
    return undefined; // default ChevronRight
  }, [separatorType]);

  const codeSnippet = `<BreadcrumbApp
  id="interactive-breadcrumb-demo"
  variant="${variant}"
  size="${size}"
  rounded="${rounded}"
  ${maxItems ? `maxItems={${maxItems}}` : ""}
  ${separatorType !== "chevron" ? `separator="${separatorElement}"` : ""}
  items={sampleBreadcrumbItems}
/>`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-breadcrumb-module"
      icon={<Layers className="w-5 h-5 text-vibrant-purple-dark" />}
      title="BreadcrumbApp (Breadcrumb Navigation)"
      description="Molecule navigasi jejak halaman hierarki admin BPKAD dengan dukungan varian Standard, Collapsed Ellipsis (...), Separator Kustom, serta Ikon & Pills."
    >
      <ShowcaseGrid cols={2}>
        <ShowcaseCard
          id="breadcrumb-showcase-default"
          title="Standard Chevron"
          description='variant="default" — separator chevron bawaan'
          code={`<BreadcrumbApp id="bc" items={items} variant="default" size="md" />`}
        >
          <BreadcrumbApp id="demo-standard-breadcrumb" items={standardItems} variant="default" size="md" />
        </ShowcaseCard>

        <ShowcaseCard
          id="breadcrumb-showcase-slash"
          title="Slash Separator"
          description='separator="/" — jejak path model file'
          code={`<BreadcrumbApp id="bc" items={items} separator="/" variant="default" size="md" />`}
        >
          <BreadcrumbApp id="demo-slash-breadcrumb" items={standardItems} separator="/" variant="default" size="md" />
        </ShowcaseCard>

        <ShowcaseCard
          id="breadcrumb-showcase-collapsed"
          title="Collapsed Ellipsis"
          description="maxItems={3} — jalur panjang otomatis dipangkas (...)"
          code={`<BreadcrumbApp id="bc" items={items} maxItems={3} variant="default" size="md" />`}
        >
          <BreadcrumbApp id="demo-collapsed-breadcrumb" items={longPathItems} maxItems={3} variant="default" size="md" />
        </ShowcaseCard>

        <ShowcaseCard
          id="breadcrumb-showcase-pills"
          title="Pills Container"
          description='variant="pills" rounded="full" — gaya pil'
          code={`<BreadcrumbApp id="bc" items={items} variant="pills" rounded="full" size="md" />`}
        >
          <BreadcrumbApp id="demo-pills-breadcrumb" items={standardItems} variant="pills" rounded="full" size="md" />
        </ShowcaseCard>

        <ShowcaseCard
          id="breadcrumb-showcase-playground"
          title="Live Interactive Playground"
          description="Konfigurasi lengkap BreadcrumbApp dengan kode JSX yang dihasilkan"
          align="start"
          className="md:col-span-2"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            <div className="flex flex-col gap-4">
              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Variant</span>
                <div className="flex flex-wrap gap-1.5">
                  {(["default", "muted", "pills"] as const).map((v) => (
                    <PlaygroundChip key={v} id={`bc-play-variant-${v}`} active={variant === v} onClick={() => setVariant(v)}>
                      {v}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Size</span>
                  <div className="flex flex-wrap gap-1">
                    {(["sm", "md", "lg"] as const).map((s) => (
                      <PlaygroundChip key={s} id={`bc-play-size-${s}`} active={size === s} onClick={() => setSize(s)} className="flex-1">
                        {s}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Rounded</span>
                  <div className="flex flex-wrap gap-1">
                    {(["none", "sm", "md", "lg", "xl", "full"] as const).map((r) => (
                      <PlaygroundChip key={r} id={`bc-play-rounded-${r}`} active={rounded === r} onClick={() => setRounded(r)} className="flex-1">
                        {r}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Max Items</span>
                <div className="flex flex-wrap gap-1.5">
                  {[undefined, 3, 4, 5].map((m) => (
                    <PlaygroundChip
                      key={m ?? "all"}
                      id={`bc-play-max-${m ?? "all"}`}
                      active={maxItems === m}
                      onClick={() => setMaxItems(m)}
                    >
                      {m ? `${m} items` : "Semua"}
                    </PlaygroundChip>
                  ))}
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Separator</span>
                <div className="flex flex-wrap gap-1.5">
                  <PlaygroundChip id="bc-play-sep-chevron" active={separatorType === "chevron"} onClick={() => setSeparatorType("chevron")} className="flex-1">
                    <ChevronRight className="mr-1 inline h-3 w-3" /> Chevron
                  </PlaygroundChip>
                  <PlaygroundChip id="bc-play-sep-slash" active={separatorType === "slash"} onClick={() => setSeparatorType("slash")} className="flex-1">
                    <Slash className="mr-1 inline h-3 w-3" /> Slash
                  </PlaygroundChip>
                  <PlaygroundChip id="bc-play-sep-dash" active={separatorType === "dash"} onClick={() => setSeparatorType("dash")} className="flex-1">
                    <Minus className="mr-1 inline h-3 w-3" /> Dash
                  </PlaygroundChip>
                </div>
              </div>
            </div>

            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[100px] items-center rounded-lg border border-dashed border-hairline bg-surface p-4">
                  <BreadcrumbApp
                    id="interactive-breadcrumb-demo"
                    variant={variant}
                    size={size}
                    rounded={rounded}
                    maxItems={maxItems}
                    separator={separatorElement}
                    items={longPathItems}
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated JSX Code
                  </span>
                  <ButtonApp
                    id="bc-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeSnippet}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
