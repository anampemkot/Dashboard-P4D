import * as React from "react";
import {
  ButtonApp,
  InputApp,
  DropdownApp,
  ToggleApp,
  useToastApp,
  ToastVariant,
  ToastPosition,
} from "@/packages/design-system";
import { BellRing, CheckCircle2, AlertCircle, AlertTriangle, Info, Code, Check, Trash2 } from "lucide-react";
import { ModuleCard } from "./ModuleCard";
import { ShowcaseCard, ShowcaseGrid, ShowcaseGroup } from "./shared/ShowcaseCard";
import { PlaygroundChip } from "./shared/PlaygroundChip";

const VARIANT_OPTIONS: { value: ToastVariant; label: string }[] = [
  { value: "success", label: "Success" },
  { value: "error", label: "Error" },
  { value: "warning", label: "Warning" },
  { value: "info", label: "Info" },
  { value: "vibrant", label: "Vibrant" },
  { value: "brand", label: "Brand" },
  { value: "default", label: "Default" },
];

const POSITION_OPTIONS: { value: ToastPosition; label: string }[] = [
  { value: "top-right", label: "Top Right" },
  { value: "top-left", label: "Top Left" },
  { value: "top-center", label: "Top Center" },
  { value: "bottom-right", label: "Bottom Right" },
  { value: "bottom-left", label: "Bottom Left" },
  { value: "bottom-center", label: "Bottom Center" },
];

export function ToastDisplayModule() {
  const { toast, clear, position, setPosition, toasts } = useToastApp();

  const [title, setTitle] = React.useState("Perubahan Tersimpan");
  const [description, setDescription] = React.useState("Data konfigurasi sistem berhasil diperbarui ke server.");
  const [variant, setVariant] = React.useState<ToastVariant>("success");
  const [badgeText, setBadgeText] = React.useState("Sistem");
  const [duration, setDuration] = React.useState(4000);
  const [includeAction, setIncludeAction] = React.useState(true);
  const [actionLabel, setActionLabel] = React.useState("Urungkan");
  const [copied, setCopied] = React.useState(false);

  const triggerCustomToast = () => {
    toast({
      title,
      description: description || undefined,
      variant,
      badge: badgeText || undefined,
      duration,
      action: includeAction
        ? { label: actionLabel, onClick: () => toast.info("Aksi diurungkan!") }
        : undefined,
    });
  };

  const codeSnippet = `const { toast } = useToastApp();

toast.${variant === "default" ? "" : variant}(${JSON.stringify(title)}, {
  description: ${JSON.stringify(description)},
  badge: ${badgeText ? JSON.stringify(badgeText) : "undefined"},
  duration: ${duration},${
    includeAction
      ? `\n  action: { label: ${JSON.stringify(actionLabel)}, onClick: () => {} },`
      : ""
  }
});`;

  const copyCode = () => {
    navigator.clipboard.writeText(codeSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModuleCard
      id="uikit-toast-module"
      icon={<BellRing className="w-5 h-5 text-vibrant-purple-dark" />}
      title="ToastApp & ProviderApp"
      description="Sistem notifikasi toast global berbasis React Context Provider (ProviderApp & useToastApp) untuk umpan balik aksi non-blocking."
    >
      <ShowcaseGroup
        id="toast-group-helper"
        title="Helper"
        description="toast.success · toast.error · toast.warning · toast.info"
        cols={4}
      >
        <ShowcaseCard
          id="toast-showcase-helper-success"
          title="Helper success"
          description="Konfirmasi aksi berhasil — badge hijau"
          code={`const { toast } = useToastApp();\ntoast.success("Data Berhasil Disimpan", {\n  description: "Perubahan profil pengguna telah disimpan.",\n  badge: "Sukses",\n});`}
        >
          <ButtonApp
            id="toast-btn-success"
            variant="secondary"
            size="sm"
            leftIcon={<CheckCircle2 className="w-4 h-4 text-success" />}
            onClick={() => toast.success("Data Berhasil Disimpan", { description: "Perubahan profil pengguna telah disimpan.", badge: "Sukses" })}
          >
            Success
          </ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="toast-showcase-helper-error"
          title="Helper error"
          description="Kegagalan dengan aksi coba lagi"
          code={`toast.error("Gagal Terhubung ke Server", {\n  description: "Koneksi terputus.",\n  badge: "Error 500",\n  action: { label: "Coba Lagi", onClick: () => {} },\n});`}
        >
          <ButtonApp
            id="toast-btn-error"
            variant="secondary"
            size="sm"
            leftIcon={<AlertCircle className="w-4 h-4 text-error" />}
            onClick={() => toast.error("Gagal Terhubung ke Server", { description: "Koneksi terputus.", badge: "Error 500", action: { label: "Coba Lagi", onClick: () => toast.info("Menghubungkan ulang...") } })}
          >
            Error
          </ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="toast-showcase-helper-warning"
          title="Helper warning"
          description="Peringatan dengan aksi perpanjang"
          code={`toast.warning("Sesi Akan Berakhir", {\n  description: "Sesi login Anda akan habis dalam 5 menit.",\n  badge: "Peringatan",\n  action: { label: "Perpanjang", onClick: () => {} },\n});`}
        >
          <ButtonApp
            id="toast-btn-warning"
            variant="secondary"
            size="sm"
            leftIcon={<AlertTriangle className="w-4 h-4 text-warning" />}
            onClick={() => toast.warning("Sesi Akan Berakhir", { description: "Sesi login Anda akan habis dalam 5 menit.", badge: "Peringatan", action: { label: "Perpanjang", onClick: () => toast.success("Sesi telah diperpanjang!") } })}
          >
            Warning
          </ButtonApp>
        </ShowcaseCard>

        <ShowcaseCard
          id="toast-showcase-helper-info"
          title="Helper info"
          description="Informasi netral tanpa aksi"
          code={`toast.info("Pembaruan Sistem Tersedia", {\n  description: "Versi v2.4.0 siap dipasang.",\n  badge: "Info",\n});`}
        >
          <ButtonApp
            id="toast-btn-info"
            variant="secondary"
            size="sm"
            leftIcon={<Info className="w-4 h-4 text-info" />}
            onClick={() => toast.info("Pembaruan Sistem Tersedia", { description: "Versi v2.4.0 siap dipasang.", badge: "Info" })}
          >
            Info
          </ButtonApp>
        </ShowcaseCard>
      </ShowcaseGroup>

      <ShowcaseGrid cols={2}>
        <ShowcaseCard
          id="toast-showcase-status"
          title="Status Toast Aktif"
          description="Jumlah toast aktif di layar dan posisi stacking saat ini"
        >
          <div className="flex w-full flex-col gap-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-ink-secondary">Toast Aktif di Layar</span>
              <span className="font-mono font-bold text-ink">{toasts.length}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-ink-secondary">Posisi Stacking</span>
              <span className="font-mono font-bold text-ink">{position}</span>
            </div>
            <ButtonApp id="clear-toasts-btn" variant="ghost" size="sm" leftIcon={<Trash2 className="w-3.5 h-3.5 text-error" />} onClick={clear}>
              Bersihkan Semua Toast
            </ButtonApp>
          </div>
        </ShowcaseCard>

        <ShowcaseCard
          id="toast-showcase-playground"
          title="Live Interactive Playground"
          description="Kustomisasi opsi notifikasi toast dan posisi penayangan"
          align="start"
          className="md:col-span-2"
        >
          <div className="grid w-full grid-cols-1 gap-6 text-left lg:grid-cols-2">
            <div className="flex flex-col gap-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Posisi Stacking</span>
                  <DropdownApp id="toast-pos-select" value={position} onChange={(value) => setPosition(value as ToastPosition)} options={POSITION_OPTIONS} />
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Varian</span>
                  <DropdownApp id="toast-variant-select" value={variant} onChange={(value) => setVariant(value as ToastVariant)} options={VARIANT_OPTIONS} />
                </div>
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Judul Toast</span>
                <InputApp id="toast-input-title" value={title} onChange={(e) => setTitle(e.target.value)} />
              </div>

              <div>
                <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Deskripsi</span>
                <InputApp id="toast-input-desc" value={description} onChange={(e) => setDescription(e.target.value)} />
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Teks Badge</span>
                  <InputApp id="toast-input-badge" value={badgeText} onChange={(e) => setBadgeText(e.target.value)} />
                </div>
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Durasi (ms)</span>
                  <div className="flex flex-wrap gap-1.5">
                    {[2000, 4000, 7000, 0].map((d) => (
                      <PlaygroundChip key={d} id={`toast-duration-${d}`} active={duration === d} onClick={() => setDuration(d)}>
                        {d === 0 ? "Permanen" : `${d}ms`}
                      </PlaygroundChip>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between border-t border-hairline-soft pt-3">
                <span className="text-[10px] font-bold uppercase tracking-wide text-ink">Sertakan Tombol Aksi</span>
                <ToggleApp id="toast-action-toggle" checked={includeAction} onCheckedChange={setIncludeAction} />
              </div>

              {includeAction && (
                <div>
                  <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-ink">Label Tombol Aksi</span>
                  <InputApp id="toast-action-label" value={actionLabel} onChange={(e) => setActionLabel(e.target.value)} />
                </div>
              )}

              <ButtonApp id="toast-trigger-custom" variant="purple" size="md" leftIcon={<BellRing className="w-4 h-4" />} onClick={triggerCustomToast}>
                Tampilkan Custom Toast
              </ButtonApp>
            </div>

            <div className="flex flex-col justify-between gap-4 rounded-xl border border-hairline-soft bg-surface-soft p-4">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-ink-muted">Live Preview Output</span>
                <div className="flex min-h-[120px] items-center justify-center rounded-lg border border-dashed border-hairline bg-surface p-4 text-center text-xs text-ink-secondary">
                  Klik &quot;Tampilkan Custom Toast&quot; untuk melihat notifikasi muncul di posisi {position}.
                </div>
              </div>

              <div className="flex flex-col gap-1 text-left">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-ink-muted">
                    <Code className="h-3.5 w-3.5" /> Generated Usage Code
                  </span>
                  <ButtonApp
                    id="toast-play-copy-jsx"
                    variant="ghost"
                    size="sm"
                    onClick={copyCode}
                    className="h-6 min-h-6 px-2 text-[10px]"
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-600" /> : undefined}
                  >
                    {copied ? "Copied!" : "Copy JSX"}
                  </ButtonApp>
                </div>
                <pre className="overflow-x-auto rounded-md bg-zinc-950 p-3 text-[10px] font-mono leading-relaxed text-zinc-100">
                  {codeSnippet}
                </pre>
              </div>
            </div>
          </div>
        </ShowcaseCard>
      </ShowcaseGrid>
    </ModuleCard>
  );
}
