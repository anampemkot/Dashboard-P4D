import * as React from "react";
import {
  ScorecardApp,
  CardApp,
  BadgeApp,
  ButtonApp,
  TextApp,
  AdvanceFilterApp,
  DataTableApp,
  ChartApp,
  DropdownApp,
  ProgressListApp,
  useToastApp,
  useRealtimeValue,
  QuickPreset,
} from "@/packages/design-system";
import {
  RefreshCw,
  Download,
  Filter,
  Calendar,
  ShieldCheck,
  UserX,
  MapPinOff,
  TrendingUp,
} from "lucide-react";
import { CHART_COLORS } from "@/constants/chartColors";

const COLOR_KRITIS = "#f43f5e";

const KATEGORI_MASALAH = [
  { name: "WP Belum Registrasi", value: 40, fill: COLOR_KRITIS },
  { name: "Profil WP Belum Lengkap", value: 35, fill: CHART_COLORS.amber },
  { name: "OP Belum Tervalidasi", value: 25, fill: "#94a3b8" },
];

const WILAYAH_BELUM_VALID = [
  { id: "umbulharjo", label: "Umbulharjo", jumlah: 450 },
  { id: "gondokusuman", label: "Gondokusuman", jumlah: 320 },
  { id: "jetis", label: "Jetis", jumlah: 150 },
  { id: "tegalrejo", label: "Tegalrejo", jumlah: 90 },
  { id: "mergangsan", label: "Mergangsan", jumlah: 62 },
];
const WILAYAH_MAKS = 500;

// Kesehatan data per jenis pajak — dua segmen per baris (valid vs kritis).
const KESEHATAN_DATA = [
  { id: "pbb", label: "PBB-P2", valid: 70 },
  { id: "pbjt-resto", label: "PBJT Restoran", valid: 50 },
  { id: "reklame", label: "Pajak Reklame", valid: 60 },
];

const TARGET_PENERTIBAN = [
  {
    id: "adm-001",
    nama: "PT Bintang Jaya Sentosa",
    jenis: "PBB-P2",
    lokasi: "Umbulharjo",
    indikator: "Belum Registrasi",
    severity: "kritis" as const,
  },
  {
    id: "adm-002",
    nama: "Restoran Rasa Nusantara",
    jenis: "PBJT Restoran",
    lokasi: "Gondokusuman",
    indikator: "Data Tidak Lengkap",
    severity: "waspada" as const,
  },
  {
    id: "adm-003",
    nama: "Toko Elektronik Makmur",
    jenis: "Pajak Reklame",
    lokasi: "Jetis",
    indikator: "Belum Registrasi",
    severity: "kritis" as const,
  },
  {
    id: "adm-004",
    nama: "Kos Eksklusif Seturan",
    jenis: "PBJT Jasa Kos",
    lokasi: "Tegalrejo",
    indikator: "OP Belum Tervalidasi",
    severity: "waspada" as const,
  },
  {
    id: "adm-005",
    nama: "CV Sinar Terang Abadi",
    jenis: "PBB-P2",
    lokasi: "Mergangsan",
    indikator: "Data Tidak Lengkap",
    severity: "waspada" as const,
  },
];

const kepatuhanFilterFields = [
  {
    id: "kategoriMasalah",
    label: "Kategori Masalah",
    type: "select" as const,
    placeholder: "Pilih Kategori...",
    options: [
      { value: "all", label: "Semua Kategori Masalah" },
      { value: "belum_registrasi", label: "WP Belum Registrasi" },
      { value: "profil_tidak_lengkap", label: "Profil WP Belum Lengkap" },
      { value: "belum_tervalidasi", label: "OP Belum Tervalidasi" },
    ],
  },
  {
    id: "jenisPajak",
    label: "Jenis Pajak",
    type: "select" as const,
    placeholder: "Pilih Jenis Pajak...",
    options: [
      { value: "all", label: "Semua Jenis Pajak" },
      { value: "pbb_p2", label: "PBB-P2" },
      { value: "pbjt_resto", label: "PBJT Restoran" },
      { value: "reklame", label: "Pajak Reklame" },
    ],
  },
  {
    id: "wilayah",
    label: "Wilayah Kemantren",
    type: "select" as const,
    placeholder: "Semua Wilayah...",
    options: [
      { value: "all", label: "Semua Kemantren" },
      ...WILAYAH_BELUM_VALID.map((w) => ({ value: w.id, label: `Kemantren ${w.label}` })),
    ],
  },
  {
    id: "periode",
    label: "Periode Audit",
    type: "select" as const,
    placeholder: "Pilih Periode...",
    options: [
      { value: "agustus", label: "Agustus 2026 (Berjalan)" },
      { value: "juli", label: "Juli 2026" },
      { value: "q3", label: "Triwulan III 2026" },
    ],
  },
];

const quickPresets: QuickPreset[] = [
  { label: "Semua Target", values: { kategoriMasalah: "all", jenisPajak: "all" } },
  { label: "Belum Registrasi", values: { kategoriMasalah: "belum_registrasi" } },
  { label: "Profil Tidak Lengkap", values: { kategoriMasalah: "profil_tidak_lengkap" } },
  { label: "Fokus Umbulharjo", values: { wilayah: "umbulharjo" } },
];

export function AdministrativeComplianceDashboardPage() {
  const { toast } = useToastApp();
  const [filterValues, setFilterValues] = React.useState<Record<string, any>>({});

  // Jumlah WP/OP bermasalah menyusut seiring penertiban berjalan. Indeks
  // kepatuhan TIDAK di-live-kan: hasil kalkulasi periodik atas seluruh basis
  // data, bukan angka yang berubah tiap transaksi.
  const liveBelumRegistrasi = useRealtimeValue({
    initialValue: 1250,
    update: (v) => Math.max(1000, v - (Math.random() > 0.6 ? 1 : 0)),
    intervalMs: 9000,
  });
  const liveBelumTervalidasi = useRealtimeValue({
    initialValue: 840,
    update: (v) => Math.max(700, v - (Math.random() > 0.65 ? 1 : 0)),
    intervalMs: 11000,
  });
  const livePemutakhiran = useRealtimeValue({
    initialValue: 320,
    update: (v) => v + (Math.random() > 0.6 ? 1 : 0),
    intervalMs: 8000,
  });

  const handleResetFilter = () => {
    setFilterValues({});
    toast.info("Filter Kepatuhan Direset", {
      description: "Semua kriteria kategori masalah, jenis pajak, dan wilayah dikembalikan ke kondisi awal.",
    });
  };

  const wilayahItems = WILAYAH_BELUM_VALID.map((w) => ({
    id: w.id,
    label: w.label,
    value: `${w.jumlah.toLocaleString("id-ID")}`,
    segments: [{ percent: (w.jumlah / WILAYAH_MAKS) * 100, color: CHART_COLORS.blue }],
  }));

  // Dua segmen per baris — inilah alasan `segments` pada ProgressListApp
  // berupa array, bukan satu nilai persen.
  const kesehatanItems = KESEHATAN_DATA.map((k) => ({
    id: k.id,
    label: k.label,
    value: `${k.valid}% Valid`,
    segments: [
      { percent: k.valid, color: CHART_COLORS.emerald, label: "Valid" },
      { percent: 100 - k.valid, color: COLOR_KRITIS, label: "Kritis" },
    ],
  }));

  const tableColumns = [
    { accessorKey: "nama", header: "Nama WP / OP" },
    {
      accessorKey: "jenis",
      header: "Jenis Pajak",
      cell: ({ row }: any) => (
        <BadgeApp id={`badge-jenis-${row.original.id}`} variant="neutral" size="sm">
          {row.original.jenis}
        </BadgeApp>
      ),
    },
    { accessorKey: "lokasi", header: "Lokasi" },
    {
      accessorKey: "indikator",
      header: "Indikator Pelanggaran",
      cell: ({ row }: any) => (
        <BadgeApp
          id={`badge-indikator-${row.original.id}`}
          variant={row.original.severity === "kritis" ? "solidRose" : "solidAmber"}
          size="sm"
        >
          {row.original.indikator}
        </BadgeApp>
      ),
    },
    {
      id: "actions",
      header: "Aksi",
      cell: ({ row }: any) => (
        <ButtonApp
          id={`btn-himbauan-${row.original.id}`}
          variant="secondary"
          size="sm"
          rounded="lg"
          onClick={() =>
            toast.vibrant("Surat Himbauan Disiapkan", {
              description: `${row.original.nama} masuk daftar penertiban ${row.original.indikator.toLowerCase()}.`,
            })
          }
        >
          Kirim Himbauan
        </ButtonApp>
      ),
    },
  ];

  return (
    <div id="kepatuhan-administrasi-root" className="space-y-6 pb-12">
      {/* ------------------------------------------------------------- */}
      {/* HEADER PAGE                                                   */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col justify-between gap-4 border-b border-hairline-soft pb-4 md:flex-row md:items-center">
        <div>
          <div className="mb-1 flex flex-wrap items-center gap-x-3 gap-y-1.5">
            <BadgeApp id="hdr-badge-br11" variant="solidPurple" size="sm">
              BR-11 · Dashboard Kepatuhan Administrasi
            </BadgeApp>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <ShieldCheck className="h-3.5 w-3.5 text-vibrant-purple" />
              Indeks Kepatuhan & Penertiban Data
            </span>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <Calendar className="h-3.5 w-3.5 text-vibrant-purple" />
              Periode Agustus 2026
            </span>
          </div>
          <TextApp id="hdr-title-kepatuhan" variant="h2" className="tracking-tight text-ink">
            Dashboard Kepatuhan Administrasi Wajib Pajak
          </TextApp>
          <TextApp id="hdr-sub-kepatuhan" variant="body" className="text-xs text-ink-secondary">
            Monitoring Indeks Kepatuhan Data, Kategori Masalah Administrasi, & Target Penertiban
          </TextApp>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <ButtonApp
            id="btn-refresh-kepatuhan"
            variant="secondary"
            size="sm"
            rounded="lg"
            onClick={() =>
              toast.info("Audit Kepatuhan Dijalankan", {
                description: "Validasi kelengkapan profil WP dan status registrasi diperbarui.",
              })
            }
            leftIcon={<RefreshCw className="h-3.5 w-3.5" />}
          >
            Audit Data
          </ButtonApp>
          <ButtonApp
            id="btn-export-kepatuhan"
            variant="primary"
            size="sm"
            rounded="lg"
            leftIcon={<Download className="h-3.5 w-3.5" />}
            onClick={() =>
              toast.vibrant("Laporan Kepatuhan Diunduh", {
                description: "Berisi daftar target penertiban administrasi beserta indikator pelanggarannya.",
              })
            }
          >
            Cetak Laporan Kepatuhan
          </ButtonApp>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* FILTER BAR */}
      {/* ------------------------------------------------------------- */}
      <div className="flex w-full min-w-0 flex-nowrap items-center gap-2 overflow-x-auto rounded-2xl border border-hairline bg-surface px-3 py-3 shadow-xs">
        <span className="flex shrink-0 items-center gap-1.5 whitespace-nowrap text-xs font-semibold text-ink-secondary">
          <Filter className="h-4 w-4 text-vibrant-purple" />
          Filter:
        </span>

        {/* Shortcut inline utk field yang paling sering dipakai — nilainya
            dibagi dgn AdvanceFilterApp supaya tidak jadi kontrol kosmetik. */}
        <div className="w-60 shrink-0">
          <DropdownApp
            id="select-kategori-masalah"
            value={String(filterValues.kategoriMasalah ?? "all")}
            onChange={(value) => setFilterValues((prev) => ({ ...prev, kategoriMasalah: String(value) }))}
            options={[
              { label: "Semua Kategori Masalah", value: "all" },
              { label: "WP Belum Registrasi", value: "belum_registrasi" },
              { label: "Profil WP Belum Lengkap", value: "profil_tidak_lengkap" },
              { label: "OP Belum Tervalidasi", value: "belum_tervalidasi" },
            ]}
            size="sm"
            rounded="lg"
            menuPortal
          />
        </div>

        <div className="ml-auto shrink-0">
          <AdvanceFilterApp
            id="filter-kepatuhan-administrasi"
            displayMode="modal"
            showActivePills={false}
            className="w-auto"
            triggerLabel="Advance Filter Kepatuhan"
            triggerVariant="secondary"
            triggerSize="sm"
            triggerRounded="lg"
            title="Filter Kategori Masalah & Wilayah Penertiban"
            fields={kepatuhanFilterFields}
            values={filterValues}
            onChange={setFilterValues}
            quickPresets={quickPresets}
            onReset={handleResetFilter}
            onApply={() => {
              toast.vibrant("Filter Kepatuhan Diterapkan", {
                description: "Menampilkan target penertiban sesuai kriteria yang dipilih.",
              });
            }}
          />
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* SCORECARD KEPATUHAN (BR-11)                                    */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col gap-2">
        <TextApp
          id="label-indeks-kepatuhan-heading"
          variant="caption"
          weight="bold"
          className="uppercase tracking-widest text-ink-muted"
        >
          Indeks & Anomali Kepatuhan
        </TextApp>
        <div className="grid grid-cols-1 items-stretch gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <ScorecardApp
            id="card-indeks-kepatuhan"
            variant="clayYellow"
            title="Indeks Kepatuhan Data"
            // Tidak di-live-kan: hasil kalkulasi periodik atas seluruh basis
            // data, bukan angka yang berubah tiap transaksi.
            value="78%"
            unit="Skor Kepatuhan"
            description="Gabungan kelengkapan profil, status registrasi, & validasi objek"
            progress={{ value: 78, max: 100, label: "Menuju target 90%" }}
            trend={{ value: "+2,4%", label: "vs Bulan Lalu", isPositive: true, direction: "up" }}
            icon={<ShieldCheck className="h-5 w-5 text-[#5c4300] dark:text-amber-300" />}
            infoTooltip="Skor gabungan kualitas administrasi basis data wajib pajak."
            infoContent={{
              formula: "Rata-rata tertimbang kelengkapan profil, status registrasi, dan validasi objek pajak",
              period: "Kalkulasi periodik (bulanan)",
              source: "SIMPAD — Modul Audit Kepatuhan",
              lastUpdated: "Awal bulan berjalan",
            }}
            insight={{
              title: "Indeks Kepatuhan Data",
              value: "78% (Zona Amber)",
              status: "waspada",
              meta: ["Indeks", "Kualitas Administrasi", "Agustus 2026"],
              summary:
                "Satu angka yang meringkas seberapa tertib administrasi basis data wajib pajak. Berada di zona amber: belum berisiko, tapi juga belum bisa diandalkan untuk penetapan massal.",
              current: [
                "Skor 78% naik 2,4% dari bulan lalu, masih 12 poin di bawah target 90%.",
                "Penyumbang penurunan terbesar adalah WP yang belum registrasi.",
              ],
              insights: [
                "Indeks ini bergerak lambat karena menghitung seluruh basis data — perbaikan yang terasa di lapangan baru terlihat setelah beberapa bulan.",
              ],
              tacticalRecs: [
                "Kejar kategori dengan bobot terbesar lebih dulu; memperbaiki kategori kecil tidak akan menggerakkan indeks.",
              ],
              strategicRecs: [
                "Jadikan indeks ini syarat kelayakan sebelum penetapan massal dijalankan, bukan sekadar laporan bulanan.",
              ],
              glossary: [
                { term: "Zona Amber", definition: "rentang skor 70-85% — perlu perbaikan tapi belum berisiko tinggi." },
              ],
              dataNotes: ["Dihitung bulanan atas seluruh basis data, bukan sampel."],
            }}
          />

          <ScorecardApp
            id="card-wp-belum-registrasi"
            variant="alert"
            title="WP Belum Registrasi"
            value={liveBelumRegistrasi}
            live
            unit="Wajib Pajak"
            description="Teridentifikasi aktif namun belum terdaftar resmi"
            trend={{ value: "-5,2%", label: "Penurunan Temuan", isPositive: true, direction: "down" }}
            icon={<UserX className="h-5 w-5 text-rose-600" />}
            infoTooltip="Wajib pajak yang aktivitas usahanya terdeteksi tapi belum punya NPWPD."
            infoContent={{
              formula: "Jumlah subjek terdeteksi aktif tanpa NPWPD terdaftar",
              period: "Snapshot (real-time)",
              source: "SIMPAD — Rekonsiliasi OSS & Survei Lapangan",
              lastUpdated: "Baru saja",
            }}
            insight={{
              title: "WP Belum Registrasi",
              value: "1.250 Wajib Pajak",
              status: "kritis",
              meta: ["Anomali", "Registrasi", "Agustus 2026"],
              summary:
                "Subjek yang usahanya sudah berjalan tapi belum terdaftar. Ini kategori paling berat karena berarti ada penerimaan yang tidak pernah masuk hitungan sama sekali.",
              current: [
                "1.250 WP teridentifikasi belum registrasi, menyumbang 40% seluruh masalah administrasi.",
                "Konsentrasi terbesar di Umbulharjo.",
              ],
              insights: [
                "Berbeda dengan profil tidak lengkap yang bisa diperbaiki dari meja, kategori ini menuntut penjangkauan lapangan.",
              ],
              tacticalRecs: [
                "Kirim surat himbauan registrasi ke wilayah dengan temuan terbanyak sebelum menempuh penertiban.",
              ],
              strategicRecs: [
                "Sambungkan pendaftaran NPWPD dengan perizinan usaha agar registrasi terjadi otomatis di hulu.",
              ],
              glossary: [
                { term: "NPWPD", expansion: "Nomor Pokok Wajib Pajak Daerah", definition: "identitas resmi wajib pajak daerah." },
              ],
              dataNotes: ["Berasal dari rekonsiliasi data OSS dengan hasil survei lapangan."],
            }}
          />

          <ScorecardApp
            id="card-op-belum-tervalidasi"
            variant="rose"
            title="OP Belum Tervalidasi"
            value={liveBelumTervalidasi}
            live
            unit="Objek Pajak"
            description="Terdaftar namun belum diverifikasi petugas lapangan"
            trend={{ value: "-3,8%", label: "Penurunan Backlog", isPositive: true, direction: "down" }}
            icon={<MapPinOff className="h-5 w-5 text-rose-600" />}
            infoTooltip="Objek pajak yang sudah terdaftar tapi belum diverifikasi kebenarannya di lapangan."
            infoContent={{
              formula: "Jumlah NOP terdaftar tanpa catatan verifikasi lapangan",
              period: "Snapshot (real-time)",
              source: "SIMPAD — Modul Validasi Objek Pajak",
              lastUpdated: "Baru saja",
            }}
            insight={{
              title: "OP Belum Tervalidasi",
              value: "840 Objek Pajak",
              status: "waspada",
              meta: ["Anomali", "Validasi Objek", "Agustus 2026"],
              summary:
                "Objek yang tercatat di sistem tapi belum pernah dicek kebenarannya. Nilainya bisa terlalu rendah maupun terlalu tinggi — keduanya sama-sama masalah.",
              current: ["840 objek menunggu verifikasi, turun 3,8% dari periode sebelumnya."],
              insights: [
                "Backlog validasi menyusut lebih lambat dari kategori lain karena setiap objek menuntut kunjungan fisik.",
              ],
              tacticalRecs: [
                "Gabungkan jadwal validasi dengan survei pendataan di kelurahan yang sama agar satu perjalanan menyelesaikan dua pekerjaan.",
              ],
              strategicRecs: [
                "Prioritaskan validasi pada objek bernilai tinggi; objek kecil bisa diverifikasi lewat citra.",
              ],
              dataNotes: ["Snapshot real-time dari modul validasi."],
            }}
          />

          <ScorecardApp
            id="card-pemutakhiran-bulan-ini"
            variant="emerald"
            title="Pemutakhiran Bulan Ini"
            value={livePemutakhiran}
            live
            unit="Record Diperbaiki"
            description="Data yang berhasil dilengkapi & divalidasi periode ini"
            trend={{ value: "+12,5%", label: "Laju Perbaikan", isPositive: true, direction: "up" }}
            icon={<TrendingUp className="h-5 w-5 text-emerald-700 dark:text-emerald-200" />}
            infoTooltip="Jumlah record yang berhasil dilengkapi atau divalidasi bulan ini."
            infoContent={{
              formula: "Jumlah record WP/OP yang berpindah status menjadi lengkap & tervalidasi",
              period: "Bulan berjalan (real-time)",
              source: "SIMPAD — Modul Audit Kepatuhan",
              lastUpdated: "Baru saja",
            }}
            insight={{
              title: "Pemutakhiran Bulan Ini",
              value: "+320 Record",
              status: "sehat",
              meta: ["Perbaikan", "Pemutakhiran Data", "Agustus 2026"],
              summary:
                "Menghitung berapa banyak data yang berhasil dibereskan bulan ini. Ini satu-satunya angka di halaman ini yang naiknya berarti kabar baik.",
              current: ["320 record diperbaiki, laju naik 12,5% dibanding bulan sebelumnya."],
              insights: [
                "Laju perbaikan sudah melampaui laju temuan baru — bila bertahan, jumlah anomali akan menyusut dengan sendirinya.",
              ],
              tacticalRecs: [
                "Pertahankan komposisi tim verifikasi saat ini; laju perbaikan sedang berada di titik terbaiknya.",
              ],
              strategicRecs: [
                "Ukur biaya per record yang diperbaiki untuk menentukan titik henti yang ekonomis.",
              ],
              dataNotes: ["Snapshot real-time; angka bertambah seiring verifikasi diselesaikan."],
            }}
          />
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* KATEGORI + WILAYAH + KESEHATAN DATA (BR-11)                    */}
      {/* ------------------------------------------------------------- */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <CardApp
          id="card-kategori-masalah"
          className="flex flex-col border-hairline-soft p-5"
          insight={{
            title: "Kategori Masalah Administrasi",
            value: "3 Kategori",
            status: "waspada",
            meta: ["Komposisi", "Kategori Masalah", "Agustus 2026"],
            summary:
              "Memecah seluruh temuan administrasi menjadi tiga kategori. Tiap kategori menuntut jenis tindakan yang berbeda, sehingga komposisinya menentukan bentuk program penertiban.",
            current: [
              "WP belum registrasi mendominasi dengan 40%.",
              "Profil tidak lengkap 35%, OP belum tervalidasi 25%.",
            ],
            insights: [
              "Dua pertiga masalah bisa diselesaikan tanpa kunjungan lapangan — hanya kategori 'belum registrasi' yang benar-benar menuntut penjangkauan.",
            ],
            tacticalRecs: [
              "Bereskan dulu kategori yang bisa digarap dari meja untuk menurunkan indeks dengan cepat.",
            ],
            strategicRecs: [
              "Rancang program terpisah untuk tiap kategori; satu program seragam akan boros pada dua kategori dan kurang pada satu.",
            ],
            dataNotes: ["Persentase atas total temuan administrasi periode berjalan."],
          }}
        >
          <div className="mb-3">
            <TextApp id="title-kategori-masalah" variant="h3" weight="bold" className="text-ink-primary">
              Kategori Masalah Administrasi
            </TextApp>
            <TextApp id="sub-kategori-masalah" variant="caption" className="text-ink-secondary">
              Proporsi temuan menurut jenis pelanggaran administrasi.
            </TextApp>
          </div>

          <div className="flex-1">
            <ChartApp
              id="chart-kategori-masalah"
              type="pie"
              data={KATEGORI_MASALAH}
              innerRadius={60}
              outerRadius={88}
              valueFormatter={(v) => `${v}%`}
              height={260}
              showLegend
            />
          </div>
        </CardApp>

        <CardApp
          id="card-wilayah-belum-valid"
          className="flex flex-col border-hairline-soft p-5"
          insight={{
            title: "Top 5 Wilayah Belum Valid",
            value: "Umbulharjo 450 WP",
            status: "waspada",
            meta: ["Peringkat", "Sebaran Wilayah", "Agustus 2026"],
            summary:
              "Peringkat kemantren berdasarkan jumlah WP/OP yang datanya belum valid. Dipakai untuk memilih wilayah tujuan penertiban berikutnya.",
            current: ["Umbulharjo memimpin dengan 450, hampir 40% dari lima wilayah teratas."],
            insights: [
              "Beban sangat terkonsentrasi — menuntaskan dua wilayah teratas menyelesaikan lebih dari separuh masalah.",
            ],
            tacticalRecs: ["Jadwalkan penertiban berurutan dari puncak daftar, bukan disebar merata."],
            strategicRecs: [
              "Tinjau apakah konsentrasi ini berulang tiap tahun; bila ya, tempatkan petugas tetap di sana.",
            ],
            dataNotes: ["Skala bar dibandingkan terhadap batas 500 WP per wilayah."],
          }}
        >
          <div className="mb-4">
            <TextApp id="title-wilayah-belum-valid" variant="h3" weight="bold" className="text-ink-primary">
              Top 5 Wilayah Belum Valid
            </TextApp>
            <TextApp id="sub-wilayah-belum-valid" variant="caption" className="text-ink-secondary">
              Kemantren dengan temuan data tidak valid terbanyak.
            </TextApp>
          </div>

          <ProgressListApp id="list-wilayah-belum-valid" items={wilayahItems} />
        </CardApp>

        <CardApp
          id="card-kesehatan-data"
          className="flex flex-col border-hairline-soft p-5"
          insight={{
            title: "Kesehatan Data per Jenis Pajak",
            value: "PBJT Restoran terendah",
            status: "kritis",
            meta: ["Kualitas Data", "Per Sektor", "Agustus 2026"],
            summary:
              "Membagi tiap jenis pajak menjadi porsi data valid dan kritis. Menunjukkan sektor mana yang basis datanya paling tidak bisa diandalkan.",
            current: [
              "PBJT Restoran hanya 50% valid — separuh datanya bermasalah.",
              "PBB-P2 paling sehat dengan 70% valid.",
            ],
            insights: [
              "Sektor dengan perputaran usaha tercepat justru punya data paling rapuh, karena perubahan di lapangan lebih cepat daripada pemutakhiran datanya.",
            ],
            tacticalRecs: [
              "Perpendek siklus verifikasi khusus PBJT Restoran, jangan disamakan dengan PBB-P2.",
            ],
            strategicRecs: [
              "Wajibkan konfirmasi data berkala untuk sektor berperputaran tinggi sebagai syarat perpanjangan izin.",
            ],
            dataNotes: ["Porsi valid dan kritis selalu berjumlah 100% per jenis pajak."],
          }}
        >
          <div className="mb-4">
            <TextApp id="title-kesehatan-data" variant="h3" weight="bold" className="text-ink-primary">
              Kesehatan Data per Jenis Pajak
            </TextApp>
            <TextApp id="sub-kesehatan-data" variant="caption" className="text-ink-secondary">
              Komposisi data valid vs kritis per sektor pajak.
            </TextApp>
          </div>

          <ProgressListApp id="list-kesehatan-data" items={kesehatanItems} />

          <div className="mt-4 flex items-center gap-4 border-t border-hairline-soft pt-3">
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: CHART_COLORS.emerald }} />
              <TextApp id="legend-kesehatan-valid" variant="caption" className="text-[11px] text-ink-secondary">
                Valid
              </TextApp>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: COLOR_KRITIS }} />
              <TextApp id="legend-kesehatan-kritis" variant="caption" className="text-[11px] text-ink-secondary">
                Kritis
              </TextApp>
            </span>
          </div>
        </CardApp>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* DAFTAR TARGET PENERTIBAN (BR-11)                               */}
      {/* ------------------------------------------------------------- */}
      <CardApp id="card-table-target-penertiban" className="border-hairline-soft p-5">
        <DataTableApp
          id="datatable-target-penertiban"
          title="Daftar Target Penertiban Administrasi"
          description="Wajib pajak dan objek pajak yang perlu ditertibkan beserta indikator pelanggarannya."
          toolbarLayout="singleRow"
          data={TARGET_PENERTIBAN}
          columns={tableColumns}
          getRowId={(row) => row.id}
          searchPlaceholder="Cari nama WP/OP, jenis pajak, atau lokasi..."
          pageSize={5}
        />
      </CardApp>
    </div>
  );
}

export default AdministrativeComplianceDashboardPage;
