import * as React from "react";
import {
  ScorecardApp,
  CardApp,
  BadgeApp,
  ButtonApp,
  TextApp,
  DataTableApp,
  DataTableColumnHeader,
  ChartApp,
  ChartToolbarApp,
  ChartToolbarYearOption,
  MarqueeApp,
  TimelineApp,
  AlertApp,
  AlertIconApp,
  AlertTitleApp,
  AlertDescriptionApp,
  useToastApp,
  DialogApp,
  DropdownApp,
  TabsApp,
  TabsListApp,
  TabsTriggerApp,
  AdvanceFilterApp,
  FilterFieldConfig,
  useRealtimeRows,
  useRealtimeValue,
} from "@/packages/design-system";
import {
  TrendingUp,
  TrendingDown,
  Users,
  Building2,
  FileText,
  CheckCircle2,
  Clock,
  AlertTriangle,
  RefreshCw,
  Download,
  Calendar,
  Filter,
  Target,
  DollarSign,
  ArrowUp,
  ArrowDown,
  Minus,
  Activity,
  ArrowUpRight,
} from "lucide-react";
import { CHART_COLORS, CHART_TARGET_COLOR } from "@/constants/chartColors";

// ==========================================================================
// BR-01 · EXECUTIVE DASHBOARD
// Layout mengikuti hierarki executive dashboard BR-01:
//   1. KPI Row (4 metrik utama)
//   2. Kinerja Pendapatan  — komposisi target/realisasi + grafik (3 : 9)
//   3. Ticker realisasi per jenis pajak
//   4. Basis Pajak         — komposisi OP/WP + grafik pertumbuhan (3 : 9)
//   5. Early Warning (BR-12)
//   6. Pelayanan & Aktivitas Terkini
//   7. Transaksi realisasi masuk
// Seluruh kartu metrik memakai ScorecardApp (bukan CardApp) supaya trend,
// progress, komposisi, dan popover info konsisten satu komponen.
// ==========================================================================

// Setiap visualisasi turunan dari "Target PAD 2026"/"Realisasi PAD (YTD)"
// wajib memakai warna variant ScorecardApp aslinya (purple/emerald) supaya
// pembaca bisa mengorelasikan legend chart ke kartu sumbernya — sebelumnya
// chart ini memakai abu-abu generik untuk target, tidak match sama sekali.
const TARGET_COLOR = CHART_COLORS.purple; // sama dgn ScorecardApp variant="purple" (revenue-target-pad)
const REALISASI_COLOR = CHART_COLORS.emerald; // sama dgn ScorecardApp variant="emerald" (revenue-realisasi-pad)

const REVENUE_MONTHLY = [
  { label: "Jan", target: 100, realisasi: 98 },
  { label: "Feb", target: 200, realisasi: 195 },
  { label: "Mar", target: 310, realisasi: 312 },
  { label: "Apr", target: 420, realisasi: 415 },
  { label: "Mei", target: 530, realisasi: 538 },
  { label: "Jun", target: 640, realisasi: 652 },
  { label: "Jul", target: 750, realisasi: 785 },
  { label: "Agu", target: 860, realisasi: 0 },
  { label: "Sep", target: 970, realisasi: 0 },
  { label: "Okt", target: 1080, realisasi: 0 },
  { label: "Nov", target: 1160, realisasi: 0 },
  { label: "Des", target: 1250, realisasi: 0 },
];

// Perbandingan realisasi antar tahun anggaran — dipakai tab periode
// Quarter/YoY/MoM pada ChartToolbarApp di kartu "Analisis Pendapatan".
// DataKey memakai prefix huruf ("y2024"), bukan angka murni ("2024") — kunci
// numerik-murni membuat lookup nilai Recharts pada tipe chart bar gagal
// diam-diam (rectangle ter-render tapi kosong), meski area/line tetap normal.
const REVENUE_YEARLY: Record<string, string | number>[] = [
  { label: "Jan", y2024: 82, y2025: 91, y2026: 98 },
  { label: "Feb", y2024: 160, y2025: 178, y2026: 195 },
  { label: "Mar", y2024: 255, y2025: 284, y2026: 312 },
  { label: "Apr", y2024: 340, y2025: 378, y2026: 415 },
  { label: "Mei", y2024: 440, y2025: 490, y2026: 538 },
  { label: "Jun", y2024: 533, y2025: 594, y2026: 652 },
  { label: "Jul", y2024: 642, y2025: 715, y2026: 785 },
];

const REVENUE_YEAR_OPTIONS: ChartToolbarYearOption[] = [
  { value: "y2024", label: "2024", color: CHART_COLORS.cyan },
  { value: "y2025", label: "2025", color: CHART_COLORS.amber },
  { value: "y2026", label: "2026", color: CHART_COLORS.purple },
];

const REVENUE_PERIODS = [
  { id: "performance", label: "Performance" },
  { id: "quarter", label: "Quarter" },
  { id: "yoy", label: "YoY" },
  { id: "mom", label: "MoM" },
];

const TAX_BASE_GROWTH = [
  { label: "Jan", wpBadan: 120, wpPribadi: 250, wpLainnya: 30, op: 800 },
  { label: "Feb", wpBadan: 90, wpPribadi: 180, wpLainnya: 30, op: 650 },
  { label: "Mar", wpBadan: 150, wpPribadi: 350, wpLainnya: 50, op: 1100 },
  { label: "Apr", wpBadan: 110, wpPribadi: 280, wpLainnya: 30, op: 900 },
  { label: "Mei", wpBadan: 180, wpPribadi: 380, wpLainnya: 40, op: 1250 },
  { label: "Jun", wpBadan: 140, wpPribadi: 300, wpLainnya: 40, op: 980 },
  { label: "Jul", wpBadan: 165, wpPribadi: 340, wpLainnya: 45, op: 1120 },
];

/** Basis OP & WP per jenis pajak — dipakai untuk komposisi kartu kiri. */
const TAX_BASE_DETAILS = [
  { name: "PBB-P2", op: 185200, wp: 125430 },
  { name: "Reklame", op: 12900, wp: 12500 },
  { name: "PBJT Makanan & Minuman", op: 12400, wp: 5400 },
  { name: "BPHTB", op: 15200, wp: 14500 },
  { name: "PBJT Jasa Perhotelan", op: 3100, wp: 2100 },
  { name: "PBJT Jasa Parkir", op: 1800, wp: 1200 },
  { name: "Pajak Air Tanah (PAT)", op: 3500, wp: 1800 },
  { name: "PBJT Tenaga Listrik", op: 1500, wp: 1200 },
  { name: "PBJT Kesenian & Hiburan", op: 2100, wp: 500 },
  { name: "Pajak MBLB", op: 150, wp: 85 },
  { name: "Sarang Burung Walet", op: 45, wp: 25 },
];

/** Ticker realisasi vs target per jenis pajak (nilai dalam juta rupiah). */
const TAX_TICKER = [
  { name: "PBB-P2", realisasi: 15400, target: 18000 },
  { name: "PAT", realisasi: 2150, target: 2000 },
  { name: "Pajak Reklame", realisasi: 1200, target: 1500 },
  { name: "Opsen PKB", realisasi: 35000, target: 35000 },
  { name: "Opsen BBNKB", realisasi: 28400, target: 25000 },
  { name: "BPHTB", realisasi: 42100, target: 50000 },
  { name: "PBJT Jasa Perhotelan", realisasi: 8500, target: 8000 },
  { name: "PBJT Makanan & Minuman", realisasi: 12500, target: 15000 },
  { name: "PBJT Parkir", realisasi: 3200, target: 3000 },
  { name: "PBJT Tenaga Listrik", realisasi: 18000, target: 18000 },
  { name: "PBJT Kesenian & Hiburan", realisasi: 4200, target: 5000 },
];

const RECENT_TRANSACTIONS = [
  { id: "NOP-00129", wpName: "PT Hotel Grand Malioboro", jenisPajak: "PBJT Makanan & Minuman", nominal: "Rp 125.400.000", tanggal: "27 Jul 2026 18:25", status: "Lunas", badgeVariant: "success" as const },
  { id: "NOP-00130", wpName: "CV Resto Nusantara Jaya", jenisPajak: "PBJT Jasa Katering", nominal: "Rp 42.800.000", tanggal: "27 Jul 2026 17:50", status: "Diproses", badgeVariant: "warning" as const },
  { id: "NOP-00131", wpName: "Bpk. H. Ahmad Sudirman", jenisPajak: "PBB-P2 Perkotaan", nominal: "Rp 8.750.000", tanggal: "27 Jul 2026 16:15", status: "Lunas", badgeVariant: "success" as const },
  { id: "NOP-00132", wpName: "PT Sentosa Graha Properti", jenisPajak: "BPHTB Pemindahan Hak", nominal: "Rp 310.000.000", tanggal: "27 Jul 2026 15:40", status: "Verifikasi", badgeVariant: "info" as const },
  { id: "NOP-00133", wpName: "Gedung Parkir Plaza Utama", jenisPajak: "PBJT Jasa Parkir", nominal: "Rp 18.250.000", tanggal: "27 Jul 2026 14:20", status: "Lunas", badgeVariant: "success" as const },
];

const formatId = (value: number) => new Intl.NumberFormat("id-ID").format(value);
const formatRupiahM = (valueInMiliar: number) => `Rp ${valueInMiliar.toFixed(1).replace(".", ",")} M`;

// Contoh sumber data untuk useRealtimeRows — dashboard produksi akan
// mengganti generator ini dengan poll/websocket sungguhan; hook-nya sendiri
// tidak peduli dari mana datanya berasal.
const NEXT_WP_POOL = [
  "PT Batik Nusantara Jaya", "CV Kopi Malioboro", "Bpk. Slamet Riyadi", "PT Wisata Prambanan Indah",
  "Toko Bangunan Jogja Sejahtera", "Ibu Sri Wahyuni", "PT Hotel Tugu Kencana", "CV Katering Gudeg Bu Cokro",
];
const NEXT_JENIS_PAJAK_POOL = [
  "PBJT Makanan & Minuman", "PBB-P2 Perkotaan", "PBJT Jasa Perhotelan", "BPHTB Pemindahan Hak",
  "PBJT Jasa Parkir", "Pajak Reklame", "Pajak Air Tanah (PAT)",
];
const NEXT_STATUS_POOL: { status: string; badgeVariant: "success" | "warning" | "info" }[] = [
  { status: "Lunas", badgeVariant: "success" },
  { status: "Diproses", badgeVariant: "warning" },
  { status: "Verifikasi", badgeVariant: "info" },
];

function generateNextTransaction() {
  const wpName = NEXT_WP_POOL[Math.floor(Math.random() * NEXT_WP_POOL.length)];
  const jenisPajak = NEXT_JENIS_PAJAK_POOL[Math.floor(Math.random() * NEXT_JENIS_PAJAK_POOL.length)];
  const { status, badgeVariant } = NEXT_STATUS_POOL[Math.floor(Math.random() * NEXT_STATUS_POOL.length)];
  const nominal = (Math.floor(Math.random() * 280) + 5) * 100_000;
  const now = new Date();
  return {
    id: `NOP-${now.getTime().toString().slice(-6)}`,
    wpName,
    jenisPajak,
    nominal: `Rp ${formatId(nominal)}`,
    tanggal: now.toLocaleString("id-ID", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }).replace(".", ":"),
    status,
    badgeVariant,
  };
}

export default function TaxDashboardPage() {
  const { toast } = useToastApp();
  const [isSyncing, setIsSyncing] = React.useState(false);
  const [lastUpdate, setLastUpdate] = React.useState("27 Juli 2026, 18:40:12 WIB");
  const [selectedPeriod, setSelectedPeriod] = React.useState("2026");
  const [selectedTaxType, setSelectedTaxType] = React.useState("semua");
  const [detailModalOpen, setDetailModalOpen] = React.useState(false);
  const [modalTitle, setModalTitle] = React.useState("");
  const [modalData, setModalData] = React.useState<any>(null);
  const [revenueYears, setRevenueYears] = React.useState<string[]>(["y2025", "y2026"]);
  const [revenuePeriod, setRevenuePeriod] = React.useState("performance");
  const [revenueDateRange, setRevenueDateRange] = React.useState<{ startDate: Date | null; endDate: Date | null }>({
    startDate: null,
    endDate: null,
  });

  // Simulasi feed transaksi real-time — baris baru masuk dari atas tiap 7
  // detik, di-highlight sebentar, maksimum 30 baris disimpan. Reusable:
  // generator-nya bisa diganti poll/websocket sungguhan tanpa menyentuh
  // DataTableApp — lihat useRealtimeRows di design-system/hooks.
  const { rows: liveTransactions, newRowIds: newTransactionIds } = useRealtimeRows({
    initialRows: RECENT_TRANSACTIONS,
    getId: (row) => row.id,
    generate: generateNextTransaction,
    intervalMs: 7000,
    maxRows: 30,
  });

  // Value KPI numerik juga "hidup" — bukan cuma tabel transaksi. Tiap
  // scorecard dapat kenaikan kecil acak per tick; dipasangkan dengan prop
  // `live` di ScorecardApp supaya perubahannya animasi count-up + pulse,
  // bukan cuma lompat ke angka baru. Scorecard bernilai string ("Rp 1,25 T",
  // dst) sengaja tidak diikutkan — itu target/realisasi kas yang memang
  // seharusnya tidak berubah tiap beberapa detik.
  const livePelayananSelesai = useRealtimeValue({ initialValue: 18450, update: (v) => v + Math.floor(Math.random() * 5) + 1, intervalMs: 8000 });
  const livePenetapanSkpd = useRealtimeValue({ initialValue: 12340, update: (v) => v + Math.floor(Math.random() * 3), intervalMs: 9000 });
  const livePermohonanAktif = useRealtimeValue({ initialValue: 1480, update: (v) => Math.max(0, v + Math.floor(Math.random() * 7) - 3), intervalMs: 6000 });
  const liveObjekPajak = useRealtimeValue({ initialValue: 215400, update: (v) => v + Math.floor(Math.random() * 3), intervalMs: 10000 });
  const liveWajibPajak = useRealtimeValue({ initialValue: 148920, update: (v) => v + Math.floor(Math.random() * 4), intervalMs: 9000 });

  // Kartu bernilai Rupiah ("Rp X M") juga hidup — piutang berkurang (sesuai
  // tren -5,2% yang sudah ditampilkan), realisasi PAD bertambah (memang
  // deskripsinya "Harian (real-time)"). Target PAD (Rp 1,25 T) SENGAJA tidak
  // diikutkan — itu pagu tahunan tetap dari Perda, bukan angka berjalan.
  const livePiutangM = useRealtimeValue({ initialValue: 45.2, update: (v) => Math.max(38, v - Math.random() * 0.3), intervalMs: 9000 });
  const REALISASI_TARGET_M = 1250;
  const liveRealisasiM = useRealtimeValue({ initialValue: 985.4, update: (v) => Math.min(REALISASI_TARGET_M, v + Math.random() * 1.5), intervalMs: 7000 });
  const liveRealisasiPercent = (liveRealisasiM / REALISASI_TARGET_M) * 100;

  const [advanceFilterValues, setAdvanceFilterValues] = React.useState<Record<string, any>>({
    kecamatan: "danurejan",
    jenisPajak: ["pbb", "bphtb", "pbjt"],
    statusKepatuhan: "lunas",
    rentangTanggal: { from: "2026-01-01", to: "2026-07-27" },
  });

  const filterFields: FilterFieldConfig[] = [
    {
      id: "kecamatan",
      label: "Wilayah Kecamatan",
      type: "select",
      placeholder: "-- Pilih Kecamatan --",
      colSpan: 1,
      options: [
        { label: "Kec. Danurejan", value: "danurejan" },
        { label: "Kec. Gondomanan", value: "gondomanan" },
        { label: "Kec. Jetis", value: "jetis" },
        { label: "Kec. Kotagede", value: "kotagede" },
        { label: "Kec. Kraton / Malioboro", value: "kraton" },
        { label: "Kec. Umbulharjo", value: "umbulharjo" },
      ],
    },
    {
      id: "statusKepatuhan",
      label: "Status Kepatuhan WP",
      type: "select",
      colSpan: 1,
      placeholder: "-- Pilih Status --",
      options: [
        { label: "Lunas / Tervalidasi", value: "lunas" },
        { label: "Proses Verifikasi", value: "proses" },
        { label: "Menunggak / Belum Lunas", value: "menunggak" },
      ],
    },
    {
      id: "jenisPajak",
      label: "Kategori Pajak Daerah (Multi Select)",
      type: "multi-select",
      colSpan: 2,
      options: [
        { label: "PBB-P2 Perkotaan & Pedesaan", value: "pbb" },
        { label: "BPHTB Bea Perolehan Hak", value: "bphtb" },
        { label: "PBJT (Resto, Hotel, Parkir, Hiburan)", value: "pbjt" },
        { label: "Pajak Reklame", value: "reklame" },
        { label: "Pajak Air Tanah (PAT)", value: "pat" },
      ],
    },
    {
      id: "rentangTanggal",
      label: "Rentang Tanggal Penetapan & Setoran APBD",
      type: "date-range",
      colSpan: 2,
    },
  ];

  const handleOpenDetail = (title: string, data: any) => {
    setModalTitle(title);
    setModalData(data);
    setDetailModalOpen(true);
  };

  const handleSyncData = () => {
    setIsSyncing(true);
    toast.info("Sinkronisasi Data Dimulai", {
      description: "Mengambil data WP/OP dan realisasi terbaru dari SIMPATDA...",
    });

    setTimeout(() => {
      setIsSyncing(false);
      const now = new Date();
      const formatted = `${now.getDate()} Juli 2026, ${now.getHours()}:${now.getMinutes() < 10 ? "0" : ""}${now.getMinutes()}:${now.getSeconds() < 10 ? "0" : ""}${now.getSeconds()} WIB`;
      setLastUpdate(formatted);
      toast.success("Sinkronisasi Berhasil", {
        description: "Data Target, Realisasi, dan Objek Pajak telah berhasil diperbarui.",
      });
    }, 1200);
  };

  const transactionColumns = [
    {
      accessorKey: "id",
      header: ({ column }: any) => <DataTableColumnHeader column={column} title="Nomor NOP / BKU" />,
      cell: (info: any) => (
        <span className="rounded-md bg-vibrant-purple/10 px-2 py-1 font-mono text-xs font-bold text-vibrant-purple-dark">
          {info.getValue()}
        </span>
      ),
    },
    {
      accessorKey: "wpName",
      header: ({ column }: any) => <DataTableColumnHeader column={column} title="Nama Wajib Pajak" />,
      cell: (info: any) => <span className="text-xs font-semibold text-ink">{info.getValue()}</span>,
    },
    {
      accessorKey: "jenisPajak",
      header: ({ column }: any) => <DataTableColumnHeader column={column} title="Jenis Pajak Daerah" />,
      cell: (info: any) => <span className="text-xs text-ink-secondary">{info.getValue()}</span>,
    },
    {
      accessorKey: "nominal",
      header: ({ column }: any) => (
        <div className="text-right">
          <DataTableColumnHeader column={column} title="Nominal Bayar" className="justify-end" />
        </div>
      ),
      cell: (info: any) => (
        <div className="text-right">
          <span className="font-mono text-xs font-bold tabular-nums text-emerald-600 dark:text-emerald-400">
            {info.getValue()}
          </span>
        </div>
      ),
    },
    {
      accessorKey: "tanggal",
      header: ({ column }: any) => <DataTableColumnHeader column={column} title="Waktu Pembayaran" />,
      cell: (info: any) => <span className="text-[11px] text-ink-muted">{info.getValue()}</span>,
    },
    {
      accessorKey: "status",
      header: ({ column }: any) => <DataTableColumnHeader column={column} title="Status" />,
      cell: (info: any) => {
        const row = info.row.original;
        return (
          <BadgeApp id={`status-${row.id}`} variant={row.badgeVariant} size="sm">
            {row.status}
          </BadgeApp>
        );
      },
    },
  ];

  const activityItems = [
    { id: "act-1", timestamp: "18:25", title: "Setoran PBJT diverifikasi", description: "PT Hotel Grand Malioboro — Rp 125,4 Jt masuk via Bank Persepsi.", status: "success" as const, icon: <CheckCircle2 className="h-3.5 w-3.5" /> },
    { id: "act-2", timestamp: "17:50", title: "Permohonan keberatan masuk", description: "CV Resto Nusantara Jaya mengajukan keberatan nilai ketetapan.", status: "warning" as const, icon: <Clock className="h-3.5 w-3.5" /> },
    { id: "act-3", timestamp: "16:15", title: "Penetapan SKPD terbit", description: "1.200 SKPD PBB-P2 masa Agustus berhasil digenerate.", status: "info" as const, icon: <FileText className="h-3.5 w-3.5" /> },
    { id: "act-4", timestamp: "15:40", title: "Validasi BPHTB selesai", description: "PT Sentosa Graha Properti — Rp 310 Jt tervalidasi notaris.", status: "success" as const, icon: <CheckCircle2 className="h-3.5 w-3.5" /> },
    { id: "act-5", timestamp: "14:20", title: "Pemutakhiran data OP", description: "312 objek pajak Kec. Umbulharjo diperbarui hasil uji petik.", status: "default" as const, icon: <Building2 className="h-3.5 w-3.5" /> },
  ];

  return (
    <div className="mx-auto flex max-w-[1600px] flex-col gap-6 pb-20 text-left">
      {/* ================= HEADER ================= */}
      <div className="flex flex-col justify-between gap-4 border-b border-hairline-soft pb-4 md:flex-row md:items-center">
        <div>
          <div className="mb-1 flex flex-wrap items-center gap-x-3 gap-y-1.5">
            <BadgeApp id="badge-tax-dashboard" variant="solidPurple" size="sm">
              BR-01 · Executive Dashboard
            </BadgeApp>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <Calendar className="h-3.5 w-3.5 text-vibrant-purple" />
              Tahun Anggaran {selectedPeriod}
            </span>
            {/* Status sinkron ikut baris meta ini, bukan baris tombol — supaya
                grup aksi di kanan cukup 2 tombol dan tidak wrap ke baris kedua. */}
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <Activity className="h-3.5 w-3.5 animate-pulse text-emerald-500" />
              Sinkron terakhir <strong className="font-mono font-semibold text-ink-secondary">{lastUpdate}</strong>
            </span>
          </div>
          <TextApp id="tax-dashboard-title" variant="h2" className="tracking-tight text-ink">
            Dashboard Monitoring Pajak Daerah
          </TextApp>
          <TextApp id="tax-dashboard-subtitle" variant="body" className="text-xs text-ink-secondary">
            Badan Pengelolaan Keuangan dan Aset Daerah (BPKAD) Kota Yogyakarta — ikhtisar real-time
            kinerja pendapatan, basis pajak, pelayanan, dan penetapan.
          </TextApp>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <ButtonApp
            id="btn-sync-data"
            variant="secondary"
            size="sm"
            rounded="lg"
            onClick={handleSyncData}
            disabled={isSyncing}
            leftIcon={<RefreshCw className={`h-3.5 w-3.5 ${isSyncing ? "animate-spin text-vibrant-purple" : ""}`} />}
          >
            {isSyncing ? "Menyinkronkan..." : "Sync Data"}
          </ButtonApp>
          <ButtonApp
            id="btn-export-tax-report"
            variant="primary"
            size="sm"
            rounded="lg"
            leftIcon={<Download className="h-3.5 w-3.5" />}
            onClick={() =>
              toast.success("Laporan Diunduh", {
                description: "Laporan Pendapatan Pajak Daerah (PDF/Excel) sedang diunduh.",
              })
            }
          >
            Cetak Laporan
          </ButtonApp>
        </div>
      </div>

      {/* ================= FILTER BAR =================
          Satu baris scroll-x (pola toolbar design system) supaya kontrol tidak
          pernah wrap jadi baris kedua; px/py memberi ruang focus ring. */}
      <div className="flex w-full min-w-0 flex-nowrap items-center gap-2 overflow-x-auto rounded-2xl border border-hairline bg-surface px-3 py-3 shadow-xs">
        <span className="flex shrink-0 items-center gap-1.5 whitespace-nowrap text-xs font-semibold text-ink-secondary">
          <Filter className="h-4 w-4 text-vibrant-purple" />
          Filter:
        </span>

        <TabsApp
          id="filter-period-tabs"
          value={selectedPeriod}
          onValueChange={setSelectedPeriod}
          className="w-fit shrink-0"
        >
          {/* variant harus sama di list & trigger: TabsTriggerApp default-nya
              "underline", jadi kalau list-nya diberi variant segmented tapi
              trigger-nya tidak, hasilnya container abu-abu + pill putih yang
              masih membawa garis underline — persis campuran yang salah. */}
          <TabsListApp id="filter-period-tabs-list" variant="pills" size="sm" rounded="full" fitContent>
            <TabsTriggerApp id="filter-period-2026" value="2026" variant="pills" rounded="full" size="sm">TA 2026</TabsTriggerApp>
            <TabsTriggerApp id="filter-period-2025" value="2025" variant="pills" rounded="full" size="sm">TA 2025</TabsTriggerApp>
          </TabsListApp>
        </TabsApp>

        <div className="w-56 shrink-0 sm:w-64">
          <DropdownApp
            id="select-tax-category"
            size="sm"
            rounded="lg"
            value={selectedTaxType}
            onChange={(value) => setSelectedTaxType(String(value))}
            options={[
              { value: "semua", label: "Semua Jenis Pajak Daerah" },
              { value: "pbb", label: "PBB-P2 Perkotaan & Pedesaan" },
              { value: "bphtb", label: "BPHTB Bea Perolehan Hak" },
              { value: "pbjt", label: "PBJT (Resto, Hotel, Parkir, Hiburan)" },
              { value: "pat", label: "Pajak Air Tanah (PAT)" },
              { value: "reklame", label: "Pajak Reklame" },
            ]}
            menuPortal
          />
        </div>

        <div className="ml-auto shrink-0">
          <AdvanceFilterApp
            id="tax-dashboard-advance-filter"
            displayMode="modal"
            showActivePills={false}
            className="w-auto"
            title="Filter Lanjutan Dashboard Pendapatan BPKAD"
            description="Pilih kategori di kiri, lalu tentukan kriterianya di kanan"
            triggerLabel="Filter Lanjutan"
            triggerVariant="secondary"
            triggerSize="sm"
            triggerRounded="lg"
            fields={filterFields}
            values={advanceFilterValues}
            onChange={setAdvanceFilterValues}
            onApply={() =>
              toast.success("Filter Diterapkan", {
                description: "Data dashboard telah disesuaikan berdasarkan kriteria pencarian.",
              })
            }
          />
        </div>
      </div>

      {/* ================= 1. KPI ROW ================= */}
      {/* 4 scorecard tanpa chart pendamping -> perlu heading kategori sendiri,
          mengikuti pola SectionTitle referensi ZIP. Dibungkus satu wrapper
          gap-2 supaya heading-nya nempel ke grid-nya sendiri, bukan ikut
          jarak gap-6 root (yang sengaja lebar untuk pemisah antar section). */}
      <div className="flex flex-col gap-2">
        <TextApp id="label-kpi-row-heading" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted">
          Indikator Utama
        </TextApp>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <ScorecardApp
          id="kpi-pelayanan-selesai"
          title="Total Pelayanan Selesai"
          value={livePelayananSelesai}
          live
          unit="Berkas"
          description="SLA tepat waktu 99,2% — loket online & drive thru"
          icon={<CheckCircle2 className="h-5 w-5 text-emerald-600" />}
          animationDelay={0}
          trend={{ value: "+5,4%", label: "Bulan ini", isPositive: true, direction: "up" }}
          infoContent={{
            formula: "Jumlah berkas layanan berstatus selesai pada periode berjalan",
            period: "Harian (real-time)",
            source: "SIMPATDA — Modul Pelayanan",
            lastUpdated: "Baru saja",
          }}
          insight={{
            title: "Total Pelayanan Selesai",
            value: "18.450 Berkas",
            status: "sehat",
            meta: ["Indikator", "Pelayanan Pajak", "Juli 2026"],
            summary: "Total Pelayanan Selesai mengukur seluruh berkas layanan (loket online & drive thru) yang sudah tuntas diproses pada periode berjalan.",
            current: ["Realisasi terkini 18.450 berkas.", "SLA tepat waktu 99,2%.", "Rata-rata waktu proses 1,2 hari kerja."],
            insights: [
              "Loket online menyerap 77% volume (14.200 permohonan) — kanal dominan dibanding drive thru (23%, 4.250 permohonan).",
              "Kenaikan 5,4% bulan ini konsisten dengan tren adopsi loket online, bukan penambahan kapasitas loket fisik.",
              "SLA 99,2% sudah mendekati batas atas praktis — ruang perbaikan lanjutan tipis tanpa investasi kapasitas baru.",
            ],
            tacticalRecs: [
              "Pantau antrean drive thru pada jam sibuk agar porsi 23% tidak menyeret rata-rata SLA turun.",
              "Audit sampel berkas selesai loket online untuk memastikan validitas data sebelum direkap final.",
            ],
            strategicRecs: [
              "Evaluasi kapasitas server loket online untuk mengantisipasi migrasi lanjutan dari drive thru.",
              "Standarkan SOP proses supaya SLA 99,2% bisa dipertahankan saat volume berkas naik musiman.",
            ],
            glossary: [
              { term: "SLA", expansion: "Service Level Agreement", definition: "batas waktu maksimum penyelesaian layanan yang dijanjikan." },
            ],
            dataNotes: ["Snapshot per periode berjalan, pembaruan real-time harian."],
          }}
          onClick={() =>
            handleOpenDetail("Kinerja Pelayanan Pajak", {
              loketOnline: "14.200 Permohonan (77%)",
              loketDriveThru: "4.250 Permohonan (23%)",
              rataRataSla: "1,2 Hari kerja",
            })
          }
        />

        <ScorecardApp
          id="kpi-penetapan-skpd"
          title="Total Penetapan SKPD"
          value={livePenetapanSkpd}
          live
          unit="SKPD/SPTPD"
          description="Total nilai ketetapan Rp 450,2 Miliar"
          icon={<FileText className="h-5 w-5 text-vibrant-purple-dark" />}
          animationDelay={0.05}
          trend={{ value: "+1.200", label: "Jatuh tempo Agustus", isPositive: true, direction: "up" }}
          infoContent={{
            formula: "Surat Ketetapan Pajak Daerah + SPTPD terbit pada masa pajak berjalan",
            period: "Per masa pajak",
            source: "SIMPATDA — Modul Penetapan",
            lastUpdated: "5 menit lalu",
          }}
          insight={{
            title: "Total Penetapan SKPD",
            value: "12.340 SKPD/SPTPD",
            status: "sehat",
            meta: ["Indikator", "Penetapan Pajak", "Juli 2026"],
            summary: "Total Penetapan SKPD mengukur seluruh Surat Ketetapan Pajak Daerah dan SPTPD yang terbit pada masa pajak berjalan, senilai total Rp 450,2 M.",
            current: ["Realisasi terkini 12.340 SKPD/SPTPD.", "1.200 ketetapan baru jatuh tempo Agustus."],
            insights: [
              "SKPD PBB (Rp 210 M) dan SPTPD self-assessment (Rp 240,2 M) hampir seimbang — basis penetapan tidak bertumpu pada satu jenis pajak saja.",
              "45 SKPDKB (kekurangan bayar) terbit dari hasil pemeriksaan — sumber potensi tambahan penerimaan di luar penetapan reguler.",
              "1.200 ketetapan jatuh tempo Agustus adalah leading indicator beban kerja penagihan bulan depan.",
            ],
            tacticalRecs: [
              "Siapkan kapasitas tim penagihan untuk 1.200 ketetapan yang jatuh tempo Agustus.",
              "Tindak lanjuti 45 SKPDKB hasil pemeriksaan sebelum lewat masa keberatan.",
            ],
            strategicRecs: [
              "Evaluasi rasio SKPD vs SPTPD self-assessment untuk menilai efektivitas kepatuhan mandiri WP.",
              "Otomatisasi notifikasi jatuh tempo SKPD agar penagihan tidak menumpuk mendadak.",
            ],
            glossary: [
              { term: "SKPD", expansion: "Surat Ketetapan Pajak Daerah", definition: "dokumen penetapan jumlah pajak terutang." },
              { term: "SPTPD", expansion: "Surat Pemberitahuan Pajak Daerah", definition: "laporan self-assessment WP atas pajak terutang." },
              { term: "SKPDKB", expansion: "SKPD Kurang Bayar", definition: "ketetapan tambahan hasil pemeriksaan atas kekurangan setoran pajak." },
            ],
            dataNotes: ["Snapshot per masa pajak berjalan."],
          }}
          onClick={() =>
            handleOpenDetail("Rincian Penetapan Pajak 2026", {
              skpdPbb: "Rp 210.000.000.000",
              sptpdSelfAssessment: "Rp 240.200.000.000",
              pemeriksaanPajak: "45 SKPDKB Terbit",
            })
          }
        />

        <ScorecardApp
          id="kpi-permohonan-aktif"
          title="Permohonan Aktif"
          value={livePermohonanAktif}
          live
          unit="Pengajuan"
          description="42 berkas menunggu verifikasi lapangan"
          icon={<Clock className="h-5 w-5 text-amber-500" />}
          animationDelay={0.1}
          trend={{ value: "42 Verifikasi", label: "Antrean tim", isPositive: false, direction: "neutral" }}
          infoContent={{
            formula: "Permohonan keberatan, pengurangan PBB, dan koreksi NOP yang belum selesai",
            period: "Real-time",
            source: "SIMPATDA — Modul Permohonan",
            lastUpdated: "2 menit lalu",
          }}
          insight={{
            title: "Permohonan Aktif",
            value: "1.480 Pengajuan",
            status: "waspada",
            meta: ["Indikator", "Permohonan WP", "Juli 2026"],
            summary: "Permohonan Aktif mengukur seluruh permohonan keberatan, pengurangan PBB, dan koreksi NOP yang belum selesai diproses.",
            current: ["Realisasi terkini 1.480 pengajuan.", "42 berkas menunggu verifikasi lapangan (antrean tim)."],
            insights: [
              "Pengurangan PBB (820 berkas, 55%) mendominasi jenis permohonan — porsi terbesar dari total antrean.",
              "42 berkas menunggu verifikasi lapangan adalah bottleneck utama — proses ini bergantung kapasitas tim, bukan sistem.",
              "Trend netral (bukan naik/turun tajam) menandakan volume permohonan stabil, tapi kapasitas verifikasi belum bertambah mengikuti volume.",
            ],
            tacticalRecs: [
              "Prioritaskan verifikasi lapangan untuk 42 berkas yang sudah antre agar tidak melebihi SLA.",
              "Kelompokkan 250 berkas keberatan nilai berdasarkan urgensi jatuh tempo pembayaran.",
            ],
            strategicRecs: [
              "Evaluasi kapasitas tim verifikasi lapangan jika backlog berulang tiap periode.",
              "Digitalisasi sebagian verifikasi (foto/GIS) untuk mengurangi ketergantungan kunjungan fisik.",
            ],
            glossary: [
              { term: "NOP", expansion: "Nomor Objek Pajak", definition: "kode identifikasi unik setiap objek pajak PBB." },
            ],
            dataNotes: ["Snapshot real-time, pembaruan terakhir 2 menit lalu."],
          }}
          onClick={() =>
            handleOpenDetail("Status Permohonan Wajib Pajak", {
              penguranganPbb: "820 Berkas",
              pembetulanData: "410 Berkas",
              keberatanNilai: "250 Berkas",
            })
          }
        />

        <ScorecardApp
          id="kpi-total-piutang"
          title="Total Piutang"
          value={formatRupiahM(livePiutangM)}
          live
          unit="Piutang Pajak"
          description="128 WP menunggak dalam proses penagihan aktif"
          icon={<TrendingDown className="h-5 w-5 text-rose-500" />}
          animationDelay={0.15}
          trend={{ value: "-5,2%", label: "Penurunan piutang", isPositive: true, direction: "down" }}
          infoContent={{
            formula: "Akumulasi tunggakan pajak daerah yang belum tertagih s/d periode berjalan",
            period: "Bulanan",
            source: "SIMPATDA — Modul Penagihan",
            lastUpdated: "1 jam lalu",
          }}
          insight={{
            title: "Total Piutang Pajak",
            value: "Rp 45,2 M",
            status: "waspada",
            meta: ["Indikator", "Piutang Pajak", "Juli 2026"],
            summary:
              "Total Piutang Pajak mengukur seluruh tagihan pajak daerah yang sudah ditetapkan (SKPD/STPD) namun belum dilunasi wajib pajak.",
            current: ["Realisasi terkini Rp 45,2 M.", "128 WP menunggak dalam proses penagihan aktif."],
            insights: [
              "Penurunan 5,2% bulan ini didorong oleh percepatan penagihan piutang BPHTB — leading indicator perbaikan cash flow PAD 30–60 hari ke depan.",
              "Konsentrasi piutang masih didominasi WP Badan (62%), bukan WP Pribadi.",
              "Piutang macet (>5 tahun, Rp 12,4 M) sudah tidak berkontribusi pada tren bulanan — perbaikan saat ini murni dari piutang lancar.",
            ],
            tacticalRecs: [
              "Kirim Surat Teguran ke 20 WP dengan piutang terbesar minggu ini.",
              "Jadwalkan rekonsiliasi data piutang dengan Bank Persepsi.",
            ],
            strategicRecs: [
              "Evaluasi kebijakan write-off untuk piutang macet > 5 tahun (Rp 12,4 M).",
              "Integrasikan sistem penagihan dengan SIMPATDA agar notifikasi jatuh tempo otomatis.",
            ],
            glossary: [
              { term: "SKPD", expansion: "Surat Ketetapan Pajak Daerah", definition: "dokumen penetapan jumlah pajak terutang." },
              { term: "STPD", expansion: "Surat Tagihan Pajak Daerah", definition: "dokumen tagihan atas pajak yang belum/kurang dibayar." },
              { term: "Piutang Macet", definition: "piutang pajak > 5 tahun yang berpotensi diusulkan write-off setelah audit." },
            ],
            dataNotes: ["Snapshot per 27 Juli 2026.", "Angka mengikuti rekonsiliasi harian terakhir dari Bank Persepsi."],
          }}
          onClick={() =>
            handleOpenDetail("Manajemen Piutang & Penagihan", {
              piutangMacet: "Rp 12,4 M (Daluwarsa Audit)",
              piutangLancar: "Rp 32,8 M (Surat Teguran 1-3)",
              wpTunggakanTerbesar: "PT Properti Maju Bersama (Rp 2,1 M)",
            })
          }
        />
        </div>
      </div>

      {/* ================= 2. KINERJA PENDAPATAN (3 : 9) ================= */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        {/* Kiri — komposisi target & realisasi */}
        <div className="flex flex-col gap-4 lg:col-span-3">
          <ScorecardApp
            id="revenue-target-pad"
            variant="purple"
            title="Target PAD 2026"
            value="Rp 1,25 T"
            unit="APBD Murni"
            icon={<Target className="h-5 w-5" />}
            infoContent={{
              formula: "Target penerimaan pokok PAD sesuai Perda APBD Murni 2026",
              period: "Tahunan",
              source: "Perda APBD Murni 2026",
              lastUpdated: "Ditetapkan 31 Des 2025",
            }}
            insight={{
              title: "Target PAD 2026",
              value: "Rp 1,25 T",
              status: "sehat",
              meta: ["Indikator", "Target PAD", "APBD Murni 2026"],
              summary: "Target PAD 2026 adalah pagu penerimaan pokok Pendapatan Asli Daerah yang ditetapkan dalam Perda APBD Murni 2026, jadi acuan capaian Realisasi PAD di sebelahnya.",
              current: ["Target Rp 1,25 T, ditetapkan 31 Des 2025.", "Komposisi: Pajak Daerah 50%, LLPS 30%, Retribusi & Kekayaan Daerah masing-masing 10%."],
              insights: [
                "Pajak Daerah adalah tulang punggung target (50%) — realisasinya paling menentukan capaian PAD keseluruhan.",
                "LLPS (30%) adalah komponen kedua terbesar tapi paling heterogen sumbernya (jasa giro, kerja sama, dll) — paling sulit diprediksi.",
                "Realisasi berjalan (78,8% di bulan ke-7) sudah dibandingkan langsung terhadap target ini — lihat kartu Realisasi PAD untuk insight capaian.",
              ],
              tacticalRecs: [
                "Pantau realisasi per-komponen mingguan agar deviasi dari target komposisi terdeteksi dini.",
              ],
              strategicRecs: [
                "Evaluasi target komposisi untuk APBD Perubahan jika satu komponen konsisten over/under-performance.",
              ],
              glossary: [
                { term: "APBD Murni", definition: "anggaran awal tahun berjalan, sebelum revisi APBD Perubahan." },
                { term: "LLPS", expansion: "Lain-lain PAD yang Sah", definition: "komponen PAD di luar pajak/retribusi/kekayaan daerah." },
              ],
              dataNotes: ["Ditetapkan 31 Desember 2025, berlaku sepanjang TA 2026."],
            }}
            breakdown={[
              { label: "Pajak Daerah", value: "Rp 625 M", percent: 50, onClick: () => handleOpenDetail("Target Pajak Daerah", { target: "Rp 625.000.000.000", porsi: "50% dari total PAD" }) },
              { label: "Retribusi Daerah", value: "Rp 125 M", percent: 10, onClick: () => handleOpenDetail("Target Retribusi Daerah", { target: "Rp 125.000.000.000", porsi: "10% dari total PAD" }) },
              { label: "Kekayaan Daerah", value: "Rp 125 M", percent: 10, onClick: () => handleOpenDetail("Target Kekayaan Daerah Dipisahkan", { target: "Rp 125.000.000.000", porsi: "10% dari total PAD" }) },
              { label: "Lain-lain (LLPS)", value: "Rp 375 M", percent: 30, onClick: () => handleOpenDetail("Target Lain-lain PAD yang Sah", { target: "Rp 375.000.000.000", porsi: "30% dari total PAD" }) },
            ]}
            onClick={() =>
              handleOpenDetail("Detail Target Pendapatan APBD 2026", {
                targetMurni: "Rp 1.250.000.000.000",
                targetPerubahan: "Rp 1.300.000.000.000 (Rencana)",
              })
            }
          />

          <ScorecardApp
            id="revenue-realisasi-pad"
            variant="emerald"
            title="Realisasi PAD (YTD)"
            value={formatRupiahM(liveRealisasiM)}
            live
            unit={`${liveRealisasiPercent.toFixed(1).replace(".", ",")}%`}
            icon={<TrendingUp className="h-5 w-5 text-success" />}
            progress={{ value: liveRealisasiPercent, max: 100, label: "Capaian target", color: CHART_COLORS.emerald }}
            infoContent={{
              formula: "Total kas yang sudah masuk ke Kas Daerah ÷ target APBD × 100%",
              period: "Harian (real-time)",
              source: "Bank Persepsi / QRIS / Outlet BPD",
              lastUpdated: "Baru saja",
            }}
            insight={{
              title: "Realisasi PAD (Year-to-Date)",
              value: "Rp 985,4 M · 78,8%",
              status: "sehat",
              meta: ["Indikator", "Realisasi PAD", "Jan – Juli 2026"],
              summary:
                "Realisasi PAD mengukur total kas yang sudah masuk ke Kas Daerah dibanding target APBD Murni 2026 (Rp 1,25 T).",
              current: ["Realisasi terkini Rp 985,4 M (78,8%).", "Sisa target Rp 264,6 M hingga akhir tahun anggaran."],
              insights: [
                "Capaian 78,8% pada bulan ke-7 (58,3% waktu berjalan) menunjukkan realisasi berjalan lebih cepat dari linier target — indikasi sehat.",
                "Pajak Daerah menyumbang porsi terbesar (Rp 475 M, 76% dari targetnya sendiri) — konsisten dengan komposisi Target PAD di sebelah.",
                "Retribusi Daerah paling tertinggal (60%) di antara empat komponen — perlu perhatian agar tidak menyeret rata-rata di kuartal terakhir.",
              ],
              tacticalRecs: [
                "Percepat penagihan retribusi daerah yang capaiannya masih 60%, komponen paling tertinggal.",
                "Pantau pembayaran terakhir (real-time) untuk deteksi dini keterlambatan setoran Bank Persepsi.",
              ],
              strategicRecs: [
                "Evaluasi target per-komponen untuk APBD Perubahan jika tren over-performance Pajak Daerah berlanjut.",
                "Bangun dashboard proyeksi akhir tahun berbasis tren realisasi bulanan berjalan.",
              ],
              glossary: [
                { term: "PAD", expansion: "Pendapatan Asli Daerah", definition: "seluruh penerimaan daerah dari pajak, retribusi, kekayaan daerah, dan lain-lain PAD yang sah." },
                { term: "LLPS", expansion: "Lain-lain PAD yang Sah", definition: "komponen PAD di luar pajak/retribusi/kekayaan daerah, mis. jasa giro dan hasil kerja sama." },
              ],
              dataNotes: ["Snapshot real-time, pembaruan terakhir 27 Juli 2026 18:25 WIB.", "Persentase dihitung terhadap Target PAD Murni, bukan target perubahan."],
            }}
            breakdown={[
              { label: "Pajak Daerah", value: "Rp 475 M", percent: 76, color: CHART_COLORS.emerald, onClick: () => handleOpenDetail("Realisasi Pajak Daerah", { realisasi: "Rp 475.000.000.000", capaian: "76% dari target" }) },
              { label: "Retribusi Daerah", value: "Rp 75 M", percent: 60, color: CHART_COLORS.emerald, onClick: () => handleOpenDetail("Realisasi Retribusi Daerah", { realisasi: "Rp 75.000.000.000", capaian: "60% dari target" }) },
              { label: "Kekayaan Daerah", value: "Rp 87,5 M", percent: 70, color: CHART_COLORS.emerald, onClick: () => handleOpenDetail("Realisasi Kekayaan Daerah", { realisasi: "Rp 87.500.000.000", capaian: "70% dari target" }) },
              { label: "Lain-lain (LLPS)", value: "Rp 247,5 M", percent: 66, color: CHART_COLORS.emerald, onClick: () => handleOpenDetail("Realisasi Lain-lain PAD", { realisasi: "Rp 247.500.000.000", capaian: "66% dari target" }) },
            ]}
            onClick={() =>
              handleOpenDetail("Detail Realisasi Pendapatan", {
                realisasiTotal: "Rp 985.420.000.000",
                persentase: "78,83%",
                sisaTarget: "Rp 264.580.000.000",
                pembayaranTerakhir: "27 Juli 2026 18:25 WIB",
              })
            }
          />
        </div>

        {/* Kanan — grafik target vs realisasi */}
        <div className="lg:col-span-9">
          <CardApp id="card-revenue-chart" variant="clay" size="sm" className="flex h-full flex-col border border-hairline bg-surface">
            <div className="mb-4 flex flex-wrap items-start justify-between gap-3 border-b border-hairline-soft pb-3">
              <div className="min-w-0">
                <TextApp id="revenue-chart-title" variant="h3" className="text-base font-bold text-ink">
                  Analisis Pendapatan
                </TextApp>
                <TextApp id="revenue-chart-subtitle" variant="body" className="text-xs text-ink-secondary">
                  Kinerja target vs realisasi akumulatif TA 2026 — klik legenda untuk menyaring seri.
                </TextApp>
              </div>
              <BadgeApp id="badge-revenue-unit" variant="neutral" size="sm">Satuan: Miliar Rp</BadgeApp>
            </div>

            {/* Toolbar filter dalam-card: satu CardApp, beberapa cara membaca
                data pendapatan yang sama — toggle tahun pembanding, tab
                periode (Performance/Quarter/YoY/MoM), dan rentang tanggal. */}
            <ChartToolbarApp
              id="revenue-chart-toolbar"
              legend={[
                { label: "Target PAD 2026", value: "Rp 1,25 T", color: TARGET_COLOR },
                { label: "Realisasi (YTD)", value: "Rp 985,4 M", color: REALISASI_COLOR },
              ]}
              years={revenuePeriod !== "performance" ? REVENUE_YEAR_OPTIONS : undefined}
              selectedYears={revenueYears}
              onYearsChange={setRevenueYears}
              periods={REVENUE_PERIODS}
              selectedPeriod={revenuePeriod}
              onPeriodChange={setRevenuePeriod}
              dateRange={revenueDateRange}
              onDateRangeChange={setRevenueDateRange}
              className="mb-4"
            />

            {/* flex-1 + min-h-0 + height="100%": kartu ini h-full mengikuti
                tinggi kolom kiri (2 scorecard bertumpuk). Dengan tinggi chart
                yang dipatok angka tetap, sisa ruang kartu jadi kosong — chart
                harus ikut memanjang mengisi kartunya. */}
            <div className="min-h-[300px] min-w-0 flex-1">
              {revenuePeriod === "performance" ? (
                <ChartApp
                  id="revenue-performance-chart"
                  // `combo`: Target akumulatif adalah garis acuan (dashed),
                  // realisasi adalah bar. Keduanya Rupiah sehingga berbagi
                  // sumbu kiri — ChartApp kini hanya memasang sumbu kanan
                  // bila ada seri yang memintanya.
                  type="combo"
                  height="100%"
                  data={REVENUE_MONTHLY}
                  xKey="label"
                  series={[
                    { key: "realisasi", label: "Realisasi Penerimaan", color: REALISASI_COLOR, chartType: "bar" },
                    { key: "target", label: "Target Akumulatif", color: TARGET_COLOR, chartType: "line", strokeDasharray: "5 4" },
                  ]}
                  showGrid
                  showLegend
                  showTooltip
                />
              ) : (
                <ChartApp
                  id="revenue-comparison-chart"
                  type={revenuePeriod === "yoy" ? "line" : "bar"}
                  height="100%"
                  data={REVENUE_YEARLY}
                  xKey="label"
                  series={REVENUE_YEAR_OPTIONS.filter((y) => revenueYears.includes(y.value)).map((y) => ({
                    key: y.value,
                    label: y.label,
                    color: y.color,
                  }))}
                  showGrid
                  showLegend
                  showTooltip
                />
              )}
            </div>
          </CardApp>
        </div>
      </div>

      {/* ================= 3. TICKER REALISASI ================= */}
      <div className="relative overflow-hidden rounded-2xl border border-hairline bg-inverse py-2.5">
        <MarqueeApp id="tax-realisasi-ticker" duration={60} pauseOnHover>
          {TAX_TICKER.map((item, index) => {
            const below = item.realisasi < item.target;
            const above = item.realisasi > item.target;
            return (
              <div key={`${item.name}-${index}`} className="mx-6 flex shrink-0 items-center gap-2.5">
                <span className="text-xs font-semibold text-ink-on-inverse-soft">{item.name}</span>
                <span
                  className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 font-mono text-xs font-bold ${
                    below
                      ? "border-rose-400/40 bg-rose-400/15 text-rose-400"
                      : "border-emerald-400/40 bg-emerald-400/15 text-emerald-400"
                  }`}
                >
                  Rp {formatId(item.realisasi)} Jt
                  {below && <ArrowDown className="h-3 w-3" />}
                  {above && <ArrowUp className="h-3 w-3" />}
                  {!below && !above && <Minus className="h-3 w-3" />}
                </span>
              </div>
            );
          })}
        </MarqueeApp>
      </div>

      {/* ================= 4. BASIS PAJAK (3 : 9) ================= */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        <div className="flex flex-col gap-4 lg:col-span-3">
          <ScorecardApp
            id="taxbase-objek-pajak"
            variant="clayPurple"
            title="Jumlah Objek Pajak"
            value={liveObjekPajak}
            live
            unit="OP Terdata"
            icon={<Building2 className="h-5 w-5" />}
            trend={{ value: "+3,1%", label: "Pemutakhiran ZNT", isPositive: true, direction: "up" }}
            infoContent={{
              formula: "Total unit tanah, bangunan, atau lokasi usaha terdaftar sebagai objek pajak",
              period: "Real-time",
              source: "SIMPATDA + GIS Spasial",
              lastUpdated: "10 menit lalu",
            }}
            insight={{
              title: "Jumlah Objek Pajak",
              value: "215.400 OP",
              status: "sehat",
              meta: ["Indikator", "Basis Pajak", "Juli 2026"],
              summary: "Jumlah Objek Pajak mengukur total unit tanah, bangunan, atau lokasi usaha yang terdaftar sebagai objek pajak — basis dasar seluruh penetapan PBB dan pajak daerah lainnya.",
              current: ["Realisasi terkini 215.400 OP.", "PBB-P2 mendominasi dengan 185.200 OP (86% dari total)."],
              insights: [
                "Kenaikan 3,1% didorong pemutakhiran ZNT (Zona Nilai Tanah), bukan penambahan objek baru murni — perlu dibedakan dari pertumbuhan organik.",
                "Sembilan jenis objek pajak di luar PBB-P2 (Reklame, PBJT, BPHTB, dst) bersama-sama hanya 14% dari total OP, tapi mencerminkan diversifikasi ekonomi lokal.",
                "Pertumbuhan basis OP adalah leading indicator untuk potensi Jumlah Wajib Pajak — biasanya bergerak paralel dengan jeda 1-2 bulan.",
              ],
              tacticalRecs: [
                "Verifikasi lapangan untuk OP hasil pemutakhiran ZNT terbaru sebelum dipakai dasar penetapan.",
                "Audit silang OP dengan data GIS Spasial untuk objek dengan status tidak terverifikasi.",
              ],
              strategicRecs: [
                "Integrasikan pemutakhiran ZNT otomatis dengan siklus penetapan SKPD tahunan.",
                "Perluas cakupan pendataan objek non-PBB (Reklame, PBJT) yang porsinya masih kecil.",
              ],
              glossary: [
                { term: "OP", expansion: "Objek Pajak", definition: "unit tanah, bangunan, atau lokasi usaha yang jadi dasar pengenaan pajak." },
                { term: "ZNT", expansion: "Zona Nilai Tanah", definition: "klasifikasi nilai tanah per zona, dasar perhitungan NJOP PBB." },
              ],
              dataNotes: ["Snapshot real-time, pembaruan terakhir 10 menit lalu."],
            }}
            breakdownMaxHeight={168}
            breakdown={TAX_BASE_DETAILS.map((tax) => ({
              id: `op-${tax.name}`,
              label: tax.name,
              value: formatId(tax.op),
            }))}
            onClick={() =>
              handleOpenDetail("Data Objek Pajak Daerah", {
                opPbb: "185.200 OP",
                opResto: "12.400 OP",
                opHotel: "3.100 OP",
                opParkir: "1.800 OP",
                opReklame: "12.900 OP",
              })
            }
          />

          <ScorecardApp
            id="taxbase-wajib-pajak"
            variant="clayBlue"
            title="Jumlah Wajib Pajak"
            value={liveWajibPajak}
            live
            unit="WP Terdaftar"
            icon={<Users className="h-5 w-5" />}
            trend={{ value: "+2.450 WP", label: "Bulan ini", isPositive: true, direction: "up" }}
            infoContent={{
              formula: "Seluruh badan usaha & perseorangan terdaftar sebagai Wajib Pajak Daerah",
              period: "Real-time",
              source: "SIMPATDA — Modul Pendaftaran",
              lastUpdated: "10 menit lalu",
            }}
            insight={{
              title: "Jumlah Wajib Pajak",
              value: "148.920 WP",
              status: "sehat",
              meta: ["Indikator", "Basis Pajak", "Juli 2026"],
              summary: "Jumlah Wajib Pajak mengukur seluruh badan usaha dan perseorangan yang terdaftar sebagai Wajib Pajak Daerah — basis populasi untuk seluruh target penerimaan pajak.",
              current: ["Realisasi terkini 148.920 WP.", "42.150 WP Badan Usaha, 106.770 WP Perorangan.", "8.420 pendaftaran baru sepanjang 2026."],
              insights: [
                "Kenaikan +2.450 WP bulan ini konsisten dengan tren pendaftaran baru 2026 (8.420 sejak Januari) — pertumbuhan organik, bukan lonjakan satu kali.",
                "Rasio WP Perorangan : Badan Usaha sekitar 2,5:1 — basis pajak masih didominasi individu, meski WP Badan biasanya berkontribusi nominal lebih besar per WP.",
                "Pertumbuhan WP biasanya mengikuti pertumbuhan Objek Pajak dengan jeda 1-2 bulan — konsisten dengan kenaikan 3,1% OP di kartu sebelah.",
              ],
              tacticalRecs: [
                "Validasi 8.420 pendaftaran baru 2026 untuk memastikan data NPWPD lengkap sebelum masuk siklus penetapan.",
                "Kirim pengingat kepatuhan ke WP Badan Usaha baru yang belum melapor SPTPD pertama.",
              ],
              strategicRecs: [
                "Segmentasi kampanye edukasi pajak berdasarkan rasio WP Badan vs Perorangan per kecamatan.",
                "Integrasikan pendaftaran WP baru dengan basis Objek Pajak (GIS Spasial) untuk deteksi WP belum terdaftar.",
              ],
              glossary: [
                { term: "WP", expansion: "Wajib Pajak", definition: "orang pribadi atau badan yang wajib membayar pajak sesuai ketentuan." },
                { term: "NPWPD", expansion: "Nomor Pokok Wajib Pajak Daerah", definition: "identitas resmi WP dalam administrasi pajak daerah." },
              ],
              dataNotes: ["Snapshot real-time, pembaruan terakhir 10 menit lalu."],
            }}
            breakdownMaxHeight={168}
            breakdown={TAX_BASE_DETAILS.map((tax) => ({
              id: `wp-${tax.name}`,
              label: tax.name,
              value: formatId(tax.wp),
            }))}
            onClick={() =>
              handleOpenDetail("Rincian Basis Wajib Pajak", {
                wpBadan: "42.150 WP",
                wpPerorangan: "106.770 WP",
                pendaftaranBaru2026: "8.420 WP",
              })
            }
          />
        </div>

        <div className="lg:col-span-9">
          <CardApp id="card-taxbase-chart" variant="clay" size="sm" className="flex h-full flex-col border border-hairline bg-surface">
            <div className="mb-4 flex flex-wrap items-start justify-between gap-3 border-b border-hairline-soft pb-3">
              <div className="min-w-0">
                <TextApp id="taxbase-chart-title" variant="h3" className="text-base font-bold text-ink">
                  Pertumbuhan Basis Pajak
                </TextApp>
                <TextApp id="taxbase-chart-subtitle" variant="body" className="text-xs text-ink-secondary">
                  Penambahan Objek Pajak & Wajib Pajak baru per bulan — WP dipecah per jenis badan.
                </TextApp>
              </div>
              <BadgeApp id="badge-taxbase-unit" variant="neutral" size="sm">Satuan: Entitas</BadgeApp>
            </div>

            <div className="min-h-[300px] min-w-0 flex-1">
              <ChartApp
                id="taxbase-growth-chart"
                // `combo`: penambahan WP dipecah per jenis badan sebagai bar
                // bertumpuk, penambahan OP sebagai garis di atasnya supaya dua
                // pertumbuhan itu bisa dibaca berdampingan. Sama-sama satuan
                // "jumlah entitas" jadi berbagi sumbu kiri.
                type="combo"
                height="100%"
                data={TAX_BASE_GROWTH}
                xKey="label"
                series={[
                  { key: "wpBadan", label: "WP Badan Usaha", color: CHART_COLORS.blue, chartType: "bar", stackId: "wp" },
                  { key: "wpPribadi", label: "WP Orang Pribadi", color: CHART_COLORS.cyan, chartType: "bar", stackId: "wp" },
                  { key: "wpLainnya", label: "WP Instansi/Lainnya", color: CHART_COLORS.emerald, chartType: "bar", stackId: "wp" },
                  { key: "op", label: "Objek Pajak", color: CHART_COLORS.purple, chartType: "line" },
                ]}
                showGrid
                showLegend
                showTooltip
              />
            </div>
          </CardApp>
        </div>
      </div>

      {/* ================= 5. EARLY WARNING (BR-12) ================= */}
      <CardApp id="card-early-warning" variant="clay" size="sm" className="border border-hairline bg-surface">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-hairline-soft pb-3">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 shrink-0 text-amber-500" />
            <TextApp id="early-warning-title" variant="h3" className="text-base font-bold text-ink">
              Early Warning
            </TextApp>
            <BadgeApp id="badge-early-warning" variant="warning" size="sm">BR-12</BadgeApp>
          </div>
          <ButtonApp
            id="btn-early-warning-detail"
            variant="ghost"
            size="sm"
            rightIcon={<ArrowUpRight className="h-3.5 w-3.5" />}
            onClick={() =>
              handleOpenDetail("Early Warning System (BR-12)", {
                potensiPelanggaranSla: "14 layanan",
                anomaliDataGanda: "2,4% di Kec. Umbulharjo",
                piutangJatuhTempo: "38 WP dalam 7 hari",
              })
            }
          >
            Lihat semua
          </ButtonApp>
        </div>

        <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
          <AlertApp id="alert-sla" variant="warning" className="items-start">
            <AlertIconApp id="alert-sla-icon">
              <Clock className="h-5 w-5 shrink-0 text-amber-500" />
            </AlertIconApp>
            <div className="min-w-0 flex-1 text-left">
              <AlertTitleApp id="alert-sla-title">Potensi Pelanggaran SLA</AlertTitleApp>
              <AlertDescriptionApp id="alert-sla-desc" className="mt-0.5">
                14 layanan berpotensi melebihi batas SLA hari ini.
              </AlertDescriptionApp>
            </div>
          </AlertApp>

          <AlertApp id="alert-anomali" variant="warning" className="items-start">
            <AlertIconApp id="alert-anomali-icon">
              <AlertTriangle className="h-5 w-5 shrink-0 text-amber-500" />
            </AlertIconApp>
            <div className="min-w-0 flex-1 text-left">
              <AlertTitleApp id="alert-anomali-title">Anomali Data Objek Pajak</AlertTitleApp>
              <AlertDescriptionApp id="alert-anomali-desc" className="mt-0.5">
                Data ganda OP meningkat 2,4% di Kec. Umbulharjo.
              </AlertDescriptionApp>
            </div>
          </AlertApp>

          <AlertApp id="alert-piutang" variant="error" className="items-start">
            <AlertIconApp id="alert-piutang-icon">
              <TrendingDown className="h-5 w-5 shrink-0 text-error" />
            </AlertIconApp>
            <div className="min-w-0 flex-1 text-left">
              <AlertTitleApp id="alert-piutang-title">Piutang Jatuh Tempo</AlertTitleApp>
              <AlertDescriptionApp id="alert-piutang-desc" className="mt-0.5">
                38 WP memasuki jatuh tempo penagihan dalam 7 hari.
              </AlertDescriptionApp>
            </div>
          </AlertApp>
        </div>
      </CardApp>

      {/* ================= 6. PELAYANAN & AKTIVITAS (2 : 1) ================= */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <CardApp id="card-service-chart" variant="clay" size="sm" className="flex h-full flex-col border border-hairline bg-surface">
            <div className="mb-4 flex flex-wrap items-start justify-between gap-3 border-b border-hairline-soft pb-3">
              <div className="min-w-0">
                <TextApp id="service-chart-title" variant="h3" className="text-base font-bold text-ink">
                  Tren Realisasi vs Target Bulanan
                </TextApp>
                <TextApp id="service-chart-subtitle" variant="body" className="text-xs text-ink-secondary">
                  Laju penerimaan kas daerah dibanding kurva target akumulatif APBD.
                </TextApp>
              </div>
              <BadgeApp id="badge-service-unit" variant="neutral" size="sm">Miliar Rp</BadgeApp>
            </div>

            <div className="min-h-[260px] min-w-0 flex-1">
              <ChartApp
                id="service-trend-chart"
                type="line"
                height="100%"
                data={REVENUE_MONTHLY}
                xKey="label"
                series={[
                  { key: "target", label: "Target", color: CHART_TARGET_COLOR, strokeDasharray: "4 4" },
                  { key: "realisasi", label: "Realisasi", color: CHART_COLORS.emerald },
                ]}
                showGrid
                showLegend
                showTooltip
              />
            </div>
          </CardApp>
        </div>

        <div className="lg:col-span-1">
          <CardApp id="card-activity" variant="clay" size="sm" className="flex h-full flex-col border border-hairline bg-surface">
            <div className="mb-4 flex items-center justify-between gap-2 border-b border-hairline-soft pb-3">
              <TextApp id="activity-title" variant="h3" className="text-base font-bold text-ink">
                Aktivitas Terkini
              </TextApp>
              <BadgeApp id="badge-activity-live" variant="success" size="sm">Live</BadgeApp>
            </div>

            <TimelineApp
              id="dashboard-activity-timeline"
              items={activityItems}
              orientation="vertical"
              alignment="left"
              indicator="icon"
              size="sm"
            />
          </CardApp>
        </div>
      </div>

      {/* ================= 7. TRANSAKSI REALISASI ================= */}
      <CardApp id="card-recent-transactions" variant="clay" size="sm" className="border border-hairline bg-surface">
        <DataTableApp
          id="data-table-pajak"
          title="Transaksi Realisasi Pajak Masuk"
          description="Setoran pembayaran terverifikasi dari Bank Persepsi / QRIS / Outlet BPD — baris baru masuk otomatis dari atas."
          columns={transactionColumns}
          data={liveTransactions}
          newRowIds={newTransactionIds}
          pageSize={5}
          enableSearch
          enablePagination
          enableRowSelection={false}
          toolbarLayout="singleRow"
          getRowId={(row) => row.id}
          rightHeaderAction={
            <div className="flex items-center gap-2">
              <BadgeApp id="badge-transactions-live" variant="success" size="sm" className="gap-1">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-current" />
                Live
              </BadgeApp>
              <ButtonApp
                id="btn-export-transactions"
                variant="secondary"
                size="sm"
                leftIcon={<Download className="h-3.5 w-3.5" />}
                onClick={() =>
                  toast.success("Ekspor Dimulai", {
                    description: "Data transaksi realisasi sedang diekspor ke Excel.",
                  })
                }
              >
                Export
              </ButtonApp>
            </div>
          }
        />
      </CardApp>

      {/* ================= DIALOG DETAIL ================= */}
      <DialogApp
        id="modal-tax-detail"
        isOpen={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        title={modalTitle}
        description="Rincian informasi audit metrik pendapatan daerah"
      >
        <div className="space-y-4 py-2 text-xs">
          {modalData && (
            <div className="space-y-2 rounded-2xl border border-hairline bg-surface-soft p-4">
              {Object.entries(modalData).map(([key, value]: [string, any]) => (
                <div
                  key={key}
                  className="flex flex-col justify-between border-b border-hairline-soft/60 py-1 last:border-none sm:flex-row sm:items-center"
                >
                  <span className="font-semibold capitalize text-ink-secondary">
                    {key.replace(/([A-Z])/g, " $1")}:
                  </span>
                  <span className="font-mono font-bold text-ink">
                    {Array.isArray(value) ? value.join(", ") : String(value)}
                  </span>
                </div>
              ))}
            </div>
          )}

          <div className="flex justify-end pt-2">
            <ButtonApp
              id="btn-close-modal-detail"
              variant="primary"
              size="sm"
              onClick={() => setDetailModalOpen(false)}
            >
              Tutup Rincian
            </ButtonApp>
          </div>
        </div>
      </DialogApp>
    </div>
  );
}
