import * as React from "react";
import {
  ScorecardApp,
  CardApp,
  BadgeApp,
  ButtonApp,
  TextApp,
  AdvanceFilterApp,
  DataTableApp,
  ChartApp,
  DropdownApp,
  ProgressListApp,
  AvatarApp,
  useToastApp,
  useRealtimeValue,
  useRealtimeRows,
  QuickPreset,
} from "@/packages/design-system";
import {
  RefreshCw,
  Download,
  Filter,
  Calendar,
  FileText,
  AlertTriangle,
  RotateCw,
  CheckCircle2,
  Inbox,
} from "lucide-react";
import { CHART_COLORS } from "@/constants/chartColors";

const COLOR_BARU = "#f43f5e";

// Distribusi status berkas — nilai persis mengikuti acuan prototype.
const STATUS_BERKAS = [
  { name: "Selesai", value: 40, fill: CHART_COLORS.emerald },
  { name: "Diproses", value: 50, fill: CHART_COLORS.blue },
  { name: "Baru", value: 10, fill: COLOR_BARU },
];

const KOMPOSISI_LAYANAN = [
  { id: "mutasi", label: "Mutasi", persen: 35 },
  { id: "pembetulan", label: "Pembetulan", persen: 25 },
  { id: "pengurangan", label: "Pengurangan", persen: 20 },
  { id: "keberatan", label: "Keberatan", persen: 15 },
  { id: "pembatalan", label: "Pembatalan", persen: 5 },
];

// Ambang beban di atas mana seorang petugas dianggap kelebihan muatan.
const AMBANG_OVERLOAD = 90;

const BEBAN_PETUGAS = [
  { id: "budi", nama: "Budi Santoso", beban: 100 },
  { id: "ani", nama: "Ani Wijaya", beban: 85 },
  { id: "dian", nama: "Dian Sastro", beban: 45 },
  { id: "reza", nama: "Reza Rahadian", beban: 30 },
];

interface PermohonanRow {
  id: string;
  pemohon: string;
  jenis: string;
  tanggal: string;
  status: "Baru" | "Diproses";
  petugas: string;
}

const ANTREAN_AWAL: PermohonanRow[] = [
  { id: "TKT-2608-001", pemohon: "PT Maju Bersama Sentosa", jenis: "Mutasi", tanggal: "01 Agu 2026", status: "Baru", petugas: "-" },
  { id: "TKT-2608-002", pemohon: "Ahmad Sobari", jenis: "Pembetulan", tanggal: "02 Agu 2026", status: "Diproses", petugas: "Budi Santoso" },
  { id: "TKT-2608-003", pemohon: "CV Sumber Rejeki", jenis: "Pengurangan", tanggal: "03 Agu 2026", status: "Diproses", petugas: "Ani Wijaya" },
  { id: "TKT-2608-004", pemohon: "Joko Tingkir", jenis: "Mutasi", tanggal: "04 Agu 2026", status: "Diproses", petugas: "Dian Sastro" },
  { id: "TKT-2608-005", pemohon: "Hotel Puri Kencana", jenis: "Keberatan", tanggal: "04 Agu 2026", status: "Baru", petugas: "-" },
];

const NAMA_POOL = [
  "PT Karya Abadi Nusantara",
  "Restoran Bumbu Desa",
  "Siti Aminah",
  "CV Tirta Mandiri",
  "Toko Emas Kencana",
  "Bengkel Jaya Motor",
];
const JENIS_POOL = ["Mutasi", "Pembetulan", "Pengurangan", "Keberatan", "Pembatalan"];

const permohonanFilterFields = [
  {
    id: "jenisPermohonan",
    label: "Jenis Permohonan",
    type: "select" as const,
    placeholder: "Pilih Jenis...",
    options: [
      { value: "all", label: "Semua Jenis Permohonan" },
      ...JENIS_POOL.map((j) => ({ value: j.toLowerCase(), label: j })),
    ],
  },
  {
    id: "statusBerkas",
    label: "Status Berkas",
    type: "select" as const,
    placeholder: "Semua Status...",
    options: [
      { value: "all", label: "Semua Status Berkas" },
      { value: "baru", label: "Baru (Menunggu)" },
      { value: "diproses", label: "Sedang Diproses" },
      { value: "selesai", label: "Selesai / Ditolak" },
    ],
  },
  {
    id: "petugas",
    label: "Petugas Penanggung Jawab",
    type: "select" as const,
    placeholder: "Semua Petugas...",
    options: [
      { value: "all", label: "Semua Petugas" },
      ...BEBAN_PETUGAS.map((p) => ({ value: p.id, label: p.nama })),
    ],
  },
  {
    id: "periode",
    label: "Periode Masuk",
    type: "select" as const,
    placeholder: "Pilih Periode...",
    options: [
      { value: "agustus", label: "Agustus 2026 (Berjalan)" },
      { value: "juli", label: "Juli 2026" },
      { value: "q3", label: "Triwulan III 2026" },
    ],
  },
];

const quickPresets: QuickPreset[] = [
  { label: "Semua Permohonan", values: { jenisPermohonan: "all", statusBerkas: "all" } },
  { label: "Belum Ditangani", values: { statusBerkas: "baru" } },
  { label: "Sedang Diproses", values: { statusBerkas: "diproses" } },
  { label: "Beban Budi Santoso", values: { petugas: "budi" } },
];

export function ApplicationMonitoringDashboardPage() {
  const { toast } = useToastApp();
  const [filterValues, setFilterValues] = React.useState<Record<string, any>>({});

  // Semua angka antrean bergerak sepanjang jam layanan, jadi keempatnya live.
  const liveTotalAntrean = useRealtimeValue({
    initialValue: 450,
    update: (v) => v + (Math.random() > 0.5 ? 1 : 0),
    intervalMs: 7000,
  });
  const liveBerkasBaru = useRealtimeValue({
    initialValue: 45,
    update: (v) => Math.max(20, v + (Math.random() > 0.5 ? 1 : -1)),
    intervalMs: 6000,
  });
  const liveDiproses = useRealtimeValue({
    initialValue: 300,
    update: (v) => Math.max(250, v + (Math.random() > 0.5 ? 1 : -1)),
    intervalMs: 9000,
  });
  const liveSelesai = useRealtimeValue({
    initialValue: 105,
    update: (v) => v + (Math.random() > 0.6 ? 1 : 0),
    intervalMs: 10000,
  });

  // Antrean permohonan adalah kasus paling wajar untuk baris realtime —
  // berkas baru memang masuk terus dan muncul dari atas tabel.
  const { rows: antreanRows, newRowIds } = useRealtimeRows<PermohonanRow>({
    initialRows: ANTREAN_AWAL,
    getId: (row) => row.id,
    intervalMs: 12000,
    maxRows: 12,
    generate: () => {
      const seq = Math.floor(Math.random() * 900) + 100;
      return {
        id: `TKT-2608-${seq}`,
        pemohon: NAMA_POOL[Math.floor(Math.random() * NAMA_POOL.length)],
        jenis: JENIS_POOL[Math.floor(Math.random() * JENIS_POOL.length)],
        tanggal: "Hari ini",
        status: "Baru" as const,
        petugas: "-",
      };
    },
  });

  const handleResetFilter = () => {
    setFilterValues({});
    toast.info("Filter Permohonan Direset", {
      description: "Semua kriteria jenis, status berkas, dan petugas dikembalikan ke kondisi awal.",
    });
  };

  const komposisiItems = KOMPOSISI_LAYANAN.map((k) => ({
    id: k.id,
    label: k.label,
    value: `${k.persen}%`,
    segments: [{ percent: k.persen, color: CHART_COLORS.purple }],
  }));

  const bebanItems = BEBAN_PETUGAS.map((p) => {
    const overload = p.beban >= AMBANG_OVERLOAD;
    return {
      id: p.id,
      label: p.nama,
      secondaryLabel: "Petugas Pelayanan",
      leading: <AvatarApp id={`avatar-${p.id}`} name={p.nama} size="sm" />,
      value: `${p.beban}%`,
      badge: overload ? (
        <BadgeApp id={`badge-overload-${p.id}`} variant="solidRose" size="sm">
          OVERLOAD
        </BadgeApp>
      ) : undefined,
      segments: [
        {
          percent: p.beban,
          color: overload ? COLOR_BARU : p.beban >= 70 ? CHART_COLORS.amber : CHART_COLORS.blue,
        },
      ],
    };
  });

  const tableColumns = [
    {
      accessorKey: "id",
      header: "No. Tiket",
      cell: ({ row }: any) => <span className="font-mono text-xs text-ink-muted">{row.original.id}</span>,
    },
    { accessorKey: "pemohon", header: "Nama Pemohon" },
    {
      accessorKey: "jenis",
      header: "Jenis Permohonan",
      cell: ({ row }: any) => (
        <BadgeApp id={`badge-jenis-${row.original.id}`} variant="neutral" size="sm">
          {row.original.jenis}
        </BadgeApp>
      ),
    },
    { accessorKey: "tanggal", header: "Tanggal Masuk" },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }: any) => (
        <BadgeApp
          id={`badge-status-${row.original.id}`}
          variant={row.original.status === "Baru" ? "solidRose" : "blue"}
          size="sm"
        >
          {row.original.status}
        </BadgeApp>
      ),
    },
    {
      accessorKey: "petugas",
      header: "Petugas",
      cell: ({ row }: any) =>
        row.original.petugas === "-" ? (
          <span className="text-xs text-ink-muted">Belum ditugaskan</span>
        ) : (
          <span className="text-xs text-ink-secondary">{row.original.petugas}</span>
        ),
    },
  ];

  return (
    <div id="permohonan-dashboard-root" className="space-y-6 pb-12">
      {/* ------------------------------------------------------------- */}
      {/* HEADER PAGE                                                   */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col justify-between gap-4 border-b border-hairline-soft pb-4 md:flex-row md:items-center">
        <div>
          <div className="mb-1 flex flex-wrap items-center gap-x-3 gap-y-1.5">
            <BadgeApp id="hdr-badge-br09" variant="solidPurple" size="sm">
              BR-09 · Dashboard Monitoring Permohonan
            </BadgeApp>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <Inbox className="h-3.5 w-3.5 text-vibrant-purple" />
              Antrean & Progres Berkas Layanan
            </span>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <Calendar className="h-3.5 w-3.5 text-vibrant-purple" />
              Periode Agustus 2026
            </span>
          </div>
          <TextApp id="hdr-title-permohonan" variant="h2" className="tracking-tight text-ink">
            Dashboard Monitoring Permohonan Wajib Pajak
          </TextApp>
          <TextApp id="hdr-sub-permohonan" variant="body" className="text-xs text-ink-secondary">
            Monitoring Antrean Berkas, Komposisi Jenis Layanan, & Beban Kerja Petugas Aktif
          </TextApp>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <ButtonApp
            id="btn-refresh-permohonan"
            variant="secondary"
            size="sm"
            rounded="lg"
            onClick={() =>
              toast.info("Antrean Disinkronkan", {
                description: "Status berkas dan penugasan petugas diperbarui dari sistem layanan.",
              })
            }
            leftIcon={<RefreshCw className="h-3.5 w-3.5" />}
          >
            Sync Antrean
          </ButtonApp>
          <ButtonApp
            id="btn-export-permohonan"
            variant="primary"
            size="sm"
            rounded="lg"
            leftIcon={<Download className="h-3.5 w-3.5" />}
            onClick={() =>
              toast.vibrant("Laporan Permohonan Diunduh", {
                description: "Berisi rincian antrean aktif beserta status dan penanggung jawabnya.",
              })
            }
          >
            Cetak Laporan Antrean
          </ButtonApp>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* FILTER BAR */}
      {/* ------------------------------------------------------------- */}
      <div className="flex w-full min-w-0 flex-nowrap items-center gap-2 overflow-x-auto rounded-2xl border border-hairline bg-surface px-3 py-3 shadow-xs">
        <span className="flex shrink-0 items-center gap-1.5 whitespace-nowrap text-xs font-semibold text-ink-secondary">
          <Filter className="h-4 w-4 text-vibrant-purple" />
          Filter:
        </span>

        {/* Shortcut inline utk field yang paling sering dipakai — nilainya
            dibagi dgn AdvanceFilterApp supaya tidak jadi kontrol kosmetik. */}
        <div className="w-52 shrink-0">
          <DropdownApp
            id="select-status-berkas"
            value={String(filterValues.statusBerkas ?? "all")}
            onChange={(value) => setFilterValues((prev) => ({ ...prev, statusBerkas: String(value) }))}
            options={[
              { label: "Semua Status Berkas", value: "all" },
              { label: "Baru (Menunggu)", value: "baru" },
              { label: "Sedang Diproses", value: "diproses" },
              { label: "Selesai / Ditolak", value: "selesai" },
            ]}
            size="sm"
            rounded="lg"
            menuPortal
          />
        </div>

        <div className="ml-auto shrink-0">
          <AdvanceFilterApp
            id="filter-monitoring-permohonan"
            displayMode="modal"
            showActivePills={false}
            className="w-auto"
            triggerLabel="Advance Filter Permohonan"
            triggerVariant="secondary"
            triggerSize="sm"
            triggerRounded="lg"
            title="Filter Antrean Permohonan & Penanggung Jawab"
            fields={permohonanFilterFields}
            values={filterValues}
            onChange={setFilterValues}
            quickPresets={quickPresets}
            onReset={handleResetFilter}
            onApply={() => {
              toast.vibrant("Filter Permohonan Diterapkan", {
                description: "Menampilkan antrean berkas sesuai kriteria yang dipilih.",
              });
            }}
          />
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* SCORECARD ANTREAN (BR-09)                                      */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col gap-2">
        <TextApp
          id="label-ringkasan-antrean-heading"
          variant="caption"
          weight="bold"
          className="uppercase tracking-widest text-ink-muted"
        >
          Ringkasan Antrean Berkas
        </TextApp>
        <div className="grid grid-cols-1 items-stretch gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <ScorecardApp
            id="card-total-antrean"
            variant="clayPurple"
            title="Total Antrean Masuk"
            value={liveTotalAntrean}
            live
            unit="Berkas"
            description="Seluruh permohonan yang masuk pada periode berjalan"
            trend={{ value: "+6,1%", label: "vs Bulan Lalu", isPositive: true, direction: "up" }}
            icon={<FileText className="h-5 w-5 text-white" />}
            infoTooltip="Jumlah seluruh permohonan yang masuk pada periode berjalan."
            infoContent={{
              formula: "Berkas baru + berkas diproses + berkas selesai/ditolak",
              period: "Bulan berjalan (real-time)",
              source: "SIMPAD — Modul Permohonan Layanan",
              lastUpdated: "Baru saja",
            }}
            insight={{
              title: "Total Antrean Masuk",
              value: "450 Berkas",
              status: "sehat",
              meta: ["Volume", "Antrean", "Agustus 2026"],
              summary:
                "Jumlah keseluruhan permohonan periode ini. Menjadi penyebut bagi tiga kartu di sebelahnya, sehingga perubahan komposisi hanya bermakna kalau dibaca bersama angka ini.",
              current: [
                "450 berkas masuk, naik 6,1% dibanding bulan sebelumnya.",
                "Dua pertiga di antaranya masih dalam proses.",
              ],
              insights: [
                "Kenaikan volume yang diiringi proporsi 'diproses' yang stabil menandakan kapasitas layanan masih terkejar.",
              ],
              tacticalRecs: [
                "Bandingkan laju masuk dengan laju penyelesaian mingguan untuk mendeteksi penumpukan lebih awal.",
              ],
              strategicRecs: [
                "Dorong migrasi jenis permohonan bervolume tinggi ke kanal mandiri agar beban loket tidak terus naik.",
              ],
              dataNotes: ["Snapshot real-time dari sistem layanan."],
            }}
          />

          <ScorecardApp
            id="card-berkas-baru"
            variant="alert"
            title="Berkas Baru (Menunggu)"
            value={liveBerkasBaru}
            live
            unit="Berkas Belum Ditangani"
            description="Belum memiliki petugas penanggung jawab"
            trend={{ value: "-3,4%", label: "Penurunan Antrean", isPositive: true, direction: "down" }}
            icon={<AlertTriangle className="h-5 w-5 text-rose-600" />}
            infoTooltip="Berkas yang sudah masuk tapi belum ditugaskan ke petugas mana pun."
            infoContent={{
              formula: "Jumlah berkas berstatus Baru tanpa petugas penanggung jawab",
              period: "Snapshot (real-time)",
              source: "SIMPAD — Modul Permohonan Layanan",
              lastUpdated: "Baru saja",
            }}
            insight={{
              title: "Berkas Baru (Menunggu)",
              value: "45 Berkas",
              status: "waspada",
              meta: ["Antrean", "Belum Ditangani", "Agustus 2026"],
              summary:
                "Berkas yang sudah masuk tapi belum dipegang siapa pun. Setiap hari mengendap di sini adalah waktu SLA yang habis tanpa pekerjaan apa pun berjalan.",
              current: ["45 berkas belum ditugaskan, turun tipis dari periode sebelumnya."],
              insights: [
                "Angka ini menumpuk justru saat sebagian petugas sudah kelebihan beban — masalahnya distribusi, bukan kapasitas total.",
              ],
              tacticalRecs: [
                "Tugaskan berkas menunggu ke petugas dengan beban di bawah 50% sebelum akhir hari kerja.",
              ],
              strategicRecs: [
                "Terapkan penugasan otomatis saat berkas masuk agar tidak ada jeda tanpa penanggung jawab.",
              ],
              dataNotes: ["Snapshot real-time; angka bergerak seiring penugasan dilakukan."],
            }}
          />

          <ScorecardApp
            id="card-sedang-diproses"
            variant="blue"
            title="Sedang Diproses"
            value={liveDiproses}
            live
            unit="Berkas Berjalan"
            description="Sudah ditangani petugas dan belum selesai"
            trend={{ value: "+2,7%", label: "vs Bulan Lalu", isPositive: true, direction: "up" }}
            icon={<RotateCw className="h-5 w-5 text-[#1e3a8a] dark:text-blue-200" />}
            infoTooltip="Berkas yang sedang dikerjakan petugas."
            infoContent={{
              formula: "Jumlah berkas berstatus Diproses dengan petugas penanggung jawab",
              period: "Snapshot (real-time)",
              source: "SIMPAD — Modul Permohonan Layanan",
              lastUpdated: "Baru saja",
            }}
            insight={{
              title: "Sedang Diproses",
              value: "300 Berkas",
              status: "sehat",
              meta: ["Antrean", "Berjalan", "Agustus 2026"],
              summary:
                "Berkas yang sudah ada penanggung jawabnya dan sedang dikerjakan. Porsi terbesar dari seluruh antrean.",
              current: ["300 dari 450 berkas berada pada tahap ini."],
              insights: [
                "Porsi 'diproses' yang besar itu normal; yang perlu diwaspadai adalah bila usianya memanjang tanpa berpindah ke status selesai.",
              ],
              tacticalRecs: [
                "Pantau berkas yang sudah lebih dari empat hari berstatus diproses sebagai peringatan dini SLA.",
              ],
              strategicRecs: [
                "Pisahkan alur berkas sederhana dan kompleks agar yang mudah tidak mengantre di belakang yang berat.",
              ],
              dataNotes: ["Snapshot real-time dari sistem layanan."],
            }}
          />

          <ScorecardApp
            id="card-selesai-ditolak"
            variant="emerald"
            title="Selesai / Ditolak"
            value={liveSelesai}
            live
            unit="Berkas Tuntas"
            description="Sudah mendapat keputusan akhir bulan ini"
            trend={{ value: "+8,9%", label: "Laju Penyelesaian", isPositive: true, direction: "up" }}
            icon={<CheckCircle2 className="h-5 w-5 text-emerald-700 dark:text-emerald-200" />}
            infoTooltip="Berkas yang sudah memperoleh keputusan akhir, baik disetujui maupun ditolak."
            infoContent={{
              formula: "Jumlah berkas berstatus Selesai + Ditolak pada periode berjalan",
              period: "Bulan berjalan (real-time)",
              source: "SIMPAD — Modul Permohonan Layanan",
              lastUpdated: "Baru saja",
            }}
            insight={{
              title: "Selesai / Ditolak",
              value: "105 Berkas",
              status: "sehat",
              meta: ["Antrean", "Keputusan Akhir", "Agustus 2026"],
              summary:
                "Berkas yang sudah tuntas, baik disetujui maupun ditolak. Laju penyelesaian inilah yang menentukan apakah antrean menyusut atau menumpuk.",
              current: ["105 berkas tuntas, laju penyelesaian naik 8,9%."],
              insights: [
                "Laju penyelesaian tumbuh lebih cepat daripada laju berkas masuk — bila bertahan, antrean akan menyusut sendiri dalam beberapa bulan.",
              ],
              tacticalRecs: [
                "Pertahankan laju ini dengan menjaga jumlah petugas aktif tetap stabil pada jam sibuk.",
              ],
              strategicRecs: [
                "Pisahkan pelaporan 'selesai' dan 'ditolak' agar rasio penolakan bisa diawasi tersendiri.",
              ],
              dataNotes: ["Mencakup berkas disetujui maupun ditolak."],
            }}
          />
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* DISTRIBUSI + KOMPOSISI + BEBAN PETUGAS (BR-09)                 */}
      {/* ------------------------------------------------------------- */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <CardApp
          id="card-distribusi-status"
          className="flex flex-col border-hairline-soft p-5"
          insight={{
            title: "Distribusi Status Berkas",
            value: "50% masih diproses",
            status: "sehat",
            meta: ["Komposisi", "Status Berkas", "Agustus 2026"],
            summary:
              "Membagi seluruh antrean menjadi tiga status. Bentuk komposisi inilah yang menunjukkan apakah alur layanan mengalir atau tersendat di satu titik.",
            current: ["Setengah antrean sedang diproses, 40% sudah tuntas, 10% belum tersentuh."],
            insights: [
              "Porsi 'baru' yang kecil menandakan penugasan berjalan; yang perlu dijaga adalah agar porsi 'diproses' tidak terus membesar.",
            ],
            tacticalRecs: ["Pantau pergeseran porsi antar-minggu, bukan nilai mutlaknya."],
            strategicRecs: [
              "Tetapkan ambang porsi 'baru' yang memicu penambahan petugas otomatis.",
            ],
            dataNotes: ["Persentase dihitung atas total berkas periode berjalan."],
          }}
        >
          <div className="mb-3">
            <TextApp id="title-distribusi-status" variant="h3" weight="bold" className="text-ink-primary">
              Distribusi Status Berkas
            </TextApp>
            <TextApp id="sub-distribusi-status" variant="caption" className="text-ink-secondary">
              Proporsi berkas menurut tahapan penanganan.
            </TextApp>
          </div>

          <div className="flex-1">
            <ChartApp
              id="chart-distribusi-status"
              type="pie"
              data={STATUS_BERKAS}
              innerRadius={60}
              outerRadius={88}
              valueFormatter={(v) => `${v}%`}
              height={260}
              showLegend
            />
          </div>
        </CardApp>

        <CardApp
          id="card-komposisi-layanan"
          className="flex flex-col border-hairline-soft p-5"
          insight={{
            title: "Komposisi Jenis Layanan",
            value: "Mutasi 35% tertinggi",
            status: "sehat",
            meta: ["Komposisi", "Jenis Layanan", "Agustus 2026"],
            summary:
              "Menunjukkan jenis permohonan apa yang paling sering diminta. Dipakai untuk menentukan layanan mana yang paling layak disederhanakan atau diotomasi lebih dulu.",
            current: ["Mutasi menyumbang 35% permohonan, disusul Pembetulan 25%."],
            insights: [
              "Dua jenis teratas menguasai 60% volume — menyederhanakan keduanya berdampak jauh lebih besar daripada memperbaiki lima jenis sekaligus.",
            ],
            tacticalRecs: ["Siapkan panduan mandiri untuk Mutasi agar berkas masuk lebih rapi sejak awal."],
            strategicRecs: [
              "Prioritaskan digitalisasi pada dua jenis layanan bervolume terbesar.",
            ],
            dataNotes: ["Persentase atas total permohonan periode berjalan."],
          }}
        >
          <div className="mb-4">
            <TextApp id="title-komposisi-layanan" variant="h3" weight="bold" className="text-ink-primary">
              Komposisi Jenis Layanan
            </TextApp>
            <TextApp id="sub-komposisi-layanan" variant="caption" className="text-ink-secondary">
              Pangsa tiap jenis permohonan terhadap total antrean.
            </TextApp>
          </div>

          <ProgressListApp id="list-komposisi-layanan" items={komposisiItems} />
        </CardApp>

        <CardApp
          id="card-beban-petugas"
          className="flex flex-col border-hairline-soft p-5"
          insight={{
            title: "Beban Kerja Petugas Aktif",
            value: "1 petugas overload",
            status: "kritis",
            meta: ["Kinerja", "Beban Petugas", "Agustus 2026"],
            summary:
              "Persentase kapasitas terpakai tiap petugas. Dibaca sebagai peta distribusi kerja — bukan penilaian kecepatan individu.",
            current: [
              "Budi Santoso berada pada 100% kapasitas, sementara dua petugas lain di bawah 50%.",
            ],
            insights: [
              "Selisih beban lebih dari dua kali lipat antar-petugas menunjukkan penugasan belum mempertimbangkan muatan aktif.",
            ],
            tacticalRecs: [
              "Alihkan berkas baru ke Dian Sastro dan Reza Rahadian sampai bebannya menyamai rata-rata.",
            ],
            strategicRecs: [
              "Terapkan pembagian berkas berbasis beban aktif supaya penumpukan tidak terulang tiap bulan.",
            ],
            glossary: [
              { term: "Overload", definition: "beban terpakai mencapai atau melewati 90% kapasitas petugas." },
            ],
            dataNotes: ["Beban dihitung dari jumlah berkas aktif terhadap kuota harian petugas."],
          }}
        >
          <div className="mb-4">
            <TextApp id="title-beban-petugas" variant="h3" weight="bold" className="text-ink-primary">
              Beban Kerja Petugas Aktif
            </TextApp>
            <TextApp id="sub-beban-petugas" variant="caption" className="text-ink-secondary">
              Kapasitas terpakai per petugas pelayanan.
            </TextApp>
          </div>

          <ProgressListApp id="list-beban-petugas" items={bebanItems} />
        </CardApp>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* DAFTAR ANTREAN PERMOHONAN AKTIF (BR-09)                        */}
      {/* ------------------------------------------------------------- */}
      <CardApp id="card-table-antrean-permohonan" className="border-hairline-soft p-5">
        <DataTableApp
          id="datatable-antrean-permohonan"
          title="Daftar Antrean Permohonan Aktif"
          description="Berkas yang sedang berjalan beserta status dan petugas penanggung jawabnya. Berkas baru muncul dari atas."
          toolbarLayout="singleRow"
          rightHeaderAction={
            <BadgeApp id="badge-antrean-live" variant="solidEmerald" size="sm">
              Live Feed
            </BadgeApp>
          }
          data={antreanRows}
          newRowIds={newRowIds}
          getRowId={(row) => row.id}
          columns={tableColumns}
          searchPlaceholder="Cari no. tiket, nama pemohon, atau jenis permohonan..."
          pageSize={5}
        />
      </CardApp>
    </div>
  );
}

export default ApplicationMonitoringDashboardPage;
