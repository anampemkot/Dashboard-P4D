import * as React from "react";
import { useNavigate } from "react-router-dom";
import { BadgeApp, TextApp, ButtonApp, SearchBarApp } from "@/packages/design-system";
import {
  Palette,
  Layers,
  FileText,
  Navigation as NavIcon,
  Layout,
  Table as TableIcon,
  BarChart3,
  Bell,
  Sparkles,
  LayoutTemplate,
  Package,
  CheckCircle2,
  ListTodo,
} from "lucide-react";

import { CategorySectionCard } from "./uikit/CategorySectionCard";
import { UI_KIT_CATEGORIES } from "./uikit/uikitCategoriesData";
import { findSectionByCategoryId } from "./uikit/shared/uikitRegistry";

const iconMap: Record<string, React.ReactNode> = {
  Palette: <Palette className="w-5 h-5" />,
  Layers: <Layers className="w-5 h-5" />,
  FileText: <FileText className="w-5 h-5" />,
  Navigation: <NavIcon className="w-5 h-5" />,
  Layout: <Layout className="w-5 h-5" />,
  Table: <TableIcon className="w-5 h-5" />,
  BarChart3: <BarChart3 className="w-5 h-5" />,
  Bell: <Bell className="w-5 h-5" />,
  Sparkles: <Sparkles className="w-5 h-5" />,
  LayoutTemplate: <LayoutTemplate className="w-5 h-5" />,
  Package: <Package className="w-5 h-5" />,
};

export default function UiKitPage() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = React.useState("");
  const [activeCategoryFilter, setActiveCategoryFilter] = React.useState<string>("all");

  const totalItems = UI_KIT_CATEGORIES.reduce((acc, cat) => acc + cat.todoItems.length, 0);
  const totalReady = UI_KIT_CATEGORIES.reduce(
    (acc, cat) => acc + cat.todoItems.filter((i) => i.status === "ready").length,
    0
  );
  const totalPlanned = totalItems - totalReady;
  const progressPercent = Math.round((totalReady / totalItems) * 100);

  const filteredCategories = UI_KIT_CATEGORIES.filter((cat) => {
    if (activeCategoryFilter !== "all" && cat.id !== activeCategoryFilter) {
      return false;
    }
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    const matchCategory =
      cat.title.toLowerCase().includes(q) ||
      cat.number.includes(q) ||
      cat.description.toLowerCase().includes(q);
    const matchItems = cat.todoItems.some(
      (item) =>
        item.name.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        (item.tag && item.tag.toLowerCase().includes(q))
    );
    return matchCategory || matchItems;
  });

  const scrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <div className="flex flex-col gap-10 pb-24 text-left">
      <section id="admin-panel-hero" data-label="Ringkasan Utama" className="scroll-mt-12">
        <div className="card p-6 md:p-8 bg-surface border border-hairline rounded-3xl flex flex-col gap-6 relative overflow-hidden shadow-xs">
          <div className="absolute right-0 top-0 h-48 w-48 bg-vibrant-purple/10 rounded-full blur-3xl pointer-events-none" />

          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
            <div>
              <div className="flex items-center gap-2.5 mb-3 flex-wrap">
                <BadgeApp id="uikit-tag" variant="solidPurple" size="sm">
                  DESIGN SYSTEM P4D v2.0
                </BadgeApp>
                <span className="text-[11px] font-mono tracking-wider text-ink-muted uppercase bg-surface-soft px-2.5 py-1 rounded-full border border-hairline-soft">
                  11 Kategori Terstruktur
                </span>
              </div>
              <TextApp id="uikit-main-title" variant="h1" className="font-bold tracking-tight mb-2">
                Katalog Komponen UI Kit P4D
              </TextApp>
              <TextApp id="uikit-desc" variant="body" className="text-ink-secondary max-w-3xl text-sm leading-relaxed">
                Pustaka antarmuka pengguna Badan Pengelolaan Keuangan dan Aset Daerah (BPKAD) Kota Yogyakarta.
                Dikelompokkan ke dalam 11 seksi standar industri — klik seksi untuk membuka halaman demo lengkap.
              </TextApp>
            </div>

            <div className="bg-surface-soft border border-hairline-soft p-4 rounded-2xl flex flex-col gap-2 min-w-[220px]">
              <div className="flex items-center justify-between text-xs font-semibold">
                <span className="text-ink-secondary flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                  Keterisian UI Kit
                </span>
                <span className="text-vibrant-purple-dark dark:text-purple-300 font-mono font-bold">
                  {progressPercent}%
                </span>
              </div>
              <div className="w-full h-2.5 bg-hairline-soft rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-vibrant-purple to-vibrant-purple-dark transition-all duration-500"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[11px] font-mono text-ink-muted pt-1">
                <span>{totalReady} Siap Pakai</span>
                <span>{totalPlanned} Rencana (TODO)</span>
              </div>
            </div>
          </div>

          <div className="border-t border-hairline-soft pt-4 flex flex-col gap-3">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <span className="text-xs font-bold uppercase tracking-wider text-ink-muted flex items-center gap-1.5">
                <ListTodo className="w-3.5 h-3.5 text-vibrant-purple-dark" />
                Pintas Seksi Kategori (11 Seksi):
              </span>

              <div className="w-full sm:w-64">
                <SearchBarApp
                  id="uikit-hub-search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Cari komponen atau kategori..."
                />
              </div>
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
              <ButtonApp
                id="uikit-filter-all"
                variant={activeCategoryFilter === "all" ? "primary" : "secondary"}
                size="sm"
                rounded="lg"
                onClick={() => setActiveCategoryFilter("all")}
                className="whitespace-nowrap"
              >
                Semua Seksi (11)
              </ButtonApp>

              {UI_KIT_CATEGORIES.map((cat) => (
                <ButtonApp
                  id={`uikit-filter-${cat.id}`}
                  key={cat.id}
                  variant="secondary"
                  size="sm"
                  rounded="lg"
                  onClick={() => {
                    setActiveCategoryFilter("all");
                    scrollToSection(cat.id);
                  }}
                  className="whitespace-nowrap gap-1.5"
                >
                  <span className="font-mono text-[10px] px-1 py-0.2 rounded bg-vibrant-purple/10 text-vibrant-purple-dark font-bold">
                    {cat.number}
                  </span>
                  {cat.title}
                </ButtonApp>
              ))}
            </div>
          </div>
        </div>
      </section>

      <div className="flex flex-col gap-10">
        {filteredCategories.map((cat) => {
          const section = findSectionByCategoryId(cat.id);
          return (
            <CategorySectionCard
              key={cat.id}
              id={cat.id}
              number={cat.number}
              title={cat.title}
              dataLabel={cat.dataLabel}
              description={cat.description}
              icon={iconMap[cat.iconName] || <Package className="w-5 h-5" />}
              todoItems={cat.todoItems}
              sectionHref={section ? `/admin/ui-kit/${section.slug}` : undefined}
              onOpenSection={section ? () => navigate(`/admin/ui-kit/${section.slug}`) : undefined}
            />
          );
        })}
      </div>
    </div>
  );
}
