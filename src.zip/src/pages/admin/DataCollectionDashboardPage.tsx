import * as React from "react";
import {
  ScorecardApp,
  CardApp,
  BadgeApp,
  ButtonApp,
  TextApp,
  AdvanceFilterApp,
  DataTableApp,
  ChartApp,
  SearchBarApp,
  DropdownApp,
  DialogApp,
  MapsApp,
  useToastApp,
  useRealtimeValue,
  useRealtimeRows,
  MapMarker,
  QuickPreset,
} from "@/packages/design-system";
import {
  FileText,
  MapPin,
  CheckCircle2,
  CheckSquare,
  Map as MapIcon,
  RefreshCw,
  Sparkles,
  TrendingUp,
  Download,
  Flame,
  Eye,
  Calendar,
  Filter,
} from "lucide-react";
import { CHART_COLORS, CHART_TARGET_COLOR, HEATMAP_DENSITY_SCALE } from "@/constants/chartColors";

// Titik objek pajak untuk peta spasial (BR-03 no. 8 "Map (Heatmap)").
// Melengkapi mosaic kepadatan per kelurahan: mosaic menjawab "wilayah mana
// yang padat", peta menjawab "objek mana persisnya, di koordinat mana".
const mockSpatialMarkers: MapMarker[] = [
  {
    id: "m-1",
    position: [-7.8012, 110.3648],
    title: "NOP 34.71.010.002.015-0 - Malioboro Mall",
    description: "PBJT Makanan & Hiburan - Status Tervalidasi (Survei 14 Jul 2026)",
    color: "purple",
  },
  {
    id: "m-2",
    position: [-7.8085, 110.3629],
    title: "NOP 34.71.020.005.011-0 - Hotel Royal Ambarrukmo Branch",
    description: "PBJT Perhotelan - Objek Baru Terdata (Survei 20 Jul 2026)",
    color: "blue",
  },
  {
    id: "m-3",
    position: [-7.8124, 110.3789],
    title: "NOP 34.71.040.012.003-0 - Resto House of Raminten",
    description: "PBJT Makanan & Minuman - Ground Check Selesai",
    color: "emerald",
  },
  {
    id: "m-4",
    position: [-7.7925, 110.3672],
    title: "NOP 34.71.030.008.022-0 - Reklame LED Simpang Tugu",
    description: "Pajak Reklame Bando - Uji Petik Tim Audit BPKAD",
    color: "amber",
  },
  {
    id: "m-5",
    position: [-7.8210, 110.3812],
    title: "NOP 34.71.050.018.009-0 - Wisma Umbulharjo",
    description: "PBB-P2 Komersial - Objek Baru (Perlu Validasi)",
    color: "red",
  },
];

// Filter Field Configuration for BR-03
const pendataanFilterFields = [
  {
    id: "sektorPajak",
    label: "Sektor Pajak",
    type: "select" as const,
    placeholder: "Pilih Sektor Pajak...",
    options: [
      { value: "all", label: "Semua Sektor Pajak" },
      { value: "pbb_p2", label: "PBB-P2 (Pedesaan & Perkotaan)" },
      { value: "bphtb", label: "BPHTB (Bea Perolehan Hak)" },
      { value: "pbjt_makanan", label: "PBJT Makanan & Minuman" },
      { value: "pbjt_hotel", label: "PBJT Jasa Perhotelan" },
      { value: "pbjt_hiburan", label: "PBJT Jasa Kesenian & Hiburan" },
      { value: "reklame", label: "Pajak Reklame" },
      { value: "air_tanah", label: "Pajak Air Tanah (PAT)" },
    ],
  },
  {
    id: "kecamatan",
    label: "Wilayah Kecamatan",
    type: "select" as const,
    placeholder: "Pilih Kecamatan...",
    options: [
      { value: "all", label: "Semua Kecamatan (14 Wilayah)" },
      { value: "gondomanan", label: "Kecamatan Gondomanan" },
      { value: "danurejan", label: "Kecamatan Danurejan" },
      { value: "kraton", label: "Kecamatan Kraton" },
      { value: "jetis", label: "Kecamatan Jetis" },
      { value: "umbulharjo", label: "Kecamatan Umbulharjo" },
      { value: "mantrijeron", label: "Kecamatan Mantrijeron" },
      { value: "kotagede", label: "Kecamatan Kotagede" },
      { value: "terban", label: "Kecamatan Gondokusuman" },
    ],
  },
  {
    id: "statusPendataan",
    label: "Status Pendataan",
    type: "select" as const,
    placeholder: "Semua Status...",
    options: [
      { value: "all", label: "Semua Status Pendataan" },
      { value: "terdata", label: "Terdata (NOP Aktif)" },
      { value: "objek_baru", label: "Objek Baru (2026)" },
      { value: "tervalidasi", label: "Validasi Selesai" },
      { value: "survei_lapangan", label: "Survei Lapangan Pending" },
      { value: "uji_petik", label: "Uji Petik Audit" },
    ],
  },
  {
    id: "tahunAnggaran",
    label: "Tahun Anggaran",
    type: "select" as const,
    placeholder: "Tahun...",
    options: [
      { value: "2026", label: "Tahun 2026 (Berjalan)" },
      { value: "2025", label: "Tahun 2025" },
      { value: "2024", label: "Tahun 2024" },
    ],
  },
];

const quickPresets: QuickPreset[] = [
  { label: "Semua Objek", values: { sektorPajak: "all", statusPendataan: "all" } },
  { label: "Objek Baru 2026", values: { statusPendataan: "objek_baru" } },
  { label: "Validasi Selesai", values: { statusPendataan: "tervalidasi" } },
  { label: "Butuh Survei Lapangan", values: { statusPendataan: "survei_lapangan" } },
];

// Mock Progress Monthly Data
const progressPendataanData = [
  { month: "Jan", target: 12000, realisasi: 11800, objekBaru: 240 },
  { month: "Feb", target: 12500, realisasi: 12450, objekBaru: 280 },
  { month: "Mar", target: 13000, realisasi: 13100, objekBaru: 310 },
  { month: "Apr", target: 13000, realisasi: 12900, objekBaru: 290 },
  { month: "Mei", target: 13500, realisasi: 13800, objekBaru: 350 },
  { month: "Jun", target: 14000, realisasi: 14250, objekBaru: 390 },
  { month: "Jul", target: 14500, realisasi: 14850, objekBaru: 420 },
  { month: "Agt", target: 14500, realisasi: 13900, objekBaru: 310 },
  { month: "Sep", target: 15000, realisasi: 14200, objekBaru: 290 },
  { month: "Okt", target: 15000, realisasi: 13800, objekBaru: 270 },
  { month: "Nov", target: 15500, realisasi: 13200, objekBaru: 230 },
  { month: "Des", target: 16000, realisasi: 12900, objekBaru: 200 },
];

// Kepadatan Objek Pajak per Kelurahan — grid mosaic 9x5 (45 kelurahan Kota Yogyakarta)
// Level: 1 = Rendah, 2 = Sedang, 3 = Tinggi, 4 = Sangat Tinggi
const kelurahanDensityGrid = [
  1, 1, 2, 3, 3, 4, 1, 1, 2,
  3, 3, 4, 1, 1, 2, 3, 3, 4,
  1, 1, 2, 3, 3, 4, 1, 1, 2,
  3, 4, 4, 1, 2, 2, 3, 4, 4,
  1, 2, 2, 3, 4, 4, 1, 2, 2,
];
// Warna sel heatmap diambil dari HEATMAP_DENSITY_SCALE (turunan
// CHART_COLORS.blue) supaya satu keluarga dengan chart lain.
const densityLevelStyle = (level: number): React.CSSProperties => ({
  backgroundColor: HEATMAP_DENSITY_SCALE[level],
});

// Ranking Kecamatan Data
const rankingKecamatanData = [
  { name: "Umbulharjo", totalNOP: 22450, tervalidasi: 20100 },
  { name: "Gondokusuman", totalNOP: 18920, tervalidasi: 17200 },
  { name: "Mergangsan", totalNOP: 15400, tervalidasi: 14100 },
  { name: "Danurejan", totalNOP: 14850, tervalidasi: 13200 },
  { name: "Gondomanan", totalNOP: 13900, tervalidasi: 12850 },
  { name: "Jetis", totalNOP: 12600, tervalidasi: 11400 },
  { name: "Mantrijeron", totalNOP: 11200, tervalidasi: 9900 },
  { name: "Kotagede", totalNOP: 10800, tervalidasi: 9600 },
];

// Ranking Kelurahan Data
const rankingKelurahanData = [
  { name: "Sosromenduran", totalNOP: 4850, percentage: 94.2, fill: CHART_COLORS.purple },
  { name: "Suryatmajan", totalNOP: 4210, percentage: 92.8, fill: CHART_COLORS.blue },
  { name: "Terban", totalNOP: 3950, percentage: 91.5, fill: CHART_COLORS.emerald },
  { name: "Muja Muju", totalNOP: 3820, percentage: 90.1, fill: CHART_COLORS.amber },
  { name: "Prawirodirjan", totalNOP: 3640, percentage: 89.4, fill: CHART_COLORS.cyan },
  { name: "Bausasran", totalNOP: 3410, percentage: 88.2, fill: CHART_COLORS.purple },
  { name: "Ngupasan", totalNOP: 3290, percentage: 87.6, fill: CHART_COLORS.blue },
  { name: "Tahunan", totalNOP: 3120, percentage: 86.0, fill: CHART_COLORS.emerald },
];

// Mock Table Records
const mockPendataanRecords = [
  {
    id: "REC-001",
    nop: "34.71.010.002.015-0",
    namaWajibPajak: "PT Hotel Jogja Utama (Malioboro)",
    sektor: "PBJT Perhotelan",
    kecamatan: "Gondomanan",
    kelurahan: "Ngupasan",
    status: "Tervalidasi",
    tglSurvei: "14 Jul 2026",
    petugas: "Budi Santoso, S.STP",
    ujiPetik: "Ya",
    koordinat: "-7.8012, 110.3648",
  },
  {
    id: "REC-002",
    nop: "34.71.020.005.011-0",
    namaWajibPajak: "CV Kuliner Malioboro Resto",
    sektor: "PBJT Makanan & Minuman",
    kecamatan: "Danurejan",
    kelurahan: "Suryatmajan",
    status: "Objek Baru",
    tglSurvei: "20 Jul 2026",
    petugas: "Rina Wijaya, A.Md",
    ujiPetik: "Tidak",
    koordinat: "-7.8085, 110.3629",
  },
  {
    id: "REC-003",
    nop: "34.71.040.012.003-0",
    namaWajibPajak: "Gedung Komersial Malioboro Plaza",
    sektor: "PBB-P2",
    kecamatan: "Gondomanan",
    kelurahan: "Ngupasan",
    status: "Survei Lapangan",
    tglSurvei: "22 Jul 2026",
    petugas: "Eko Prasetyo",
    ujiPetik: "Tidak",
    koordinat: "-7.8124, 110.3789",
  },
  {
    id: "REC-004",
    nop: "34.71.030.008.022-0",
    namaWajibPajak: "Billboard LED Simpang Tugu Jogja",
    sektor: "Pajak Reklame",
    kecamatan: "Jetis",
    kelurahan: "Gowongan",
    status: "Uji Petik",
    tglSurvei: "18 Jul 2026",
    petugas: "Tim Audit BPKAD",
    ujiPetik: "Ya",
    koordinat: "-7.7925, 110.3672",
  },
  {
    id: "REC-005",
    nop: "34.71.050.018.009-0",
    namaWajibPajak: "Wisma Dewaruci Umbulharjo",
    sektor: "PAT (Air Tanah)",
    kecamatan: "Umbulharjo",
    kelurahan: "Muja Muju",
    status: "Terdata",
    tglSurvei: "10 Jul 2026",
    petugas: "Agus Setiawan",
    ujiPetik: "Tidak",
    koordinat: "-7.8210, 110.3812",
  },
];

// Realtime feed: pola sama seperti useRealtimeRows di halaman lain.
const PDT_NAMA_POOL = [
  "Toko Batik Pasar Beringharjo", "CV Souvenir Malioboro Jaya", "Warung Gudeg Bu Slamet",
  "PT Konveksi Kotagede Mandiri", "Rumah Kos Mahasiswa Seturan", "UD Perak Kotagede Asli",
  "Kedai Kopi Prawirotaman", "Toko Oleh-oleh Bakpia Patuk",
];
const PDT_SEKTOR_POOL = ["PBJT Makanan & Minuman", "PBB-P2", "PBJT Jasa Perhotelan", "Pajak Reklame", "BPHTB"];
const PDT_WILAYAH_POOL = [
  { kecamatan: "Gondomanan", kelurahan: "Ngupasan" },
  { kecamatan: "Danurejan", kelurahan: "Suryatmajan" },
  { kecamatan: "Umbulharjo", kelurahan: "Muja Muju" },
  { kecamatan: "Jetis", kelurahan: "Gowongan" },
];
const PDT_STATUS_POOL = ["Terdata", "Objek Baru", "Survei Lapangan", "Tervalidasi", "Uji Petik"];
const PDT_PETUGAS_POOL = ["Budi Santoso, S.STP", "Rina Wijaya, A.Md", "Eko Prasetyo", "Agus Setiawan"];

function generateNextPendataanRecord(): typeof mockPendataanRecords[0] {
  const now = new Date();
  const seq = `${now.getTime().toString().slice(-6)}${Math.floor(Math.random() * 900) + 100}`;
  const wilayah = PDT_WILAYAH_POOL[Math.floor(Math.random() * PDT_WILAYAH_POOL.length)];
  const status = PDT_STATUS_POOL[Math.floor(Math.random() * PDT_STATUS_POOL.length)];
  return {
    id: `REC-${seq}`,
    nop: `34.71.0${Math.floor(Math.random() * 90) + 10}.0${Math.floor(Math.random() * 90) + 10}.${Math.floor(Math.random() * 900) + 100}-0`,
    namaWajibPajak: PDT_NAMA_POOL[Math.floor(Math.random() * PDT_NAMA_POOL.length)],
    sektor: PDT_SEKTOR_POOL[Math.floor(Math.random() * PDT_SEKTOR_POOL.length)],
    kecamatan: wilayah.kecamatan,
    kelurahan: wilayah.kelurahan,
    status,
    tglSurvei: now.toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" }),
    petugas: PDT_PETUGAS_POOL[Math.floor(Math.random() * PDT_PETUGAS_POOL.length)],
    ujiPetik: status === "Uji Petik" ? "Ya" : "Tidak",
    koordinat: `-7.${7900 + Math.floor(Math.random() * 300)}, 110.${3600 + Math.floor(Math.random() * 300)}`,
  };
}

export function DataCollectionDashboardPage() {
  const { toast } = useToastApp();

  // Realtime KPI — mengikuti pola live/statis persis referensi ZIP: 5 metrik
  // running count live (Objek Terdata/Baru/Validasi/Survei/Uji Petik), 1
  // metrik rasio (Persentase Penyelesaian) tetap statis seperti di ZIP.
  const liveObjekTerdata = useRealtimeValue({ initialValue: 148520, update: (v) => v + Math.floor(Math.random() * 4) + 1, intervalMs: 6500 });
  const liveObjekBaru = useRealtimeValue({ initialValue: 3240, update: (v) => v + Math.floor(Math.random() * 2) + 1, intervalMs: 8000 });
  const liveValidasi = useRealtimeValue({ initialValue: 14890, update: (v) => v + Math.floor(Math.random() * 3) + 1, intervalMs: 7000 });
  const liveSurveiLapangan = useRealtimeValue({ initialValue: 1850, update: (v) => v + (Math.random() > 0.4 ? 1 : 0), intervalMs: 9500 });
  const liveUjiPetik = useRealtimeValue({ initialValue: 620, update: (v) => v + (Math.random() > 0.7 ? 1 : 0), intervalMs: 13000 });

  // Realtime feed tabel pendataan — baris baru masuk dari atas, di-highlight.
  const { rows: livePendataanRecords, newRowIds: newPendataanRecordIds } = useRealtimeRows({
    initialRows: mockPendataanRecords,
    getId: (row) => row.id,
    generate: generateNextPendataanRecord,
    intervalMs: 10000,
    maxRows: 20,
  });

  // Active Map View Mode
  const [heatmapViewMode, setHeatmapViewMode] = React.useState<"heatmap" | "tabel">("heatmap");
  const [heatmapSearch, setHeatmapSearch] = React.useState("");
  const [heatmapSektor, setHeatmapSektor] = React.useState("all");
  
  // Selected Detail Record for Dialog
  const [selectedRecord, setSelectedRecord] = React.useState<typeof mockPendataanRecords[0] | null>(null);
  const [isDetailDialogOpen, setIsDetailDialogOpen] = React.useState(false);

  // Active Filters state
  const [filterValues, setFilterValues] = React.useState<Record<string, any>>({});

  const handleResetFilter = () => {
    setFilterValues({});
    toast.info("Filter Direset", {
      description: "Semua kriteria filter pendataan telah dikembalikan ke kondisi default.",
    });
  };

  const handleExportReport = () => {
    toast.success("Laporan Pendataan Diexport", {
      description: "Berkas PDF/XLSX Rekapitulasi Pendataan Objek Pajak BR-03 berhasil diunduh.",
    });
  };

  const handleOpenDetailModal = (record: typeof mockPendataanRecords[0]) => {
    setSelectedRecord(record);
    setIsDetailDialogOpen(true);
  };

  // Columns for DataTableApp
  const tableColumns = [
    {
      accessorKey: "nop",
      header: "Nomor Objek Pajak (NOP)",
      cell: ({ row }: any) => (
        <div className="font-mono text-xs font-bold text-vibrant-purple">
          {row.original.nop}
        </div>
      ),
    },
    {
      accessorKey: "namaWajibPajak",
      header: "Nama Wajib Pajak / Subjek",
      cell: ({ row }: any) => (
        <div className="font-medium text-ink-primary text-xs">
          {row.original.namaWajibPajak}
        </div>
      ),
    },
    {
      accessorKey: "sektor",
      header: "Sektor Pajak",
      cell: ({ row }: any) => (
        <BadgeApp id={`badge-sektor-${row.original.id}`} variant="solidPurple" size="sm">
          {row.original.sektor}
        </BadgeApp>
      ),
    },
    {
      accessorKey: "kecamatan",
      header: "Kecamatan / Kelurahan",
      cell: ({ row }: any) => (
        <div className="text-xs text-ink-secondary">
          {row.original.kecamatan} ({row.original.kelurahan})
        </div>
      ),
    },
    {
      accessorKey: "status",
      header: "Status Pendataan",
      cell: ({ row }: any) => {
        const val = row.original.status;
        let badgeVariant: any = "solidPurple";
        if (val === "Objek Baru") badgeVariant = "blue";
        if (val === "Tervalidasi") badgeVariant = "solidEmerald";
        if (val === "Survei Lapangan") badgeVariant = "solidAmber";
        if (val === "Uji Petik") badgeVariant = "solidPurple";

        return <BadgeApp id={`badge-status-${row.original.id}`} variant={badgeVariant} size="sm">{val}</BadgeApp>;
      },
    },
    {
      accessorKey: "tglSurvei",
      header: "Tgl Survei",
      cell: ({ row }: any) => (
        <div className="text-xs font-mono text-ink-secondary">{row.original.tglSurvei}</div>
      ),
    },
    {
      accessorKey: "petugas",
      header: "Petugas Lapangan",
      cell: ({ row }: any) => (
        <div className="text-xs text-ink-primary">{row.original.petugas}</div>
      ),
    },
    {
      id: "actions",
      header: "Aksi",
      cell: ({ row }: any) => (
        <ButtonApp
          id={`btn-detail-nop-${row.original.id}`}
          variant="purpleDark"
          theme="default"
          size="sm"
          rounded="pill"
          onClick={() => handleOpenDetailModal(row.original)}
          className="flex items-center gap-1 text-[11px] h-7 px-2.5"
        >
          <Eye className="w-3.5 h-3.5" />
          Detail
        </ButtonApp>
      ),
    },
  ];

  return (
    <div id="pendataan-dashboard-root" className="space-y-6 pb-12">
      {/* ------------------------------------------------------------- */}
      {/* HEADER PAGE                                                   */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col justify-between gap-4 border-b border-hairline-soft pb-4 md:flex-row md:items-center">
        <div>
          <div className="mb-1 flex flex-wrap items-center gap-x-3 gap-y-1.5">
            <BadgeApp id="hdr-badge-br03" variant="solidPurple" size="sm">
              BR-03 · Dashboard Pendataan
            </BadgeApp>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <MapPin className="h-3.5 w-3.5 text-vibrant-purple" />
              GIS Spasial Yogyakarta
            </span>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <Calendar className="h-3.5 w-3.5 text-vibrant-purple" />
              Tahun Anggaran 2026
            </span>
          </div>
          <TextApp id="hdr-title-pendataan" variant="h2" className="tracking-tight text-ink">
            Dashboard Pendataan Objek Pajak
          </TextApp>
          <TextApp id="hdr-sub-pendataan" variant="body" className="text-xs text-ink-secondary">
            Integrasi Pemetaan Spasial, Registrasi Objek Baru, Validasi Lapangan, & Analysis Uji Petik
          </TextApp>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <ButtonApp
            id="btn-refresh-pendataan-data"
            variant="secondary"
            size="sm"
            rounded="lg"
            onClick={() =>
              toast.info("Data Disinkronisasi", {
                description: "Map GIS dan database pendataan NOP telah diperbarui secara live.",
              })
            }
            leftIcon={<RefreshCw className="h-3.5 w-3.5" />}
          >
            Refresh
          </ButtonApp>
          <ButtonApp
            id="btn-export-pendataan-report"
            variant="primary"
            size="sm"
            rounded="lg"
            leftIcon={<Download className="h-3.5 w-3.5" />}
            onClick={handleExportReport}
          >
            Cetak Laporan Pendataan
          </ButtonApp>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* FILTER BAR */}
      {/* ------------------------------------------------------------- */}
      <div className="flex w-full min-w-0 flex-nowrap items-center gap-2 overflow-x-auto rounded-2xl border border-hairline bg-surface px-3 py-3 shadow-xs">
        <span className="flex shrink-0 items-center gap-1.5 whitespace-nowrap text-xs font-semibold text-ink-secondary">
          <Filter className="h-4 w-4 text-vibrant-purple" />
          Filter:
        </span>

        {/* Shortcut inline utk field yang paling sering dipakai — nilainya
            dibagi dgn AdvanceFilterApp supaya tidak jadi kontrol kosmetik. */}
        <div className="w-52 shrink-0">
          <DropdownApp
            id="select-tahun-anggaran-pendataan"
            value={String(filterValues.tahunAnggaran ?? "2026")}
            onChange={(value) =>
              setFilterValues((prev) => ({ ...prev, tahunAnggaran: String(value) }))
            }
            options={[
              { label: "Tahun 2026 (Berjalan)", value: "2026" },
              { label: "Tahun 2025", value: "2025" },
              { label: "Tahun 2024", value: "2024" },
            ]}
            size="sm"
            rounded="lg"
            menuPortal
          />
        </div>

        <div className="ml-auto shrink-0">
          <AdvanceFilterApp
            id="filter-pendataan-objek"
            displayMode="modal"
            showActivePills={false}
            className="w-auto"
            triggerLabel="Advance Filter Pendataan"
            triggerVariant="secondary"
            triggerSize="sm"
            triggerRounded="lg"
            title="Filter Objek Pajak & Wilayah Pendataan"
            fields={pendataanFilterFields}
            values={filterValues}
            onChange={setFilterValues}
            quickPresets={quickPresets}
            onReset={handleResetFilter}
            onApply={() => {
              toast.vibrant("Filter Pendataan Berhasil Diterapkan", {
                description: "Menampilkan data pendataan objek pajak berdasarkan kriteria yang dipilih.",
              });
            }}
          />
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* SCORECARD BENTO GRID (BR-03 Items 1 to 6)                     */}
      {/* Rules: Top 3 colored side-by-side; remainder default white.   */}
      {/* Clean titles without prefixed numbers.                        */}
      {/* 2 baris kartu tanpa chart pendamping -> heading kategori per     */}
      {/* baris, mengikuti pola SectionTitle referensi ZIP.               */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col gap-2">
        <TextApp id="label-statistik-objek-heading" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted">
          Statistik Objek
        </TextApp>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-stretch">

        {/* 1. Jumlah Objek Pajak Terdata - Purple Clay */}
        <div className="col-span-1 sm:col-span-1 lg:col-span-1 xl:col-span-1 flex flex-col h-full">
          <ScorecardApp
            id="card-objek-pajak-terdata"
            variant="clayPurple"
            title="Jumlah Objek Pajak Terdata"
            value={liveObjekTerdata}
            live
            unit="NOP Terdaftar"
            description="Total Objek Pajak Daerah Kota Yogyakarta"
            trend={{
              value: "+8.2%",
              label: "Pertumbuhan YTD",
              isPositive: true,
              direction: "up",
            }}
            icon={<FileText className="w-5 h-5 text-white" />}
            infoTooltip="Jumlah seluruh Objek Pajak (NOP) yang telah masuk dalam master database BPKAD."
            infoContent={{
              formula: "Total seluruh Objek Pajak (NOP) yang telah masuk ke master database BPKAD",
              period: "Snapshot (real-time)",
              source: "SIMPAD — Modul Pendataan Objek",
              lastUpdated: "Baru saja",
            }}
            insight={{
              title: "Jumlah Objek Pajak Terdata",
              value: "148.520 NOP",
              status: "sehat",
              meta: ["Indikator", "Basis Data NOP", "TA 2026"],
              summary: "Jumlah Objek Pajak Terdata mengukur total Objek Pajak (NOP) yang telah masuk ke master database BPKAD, dibandingkan target 155.000 NOP TA 2026.",
              current: [
                "Realisasi 148.520 NOP, setara 95,8% dari target 155.000.",
                "Tumbuh 8,2% YTD, konsisten dengan laju pendataan objek baru & survei lapangan.",
              ],
              insights: [
                "Gap 4,2% menuju target masih dapat ditutup mengingat laju pertumbuhan tahun berjalan positif.",
              ],
              tacticalRecs: [
                "Prioritaskan kecamatan dengan capaian NOP terendah untuk percepatan pendataan sisa target.",
              ],
              strategicRecs: [
                "Evaluasi kapasitas tim survei lapangan agar target 155.000 tercapai sebelum akhir tahun anggaran.",
              ],
              dataNotes: ["Snapshot basis data live, pembaruan real-time."],
            }}
          />
        </div>

        {/* 2. Jumlah Objek Baru - Blue Clay */}
        <div className="col-span-1 sm:col-span-1 lg:col-span-1 xl:col-span-1 flex flex-col h-full">
          <ScorecardApp
            id="card-objek-baru"
            variant="clayBlue"
            title="Jumlah Objek Baru"
            value={liveObjekBaru}
            live
            unit="NOP Baru 2026"
            description="Penambahan dari hasil pendataan aktif"
            trend={{
              value: "+12.4%",
              label: "Dibanding 2025",
              isPositive: true,
              direction: "up",
            }}
            icon={<Sparkles className="w-5 h-5 text-[#1e3a8a] dark:text-blue-200" />}
            infoTooltip="NOP baru yang terdaftar hasil pendataan mandiri dan survei wilayah."
            infoContent={{
              formula: "NOP baru yang terdaftar hasil pendataan mandiri dan survei wilayah, akumulasi TA 2026",
              period: "Tahunan (YTD)",
              source: "SIMPAD — Modul Registrasi Objek Baru",
              lastUpdated: "Baru saja",
            }}
            insight={{
              title: "Jumlah Objek Baru",
              value: "3.240 NOP Baru",
              status: "sehat",
              meta: ["Indikator", "Registrasi 2026", "TA 2026"],
              summary: "Jumlah Objek Baru mengukur NOP yang baru terdaftar hasil pendataan mandiri dan survei wilayah sepanjang tahun anggaran berjalan.",
              current: [
                "Realisasi 3.240 NOP baru, tumbuh 12,4% dibanding periode sama 2025.",
                "Setara 2,2% dari total basis NOP terdata — laju akuisisi objek baru wajar.",
              ],
              insights: [
                "Pertumbuhan 12,4% lebih tinggi dari pertumbuhan basis total (8,2%) — akuisisi objek baru berjalan lebih cepat dari basis existing.",
              ],
              tacticalRecs: [
                "Audit sampel objek baru untuk memastikan validitas koordinat & legalitas sebelum masuk basis permanen.",
              ],
              strategicRecs: [
                "Petakan wilayah dengan konsentrasi objek baru tertinggi untuk prioritas alokasi tim survei berikutnya.",
              ],
              dataNotes: ["Akumulasi tahun berjalan, pembaruan real-time."],
            }}
          />
        </div>

        </div>
      </div>

      <div className="flex flex-col gap-2">
        <TextApp id="label-aktivitas-validasi-heading" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted">
          Aktivitas & Validasi
        </TextApp>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 items-stretch">

        {/* 3. Jumlah Validasi - Yellow Clay */}
        <div className="col-span-1 sm:col-span-1 lg:col-span-1 xl:col-span-1 flex flex-col h-full">
          <ScorecardApp
            id="card-jumlah-validasi"
            variant="clayYellow"
            title="Jumlah Validasi"
            value={liveValidasi}
            live
            unit="Berkas Validated"
            description="Tervalidasi oleh Petugas & Tim Evaluasi"
            trend={{
              value: "+15.1%",
              label: "Laju Validasi",
              isPositive: true,
              direction: "up",
            }}
            icon={<CheckCircle2 className="w-5 h-5 text-[#5c4300] dark:text-amber-300" />}
            infoTooltip="Berkas pendataan yang telah lulus pemeriksaan administratif dan data teknis."
            infoContent={{
              formula: "Berkas pendataan yang lulus pemeriksaan administratif & data teknis oleh tim evaluasi",
              period: "Tahunan (YTD)",
              source: "SIMPAD — Modul Validasi Pendataan",
              lastUpdated: "5 menit lalu",
            }}
            insight={{
              title: "Jumlah Validasi",
              value: "14.890 Berkas",
              status: "sehat",
              meta: ["Indikator", "Tim Validasi", "TA 2026"],
              summary: "Jumlah Validasi mengukur berkas pendataan yang telah lulus pemeriksaan administratif dan data teknis oleh petugas & tim evaluasi.",
              current: [
                "Realisasi 14.890 berkas tervalidasi, tumbuh 15,1% — laju tercepat di antara metrik aktivitas pendataan.",
                "42 berkas masih pending validasi menunggu giliran pemeriksaan tim.",
              ],
              insights: [
                "Laju validasi 15,1% melampaui laju objek baru (12,4%) — backlog validasi cenderung menyusut.",
              ],
              tacticalRecs: [
                "Prioritaskan 42 berkas pending agar tidak menumpuk melewati SLA internal.",
              ],
              strategicRecs: [
                "Evaluasi kapasitas tim validasi untuk mempertahankan laju yang melampaui laju objek baru.",
              ],
              dataNotes: ["Akumulasi tahun berjalan, pembaruan real-time."],
            }}
          />
        </div>

        {/* 4. Jumlah Survei Lapangan - Default White */}
        <div className="col-span-1 sm:col-span-1 lg:col-span-1 xl:col-span-1 flex flex-col h-full">
          <ScorecardApp
            id="card-survei-lapangan"
            variant="default"
            title="Jumlah Survei Lapangan"
            value={liveSurveiLapangan}
            live
            unit="Titik Field Check"
            description="Pemeriksaan fisik & koordinat lokasi NOP"
            trend={{
              value: "+5.8%",
              label: "Bulan Berjalan",
              isPositive: true,
              direction: "up",
            }}
            icon={<MapPin className="w-5 h-5 text-purple-600" />}
            infoTooltip="Hasil peninjauan lapangan langsung oleh tim surveyor BPKAD dengan tagging koordinat."
            infoContent={{
              formula: "Titik hasil peninjauan lapangan langsung oleh tim surveyor BPKAD dengan geotagging koordinat",
              period: "Bulan berjalan",
              source: "Aplikasi Survei Lapangan GIS",
              lastUpdated: "10 menit lalu",
            }}
            insight={{
              title: "Jumlah Survei Lapangan",
              value: "1.850 Titik",
              status: "sehat",
              meta: ["Indikator", "Geotagging GIS", "Bulan Berjalan"],
              summary: "Jumlah Survei Lapangan mengukur titik hasil peninjauan lapangan langsung oleh tim surveyor BPKAD, lengkap dengan geotagging koordinat.",
              current: [
                "Realisasi 1.850 titik field check, tumbuh 5,8% bulan berjalan.",
                "Setiap titik survei tercatat dengan koordinat GIS untuk pemetaan spasial.",
              ],
              insights: [
                "Laju survei lapangan (5,8%) lebih lambat dari objek baru (12,4%) — indikasi backlog survei berpotensi menumpuk jika tren berlanjut.",
              ],
              tacticalRecs: [
                "Tambah kapasitas tim surveyor pada wilayah dengan volume objek baru tertinggi.",
              ],
              strategicRecs: [
                "Evaluasi rute survei lapangan agar lebih efisien menutup gap dengan laju objek baru.",
              ],
              dataNotes: ["Akumulasi bulan berjalan, pembaruan real-time."],
            }}
          />
        </div>

        {/* 5. Jumlah Uji Petik - Default White */}
        <div className="col-span-1 sm:col-span-1 lg:col-span-1 xl:col-span-1 flex flex-col h-full">
          <ScorecardApp
            id="card-uji-petik"
            variant="default"
            title="Jumlah Uji Petik"
            value={liveUjiPetik}
            live
            unit="Sample Potensi"
            description="Sampling verifikasi omzet & luas tanah/bangunan"
            trend={{
              value: "+4.2%",
              label: "Target 700 Sample",
              isPositive: true,
              direction: "up",
            }}
            icon={<CheckSquare className="w-5 h-5 text-amber-500" />}
            infoTooltip="Prosedur uji petik audit untuk memastikan kesesuaian omzet nyata dengan data pelaporan."
            infoContent={{
              formula: "Sample yang telah melalui prosedur uji petik audit omzet & luas tanah/bangunan",
              period: "Tahunan (YTD)",
              source: "SIMPAD — Modul Audit Uji Petik",
              lastUpdated: "1 jam lalu",
            }}
            insight={{
              title: "Jumlah Uji Petik",
              value: "620 Sample",
              status: "waspada",
              meta: ["Indikator", "Audit BPKAD", "Target 700 Sample"],
              summary: "Jumlah Uji Petik mengukur sample yang telah melalui prosedur uji petik audit untuk memastikan kesesuaian omzet nyata dengan data pelaporan.",
              current: [
                "Realisasi 620 sample, setara 88,6% dari target 700 sample.",
                "Tumbuh 4,2% — laju pertumbuhan paling lambat di antara metrik aktivitas pendataan.",
              ],
              insights: [
                "Volume uji petik jauh lebih kecil dari validasi (14.890) dan survei (1.850) — wajar mengingat sifatnya sampling, bukan sensus penuh.",
              ],
              tacticalRecs: [
                "Percepat sisa 80 sample menuju target 700 sebelum akhir tahun anggaran.",
              ],
              strategicRecs: [
                "Evaluasi metodologi sampling untuk memastikan representativitas tanpa perlu menaikkan target volume signifikan.",
              ],
              dataNotes: ["Akumulasi tahun berjalan, pembaruan real-time (laju lambat)."],
            }}
          />
        </div>

        {/* 6. Persentase Penyelesaian Pendataan - Default White */}
        <div className="col-span-1 flex flex-col h-full">
          <ScorecardApp
            id="card-persentase-penyelesaian"
            variant="default"
            title="Persentase Penyelesaian Pendataan"
            value="88.4%"
            unit="Penyelesaian Target 2026"
            description="Capaian 131.291 dari 148.520 NOP Terdata"
            progress={{
              value: 88.4,
              max: 100,
              label: "Capaian Target",
              color: CHART_COLORS.purple,
            }}
            trend={{
              value: "+3.2%",
              label: "Kenaikan Bulan Ini",
              isPositive: true,
              direction: "up",
            }}
            icon={<TrendingUp className="w-5 h-5 text-emerald-500" />}
            infoTooltip="Rasio Objek Pajak yang telah selesai dipetakan, divalidasi, dan dimasukkan ke SIMPAD."
            infoContent={{
              formula: "Objek Pajak selesai dipetakan, divalidasi & dimasukkan SIMPAD dibagi total NOP terdata",
              period: "Tahunan (Target 2026)",
              source: "SIMPAD — Modul Pendataan Objek",
              lastUpdated: "5 menit lalu",
            }}
            insight={{
              title: "Persentase Penyelesaian Pendataan",
              value: "88,4% Selesai",
              status: "sehat",
              meta: ["Indikator", "On Schedule", "Target 2026"],
              summary: "Persentase Penyelesaian Pendataan mengukur rasio Objek Pajak yang telah selesai dipetakan, divalidasi, dan dimasukkan ke SIMPAD dibanding total NOP terdata.",
              current: [
                "Realisasi 88,4% (131.291 dari 148.520 NOP), naik 3,2 poin bulan ini.",
                "Status \"On Schedule\" terhadap target penyelesaian TA 2026.",
              ],
              insights: [
                "Kenaikan 3,2 poin per bulan konsisten dengan laju validasi yang tinggi (15,1%) — penyelesaian bergerak sehat menuju 100%.",
              ],
              tacticalRecs: [
                "Pertahankan laju validasi saat ini agar status \"On Schedule\" tidak bergeser jadi tertinggal.",
              ],
              strategicRecs: [
                "Proyeksikan bulan penyelesaian penuh (100%) berdasarkan tren kenaikan 3,2 poin/bulan untuk perencanaan target berikutnya.",
              ],
              dataNotes: ["Snapshot bulanan, dihitung dari rasio validasi terhadap basis NOP terdata."],
            }}
          />
        </div>

        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* SEBARAN & HEATMAP OBJEK PAJAK (grid mosaic, persis referensi   */}
      {/* ZIP) + RANKING KEMANTREN (BR-03 Item 7)                        */}
      {/* ------------------------------------------------------------- */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
        <div className="lg:col-span-2">
          <CardApp
            id="card-map-sebaran-heatmap"
            className="p-5 border-hairline-soft h-full flex flex-col"
            insight={{
              title: "Sebaran Objek Pajak & Heatmap Spasial",
              value: "45 Kelurahan Terpetakan",
              status: "sehat",
              meta: ["Visualisasi", "Kepadatan Objek", "Kota Yogyakarta"],
              summary: "Grid mosaic ini memvisualisasikan tingkat kepadatan Objek Pajak (NOP) per kelurahan di seluruh 45 kelurahan Kota Yogyakarta.",
              current: [
                "Klaster kepadatan tertinggi terkonsentrasi di kawasan Malioboro & Umbulharjo.",
                "Kelurahan dengan kepadatan Sangat Tinggi umumnya berada di kawasan komersial & wisata.",
              ],
              insights: [
                "Kepadatan objek pajak berkorelasi dengan kawasan komersial & wisata — pola ini konsisten dengan sebaran sektor PBJT.",
              ],
              tacticalRecs: [
                "Prioritaskan wilayah dengan kepadatan Sangat Tinggi untuk survei lapangan & uji petik berikutnya.",
              ],
              strategicRecs: [
                "Bangun proyeksi ekstensifikasi berbasis kepadatan objek per kelurahan untuk perencanaan jangka panjang.",
              ],
              dataNotes: ["Snapshot kepadatan objek per kelurahan, pembaruan berkala."],
            }}
          >
            <div className="flex flex-col gap-3 mb-4">
              <div>
                <TextApp id="title-map-section" variant="h3" weight="bold" className="text-ink-primary">
                  Sebaran & Heatmap Objek Pajak
                </TextApp>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="min-w-[180px] flex-1">
                  <SearchBarApp
                    id="search-kelurahan-heatmap"
                    size="sm"
                    rounded="lg"
                    placeholder="Cari Kelurahan..."
                    value={heatmapSearch}
                    onSearchChange={setHeatmapSearch}
                  />
                </div>
                <div className="w-full sm:w-56">
                  <DropdownApp
                    id="select-jenis-pajak-heatmap"
                    size="sm"
                    rounded="lg"
                    value={heatmapSektor}
                    onChange={(value) => setHeatmapSektor(String(value))}
                    options={[
                      { value: "all", label: "Semua Jenis Pajak" },
                      { value: "pbb", label: "PBB-P2" },
                      { value: "pbjt", label: "PBJT" },
                      { value: "bphtb", label: "BPHTB" },
                    ]}
                  />
                </div>
                <div className="flex items-center gap-1 bg-surface-subtle p-1 rounded-full border border-hairline-soft">
                  <button
                    id="btn-heatmap-view-heatmap"
                    type="button"
                    onClick={() => setHeatmapViewMode("heatmap")}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                      heatmapViewMode === "heatmap"
                        ? "bg-vibrant-purple text-white shadow-xs"
                        : "text-ink-secondary hover:text-ink-primary"
                    }`}
                  >
                    <Flame className="w-3.5 h-3.5 inline mr-1" />
                    Heatmap
                  </button>
                  <button
                    id="btn-heatmap-view-tabel"
                    type="button"
                    onClick={() => setHeatmapViewMode("tabel")}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                      heatmapViewMode === "tabel"
                        ? "bg-vibrant-purple text-white shadow-xs"
                        : "text-ink-secondary hover:text-ink-primary"
                    }`}
                  >
                    Tabel
                  </button>
                </div>
              </div>
            </div>

            {heatmapViewMode === "heatmap" ? (
              <div className="grid grid-cols-9 gap-1.5">
                {kelurahanDensityGrid.map((level, index) => (
                  <div
                    key={`density-cell-${index}`}
                    id={`density-cell-${index}`}
                    title={`Level kepadatan: ${level}`}
                    className="aspect-square rounded-md" style={densityLevelStyle(level)}
                  />
                ))}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-hairline-soft text-left text-ink-muted">
                      <th className="py-2 pr-3 font-semibold">Kelurahan</th>
                      <th className="py-2 pr-3 font-semibold">Kecamatan</th>
                      <th className="py-2 font-semibold">Kepadatan</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rankingKelurahanData.map((item, index) => (
                      <tr key={item.name} className="border-b border-hairline-soft/60">
                        <td className="py-2 pr-3 font-medium text-ink">{item.name}</td>
                        <td className="py-2 pr-3 text-ink-secondary">{rankingKecamatanData[index % rankingKecamatanData.length].name}</td>
                        <td className="py-2">
                          <BadgeApp id={`badge-density-${item.name}`} variant="solidAmber" size="sm">
                            {index < 2 ? "Sangat Tinggi" : index < 5 ? "Tinggi" : "Sedang"}
                          </BadgeApp>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            <div className="mt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-ink-secondary">
              <span>45 Kelurahan Kota Yogyakarta</span>
              <div className="flex flex-wrap items-center gap-3">
                <span className="font-semibold">KEPADATAN OBJEK:</span>
                <span className="inline-flex items-center gap-1.5"><span className="h-3 w-3 rounded-full" style={densityLevelStyle(1)} />Rendah</span>
                <span className="inline-flex items-center gap-1.5"><span className="h-3 w-3 rounded-full" style={densityLevelStyle(2)} />Sedang</span>
                <span className="inline-flex items-center gap-1.5"><span className="h-3 w-3 rounded-full" style={densityLevelStyle(3)} />Tinggi</span>
                <span className="inline-flex items-center gap-1.5"><span className="h-3 w-3 rounded-full" style={densityLevelStyle(4)} />Sangat Tinggi</span>
              </div>
            </div>
          </CardApp>
        </div>

        <div className="lg:col-span-1">
          <CardApp
            id="card-ranking-kemantren"
            className="p-5 border-hairline-soft h-full flex flex-col"
            insight={{
              title: "Ranking Kemantren",
              value: "Umbulharjo Tertinggi",
              status: "sehat",
              meta: ["Visualisasi", "Volume NOP", "Kota Yogyakarta"],
              summary: "Ranking Kemantren membandingkan volume Objek Pajak terdata di 8 kemantren (kecamatan) Kota Yogyakarta.",
              current: [
                "Kemantren Umbulharjo memimpin dengan 22.450 NOP.",
                "Kemantren Kotagede berada di posisi terendah dengan 10.800 NOP.",
              ],
              insights: [
                "Distribusi volume NOP antar kemantren relatif proporsional dengan luas wilayah & kepadatan komersial masing-masing.",
              ],
              tacticalRecs: [
                "Fokuskan tambahan sumber daya pendataan ke Kotagede & Mantrijeron yang volumenya paling rendah.",
              ],
              strategicRecs: [
                "Gunakan pola distribusi ini sebagai basis alokasi anggaran survei lapangan tahun berikutnya.",
              ],
              dataNotes: ["Snapshot basis data per kemantren."],
            }}
          >
            <TextApp id="title-ranking-kemantren" variant="h4" weight="bold" className="text-ink-primary mb-4">
              Ranking Kemantren
            </TextApp>

            <div className="space-y-3">
              {rankingKecamatanData.slice(0, 5).map((item) => {
                const maxNOP = rankingKecamatanData[0].totalNOP;
                const pct = Math.round((item.totalNOP / maxNOP) * 100);
                return (
                  <div key={item.name} id={`bar-kemantren-${item.name}`}>
                    <TextApp id={`label-kemantren-${item.name}`} variant="caption" className="text-ink-secondary mb-1">
                      Kec. {item.name}
                    </TextApp>
                    <div className="h-2.5 w-full overflow-hidden rounded-full bg-black/10 dark:bg-white/15">
                      <div
                        className="h-full rounded-full"
                        style={{ width: `${pct}%`, backgroundColor: CHART_COLORS.blue }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-5 space-y-2">
              {rankingKecamatanData.slice(0, 3).map((item, index) => (
                <div
                  key={`top-${item.name}`}
                  id={`top-kemantren-${index + 1}`}
                  className="flex items-center justify-between rounded-lg bg-surface-subtle px-3 py-2"
                >
                  <TextApp id={`top-kemantren-label-${index + 1}`} variant="caption" weight="bold" className="text-ink">
                    {index + 1}. Kec. {item.name}
                  </TextApp>
                  <TextApp id={`top-kemantren-value-${index + 1}`} variant="caption" weight="bold" className="font-mono text-ink">
                    {item.totalNOP.toLocaleString("id-ID")}
                  </TextApp>
                </div>
              ))}
            </div>
          </CardApp>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* PETA SPASIAL OBJEK PAJAK (BR-03 Item 8 "Map (Heatmap)")        */}
      {/* Melengkapi mosaic di atas: mosaic = agregat kepadatan per      */}
      {/* kelurahan, peta = posisi geografis objek per NOP.              */}
      {/* ------------------------------------------------------------- */}
      <CardApp
        id="card-map-spasial-objek"
        className="p-5 border-hairline-soft"
        insight={{
          title: "Peta Spasial Objek Pajak",
          value: "148.520 NOP Terpetakan",
          status: "sehat",
          meta: ["GIS", "Koordinat NOP", "Kota Yogyakarta"],
          summary:
            "Peta ini menampilkan posisi geografis Objek Pajak hasil pendataan lapangan, lengkap dengan koordinat NOP dan status validasinya. Berbeda dengan grid mosaic yang meringkas kepadatan per kelurahan, peta menjawab pertanyaan 'objek mana persisnya, di titik mana'.",
          current: [
            "Titik sampel yang ditampilkan mewakili objek dengan status berbeda: tervalidasi, objek baru, ground check selesai, uji petik, dan perlu validasi.",
          ],
          insights: [
            "Konsentrasi objek bernilai tinggi mengikuti koridor Malioboro - Tugu - Umbulharjo, sejalan dengan pola kepadatan pada grid mosaic.",
          ],
          tacticalRecs: [
            "Gunakan peta untuk menyusun rute survei lapangan per petugas supaya kunjungan dalam satu hari saling berdekatan.",
          ],
          strategicRecs: [
            "Integrasikan koordinat NOP dengan peta zona nilai tanah (ZNT) untuk mendeteksi objek yang nilainya belum diperbarui.",
          ],
          glossary: [
            { term: "NOP", expansion: "Nomor Objek Pajak", definition: "identitas unik tiap objek pajak daerah." },
          ],
          dataNotes: ["Titik pada peta adalah sampel representatif, bukan seluruh 148.520 NOP."],
        }}
      >
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <div>
            <TextApp id="title-map-spasial" variant="h3" weight="bold" className="text-ink-primary">
              Peta Spasial Objek Pajak
            </TextApp>
            <TextApp id="sub-map-spasial" variant="body" className="text-xs text-ink-secondary">
              Posisi geografis Objek Pajak hasil pendataan lapangan — klik penanda untuk detail NOP.
            </TextApp>
          </div>
          <BadgeApp id="badge-map-spasial" variant="neutral" size="sm">
            <MapIcon className="mr-1 inline h-3.5 w-3.5" />
            GIS Spasial
          </BadgeApp>
        </div>

        <div className="h-[420px] w-full overflow-hidden rounded-xl border border-hairline-soft">
          <MapsApp
            id="map-pendataan-spasial"
            center={[-7.7956, 110.3695]}
            zoom={13}
            markers={mockSpatialMarkers}
            tileProvider="openstreetmap"
            showControls
            className="h-full w-full"
          />
        </div>
      </CardApp>

      {/* ------------------------------------------------------------- */}
      {/* CHARTS SECTION (BR-03 Items 9, 10, 11)                        */}
      {/* Clean titles, thick bars for ranking charts                   */}
      {/* ------------------------------------------------------------- */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Item 9: Progress Pendataan Bulanan */}
        <div className="lg:col-span-1 flex flex-col">
          <CardApp
            id="card-chart-progress-pendataan"
            className="p-5 border-hairline-soft h-full flex flex-col justify-between"
            insight={{
              title: "Progress Pendataan Bulanan",
              value: "14.850 / 14.500 NOP (Jul)",
              status: "sehat",
              meta: ["Visualisasi", "Tren Bulanan", "TA 2026"],
              summary: "Progress Pendataan Bulanan membandingkan target vs realisasi pendataan NOP tiap bulan sepanjang TA 2026.",
              current: [
                "Realisasi Juli 2026 melampaui target (14.850 vs target 14.500).",
                "Sejak Agustus tren realisasi mulai di bawah target — perlu diwaspadai menuju akhir tahun.",
              ],
              insights: [
                "Paruh pertama tahun (Jan-Jul) konsisten realisasi ≥ target; paruh kedua menunjukkan tren melambat.",
              ],
              tacticalRecs: [
                "Investigasi penyebab perlambatan realisasi sejak Agustus untuk koreksi cepat.",
              ],
              strategicRecs: [
                "Revisi proyeksi target Q4 berdasarkan tren realisasi aktual paruh kedua tahun.",
              ],
              dataNotes: ["Data bulanan Jan-Des 2026."],
            }}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <TextApp id="title-chart-progress" variant="h4" weight="bold" className="text-ink-primary">
                  Progress Pendataan Bulanan
                </TextApp>
                <BadgeApp id="badge-chart-progress" variant="solidPurple" size="sm">Jan - Des 2026</BadgeApp>
              </div>
              <TextApp id="sub-chart-progress" variant="caption" className="text-ink-secondary mb-4">
                Perbandingan Target vs Realisasi Pendataan NOP
              </TextApp>
            </div>

            <div className="h-[280px] w-full">
              <ChartApp
                id="chart-progress-pendataan"
                // Spec BR-03 no. 9 meminta Line Chart, bukan area.
                type="line"
                data={progressPendataanData}
                xKey="month"
                series={[
                  { key: "target", label: "Target NOP", color: CHART_TARGET_COLOR },
                  { key: "realisasi", label: "Realisasi NOP", color: CHART_COLORS.purple },
                ]}
                showGrid={true}
                showTooltip={true}
                showLegend={true}
              />
            </div>
          </CardApp>
        </div>

        {/* Item 10: Ranking Kecamatan (Thick bars) */}
        <div className="lg:col-span-1 flex flex-col">
          <CardApp
            id="card-chart-ranking-kecamatan"
            className="p-5 border-hairline-soft h-full flex flex-col justify-between"
            insight={{
              title: "Ranking Kecamatan",
              value: "Umbulharjo Tertinggi",
              status: "sehat",
              meta: ["Visualisasi", "Volume NOP", "Kota Yogyakarta"],
              summary: "Ranking Kecamatan membandingkan volume Objek Pajak terdata dan yang sudah tervalidasi di 8 kecamatan Kota Yogyakarta.",
              current: [
                "Kecamatan Umbulharjo memimpin dengan 22.450 NOP, 20.100 di antaranya tervalidasi (89,5%).",
                "Kotagede berada di posisi terendah dengan 10.800 NOP.",
              ],
              insights: [
                "Rasio tervalidasi:total relatif konsisten (~88-90%) di seluruh kecamatan — tidak ada kecamatan yang tertinggal signifikan dalam validasi.",
              ],
              tacticalRecs: [
                "Fokuskan tambahan sumber daya pendataan ke Kotagede & Mantrijeron yang volumenya paling rendah.",
              ],
              strategicRecs: [
                "Gunakan pola distribusi ini sebagai basis alokasi anggaran survei lapangan tahun berikutnya.",
              ],
              dataNotes: ["Snapshot basis data per kecamatan."],
            }}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <TextApp id="title-chart-kecamatan" variant="h4" weight="bold" className="text-ink-primary">
                  Ranking Kecamatan
                </TextApp>
                <BadgeApp id="badge-chart-kecamatan" variant="solidAmber" size="sm">Volume NOP</BadgeApp>
              </div>
              <TextApp id="sub-chart-kecamatan" variant="caption" className="text-ink-secondary mb-4">
                Kecamatan dengan Jumlah Objek Pajak Terdata
              </TextApp>
            </div>

            <div className="h-[280px] w-full">
              <ChartApp
                id="chart-ranking-kecamatan"
                type="bar"
                data={rankingKecamatanData}
                xKey="name"
                barSize={24}
                series={[
                  { key: "totalNOP", label: "Total NOP", color: CHART_COLORS.purple },
                  { key: "tervalidasi", label: "Tervalidasi", color: CHART_COLORS.emerald },
                ]}
                showGrid={true}
                showTooltip={true}
                showLegend={true}
              />
            </div>
          </CardApp>
        </div>

        {/* Item 11: Ranking Kelurahan (Thick bars) */}
        <div className="lg:col-span-1 flex flex-col">
          <CardApp
            id="card-chart-ranking-kelurahan"
            className="p-5 border-hairline-soft h-full flex flex-col justify-between"
            insight={{
              title: "Ranking Kelurahan",
              value: "Sosromenduran Tertinggi (94,2%)",
              status: "sehat",
              meta: ["Visualisasi", "% Penyelesaian", "Top 8 Kelurahan"],
              summary: "Ranking Kelurahan menampilkan Top 8 kelurahan dengan capaian persentase penyelesaian pendataan tertinggi di Kota Yogyakarta.",
              current: [
                "Sosromenduran memimpin dengan capaian 94,2% (4.850 NOP).",
                "Tahunan berada di posisi ke-8 dengan capaian 86,0% (3.120 NOP) — masih di atas rata-rata kota.",
              ],
              insights: [
                "Selisih capaian antar top 8 kelurahan relatif tipis (86%-94%), menunjukkan pemerataan kualitas pendataan di kelurahan-kelurahan terdepan.",
              ],
              tacticalRecs: [
                "Jadikan praktik pendataan Sosromenduran sebagai acuan (best practice) untuk kelurahan dengan capaian lebih rendah.",
              ],
              strategicRecs: [
                "Bandingkan kelurahan top 8 ini dengan kelurahan capaian terendah untuk identifikasi hambatan sistemik.",
              ],
              dataNotes: ["Snapshot capaian per kelurahan, top 8 dari 45 kelurahan."],
            }}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <TextApp id="title-chart-kelurahan" variant="h4" weight="bold" className="text-ink-primary">
                  Top Kelurahan
                </TextApp>
                <BadgeApp id="badge-chart-kelurahan" variant="solidAmber" size="sm">Jumlah NOP</BadgeApp>
              </div>
              <TextApp id="sub-chart-kelurahan" variant="caption" className="text-ink-secondary mb-4">
                Top Kelurahan dengan Capaian Pendataan Tertinggi
              </TextApp>
            </div>

            <div className="h-[200px] w-full">
              <ChartApp
                id="chart-ranking-kelurahan"
                type="pie"
                data={rankingKelurahanData.slice(0, 5).map((item) => ({ name: item.name, value: item.totalNOP, fill: item.fill }))}
                pieValueKey="value"
                pieNameKey="name"
                showTooltip={true}
                showLegend={true}
              />
            </div>

            <div className="mt-3 space-y-1.5">
              {rankingKelurahanData.slice(0, 3).map((item) => (
                <div key={`top-kelurahan-${item.name}`} className="flex items-center justify-between text-xs">
                  <TextApp id={`top-kelurahan-label-${item.name}`} variant="caption" weight="bold" className="text-ink">{item.name}</TextApp>
                  <span className="font-mono text-ink-secondary">{item.totalNOP.toLocaleString("id-ID")}</span>
                  <span className="font-mono font-bold text-success">{item.percentage}%</span>
                </div>
              ))}
            </div>
          </CardApp>
        </div>

      </div>

      {/* ------------------------------------------------------------- */}
      {/* DATA TABLE REKAPITULASI OBJEK PAJAK                           */}
      {/* ------------------------------------------------------------- */}
      <CardApp id="card-table-pendataan-objek" className="p-5 border-hairline-soft">
        <DataTableApp
          id="datatable-pendataan-objek"
          title="Daftar Objek Pajak Hasil Pendataan & Ground Check"
          description="Detail Rekam Pendataan Objek Pajak, Koordinat GIS, Status Validasi, & Tim Field Check"
          toolbarLayout="singleRow"
          data={livePendataanRecords}
          newRowIds={newPendataanRecordIds}
          getRowId={(row) => row.id}
          columns={tableColumns}
          searchPlaceholder="Cari NOP, Wajib Pajak, Petugas, atau Kelurahan..."
          pageSize={5}
        />
      </CardApp>

      {/* ------------------------------------------------------------- */}
      {/* DETAIL DIALOG MODAL (Portalled by DialogApp)                   */}
      {/* ------------------------------------------------------------- */}
      {selectedRecord && (
        <DialogApp
          id="dialog-detail-pendataan-nop"
          isOpen={isDetailDialogOpen}
          onClose={() => setIsDetailDialogOpen(false)}
          title={`Detail Objek Pajak: ${selectedRecord.nop}`}
          description="Informasi hasil pendataan geospasial dan status verifikasi lapangan."
          size="lg"
        >
          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-3 p-3 bg-surface-subtle rounded-xl border border-hairline-soft">
              <div>
                <span className="text-ink-secondary block">Nama Wajib Pajak:</span>
                <span className="font-bold text-ink-primary">{selectedRecord.namaWajibPajak}</span>
              </div>
              <div>
                <span className="text-ink-secondary block">Sektor Pajak:</span>
                <BadgeApp id="badge-dlg-sektor" variant="solidPurple" size="sm">{selectedRecord.sektor}</BadgeApp>
              </div>
              <div>
                <span className="text-ink-secondary block">Wilayah Administratif:</span>
                <span className="font-medium text-ink-primary">Kec. {selectedRecord.kecamatan}, Kel. {selectedRecord.kelurahan}</span>
              </div>
              <div>
                <span className="text-ink-secondary block">Status Pendataan:</span>
                <BadgeApp id="badge-dlg-status" variant="solidEmerald" size="sm">{selectedRecord.status}</BadgeApp>
              </div>
            </div>

            <div className="p-3 border border-hairline-soft rounded-xl space-y-2">
              <div className="font-semibold text-ink-primary flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-vibrant-purple" />
                <span>Geotagging Spasial GIS</span>
              </div>
              <p className="text-ink-secondary font-mono">
                Koordinat Lat/Lng: <span className="text-ink-primary font-bold">{selectedRecord.koordinat}</span>
              </p>
              <p className="text-ink-secondary">
                Petugas Field Check: <span className="text-ink-primary font-medium">{selectedRecord.petugas}</span> ({selectedRecord.tglSurvei})
              </p>
              <p className="text-ink-secondary">
                Status Sampling Uji Petik: <span className="font-semibold text-purple-700">{selectedRecord.ujiPetik}</span>
              </p>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <ButtonApp
                id="btn-close-detail-dialog"
                variant="purpleDark"
                theme="default"
                size="sm"
                rounded="pill"
                onClick={() => setIsDetailDialogOpen(false)}
              >
                Tutup Detail
              </ButtonApp>
            </div>
          </div>
        </DialogApp>
      )}
    </div>
  );
}

export default DataCollectionDashboardPage;
