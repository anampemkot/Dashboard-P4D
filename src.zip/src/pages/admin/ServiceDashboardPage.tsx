import * as React from "react";
import {
  ScorecardApp,
  CardApp,
  BadgeApp,
  ButtonApp,
  TextApp,
  DataTableApp,
  ChartApp,
  TimelineApp,
  useToastApp,
  useRealtimeValue,
  useRealtimeRows,
  DialogApp,
  DropdownApp,
  AdvanceFilterApp,
  FilterFieldConfig,
} from "@/packages/design-system";
import {
  Clock,
  Users,
  CheckCircle2,
  Activity,
  RefreshCw,
  Download,
  Calendar,
  Monitor,
  Building2,
  Zap,
  UserPlus,
  FileText,
  Banknote,
  ClipboardCheck,
  RefreshCcw,
  Timer,
  Filter,
  Headphones,
  ClipboardList,
  XCircle,
} from "lucide-react";
import { CHART_COLORS, CHART_TARGET_COLOR } from "@/constants/chartColors";

// Types for Service Queue / Application Data
interface ServiceQueueItem {
  id: string;
  nomorAntrean: string;
  namaPemohon: string;
  jenisLayanan: string;
  kanal: "Online" | "Loket PTSP";
  waktuMasuk: string;
  durasiPelayanan: string;
  petugas: string;
  status: "Selesai" | "Dalam Proses" | "Menunggu SLA" | "Terlambat";
  slaTime: string;
}

// Grafik Realisasi vs Target Pendapatan — data bulanan persis referensi ZIP.
const pendapatanRealisasiVsTargetData = [
  { name: "Jan", realisasi: 4000, target: 4500 },
  { name: "Feb", realisasi: 3000, target: 3500 },
  { name: "Mar", realisasi: 9800, target: 5000 },
  { name: "Apr", realisasi: 3908, target: 4000 },
  { name: "Mei", realisasi: 4800, target: 4500 },
  { name: "Jun", realisasi: 3800, target: 4000 },
  { name: "Jul", realisasi: 4300, target: 4500 },
];

// Sparkline "Jumlah Pelayanan" — volume 7 hari terakhir.
const pelayananWeeklyTrend = [
  { name: "Sen", value: 620 },
  { name: "Sel", value: 760 },
  { name: "Rab", value: 540 },
  { name: "Kam", value: 810 },
  { name: "Jum", value: 700 },
  { name: "Sab", value: 1010 },
  { name: "Min", value: 880 },
];

// Realtime queue feed generator — pola sama seperti useRealtimeRows di halaman lain.
const SRV_PEMOHON_POOL = [
  "Hendra Wijaya, S.E.", "PT Malioboro Perdana", "Siti Nurjanah", "CV Jogja Kreatif Media",
  "Dr. Agung Laksono", "Bambang Susilo", "Rina Kartika, S.H.", "UD Sumber Rejeki",
];
const SRV_LAYANAN_POOL = [
  "Mutasi / Salinan PBB-P2", "Validasi Setoran BPHTB", "Pendaftaran PBJT Restoran",
  "Permohonan Izin Reklame", "Surat Keterangan Bebas Tunggakan",
];
const SRV_PETUGAS_LOKET_POOL = ["Rina Setyowati (Loket 1)", "Budi Santoso (Loket 2)", "Dewi Lestari (Loket 3)"];
const SRV_STATUS_POOL: ServiceQueueItem["status"][] = ["Selesai", "Dalam Proses", "Menunggu SLA"];

function generateNextServiceQueueItem(): ServiceQueueItem {
  const now = new Date();
  const seq = `${now.getTime().toString().slice(-6)}${Math.floor(Math.random() * 900) + 100}`;
  const isOnline = Math.random() > 0.5;
  const status = SRV_STATUS_POOL[Math.floor(Math.random() * SRV_STATUS_POOL.length)];
  return {
    id: `SRV-2026-${seq}`,
    nomorAntrean: isOnline ? `E-${Math.floor(Math.random() * 900) + 100}` : `A-${Math.floor(Math.random() * 90) + 10}`,
    namaPemohon: SRV_PEMOHON_POOL[Math.floor(Math.random() * SRV_PEMOHON_POOL.length)],
    jenisLayanan: SRV_LAYANAN_POOL[Math.floor(Math.random() * SRV_LAYANAN_POOL.length)],
    kanal: isOnline ? "Online" : "Loket PTSP",
    waktuMasuk: now.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", second: "2-digit" }) + " WIB",
    durasiPelayanan: `${Math.floor(Math.random() * 20) + 5} Menit`,
    petugas: isOnline ? "Sistem Verifikasi Otomatis" : SRV_PETUGAS_LOKET_POOL[Math.floor(Math.random() * SRV_PETUGAS_LOKET_POOL.length)],
    status,
    slaTime: status === "Menunggu SLA" ? "Mendekati Batas SLA" : `Sesuai SLA (≤${isOnline ? 15 : 30}m)`,
  };
}

export default function ServiceDashboardPage() {
  const { toast } = useToastApp();
  const [isSyncing, setIsSyncing] = React.useState(false);
  const [lastUpdate, setLastUpdate] = React.useState("27 Juli 2026, 19:45:00 WIB");
  const [selectedPeriod, setSelectedPeriod] = React.useState("2026");

  // Detail Modal State
  const [detailModalOpen, setDetailModalOpen] = React.useState(false);
  const [modalTitle, setModalTitle] = React.useState("");
  const [modalData, setModalData] = React.useState<any>(null);

  // Advance Filter State
  const [advanceFilterValues, setAdvanceFilterValues] = React.useState<Record<string, any>>({
    kanalPelayanan: "semua",
    jenisLayanan: ["pbb", "bphtb", "pbjt"],
    statusSla: "tepat",
    rentangTanggal: { from: "2026-07-01", to: "2026-07-27" },
  });

  // Filter fields configuration
  const filterFields: FilterFieldConfig[] = [
    {
      id: "kanalPelayanan",
      label: "Kanal Pelayanan",
      type: "select",
      placeholder: "-- Semua Kanal --",
      colSpan: 1,
      options: [
        { label: "Semua Kanal", value: "semua" },
        { label: "Online (E-Services)", value: "online" },
        { label: "Loket PTSP Tatap Muka", value: "loket" },
      ],
    },
    {
      id: "statusSla",
      label: "Status SLA Pelayanan",
      type: "select",
      colSpan: 1,
      placeholder: "-- Pilih Status SLA --",
      options: [
        { label: "Sesuai Target SLA (≤ 30 Menit)", value: "tepat" },
        { label: "Mendekati Batas SLA (20-30 Menit)", value: "warning" },
        { label: "Melebihi SLA (> 30 Menit)", value: "over" },
      ],
    },
    {
      id: "jenisLayanan",
      label: "Kategori Layanan Perpajakan & Retribusi",
      type: "multi-select",
      colSpan: 2,
      options: [
        { label: "Mutasi & Salinan PBB-P2", value: "pbb" },
        { label: "Validasi Setoran BPHTB", value: "bphtb" },
        { label: "Pendaftaran Pajak Barang & Jasa (PBJT)", value: "pbjt" },
        { label: "Permohonan Izin Pajak Reklame", value: "reklame" },
        { label: "Surat Keterangan Bebas Tunggakan Pajak", value: "skbt" },
      ],
    },
    {
      id: "rentangTanggal",
      label: "Rentang Tanggal Pelayanan",
      type: "date-range",
      colSpan: 2,
    },
  ];

  // Handler for Syncing Data
  const handleSyncData = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      const now = new Date();
      const formatted = `${now.getDate()} Juli ${now.getFullYear()}, ${String(
        now.getHours()
      ).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}:${String(
        now.getSeconds()
      ).padStart(2, "0")} WIB`;
      setLastUpdate(formatted);
      toast.vibrant("Sinkronisasi Berhasil", {
        description: "Data antrean dan SLA pelayanan publik BPKAD telah diperbarui secara real-time.",
      });
    }, 1200);
  };

  // Handler for Exporting Report
  const handleExportReport = () => {
    toast.vibrant("Laporan Pelayanan Diunduh", {
      description: "Berkas PDF Laporan SLA & Pelayanan Publik BPKAD BR-02 berhasil dirilis.",
    });
  };

  // Handler for Scorecard Info Modal
  const handleOpenMetricInfo = (title: string, data: any) => {
    setModalTitle(title);
    setModalData(data);
    setDetailModalOpen(true);
  };

  // Realtime KPI — mengikuti pola live/statis persis referensi ZIP: 5 metrik
  // running count live (Pelayanan Hari Ini/Bulan Ini/Antrean/Online/Loket),
  // 3 metrik rata-rata/rasio tetap statis (Rata-rata Waktu, SLA, Penyelesaian).
  const livePelayananHariIni = useRealtimeValue({ initialValue: 1248, update: (v) => v + Math.floor(Math.random() * 3) + 1, intervalMs: 8000 });
  const livePelayananBulanIni = useRealtimeValue({ initialValue: 28650, update: (v) => v + Math.floor(Math.random() * 4) + 1, intervalMs: 7000 });
  const liveAntrean = useRealtimeValue({ initialValue: 18, update: (v) => Math.max(4, v + (Math.random() > 0.5 ? 1 : -1)), intervalMs: 6000 });
  const livePelayananOnline = useRealtimeValue({ initialValue: 18420, update: (v) => v + Math.floor(Math.random() * 3) + 1, intervalMs: 9000 });
  const livePelayananLoket = useRealtimeValue({ initialValue: 10230, update: (v) => v + Math.floor(Math.random() * 2), intervalMs: 11000 });
  // Komplemen SLA Pelayanan: 1,6% dari 28.650 berkas = 460 berkas overtime.
  const livePermohonanOvertime = useRealtimeValue({ initialValue: 460, update: (v) => Math.max(300, v + (Math.random() > 0.6 ? 1 : -1)), intervalMs: 10000 });

  // Status Antrean Saat Ini — panel loket, mengikuti struktur referensi ZIP.
  const liveAntreanLoket = useRealtimeValue({ initialValue: 18, update: (v) => Math.max(4, v + (Math.random() > 0.5 ? 1 : -1)), intervalMs: 7000 });
  const liveAntreanOnline = useRealtimeValue({ initialValue: 14, update: (v) => Math.max(2, v + (Math.random() > 0.5 ? 1 : -1)), intervalMs: 8000 });
  const liveLoketA = useRealtimeValue({ initialValue: 45, update: (v) => v + (Math.random() > 0.6 ? 1 : 0), intervalMs: 16000 });
  const liveLoketB = useRealtimeValue({ initialValue: 46, update: (v) => v + (Math.random() > 0.6 ? 1 : 0), intervalMs: 18000 });
  const liveLoketC = useRealtimeValue({ initialValue: 47, update: (v) => v + (Math.random() > 0.6 ? 1 : 0), intervalMs: 17000 });

  const antreanStatusLoket = [
    { id: "loket-a", nama: "Loket A", status: "aktif" as const, nomor: liveLoketA },
    { id: "loket-b", nama: "Loket B", status: "aktif" as const, nomor: liveLoketB },
    { id: "loket-c", nama: "Loket C", status: "aktif" as const, nomor: liveLoketC },
    { id: "loket-d", nama: "Loket D", status: "istirahat" as const, nomor: null },
  ];

  // Aktivitas Terkini — TimelineApp, item & ikon persis referensi ZIP.
  const aktivitasTerkiniItems = [
    { id: "act-1", icon: <UserPlus className="h-4 w-4" />, title: "WP Baru Terdaftar", description: "3 WP baru", timestamp: "08:20 WIB" },
    { id: "act-2", icon: <FileText className="h-4 w-4" />, title: "SKP Diterbitkan", description: "12 SKP", timestamp: "07:55 WIB" },
    { id: "act-3", icon: <Banknote className="h-4 w-4" />, title: "Pembayaran Masuk", description: "Rp 320 Juta", timestamp: "07:40 WIB" },
    { id: "act-4", icon: <ClipboardCheck className="h-4 w-4" />, title: "Permohonan Diproses", description: "5 permohonan", timestamp: "07:15 WIB" },
    { id: "act-5", icon: <RefreshCcw className="h-4 w-4" />, title: "Sinkronisasi Data OP", description: "Berhasil", timestamp: "06:00 WIB" },
  ];

  // -------------------------------------------------------------
  // CHART DATA DEFINITIONS (BR-02 Items 9, 10, 11)
  // -------------------------------------------------------------

  // Item 9: Trend Pelayanan (Line Chart Data)
  const trendPelayananData = [
    { name: "Jan", Online: 2100, Loket: 1450, Total: 3550 },
    { name: "Feb", Online: 2350, Loket: 1380, Total: 3730 },
    { name: "Mar", Online: 2580, Loket: 1520, Total: 4100 },
    { name: "Apr", Online: 2420, Loket: 1310, Total: 3730 },
    { name: "Mei", Online: 2890, Loket: 1600, Total: 4490 },
    { name: "Jun", Online: 3120, Loket: 1540, Total: 4660 },
    { name: "Jul", Online: 3460, Loket: 1430, Total: 4890 },
  ];

  // Item 10: Pie Pelayanan Online vs Loket (Pie/Donut Chart Data)
  const pieOnlineVsLoketData = [
    { name: "Pelayanan Online (E-Services)", value: 18420, fill: CHART_COLORS.purple },
    { name: "Pelayanan Loket PTSP", value: 10230, fill: CHART_COLORS.blue },
  ];

  // Item 11: Jenis Layanan Terbanyak (Bar Chart Data)
  const jenisLayananTerbanyakData = [
    { name: "Mutasi PBB-P2", Jumlah: 8420, fill: CHART_COLORS.purple },
    { name: "Validasi BPHTB", Jumlah: 6850, fill: CHART_COLORS.blue },
    { name: "Pendaftaran PBJT", Jumlah: 4120, fill: CHART_COLORS.emerald },
    { name: "Izin Reklame", Jumlah: 3240, fill: CHART_COLORS.amber },
    { name: "Surat Bebas Pajak", Jumlah: 2680, fill: CHART_COLORS.cyan },
  ];

  // -------------------------------------------------------------
  // TABLE DATA (Daftar Antrean & Permohonan Pelayanan)
  // -------------------------------------------------------------
  const serviceQueueList: ServiceQueueItem[] = [
    {
      id: "SRV-2026-001",
      nomorAntrean: "A-014",
      namaPemohon: "Hendra Wijaya, S.E.",
      jenisLayanan: "Mutasi / Salinan PBB-P2",
      kanal: "Loket PTSP",
      waktuMasuk: "08:15:20 WIB",
      durasiPelayanan: "11 Menit",
      petugas: "Rina Setyowati (Loket 1)",
      status: "Selesai",
      slaTime: "Sesuai SLA (≤30m)",
    },
    {
      id: "SRV-2026-002",
      nomorAntrean: "E-892",
      namaPemohon: "PT Malioboro Perdana",
      jenisLayanan: "Validasi Setoran BPHTB",
      kanal: "Online",
      waktuMasuk: "08:30:10 WIB",
      durasiPelayanan: "8 Menit",
      petugas: "Sistem Verifikasi Otomatis",
      status: "Selesai",
      slaTime: "Sesuai SLA (≤15m)",
    },
    {
      id: "SRV-2026-003",
      nomorAntrean: "A-015",
      namaPemohon: "Siti Nurjanah",
      jenisLayanan: "Pendaftaran PBJT Restoran",
      kanal: "Loket PTSP",
      waktuMasuk: "09:02:45 WIB",
      durasiPelayanan: "18 Menit",
      petugas: "Budi Santoso (Loket 2)",
      status: "Dalam Proses",
      slaTime: "Sesuai SLA (≤30m)",
    },
    {
      id: "SRV-2026-004",
      nomorAntrean: "E-893",
      namaPemohon: "CV Jogja Kreatif Media",
      jenisLayanan: "Permohonan Izin Reklame",
      kanal: "Online",
      waktuMasuk: "09:12:00 WIB",
      durasiPelayanan: "14 Menit",
      petugas: "Tim Verifikasi E-Pajak",
      status: "Selesai",
      slaTime: "Sesuai SLA (≤30m)",
    },
    {
      id: "SRV-2026-005",
      nomorAntrean: "A-016",
      namaPemohon: "Dr. Agung Laksono",
      jenisLayanan: "Surat Keterangan Bebas Tunggakan",
      kanal: "Loket PTSP",
      waktuMasuk: "09:25:30 WIB",
      durasiPelayanan: "22 Menit",
      petugas: "Dewi Lestari (Loket 3)",
      status: "Menunggu SLA",
      slaTime: "Mendekati Batas SLA",
    },
    {
      id: "SRV-2026-006",
      nomorAntrean: "E-894",
      namaPemohon: "Bambang Susilo",
      jenisLayanan: "Mutasi / Salinan PBB-P2",
      kanal: "Online",
      waktuMasuk: "09:40:15 WIB",
      durasiPelayanan: "6 Menit",
      petugas: "Sistem Verifikasi Otomatis",
      status: "Selesai",
      slaTime: "Sesuai SLA (≤15m)",
    },
  ];

  // Realtime feed antrean & permohonan — baris baru masuk dari atas, di-highlight.
  const { rows: liveServiceQueue, newRowIds: newServiceQueueIds } = useRealtimeRows({
    initialRows: serviceQueueList,
    getId: (row) => row.id,
    generate: generateNextServiceQueueItem,
    intervalMs: 9000,
    maxRows: 20,
  });

  const tableColumns = [
    {
      accessorKey: "nomorAntrean",
      header: "No. Antrean",
      cell: (info: any) => (
        <span
          onClick={() =>
            handleOpenMetricInfo(`Detail Permohonan ${info.row.original.id}`, {
              noAntrean: info.row.original.nomorAntrean,
              pemohon: info.row.original.namaPemohon,
              layanan: info.row.original.jenisLayanan,
              kanal: info.row.original.kanal,
              waktu: info.row.original.waktuMasuk,
              durasi: info.row.original.durasiPelayanan,
              petugas: info.row.original.petugas,
              status: info.row.original.status,
              slaTime: info.row.original.slaTime,
            })
          }
          className="font-mono font-bold text-xs text-vibrant-purple bg-vibrant-purple/10 hover:bg-vibrant-purple/20 px-2.5 py-1 rounded-md border border-vibrant-purple/20 inline-block cursor-pointer transition-colors"
        >
          {info.getValue()}
        </span>
      ),
    },
    {
      accessorKey: "namaPemohon",
      header: "Nama Pemohon",
      cell: (info: any) => (
        <div className="flex flex-col">
          <span className="font-bold text-xs text-ink">{info.getValue()}</span>
          <span className="text-[10px] text-ink-muted">{info.row.original.id}</span>
        </div>
      ),
    },
    {
      accessorKey: "jenisLayanan",
      header: "Jenis Layanan",
      cell: (info: any) => (
        <span className="text-xs font-medium text-ink-secondary">{info.getValue()}</span>
      ),
    },
    {
      accessorKey: "kanal",
      header: "Kanal",
      cell: (info: any) => {
        const isOnline = info.getValue() === "Online";
        return (
          <BadgeApp
            id={`badge-kanal-${info.row.original.id}`}
            variant={isOnline ? "solidPurple" : "neutral"}
            size="sm"
            className="flex items-center gap-1.5"
          >
            {isOnline ? <Monitor className="w-3 h-3" /> : <Building2 className="w-3 h-3" />}
            {info.getValue()}
          </BadgeApp>
        );
      },
    },
    {
      accessorKey: "waktuMasuk",
      header: "Waktu Masuk",
      cell: (info: any) => (
        <span className="text-xs font-mono text-ink-secondary">{info.getValue()}</span>
      ),
    },
    {
      accessorKey: "durasiPelayanan",
      header: "Durasi / SLA",
      cell: (info: any) => (
        <div className="flex flex-col">
          <span className="text-xs font-bold text-ink">{info.getValue()}</span>
          <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
            {info.row.original.slaTime}
          </span>
        </div>
      ),
    },
    {
      accessorKey: "status",
      header: "Status Berkas",
      cell: (info: any) => {
        const val = info.getValue();
        let variant: "solidPurple" | "neutral" = "solidPurple";
        if (val === "Dalam Proses") variant = "neutral";
        return (
          <BadgeApp
            id={`badge-status-${info.row.original.id}`}
            variant={variant}
            size="sm"
          >
            {val}
          </BadgeApp>
        );
      },
    },
  ];

  return (
    <div id="service-dashboard-root" className="flex flex-col gap-6 pb-20 select-none">
      {/* ------------------------------------------------------------- */}
      {/* HEADER SECTION: Title, Subtitle, Quick Actions */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col justify-between gap-4 border-b border-hairline-soft pb-4 md:flex-row md:items-center">
        <div>
          <div className="mb-1 flex flex-wrap items-center gap-x-3 gap-y-1.5">
            <BadgeApp id="badge-service-dashboard" variant="solidPurple" size="sm">
              BR-02 · Dashboard Pelayanan
            </BadgeApp>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <Activity className="h-3.5 w-3.5 animate-pulse text-emerald-500" />
              Real-time Feed <strong className="font-mono font-semibold text-ink-secondary">{lastUpdate}</strong>
            </span>
          </div>
          <TextApp id="title-service-dashboard" variant="h2" className="tracking-tight text-ink">
            Monitoring Pelayanan & SLA BPKAD
          </TextApp>
          <TextApp id="subtitle-service-dashboard" variant="body" className="text-xs text-ink-secondary">
            Integrasi Layanan Loket PTSP & Portal E-Services Perpajakan Daerah Kota Yogyakarta
          </TextApp>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <ButtonApp
            id="btn-sync-service-data"
            variant="secondary"
            size="sm"
            rounded="lg"
            onClick={handleSyncData}
            disabled={isSyncing}
            leftIcon={<RefreshCw className={`h-3.5 w-3.5 ${isSyncing ? "animate-spin text-vibrant-purple" : ""}`} />}
          >
            {isSyncing ? "Menyinkronkan..." : "Sync Data"}
          </ButtonApp>
          <ButtonApp
            id="btn-export-service-report"
            variant="primary"
            size="sm"
            rounded="lg"
            leftIcon={<Download className="h-3.5 w-3.5" />}
            onClick={handleExportReport}
          >
            Cetak Laporan
          </ButtonApp>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* FILTER BAR */}
      {/* ------------------------------------------------------------- */}
      <div className="flex w-full min-w-0 flex-nowrap items-center gap-2 overflow-x-auto rounded-2xl border border-hairline bg-surface px-3 py-3 shadow-xs">
        <span className="flex shrink-0 items-center gap-1.5 whitespace-nowrap text-xs font-semibold text-ink-secondary">
          <Filter className="h-4 w-4 text-vibrant-purple" />
          Filter:
        </span>

        <div className="w-44 shrink-0">
          <DropdownApp
            id="select-period-filter"
            value={selectedPeriod}
            onChange={(value) => setSelectedPeriod(String(value))}
            options={[
              { label: "Tahun 2026", value: "2026" },
              { label: "Bulan Juli 2026", value: "juli" },
              { label: "Hari Ini", value: "today" },
            ]}
            size="sm"
            rounded="lg"
            menuPortal
          />
        </div>

        <div className="ml-auto shrink-0">
          <AdvanceFilterApp
            id="advance-filter-service"
            displayMode="modal"
            showActivePills={false}
            className="w-auto"
            triggerLabel="Advance Filter Pelayanan"
            triggerVariant="secondary"
            triggerSize="sm"
            triggerRounded="lg"
            fields={filterFields}
            values={advanceFilterValues}
            onChange={setAdvanceFilterValues}
            onApply={() => {
              toast.vibrant("Filter Berhasil Diterapkan", {
                description: "Menampilkan metrics pelayanan berdasarkan kriteria yang dipilih.",
              });
            }}
          />
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* BENTO GRID: 8 SCORECARDS (BR-02 METRICS 1 THROUGH 8) */}
      {/* STRICT RULE: NO PREFIXED NUMBERS IN CARD TITLES */}
      {/* 2 baris kartu tanpa chart pendamping -> heading kategori per baris,
          mengikuti pola SectionTitle referensi ZIP. */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col gap-2">
        <TextApp id="label-indikator-utama-heading" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted">
          Indikator Utama
        </TextApp>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 items-stretch">

        {/* 1. Jumlah Pelayanan Hari Ini - Purple Clay */}
        <div className="col-span-1 sm:col-span-1 lg:col-span-1 xl:col-span-1 flex flex-col h-full">
          <ScorecardApp
            id="card-pelayanan-hari-ini"
            variant="clayPurple"
            title="Jumlah Pelayanan Hari Ini"
            value={livePelayananHariIni}
            live
            unit="Berkas Masuk"
            description="Online: 812 | Loket PTSP: 436"
            trend={{
              value: "+14.2%",
              label: "vs Kemarin",
              isPositive: true,
              direction: "up",
            }}
            icon={<Activity className="w-5 h-5 text-white" />}
            infoTooltip="Total berkas pelayanan perpajakan dan retribusi yang diterima hari ini."
            infoContent={{
              formula: "Total berkas pelayanan perpajakan & retribusi yang diterima hari ini (online + loket)",
              period: "Harian (real-time)",
              source: "SIMPATDA — Modul Pelayanan PTSP",
              lastUpdated: "Baru saja",
            }}
            insight={{
              title: "Jumlah Pelayanan Hari Ini",
              value: "1.248 Berkas",
              status: "sehat",
              meta: ["Indikator", "Volume Harian", "Juli 2026"],
              summary: "Jumlah Pelayanan Hari Ini mengukur total berkas pelayanan perpajakan & retribusi yang diterima BPKAD hari ini, gabungan kanal online dan loket PTSP tatap muka.",
              current: [
                "Realisasi hari ini 1.248 berkas, tumbuh 14,2% dibanding kemarin.",
                "Komposisi: 812 berkas online (65%), 436 berkas loket PTSP (35%).",
              ],
              insights: [
                "Dominasi kanal online konsisten dengan tren digitalisasi layanan pajak daerah — porsi online terus menggeser volume loket.",
              ],
              tacticalRecs: [
                "Pantau kapasitas loket saat volume harian melonjak agar antrean tidak menumpuk.",
              ],
              strategicRecs: [
                "Evaluasi kanal online yang paling sering dipakai untuk prioritas pengembangan fitur e-services berikutnya.",
              ],
              dataNotes: ["Snapshot real-time harian, pembaruan berkala."],
            }}
          />
        </div>

        {/* 2. Jumlah Pelayanan Online - Blue Clay */}
        <div className="col-span-1 sm:col-span-1 lg:col-span-1 xl:col-span-1 flex flex-col h-full">
          <ScorecardApp
            id="card-pelayanan-online"
            variant="clayBlue"
            title="Jumlah Pelayanan Online"
            value={livePelayananOnline}
            live
            unit="E-Services (64.3%)"
            description="Portal E-Pajak & Mobile Web"
            trend={{
              value: "+18.4%",
              label: "Pertumbuhan E-Services",
              isPositive: true,
              direction: "up",
            }}
            icon={<Monitor className="w-5 h-5 text-[#1e3a8a] dark:text-blue-200" />}
            infoTooltip="Jumlah transaksi/permohonan melalui portal online tanpa tatap muka."
            infoContent={{
              formula: "Jumlah transaksi/permohonan melalui Portal E-Pajak & Mobile Web tanpa tatap muka",
              period: "Harian (real-time)",
              source: "Portal E-Pajak — Modul E-Services",
              lastUpdated: "Baru saja",
            }}
            insight={{
              title: "Jumlah Pelayanan Online",
              value: "18.420 Transaksi",
              status: "sehat",
              meta: ["Indikator", "Kanal Digital", "Juli 2026"],
              summary: "Jumlah Pelayanan Online mengukur volume transaksi/permohonan yang diselesaikan lewat Portal E-Pajak & Mobile Web BPKAD tanpa tatap muka, setara 64,3% dari total pelayanan bulan ini.",
              current: [
                "Realisasi 18.420 transaksi online, tumbuh 18,4% — pertumbuhan tercepat di antara kedua kanal.",
                "Porsi online (64,3%) sudah melampaui loket PTSP (35,7%), menandakan pergeseran preferensi kanal.",
              ],
              insights: [
                "Pertumbuhan online yang jauh lebih cepat dari loket mengindikasikan adopsi digital berjalan baik dan mengurangi beban tatap muka.",
              ],
              tacticalRecs: [
                "Pantau uptime & kapasitas server Portal E-Pajak menjelang periode volume tinggi.",
              ],
              strategicRecs: [
                "Investasi lanjutan pada UX Portal E-Pajak untuk mempercepat migrasi sisa 35,7% pengguna loket.",
              ],
              dataNotes: ["Akumulasi bulan berjalan, pembaruan real-time."],
            }}
          />
        </div>

        {/* 3. Jumlah Antrean - Yellow Clay */}
        <div className="col-span-1 sm:col-span-1 lg:col-span-1 xl:col-span-1 flex flex-col h-full">
          <ScorecardApp
            id="card-jumlah-antrean"
            variant="clayYellow"
            title="Jumlah Antrean Saat Ini"
            value={liveAntrean}
            live
            unit="Orang Menunggu"
            description="Loket 1: 4 | Loket 2: 5 | Loket 3: 3 | Loket 4: 6"
            trend={{
              value: "-8.2%",
              label: "vs Kemarin",
              isPositive: true,
              direction: "down",
            }}
            icon={<Users className="w-5 h-5 text-[#5c4300] dark:text-amber-300" />}
            infoTooltip="Jumlah pemohon yang sedang menunggu antrean di ruang tunggu PTSP saat ini."
            infoContent={{
              formula: "Jumlah pemohon yang sedang menunggu di ruang tunggu PTSP, terdistribusi ke 4 loket",
              period: "Real-time",
              source: "Sistem Antrean PTSP",
              lastUpdated: "Baru saja",
            }}
            insight={{
              title: "Jumlah Antrean Saat Ini",
              value: "18 Orang Menunggu",
              status: "sehat",
              meta: ["Indikator", "Real-time", "Ruang Tunggu PTSP"],
              summary: "Jumlah Antrean Saat Ini mengukur jumlah pemohon yang sedang menunggu di ruang tunggu PTSP secara real-time, terdistribusi ke 4 loket layanan.",
              current: [
                "Realisasi terkini 18 orang menunggu — Loket 1: 4, Loket 2: 5, Loket 3: 3, Loket 4: 6.",
                "Estimasi waktu tunggu loket ± 22 menit, jauh di atas estimasi kanal online ± 8 menit.",
              ],
              insights: [
                "Distribusi antrean antar loket relatif merata, tidak ada loket tunggal yang overload signifikan.",
              ],
              tacticalRecs: [
                "Alihkan pemohon ke loket dengan antrean tersingkat saat selisih beban antar loket melebar.",
              ],
              strategicRecs: [
                "Dorong migrasi pemohon loket ke kanal online untuk memangkas estimasi tunggu ± 22 menit menjadi setara online.",
              ],
              dataNotes: ["Snapshot real-time ruang tunggu, pembaruan tiap beberapa detik."],
            }}
          />
        </div>

        {/* 4. Jumlah Pelayanan Bulan Berjalan - Default White */}
        <div className="col-span-1 sm:col-span-1 lg:col-span-1 xl:col-span-1 flex flex-col h-full">
          <ScorecardApp
            id="card-pelayanan-bulan-berjalan"
            variant="default"
            title="Jumlah Pelayanan Bulan Berjalan"
            value={livePelayananBulanIni}
            live
            unit="Pemohon"
            description="Capaian 92% dari Target Bulanan"
            trend={{
              value: "+8.5%",
              label: "vs YoY",
              isPositive: true,
              direction: "up",
            }}
            icon={<Calendar className="w-5 h-5 text-amber-500" />}
            infoTooltip="Akumulasi pemohon yang dilayani selama bulan berjalan (Juli 2026)."
            infoContent={{
              formula: "Akumulasi pemohon yang dilayani sepanjang bulan berjalan, dibanding target bulanan",
              period: "Bulanan (Juli 2026)",
              source: "SIMPATDA — Modul Pelayanan PTSP",
              lastUpdated: "5 menit lalu",
            }}
            insight={{
              title: "Jumlah Pelayanan Bulan Berjalan",
              value: "28.650 Pemohon",
              status: "sehat",
              meta: ["Indikator", "Akumulasi Bulanan", "Juli 2026"],
              summary: "Jumlah Pelayanan Bulan Berjalan mengukur akumulasi pemohon yang dilayani sepanjang Juli 2026, dibandingkan target bulanan 31.000 pemohon.",
              current: [
                "Realisasi 28.650 pemohon, setara 92,4% dari target bulanan 31.000.",
                "Tumbuh 8,5% dibanding periode yang sama tahun lalu (YoY).",
              ],
              insights: [
                "Capaian 92,4% menjelang akhir bulan menunjukkan target bulanan berpotensi tercapai penuh.",
              ],
              tacticalRecs: [
                "Pantau sisa hari kerja bulan berjalan untuk memastikan gap 7,6% terhadap target tertutup.",
              ],
              strategicRecs: [
                "Gunakan tren YoY +8,5% sebagai basis proyeksi target bulanan periode berikutnya.",
              ],
              dataNotes: ["Akumulasi bulan berjalan, pembaruan real-time harian."],
            }}
          />
        </div>

        </div>
      </div>

      <div className="flex flex-col gap-2">
        <TextApp id="label-kanal-kualitas-heading" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted">
          Kanal & Kualitas Pelayanan
        </TextApp>
        {/* 5 kartu -> xl:grid-cols-5 supaya pas satu baris penuh; kalau tetap
            4 kolom, kartu ke-5 (Permohonan Overtime) turun sendirian dan
            menyisakan 3 slot kosong. */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 items-stretch">

        {/* 5. Rata-rata Waktu Pelayanan - Default White */}
        <div className="col-span-1 sm:col-span-1 lg:col-span-1 xl:col-span-1 flex flex-col h-full">
          <ScorecardApp
            id="card-rata-waktu-pelayanan"
            variant="default"
            title="Rata-rata Waktu Pelayanan"
            value="14"
            unit="Menit / Berkas"
            description="Standar SLA: Maksimal 30 Menit"
            trend={{
              value: "-2.5m",
              label: "Lebih Cepat",
              isPositive: true,
              direction: "up",
            }}
            icon={<Clock className="w-5 h-5 text-emerald-500" />}
            infoTooltip="Rata-rata durasi penyelesaian per berkas dari pemanggilan hingga verifikasi selesai."
            infoContent={{
              formula: "Rata-rata durasi berkas dari pemanggilan nomor antrean hingga verifikasi selesai",
              period: "Harian (rolling average)",
              source: "Sistem Antrean PTSP",
              lastUpdated: "10 menit lalu",
            }}
            insight={{
              title: "Rata-rata Waktu Pelayanan",
              value: "14 Menit / Berkas",
              status: "sehat",
              meta: ["Indikator", "Efisiensi", "Standar SLA 30 Menit"],
              summary: "Rata-rata Waktu Pelayanan mengukur durasi rata-rata penyelesaian per berkas dari pemanggilan hingga verifikasi selesai, gabungan kanal online (8 menit) dan loket (18 menit).",
              current: [
                "Rata-rata gabungan 14 menit/berkas, 2,5 menit lebih cepat dibanding kemarin.",
                "Kanal online jauh lebih cepat (8 menit) dibanding loket tatap muka (18 menit).",
              ],
              insights: [
                "Selisih 10 menit antara online dan loket adalah pendorong utama migrasi pemohon ke kanal digital.",
              ],
              tacticalRecs: [
                "Audit tahapan proses loket yang paling lama untuk memangkas rata-rata 18 menit mendekati standar online.",
              ],
              strategicRecs: [
                "Standarisasi SOP loket berbasis praktik terbaik kanal online untuk memangkas kesenjangan waktu.",
              ],
              dataNotes: ["Rata-rata bergerak harian, standar SLA maksimal 30 menit."],
            }}
          />
        </div>

        {/* 6. Jumlah Pelayanan Loket - Default White */}
        <div className="col-span-1 sm:col-span-1 lg:col-span-1 xl:col-span-1 flex flex-col h-full">
          <ScorecardApp
            id="card-pelayanan-loket"
            variant="default"
            title="Jumlah Pelayanan Loket"
            value={livePelayananLoket}
            live
            unit="Tatap Muka (35.7%)"
            description="Loket 1 - 6 Gedung BPKAD"
            trend={{
              value: "-3.1%",
              label: "Porsi vs Bulan Lalu",
              isPositive: false,
              direction: "down",
            }}
            icon={<Building2 className="w-5 h-5 text-blue-500" />}
            infoTooltip="Jumlah berkas yang diproses melalui tatap muka langsung di Kantor PTSP."
            infoContent={{
              formula: "Jumlah berkas yang diproses tatap muka langsung di 6 loket operasional Gedung BPKAD",
              period: "Bulanan (Juli 2026)",
              source: "SIMPATDA — Modul Pelayanan Loket",
              lastUpdated: "5 menit lalu",
            }}
            insight={{
              title: "Jumlah Pelayanan Loket",
              value: "10.230 Berkas",
              status: "sehat",
              meta: ["Indikator", "Kanal Tatap Muka", "Juli 2026"],
              summary: "Jumlah Pelayanan Loket mengukur volume berkas yang diproses tatap muka langsung di 6 loket operasional Kantor PTSP BPKAD, setara 35,7% dari total pelayanan bulan ini.",
              current: [
                "Realisasi 10.230 berkas loket, setara 35,7% dari total pelayanan bulan ini.",
                "6 loket operasional melayani secara paralel di Gedung BPKAD.",
              ],
              insights: [
                "Porsi loket terus menyusut relatif terhadap online — konsisten dengan tren digitalisasi layanan.",
              ],
              tacticalRecs: [
                "Evaluasi jam sibuk loket untuk penjadwalan petugas yang lebih efisien.",
              ],
              strategicRecs: [
                "Rencanakan realokasi sebagian kapasitas loket ke dukungan kanal online seiring tren migrasi.",
              ],
              dataNotes: ["Akumulasi bulan berjalan, pembaruan real-time."],
            }}
          />
        </div>

        {/* 7. SLA Pelayanan - Default White */}
        <div className="col-span-1 sm:col-span-1 lg:col-span-1 xl:col-span-1 flex flex-col h-full">
          <ScorecardApp
            id="card-sla-pelayanan"
            variant="default"
            title="SLA Pelayanan"
            value="98.4%"
            unit="Tepat Waktu"
            description="28.190 / 28.650 Berkas Sesuai SLA"
            trend={{
              value: "≥ 95%",
              label: "Target SLA Nasional",
              isPositive: true,
              direction: "up",
            }}
            icon={<CheckCircle2 className="w-5 h-5 text-emerald-500" />}
            infoTooltip="Persentase layanan yang diselesaikan sesuai Service Level Agreement standar."
            infoContent={{
              formula: "Berkas selesai sesuai SLA standar dibagi total berkas yang diproses",
              period: "Bulanan (Juli 2026)",
              source: "SIMPATDA — Modul SLA Pelayanan",
              lastUpdated: "10 menit lalu",
            }}
            insight={{
              title: "SLA Pelayanan",
              value: "98,4% Tepat Waktu",
              status: "sehat",
              meta: ["Indikator", "SOP", "Target ≥ 95%"],
              summary: "SLA Pelayanan mengukur persentase layanan yang diselesaikan sesuai Service Level Agreement standar, dibandingkan target nasional minimal 95%.",
              current: [
                "Realisasi 98,4% (28.190 dari 28.650 berkas) tepat waktu, 460 berkas (1,6%) terlambat.",
                "Capaian 98,4% berada 3,4 poin di atas target nasional ≥ 95%.",
              ],
              insights: [
                "Konsistensi capaian di atas target nasional menunjukkan SOP pelayanan berjalan stabil.",
              ],
              tacticalRecs: [
                "Audit 460 berkas terlambat untuk identifikasi pola penyebab (loket tertentu, jenis layanan tertentu).",
              ],
              strategicRecs: [
                "Tetapkan target internal lebih ambisius (>98%) mengingat capaian sudah konsisten melampaui standar nasional.",
              ],
              dataNotes: ["Akumulasi bulan berjalan, snapshot harian."],
            }}
          />
        </div>

        {/* 8. Tingkat Penyelesaian Pelayanan - Default White */}
        <div className="col-span-1 sm:col-span-1 lg:col-span-1 xl:col-span-1 flex flex-col h-full">
          <ScorecardApp
            id="card-tingkat-penyelesaian"
            variant="default"
            title="Tingkat Penyelesaian Pelayanan"
            value="96.2%"
            unit="Terselesaikan"
            description="27.561 Selesai | 1.089 Dalam Proses"
            trend={{
              value: "+2.1%",
              label: "vs Bulan Lalu",
              isPositive: true,
              direction: "up",
            }}
            icon={<Zap className="w-5 h-5 text-vibrant-purple" />}
            infoTooltip="Rasio permohonan yang telah terbit SK/bukti bayar dibanding total permohonan masuk."
            infoContent={{
              formula: "Permohonan terbit SK/bukti bayar dibagi total permohonan masuk pada bulan berjalan",
              period: "Bulanan (Juli 2026)",
              source: "SIMPATDA — Modul Pelayanan PTSP",
              lastUpdated: "10 menit lalu",
            }}
            insight={{
              title: "Tingkat Penyelesaian Pelayanan",
              value: "96,2% Terselesaikan",
              status: "sehat",
              meta: ["Indikator", "Rasio Progress", "Juli 2026"],
              summary: "Tingkat Penyelesaian Pelayanan mengukur rasio permohonan yang telah terbit SK/bukti bayar dibanding total permohonan masuk bulan ini.",
              current: [
                "Realisasi 96,2% (27.561 selesai dari 28.650 total), 1.089 masih dalam proses.",
                "Naik 2,1 poin dibanding bulan lalu.",
              ],
              insights: [
                "Kenaikan konsisten tiap bulan menunjukkan backlog permohonan dalam proses terus menyusut.",
              ],
              tacticalRecs: [
                "Prioritaskan 1.089 permohonan dalam proses yang mendekati batas waktu SLA.",
              ],
              strategicRecs: [
                "Analisis jenis layanan dengan waktu penyelesaian terlama untuk perbaikan proses target berikutnya.",
              ],
              dataNotes: ["Akumulasi bulan berjalan, pembaruan real-time."],
            }}
          />
        </div>

        {/* 9. Permohonan Overtime (BR-02 item 12) - Default White */}
        <div className="col-span-1 sm:col-span-1 lg:col-span-1 xl:col-span-1 flex flex-col h-full">
          <ScorecardApp
            id="card-permohonan-overtime"
            variant="default"
            title="Permohonan Overtime"
            value={livePermohonanOvertime}
            live
            unit="Berkas Lewat SLA"
            description="Melebihi batas SLA (Loket 30m | Online 15m)"
            trend={{
              value: "-6.8%",
              label: "vs Bulan Lalu",
              isPositive: true,
              direction: "down",
            }}
            icon={<Timer className="w-5 h-5 text-amber-500" />}
            infoTooltip="Jumlah permohonan yang waktu prosesnya sudah melewati batas SLA yang ditetapkan."
            infoContent={{
              formula: "Jumlah berkas dengan durasi proses melebihi batas SLA kanalnya (Loket 30 menit, Online 15 menit)",
              period: "Bulanan (Juli 2026)",
              source: "SIMPATDA — Modul SLA Pelayanan",
              lastUpdated: "Baru saja",
            }}
            insight={{
              title: "Permohonan Overtime",
              value: "460 Berkas",
              status: "waspada",
              meta: ["Indikator", "Pelanggaran SLA", "Juli 2026"],
              summary: "Permohonan Overtime mengukur berkas yang durasi prosesnya sudah melewati batas SLA kanalnya — komplemen langsung dari metrik SLA Pelayanan (98,4% tepat waktu).",
              current: [
                "460 berkas overtime dari 28.650 total, setara 1,6% — sisi lain dari SLA 98,4%.",
                "Turun 6,8% dibanding bulan lalu seiring perbaikan alur verifikasi.",
              ],
              insights: [
                "Angka 1,6% masih jauh di bawah ambang toleransi 5%, namun tetap perlu dipantau karena berkas overtime berisiko jadi keluhan formal.",
              ],
              tacticalRecs: [
                "Audit 460 berkas overtime untuk identifikasi pola penyebab (loket tertentu / jenis layanan tertentu).",
              ],
              strategicRecs: [
                "Pasang peringatan otomatis saat berkas mendekati 80% batas SLA agar tidak terlanjur overtime.",
              ],
              glossary: [
                { term: "SLA", expansion: "Service Level Agreement", definition: "batas waktu maksimal penyelesaian layanan yang dijanjikan ke pemohon." },
              ],
              dataNotes: ["Akumulasi bulan berjalan, pembaruan real-time."],
            }}
          />
        </div>

        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* CHARTS SECTION (BR-02 METRICS 9, 10, 11) */}
      {/* STRICT RULE: NO PREFIXED NUMBERS IN CARD TITLES */}
      {/* ------------------------------------------------------------- */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch mt-2">
        
        {/* 9. Trend Pelayanan (Line Chart - Spans 2 Cols on LG) */}
        <div className="col-span-1 lg:col-span-2 flex flex-col">
          <CardApp id="card-trend-pelayanan" variant="clay" size="sm" className="bg-surface border border-hairline flex-1 flex flex-col">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-hairline-soft">
              <div>
                <TextApp id="title-trend-pelayanan" variant="h4" className="font-bold tracking-tight">
                  Trend Pelayanan
                </TextApp>
                <TextApp id="sub-trend-pelayanan" variant="caption" className="text-ink-muted">
                  Perbandingan Volume Pelayanan Online vs Loket (Januari - Juli 2026)
                </TextApp>
              </div>
              <BadgeApp id="badge-chart-trend" variant="solidPurple" size="sm">
                Line Chart
              </BadgeApp>
            </div>

            <div className="flex-1 w-full pt-2">
              <ChartApp
                id="chart-trend-pelayanan-line"
                type="line"
                variant="vibrant"
                data={trendPelayananData}
                xKey="name"
                height={260}
                showGrid={true}
                showLegend={true}
                series={[
                  { key: "Online", label: "Pelayanan Online", color: CHART_COLORS.purple },
                  { key: "Loket", label: "Pelayanan Loket PTSP", color: CHART_COLORS.blue },
                  { key: "Total", label: "Total Pelayanan", color: CHART_COLORS.amber },
                ]}
              />
            </div>
          </CardApp>
        </div>

        {/* 10. Pie Pelayanan Online vs Loket (Pie Chart) */}
        <div className="col-span-1 flex flex-col">
          <CardApp id="card-pie-online-loket" variant="clay" size="sm" className="bg-surface border border-hairline flex-1 flex flex-col">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-hairline-soft">
              <div>
                <TextApp id="title-pie-online-loket" variant="h4" className="font-bold tracking-tight">
                  Pelayanan Online vs Loket
                </TextApp>
                <TextApp id="sub-pie-online-loket" variant="caption" className="text-ink-muted">
                  Proporsi Kanal Pelayanan
                </TextApp>
              </div>
              <BadgeApp id="badge-chart-pie" variant="solidPurple" size="sm">
                Donut Chart
              </BadgeApp>
            </div>

            <div className="flex-1 w-full flex items-center justify-center pt-1">
              <ChartApp
                id="chart-pie-online-vs-loket"
                type="pie"
                variant="purple"
                data={pieOnlineVsLoketData}
                xKey="name"
                yKey="value"
                height={260}
                innerRadius={55}
                outerRadius={85}
                showLegend={true}
              />
            </div>
          </CardApp>
        </div>

        {/* 11. Jenis Layanan Terbanyak (Bar Chart) */}
        <div className="col-span-1 lg:col-span-2 flex flex-col">
          <CardApp id="card-jenis-layanan-terbanyak" variant="clay" size="sm" className="bg-surface border border-hairline flex-1 flex flex-col">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-hairline-soft">
              <div>
                <TextApp id="title-jenis-layanan" variant="h4" className="font-bold tracking-tight">
                  Jenis Layanan Terbanyak
                </TextApp>
                <TextApp id="sub-jenis-layanan" variant="caption" className="text-ink-muted">
                  Top 5 Volume Layanan Perpajakan & Retribusi Daerah Kota Yogyakarta
                </TextApp>
              </div>
              <BadgeApp id="badge-chart-bar" variant="solidPurple" size="sm">
                Bar Chart
              </BadgeApp>
            </div>

            <div className="flex-1 min-h-[240px] w-full pt-2">
              <ChartApp
                id="chart-jenis-layanan-bar"
                type="bar"
                variant="vibrant"
                data={jenisLayananTerbanyakData}
                xKey="name"
                height="100%"
                showGrid={true}
                showLegend={false}
                series={[
                  { key: "Jumlah", label: "Jumlah Berkas Pelayanan", color: CHART_COLORS.purple },
                ]}
              />
            </div>
          </CardApp>
        </div>

        {/* Status Antrean Saat Ini — panel loket real-time, sesuai referensi ZIP */}
        <div className="col-span-1 flex flex-col">
          <CardApp
            id="card-status-antrean"
            variant="clay"
            size="sm"
            className="bg-surface border border-hairline flex-1 flex flex-col"
            insight={{
              title: "Status Antrean",
              value: `${liveAntreanLoket + liveAntreanOnline} Orang Menunggu`,
              status: "sehat",
              meta: ["Indikator", "Real-time", "Ruang Tunggu PTSP"],
              summary: "Status Antrean menggabungkan antrean loket dan online secara real-time, dengan status per-loket (aktif/istirahat) dan estimasi waktu tunggu masing-masing kanal.",
              current: [
                `Antrean loket ${liveAntreanLoket} orang, antrean online ${liveAntreanOnline} orang.`,
                "3 dari 4 loket aktif melayani; Loket D sedang istirahat.",
              ],
              insights: [
                "Estimasi tunggu loket (± 22 menit) jauh lebih lama dari online (± 8 menit) — pola konsisten dengan gap rata-rata waktu pelayanan.",
              ],
              tacticalRecs: [
                "Aktifkan kembali Loket D saat antrean loket melonjak di atas ambang normal.",
              ],
              strategicRecs: [
                "Evaluasi jadwal istirahat petugas loket agar tidak bersamaan dengan jam sibuk.",
              ],
              dataNotes: ["Snapshot real-time, pembaruan tiap beberapa detik."],
            }}
          >
            <div className="pb-3 mb-4 border-b border-hairline-soft">
              <TextApp id="title-status-antrean" variant="h4" className="font-bold tracking-tight">
                Status Antrean Saat Ini
              </TextApp>
              <TextApp id="sub-status-antrean" variant="caption" className="text-ink-muted">
                Real-time — pembaruan otomatis
              </TextApp>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-6">
              <div className="rounded-xl border border-hairline-soft bg-surface-subtle p-4 text-center">
                <TextApp id="stat-antrean-loket" variant="h3" weight="bold" className="text-ink-primary">
                  {liveAntreanLoket}
                </TextApp>
                <TextApp id="label-antrean-loket" variant="caption" className="text-ink-secondary mt-1">
                  Antrean Loket
                </TextApp>
              </div>
              <div className="rounded-xl border border-hairline-soft bg-surface-subtle p-4 text-center">
                <TextApp id="stat-antrean-online" variant="h3" weight="bold" className="text-ink-primary">
                  {liveAntreanOnline}
                </TextApp>
                <TextApp id="label-antrean-online" variant="caption" className="text-ink-secondary mt-1">
                  Antrean Online
                </TextApp>
              </div>
            </div>

            <div className="mb-6">
              <TextApp id="heading-status-loket" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted mb-3">
                Status Loket
              </TextApp>
              <div className="space-y-3">
                {antreanStatusLoket.map((loket) => (
                  <div key={loket.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span
                        className={`h-2 w-2 rounded-full ${
                          loket.status === "aktif" ? "bg-emerald-500 animate-pulse" : "bg-rose-400"
                        }`}
                      />
                      <TextApp id={`label-${loket.id}`} variant="body" weight="medium" className="text-ink-secondary">
                        {loket.nama}
                      </TextApp>
                    </div>
                    <TextApp id={`value-${loket.id}`} variant="body" weight="medium" className="text-ink-secondary">
                      {loket.status === "aktif"
                        ? `Melayani No. ${String(loket.nomor).padStart(3, "0")}`
                        : "Istirahat"}
                    </TextApp>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <TextApp id="heading-estimasi-tunggu" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted mb-3">
                Estimasi Tunggu
              </TextApp>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <TextApp id="label-estimasi-loket" variant="body" weight="medium" className="text-ink-secondary">
                    Loket
                  </TextApp>
                  <TextApp id="value-estimasi-loket" variant="body" weight="bold" className="text-ink-primary">
                    ± 22 menit
                  </TextApp>
                </div>
                <div className="flex items-center justify-between">
                  <TextApp id="label-estimasi-online" variant="body" weight="medium" className="text-ink-secondary">
                    Online
                  </TextApp>
                  <TextApp id="value-estimasi-online" variant="body" weight="bold" className="text-ink-primary">
                    ± 8 menit
                  </TextApp>
                </div>
              </div>
            </div>
          </CardApp>
        </div>

      </div>

      {/* ------------------------------------------------------------- */}
      {/* PELAYANAN & ADMINISTRASI (2 kartu ringkasan, persis referensi   */}
      {/* ZIP) — breakdown jenis layanan + status permohonan.            */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col gap-2">
        <TextApp id="label-pelayanan-administrasi-heading" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted">
          Pelayanan & Administrasi
        </TextApp>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-stretch">
          <CardApp
            id="card-jumlah-pelayanan-admin"
            className="p-5 border-hairline-soft"
            insight={{
              title: "Jumlah Pelayanan",
              value: "5.694 Layanan",
              status: "sehat",
              meta: ["Indikator", "Bulan Berjalan", "Juli 2026"],
              summary: "Jumlah Pelayanan merangkum seluruh layanan yang diberikan bulan ini, terdiri dari konsultasi, administrasi, dan layanan lainnya.",
              current: [
                "Realisasi 5.694 layanan bulan ini: 3.285 Konsultasi, 1.576 Administrasi, 810 Lainnya.",
                "Konsultasi mendominasi porsi layanan (57,7%), konsisten dengan pola permintaan informasi perpajakan.",
              ],
              insights: [
                "Volume harian relatif stabil dengan puncak menjelang akhir bulan, sejalan dengan musim jatuh tempo pelaporan.",
              ],
              tacticalRecs: [
                "Siapkan tambahan petugas konsultasi menjelang tanggal jatuh tempo untuk menghindari antrean panjang.",
              ],
              strategicRecs: [
                "Evaluasi migrasi sebagian layanan konsultasi ke kanal digital (chatbot/FAQ) untuk memangkas beban loket.",
              ],
              dataNotes: ["Akumulasi bulan berjalan, pembaruan harian."],
            }}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-surface-subtle border border-hairline-soft">
                  <Headphones className="w-4 h-4 text-ink-secondary" />
                </div>
                <TextApp id="title-jumlah-pelayanan-admin" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted">
                  Jumlah Pelayanan
                </TextApp>
              </div>
              <BadgeApp id="badge-jumlah-pelayanan-admin" variant="neutral" size="sm">Jul 2026</BadgeApp>
            </div>

            <TextApp id="value-jumlah-pelayanan-admin" variant="h2" weight="bold" className="text-ink">
              5.694<span className="ml-1.5 text-sm font-medium text-ink-muted align-middle">layanan bulan ini</span>
            </TextApp>

            <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-hairline-soft">
              <div>
                <TextApp id="value-pelayanan-konsultasi" variant="h4" weight="bold" className="text-ink">3.285</TextApp>
                <TextApp id="label-pelayanan-konsultasi" variant="caption" className="text-ink-secondary">Konsultasi</TextApp>
              </div>
              <div>
                <TextApp id="value-pelayanan-administrasi" variant="h4" weight="bold" className="text-ink">1.576</TextApp>
                <TextApp id="label-pelayanan-administrasi" variant="caption" className="text-ink-secondary">Administrasi</TextApp>
              </div>
              <div>
                <TextApp id="value-pelayanan-lainnya" variant="h4" weight="bold" className="text-ink">810</TextApp>
                <TextApp id="label-pelayanan-lainnya" variant="caption" className="text-ink-secondary">Lainnya</TextApp>
              </div>
            </div>

            <div className="mt-4 h-20 w-full">
              <ChartApp
                id="chart-pelayanan-sparkline"
                type="bar"
                data={pelayananWeeklyTrend}
                xKey="name"
                height="100%"
                showGrid={false}
                showLegend={false}
                showTooltip={true}
                series={[{ key: "value", label: "Jumlah Layanan", color: CHART_COLORS.purple }]}
              />
            </div>
          </CardApp>

          <CardApp
            id="card-jumlah-permohonan-admin"
            className="p-5 border-hairline-soft"
            insight={{
              title: "Jumlah Permohonan",
              value: "1.974 Permohonan",
              status: "sehat",
              meta: ["Indikator", "Bulan Berjalan", "Juli 2026"],
              summary: "Jumlah Permohonan merangkum seluruh permohonan yang diterima bulan ini beserta status penyelesaiannya.",
              current: [
                "Realisasi 1.974 permohonan diterima: 1.198 Disetujui, 540 Dalam Proses, 230 Ditolak.",
                "Tingkat persetujuan 60,7% dari total permohonan yang diterima bulan ini.",
              ],
              insights: [
                "Rasio ditolak (11,7%) relatif rendah, menunjukkan kualitas berkas pemohon cukup baik sebelum diajukan.",
              ],
              tacticalRecs: [
                "Percepat verifikasi 540 permohonan yang masih dalam proses agar tidak menumpuk ke bulan berikutnya.",
              ],
              strategicRecs: [
                "Analisis pola penolakan untuk menyusun panduan kelengkapan berkas yang lebih jelas bagi pemohon.",
              ],
              dataNotes: ["Akumulasi bulan berjalan, pembaruan harian."],
            }}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-surface-subtle border border-hairline-soft">
                  <ClipboardList className="w-4 h-4 text-ink-secondary" />
                </div>
                <TextApp id="title-jumlah-permohonan-admin" variant="caption" weight="bold" className="uppercase tracking-widest text-ink-muted">
                  Jumlah Permohonan
                </TextApp>
              </div>
              <BadgeApp id="badge-jumlah-permohonan-admin" variant="neutral" size="sm">Jul 2026</BadgeApp>
            </div>

            <TextApp id="value-jumlah-permohonan-admin" variant="h2" weight="bold" className="text-ink">
              1.974<span className="ml-1.5 text-sm font-medium text-ink-muted align-middle">permohonan diterima</span>
            </TextApp>

            <div className="mt-4 pt-4 border-t border-hairline-soft space-y-3">
              {[
                { id: "disetujui", label: "Disetujui", value: 1198, percent: 61, icon: <CheckCircle2 className="w-4 h-4" style={{ color: CHART_COLORS.emerald }} />, color: CHART_COLORS.emerald },
                { id: "proses", label: "Proses", value: 540, percent: 27, icon: <Clock className="w-4 h-4" style={{ color: CHART_COLORS.amber }} />, color: CHART_COLORS.amber },
                { id: "ditolak", label: "Ditolak", value: 230, percent: 12, icon: <XCircle className="w-4 h-4" style={{ color: CHART_COLORS.blue }} />, color: CHART_COLORS.blue },
              ].map((row) => (
                <div key={row.id} id={`permohonan-row-${row.id}`}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="flex items-center gap-2 text-sm font-semibold text-ink">
                      {row.icon}
                      {row.label}
                    </span>
                    <span className="font-mono font-bold text-ink">{row.value.toLocaleString("id-ID")}</span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-black/10 dark:bg-white/15">
                    <div className="h-full rounded-full" style={{ width: `${row.percent}%`, backgroundColor: row.color }} />
                  </div>
                </div>
              ))}
            </div>
          </CardApp>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* REALISASI VS TARGET PENDAPATAN + AKTIVITAS TERKINI              */}
      {/* ------------------------------------------------------------- */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
        <div className="col-span-1 lg:col-span-2 flex flex-col">
          <CardApp
            id="card-realisasi-vs-target-pendapatan"
            variant="clay"
            size="sm"
            className="bg-surface border border-hairline flex-1 flex flex-col"
            insight={{
              title: "Grafik Realisasi vs Target Pendapatan",
              value: "Rp 4,3 M (Jul 2026)",
              status: "waspada",
              meta: ["Visualisasi", "Tren Bulanan", "TA 2026"],
              summary: "Grafik Realisasi vs Target Pendapatan membandingkan capaian bulanan pendapatan pelayanan terhadap target yang ditetapkan sepanjang TA 2026.",
              current: [
                "Realisasi Juli 2026 Rp 4,3 M, sedikit di bawah target Rp 4,5 M.",
                "Maret 2026 mencatat lonjakan realisasi tertinggi (Rp 9,8 M) jauh melampaui target Rp 5 M.",
              ],
              insights: [
                "Realisasi cenderung fluktuatif bulan ke bulan, dengan satu lonjakan signifikan (Maret) yang menutup gap bulan-bulan lain.",
              ],
              tacticalRecs: [
                "Investigasi penyebab lonjakan Maret untuk menilai apakah polanya bisa direplikasi atau bersifat one-off.",
              ],
              strategicRecs: [
                "Susun proyeksi target bulanan yang lebih realistis berdasarkan pola musiman historis.",
              ],
              dataNotes: ["Data bulanan, satuan Juta Rupiah."],
            }}
          >
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-hairline-soft">
              <div>
                <TextApp id="title-realisasi-target" variant="h4" className="font-bold tracking-tight">
                  Grafik Realisasi vs Target Pendapatan
                </TextApp>
                <TextApp id="sub-realisasi-target" variant="caption" className="text-ink-muted">
                  Perbulan — Tahun 2026
                </TextApp>
              </div>
              <BadgeApp id="badge-chart-realisasi-target" variant="solidPurple" size="sm">
                Line Chart
              </BadgeApp>
            </div>

            <div className="flex-1 min-h-[280px] w-full pt-2">
              <ChartApp
                id="chart-realisasi-vs-target"
                type="line"
                variant="vibrant"
                data={pendapatanRealisasiVsTargetData}
                xKey="name"
                height="100%"
                showGrid={true}
                showLegend={true}
                series={[
                  { key: "realisasi", label: "Realisasi", color: CHART_COLORS.purple },
                  { key: "target", label: "Target", color: CHART_TARGET_COLOR },
                ]}
              />
            </div>
          </CardApp>
        </div>

        <div className="col-span-1 flex flex-col">
          <CardApp id="card-aktivitas-terkini" variant="clay" size="sm" className="bg-surface border border-hairline flex-1 flex flex-col">
            <div className="pb-3 mb-4 border-b border-hairline-soft">
              <TextApp id="title-aktivitas-terkini" variant="h4" className="font-bold tracking-tight">
                Aktivitas Terkini
              </TextApp>
              <TextApp id="sub-aktivitas-terkini" variant="caption" className="text-ink-muted">
                Update & transaksi terbaru
              </TextApp>
            </div>

            <TimelineApp id="timeline-aktivitas-terkini" items={aktivitasTerkiniItems} indicator="icon" size="sm" />
          </CardApp>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* DATA TABLE SECTION: Real-time Queue & Application Stream */}
      {/* ------------------------------------------------------------- */}
      <CardApp id="card-table-service-stream" variant="clay" size="sm" className="bg-surface border border-hairline mt-2">
        <DataTableApp
          id="table-service-queue"
          title="Daftar Permohonan & Antrean Pelayanan Terbaru"
          description="Monitoring Waktu Nyata Berkas Pelayanan PTSP & Portal Online"
          toolbarLayout="singleRow"
          data={liveServiceQueue}
          newRowIds={newServiceQueueIds}
          getRowId={(row) => row.id}
          columns={tableColumns}
          enablePagination={true}
          pageSize={5}
        />
      </CardApp>

      {/* ------------------------------------------------------------- */}
      {/* DETAIL MODAL (DIALOG APP) */}
      {/* ------------------------------------------------------------- */}
      <DialogApp
        id="dialog-service-detail"
        isOpen={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        title={modalTitle || "Detail Informasi Pelayanan"}
        description="Rincian data metrik dan status operasional pelayanan publik BPKAD Kota Yogyakarta."
      >
        <div className="py-2 space-y-4">
          {modalData ? (
            <div className="bg-surface-soft border border-hairline p-4 rounded-2xl space-y-2">
              {Object.entries(modalData).map(([key, value]) => (
                <div key={key} className="flex justify-between items-center text-xs border-b border-hairline-soft pb-2 last:border-0 last:pb-0">
                  <span className="font-semibold text-ink-secondary capitalize">
                    {key.replace(/([A-Z])/g, " $1")}:
                  </span>
                  <span className="font-mono font-bold text-ink text-right">
                    {String(value)}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <TextApp id="modal-empty-text" variant="caption" className="text-ink-muted">
              Tidak ada data tambahan.
            </TextApp>
          )}

          <div className="flex justify-end pt-2">
            <ButtonApp
              id="btn-close-service-modal"
              variant="primary"
              size="sm"
              onClick={() => setDetailModalOpen(false)}
            >
              Tutup Rincian
            </ButtonApp>
          </div>
        </div>
      </DialogApp>
    </div>
  );
}
