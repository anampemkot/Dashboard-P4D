import * as React from "react";
import {
  CardApp,
  BadgeApp,
  ButtonApp,
  TextApp,
  AdvanceFilterApp,
  DataTableApp,
  ChartApp,
  DropdownApp,
  DialogApp,
  MapsApp,
  ProgressIndicatorApp,
  ProgressListApp,
  useToastApp,
  QuickPreset,
  MapPolygon,
  BadgeVariant,
} from "@/packages/design-system";
import { RefreshCw, Download, Filter, Map as MapIcon, Calendar, Eye } from "lucide-react";
import { CHART_COLORS, CHART_TARGET_COLOR } from "@/constants/chartColors";
import { KEMANTREN_POLYGONS, YOGYAKARTA_CENTER } from "@/constants/mockKemantrenPolygons";

// ---------------------------------------------------------------------------
// Dua lapis diagnostik yang ditumpuk di peta. Warnanya juga dipakai pada
// legenda & titik kuadran supaya satu wilayah terbaca sama di semua panel.
// ---------------------------------------------------------------------------
const LAYER_AREA_TAK_TERDATA = { label: "Area Tak Terdata", color: "#f43f5e" };
const LAYER_POTENSI_TINGGI = { label: "Potensi Tinggi", color: CHART_COLORS.purple };

interface DiagnostikWilayah {
  id: string;
  kemantren: keyof typeof KEMANTREN_POLYGONS;
  /** Persentase area yang belum terdata — sumbu X kuadran. */
  kepadatan: number;
  /** Estimasi potensi tersembunyi (skala 0-100) — sumbu Y kuadran. */
  potensi: number;
  /** Luas area belum terdata dalam hektar. */
  luasHa: number;
}

const DIAGNOSTIK_WILAYAH: DiagnostikWilayah[] = [
  { id: "umbulharjo", kemantren: "Umbulharjo", kepadatan: 95, potensi: 85, luasHa: 142.5 },
  { id: "kotagede", kemantren: "Kotagede", kepadatan: 80, potensi: 70, luasHa: 118.2 },
  { id: "gondomanan", kemantren: "Gondomanan", kepadatan: 60, potensi: 35, luasHa: 94.0 },
  { id: "gondokusuman", kemantren: "Gondokusuman", kepadatan: 45, potensi: 55, luasHa: 76.1 },
  { id: "mantrijeron", kemantren: "Mantrijeron", kepadatan: 30, potensi: 40, luasHa: 52.4 },
];

// Ambang pembagi kuadran — wilayah di kanan-atas keduanya berarti area luas
// yang belum terdata SEKALIGUS berpotensi tinggi, itulah zona kritis.
const AMBANG_KEPADATAN = 60;
const AMBANG_POTENSI = 60;

const isKritis = (w: DiagnostikWilayah) => w.kepadatan >= AMBANG_KEPADATAN && w.potensi >= AMBANG_POTENSI;

const LUAS_MAKS = Math.max(...DIAGNOSTIK_WILAYAH.map((w) => w.luasHa));

// Antrean penugasan survei — nilai mengikuti acuan prototype.
const ANTREAN_SURVEI = [
  {
    id: "srv-umbulharjo",
    kemantren: "Umbulharjo",
    prioritas: "Mendesak",
    opTakTercatat: 1240,
    potensiLoss: 4.2,
    progres: 15,
  },
  {
    id: "srv-kotagede",
    kemantren: "Kotagede",
    prioritas: "Tinggi",
    opTakTercatat: 845,
    potensiLoss: 2.8,
    progres: 42,
  },
  {
    id: "srv-gondomanan",
    kemantren: "Gondomanan",
    prioritas: "Sedang",
    opTakTercatat: 512,
    potensiLoss: 1.1,
    progres: 68,
  },
  {
    id: "srv-mantrijeron",
    kemantren: "Mantrijeron",
    prioritas: "Sedang",
    opTakTercatat: 410,
    potensiLoss: 0.9,
    progres: 82,
  },
  {
    id: "srv-gondokusuman",
    kemantren: "Gondokusuman",
    prioritas: "Tinggi",
    opTakTercatat: 690,
    potensiLoss: 2.1,
    progres: 34,
  },
];

type AntreanRow = (typeof ANTREAN_SURVEI)[number];

const gisFilterFields = [
  {
    id: "layerDiagnostik",
    label: "Layer Diagnostik",
    type: "select" as const,
    placeholder: "Pilih Layer...",
    options: [
      { value: "all", label: "Semua Lapis Diagnostik" },
      { value: "tak_terdata", label: "Area Tak Terdata" },
      { value: "potensi_tinggi", label: "Potensi Tinggi" },
    ],
  },
  {
    id: "kemantren",
    label: "Wilayah Kemantren",
    type: "select" as const,
    placeholder: "Pilih Kemantren...",
    options: [
      { value: "all", label: "Semua Kemantren (14 Wilayah)" },
      ...Object.keys(KEMANTREN_POLYGONS).map((nama) => ({ value: nama.toLowerCase(), label: `Kemantren ${nama}` })),
    ],
  },
  {
    id: "tingkatPrioritas",
    label: "Tingkat Prioritas Survei",
    type: "select" as const,
    placeholder: "Semua Prioritas...",
    options: [
      { value: "all", label: "Semua Tingkat Prioritas" },
      { value: "mendesak", label: "Mendesak" },
      { value: "tinggi", label: "Tinggi" },
      { value: "sedang", label: "Sedang" },
    ],
  },
  {
    id: "tahunAnggaran",
    label: "Tahun Anggaran",
    type: "select" as const,
    placeholder: "Tahun...",
    options: [
      { value: "2026", label: "Tahun 2026 (Berjalan)" },
      { value: "2025", label: "Tahun 2025" },
      { value: "2024", label: "Tahun 2024" },
    ],
  },
];

const quickPresets: QuickPreset[] = [
  { label: "Semua Lapis", values: { layerDiagnostik: "all", tingkatPrioritas: "all" } },
  { label: "Area Tak Terdata", values: { layerDiagnostik: "tak_terdata" } },
  { label: "Potensi Tinggi", values: { layerDiagnostik: "potensi_tinggi" } },
  { label: "Survei Mendesak", values: { tingkatPrioritas: "mendesak" } },
];

const formatMiliar = (value: number) => `Rp ${value.toFixed(1).replace(".", ",")} M`;

export function GISDashboardPage() {
  const { toast } = useToastApp();

  const [filterValues, setFilterValues] = React.useState<Record<string, any>>({});
  const [selectedWilayah, setSelectedWilayah] = React.useState<AntreanRow | null>(null);
  const [isDetailOpen, setIsDetailOpen] = React.useState(false);

  const handleResetFilter = () => {
    setFilterValues({});
    toast.info("Filter Diagnostik Direset", {
      description: "Semua lapis peta dan kriteria wilayah dikembalikan ke kondisi awal.",
    });
  };

  const activeLayer = String(filterValues.layerDiagnostik ?? "all");

  // Poligon dua lapis: wilayah kritis (kanan-atas kuadran) diwarnai sebagai
  // "Area Tak Terdata", sisanya sebagai "Potensi Tinggi". Opasitas mengikuti
  // luas area, dan `centerLabel` menyebut nama wilayah beserta luasnya tepat di
  // tengah bentuknya — jadi peta sudah terbaca sebelum ada yang mengkliknya.
  const mapPolygons: MapPolygon[] = React.useMemo(() => {
    return DIAGNOSTIK_WILAYAH.filter((w) => {
      if (activeLayer === "tak_terdata") return isKritis(w);
      if (activeLayer === "potensi_tinggi") return !isKritis(w);
      return true;
    }).map((w) => {
      const layer = isKritis(w) ? LAYER_AREA_TAK_TERDATA : LAYER_POTENSI_TINGGI;
      return {
        id: w.id,
        positions: KEMANTREN_POLYGONS[w.kemantren],
        title: w.kemantren,
        color: layer.color,
        fillColor: layer.color,
        fillOpacity: 0.18 + (w.luasHa / LUAS_MAKS) * 0.35,
        weight: 1.5,
        centerLabel: `${w.kemantren} (${w.luasHa.toLocaleString("id-ID")} Ha)`,
        centerLabelAlert: isKritis(w),
        popup: `${w.kemantren} — ${layer.label}, ${w.luasHa.toLocaleString("id-ID")} Ha belum terdata`,
      };
    });
  }, [activeLayer]);

  const quadrantData = React.useMemo(
    () =>
      DIAGNOSTIK_WILAYAH.map((w) => ({
        name: w.kemantren,
        kepadatan: w.kepadatan,
        potensi: w.potensi,
        fill: isKritis(w) ? LAYER_AREA_TAK_TERDATA.color : CHART_TARGET_COLOR,
      })),
    [],
  );

  const profilAreaItems = React.useMemo(
    () =>
      [...DIAGNOSTIK_WILAYAH]
        .sort((a, b) => b.luasHa - a.luasHa)
        .map((w) => ({
          id: w.id,
          label: w.kemantren,
          value: `${w.luasHa.toLocaleString("id-ID", { minimumFractionDigits: 1 })} Ha`,
          segments: [
            {
              percent: (w.luasHa / LUAS_MAKS) * 100,
              color: isKritis(w) ? LAYER_AREA_TAK_TERDATA.color : CHART_COLORS.amber,
            },
          ],
        })),
    [],
  );

  const handleOpenDetail = (row: AntreanRow) => {
    setSelectedWilayah(row);
    setIsDetailOpen(true);
  };

  const tableColumns = [
    { accessorKey: "kemantren", header: "Nama Kemantren" },
    {
      accessorKey: "prioritas",
      header: "Tingkat Prioritas",
      cell: ({ row }: any) => {
        const value = row.original.prioritas as string;
        // Tiga tingkat, tiga bobot visual yang menurun: isian merah, isian
        // kuning, lalu pil kuning lembut. `BadgeVariant` sengaja ditulis
        // eksplisit — nama varian yang salah ketik sebelumnya lolos ke runtime
        // sebagai badge tanpa gaya karena di-cast `as any`.
        const variant: BadgeVariant =
          value === "Mendesak" ? "solidRose" : value === "Tinggi" ? "solidAmber" : "amber";
        return (
          <BadgeApp id={`badge-prioritas-${row.original.id}`} variant={variant} size="sm">
            {value}
          </BadgeApp>
        );
      },
    },
    {
      accessorKey: "opTakTercatat",
      header: "Est. OP Tak Tercatat",
      cell: ({ row }: any) => (
        <span className="font-mono text-xs text-ink-secondary">
          {row.original.opTakTercatat.toLocaleString("id-ID")} Unit
        </span>
      ),
    },
    {
      accessorKey: "potensiLoss",
      header: "Est. Potensi Loss",
      cell: ({ row }: any) => (
        <span className="font-mono text-xs font-bold text-ink">{formatMiliar(row.original.potensiLoss)}</span>
      ),
    },
    {
      accessorKey: "progres",
      header: "Progres Survei",
      cell: ({ row }: any) => (
        <div className="flex min-w-[140px] items-center gap-2">
          <div className="flex-1">
            <ProgressIndicatorApp
              id={`progres-survei-${row.original.id}`}
              type="linear"
              value={row.original.progres}
              size="sm"
              color={row.original.progres < 40 ? "yellow" : "purple"}
            />
          </div>
          <span className="w-9 shrink-0 text-right font-mono text-[11px] text-ink-secondary">
            {row.original.progres}%
          </span>
        </div>
      ),
    },
    {
      id: "actions",
      header: "Aksi",
      cell: ({ row }: any) => (
        <ButtonApp
          id={`btn-tugaskan-${row.original.id}`}
          variant="secondary"
          size="sm"
          rounded="lg"
          leftIcon={<Eye className="h-3.5 w-3.5" />}
          onClick={() => handleOpenDetail(row.original)}
        >
          Tugaskan
        </ButtonApp>
      ),
    },
  ];

  return (
    <div id="gis-dashboard-root" className="space-y-6 pb-12">
      {/* ------------------------------------------------------------- */}
      {/* HEADER PAGE                                                   */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col justify-between gap-4 border-b border-hairline-soft pb-4 md:flex-row md:items-center">
        <div>
          <div className="mb-1 flex flex-wrap items-center gap-x-3 gap-y-1.5">
            <BadgeApp id="hdr-badge-br07" variant="solidPurple" size="sm">
              BR-07 · Dashboard GIS & Pemetaan Potensi
            </BadgeApp>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <MapIcon className="h-3.5 w-3.5 text-vibrant-purple" />
              Diagnostik Spasial Kota Yogyakarta
            </span>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <Calendar className="h-3.5 w-3.5 text-vibrant-purple" />
              Tahun Anggaran 2026
            </span>
          </div>
          <TextApp id="hdr-title-gis" variant="h2" className="tracking-tight text-ink">
            Dashboard GIS & Pemetaan Potensi Pajak
          </TextApp>
          <TextApp id="hdr-sub-gis" variant="body" className="text-xs text-ink-secondary">
            Visualisasi Diagnostik Potensi Pajak yang Belum Tercatat di Seluruh Kemantren
          </TextApp>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <ButtonApp
            id="btn-refresh-gis"
            variant="secondary"
            size="sm"
            rounded="lg"
            onClick={() =>
              toast.info("Lapis Diagnostik Disinkronkan", {
                description: "Batas wilayah dan estimasi area belum terdata diperbarui dari server GIS.",
              })
            }
            leftIcon={<RefreshCw className="h-3.5 w-3.5" />}
          >
            Sync Peta
          </ButtonApp>
          <ButtonApp
            id="btn-export-gis"
            variant="primary"
            size="sm"
            rounded="lg"
            leftIcon={<Download className="h-3.5 w-3.5" />}
            onClick={() =>
              toast.vibrant("Laporan Diagnostik Diunduh", {
                description: "Berisi profil area tak terdata & antrean penugasan survei per kemantren.",
              })
            }
          >
            Cetak Laporan Survei
          </ButtonApp>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* FILTER BAR */}
      {/* ------------------------------------------------------------- */}
      <div className="flex w-full min-w-0 flex-nowrap items-center gap-2 overflow-x-auto rounded-2xl border border-hairline bg-surface px-3 py-3 shadow-xs">
        <span className="flex shrink-0 items-center gap-1.5 whitespace-nowrap text-xs font-semibold text-ink-secondary">
          <Filter className="h-4 w-4 text-vibrant-purple" />
          Filter:
        </span>

        {/* Shortcut inline lapis peta — nilainya dibagi dgn AdvanceFilterApp
            DAN menyaring poligon yang tampil, jadi bukan kontrol kosmetik. */}
        <div className="w-56 shrink-0">
          <DropdownApp
            id="select-layer-diagnostik"
            value={activeLayer}
            onChange={(value) => setFilterValues((prev) => ({ ...prev, layerDiagnostik: String(value) }))}
            options={[
              { label: "Semua Lapis Diagnostik", value: "all" },
              { label: "Area Tak Terdata", value: "tak_terdata" },
              { label: "Potensi Tinggi", value: "potensi_tinggi" },
            ]}
            size="sm"
            rounded="lg"
            menuPortal
          />
        </div>

        <div className="ml-auto shrink-0">
          <AdvanceFilterApp
            id="filter-gis-diagnostik"
            displayMode="modal"
            showActivePills={false}
            className="w-auto"
            triggerLabel="Advance Filter Spasial"
            triggerVariant="secondary"
            triggerSize="sm"
            triggerRounded="lg"
            title="Filter Lapis Diagnostik & Wilayah Survei"
            fields={gisFilterFields}
            values={filterValues}
            onChange={setFilterValues}
            quickPresets={quickPresets}
            onReset={handleResetFilter}
            onApply={() => {
              toast.vibrant("Filter Diagnostik Diterapkan", {
                description: "Peta, kuadran prioritas, dan antrean survei menyesuaikan kriteria yang dipilih.",
              });
            }}
          />
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* DIAGNOSTIK SPASIAL (BR-07) — peta multi-lapis + kuadran        */}
      {/* prioritas + profil area. Acuan tidak punya scorecard.          */}
      {/* ------------------------------------------------------------- */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <CardApp
          id="card-map-diagnostik"
          className="flex flex-col border-hairline-soft p-5 lg:col-span-2"
          insight={{
            title: "Diagnostik Multi-Lapis Spasial",
            value: `${DIAGNOSTIK_WILAYAH.reduce((acc, w) => acc + w.luasHa, 0).toFixed(1).replace(".", ",")} Ha Belum Terdata`,
            status: "waspada",
            meta: ["Diagnostik", "Spasial", "TA 2026"],
            summary:
              "Peta ini menumpuk dua lapis: area yang belum terdata dan area yang potensinya tinggi. Wilayah yang memenuhi keduanya adalah tempat kehilangan penerimaan paling besar terjadi tanpa terlihat di laporan mana pun.",
            current: [
              "Umbulharjo dan Kotagede menempati keduanya sekaligus — luas belum terdata terbesar dengan potensi tertinggi.",
              "Wilayah lain berpotensi tinggi tapi cakupan pendataannya sudah relatif baik.",
            ],
            insights: [
              "Luas area yang belum terdata tidak otomatis berarti potensi besar — yang menentukan adalah irisan antara keduanya, dan itulah yang dipisahkan oleh kuadran di sebelah kanan.",
            ],
            tacticalRecs: [
              "Kerahkan survei ke wilayah pada kuadran kanan-atas lebih dulu; wilayah luas tapi berpotensi rendah bisa menyusul.",
            ],
            strategicRecs: [
              "Jadwalkan pembaruan citra berkala supaya area terbangun baru terdeteksi tanpa menunggu laporan warga.",
            ],
            glossary: [
              { term: "OP", expansion: "Objek Pajak", definition: "unit tanah, bangunan, atau usaha yang dikenai pajak daerah." },
            ],
            dataNotes: ["Batas wilayah adalah aproksimasi untuk keperluan visualisasi."],
          }}
        >
          <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
            <div>
              <TextApp id="title-map-diagnostik" variant="h3" weight="bold" className="text-ink-primary">
                Diagnostik Multi-Lapis Spasial
              </TextApp>
              <TextApp id="sub-map-diagnostik" variant="caption" className="text-ink-secondary">
                Tumpukan lapis area tak terdata & zona potensi tinggi per kemantren.
              </TextApp>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              {[LAYER_AREA_TAK_TERDATA, LAYER_POTENSI_TINGGI].map((layer) => (
                <span key={layer.label} className="flex items-center gap-1.5">
                  <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: layer.color }} />
                  <TextApp id={`legend-${layer.label}`} variant="caption" className="text-[11px] text-ink-secondary">
                    {layer.label}
                  </TextApp>
                </span>
              ))}
            </div>
          </div>

          <div className="h-[500px] w-full overflow-hidden rounded-xl border border-hairline-soft">
            <MapsApp
              id="map-gis-diagnostik"
              center={YOGYAKARTA_CENTER}
              zoom={12}
              polygons={mapPolygons}
              tileProvider="carto-light"
              showControls
              className="h-full w-full"
            />
          </div>
        </CardApp>

        <div className="flex flex-col gap-6">
          <CardApp
            id="card-kuadran-prioritas"
            className="flex flex-col border-hairline-soft p-5"
            insight={{
              title: "Kuadran Prioritas",
              value: `${DIAGNOSTIK_WILAYAH.filter(isKritis).length} Wilayah Kritis`,
              status: "kritis",
              meta: ["Diagnostik", "Integritas Data", "TA 2026"],
              summary:
                "Kuadran memisahkan wilayah berdasarkan dua sumbu sekaligus: seberapa luas area yang belum terdata, dan seberapa besar potensi yang diperkirakan tersembunyi di sana. Hanya irisan kanan-atas yang benar-benar mendesak.",
              current: [
                "Dua wilayah berada di kuadran kritis: kepadatan area tak terdata dan potensi sama-sama di atas ambang.",
                "Sisanya tersebar di kuadran stabil dengan salah satu sumbu masih rendah.",
              ],
              insights: [
                "Memakai satu sumbu saja menyesatkan — wilayah dengan area tak terdata luas bisa saja bernilai rendah, dan sebaliknya.",
              ],
              tacticalRecs: [
                "Batasi penugasan survei triwulan ini hanya pada wilayah kuadran kanan-atas.",
              ],
              strategicRecs: [
                "Tinjau ulang posisi ambang tiap tahun; ambang yang tidak pernah bergerak akan menyembunyikan perbaikan yang sudah dicapai.",
              ],
              dataNotes: ["Sumbu potensi dinormalkan ke skala 0-100 untuk perbandingan antarwilayah."],
            }}
          >
            <div className="mb-3 flex items-start justify-between gap-2">
              <TextApp id="title-kuadran" variant="h3" weight="bold" className="text-ink-primary">
                Kuadran Prioritas
              </TextApp>
              <BadgeApp id="badge-kuadran" variant="neutral" size="sm">
                Integritas Data
              </BadgeApp>
            </div>

            <ChartApp
              id="chart-kuadran-prioritas"
              type="scatter"
              data={quadrantData}
              scatterXKey="kepadatan"
              scatterYKey="potensi"
              xAxisLabel="Kepadatan Area Tak Terdata (%)"
              yAxisLabel="Estimasi Potensi"
              referenceLines={[
                { axis: "x", value: AMBANG_KEPADATAN, label: "Ambang kepadatan" },
                { axis: "y", value: AMBANG_POTENSI, label: "Ambang potensi" },
              ]}
              showLegend={false}
              height={220}
            />

            <div className="mt-3 flex items-center justify-between border-t border-hairline-soft pt-3">
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full" style={{ backgroundColor: LAYER_AREA_TAK_TERDATA.color }} />
                <TextApp id="legend-kuadran-kritis" variant="caption" className="text-[11px] text-ink-secondary">
                  Area Kritis
                </TextApp>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full" style={{ backgroundColor: CHART_TARGET_COLOR }} />
                <TextApp id="legend-kuadran-stabil" variant="caption" className="text-[11px] text-ink-secondary">
                  Area Stabil
                </TextApp>
              </span>
            </div>
          </CardApp>

          <CardApp
            id="card-profil-area"
            className="flex flex-1 flex-col border-hairline-soft p-5"
            insight={{
              title: "Profil Area Tak Terdata",
              value: `${LUAS_MAKS.toLocaleString("id-ID", { minimumFractionDigits: 1 })} Ha Tertinggi`,
              status: "waspada",
              meta: ["Diagnostik", "Luas Area", "TA 2026"],
              summary:
                "Peringkat luas area yang belum terdata per kemantren, dalam hektar. Dipakai untuk memperkirakan berapa hari-orang survei yang dibutuhkan tiap wilayah.",
              current: [
                "Umbulharjo memimpin dengan 142,5 Ha, hampir tiga kali lipat wilayah terendah pada daftar.",
              ],
              insights: [
                "Luas berbanding lurus dengan biaya survei, tapi tidak dengan hasilnya — itulah kenapa kuadran di atas dipakai sebagai penentu urutan, bukan daftar ini.",
              ],
              tacticalRecs: [
                "Pakai angka hektar untuk menghitung kebutuhan tim, bukan untuk menentukan wilayah mana yang didahulukan.",
              ],
              strategicRecs: [
                "Pertimbangkan survei berbasis citra untuk wilayah berluas besar dengan potensi rendah agar biaya tetap wajar.",
              ],
              dataNotes: ["Luas dihitung dari overlay citra terhadap zona terbangun."],
            }}
          >
            <div className="mb-3 flex items-start justify-between gap-2">
              <TextApp id="title-profil-area" variant="h3" weight="bold" className="text-ink-primary">
                Profil Area Tak Terdata
              </TextApp>
              <BadgeApp id="badge-profil-area" variant="neutral" size="sm">
                Satuan: Hektar
              </BadgeApp>
            </div>

            <ProgressListApp id="list-profil-area" items={profilAreaItems} dense />
          </CardApp>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* ANTREAN PENUGASAN SURVEI (BR-07)                               */}
      {/* ------------------------------------------------------------- */}
      <CardApp id="card-table-antrean-survei" className="border-hairline-soft p-5">
        <DataTableApp
          id="datatable-antrean-survei"
          title="Antrean Penugasan Survei"
          description="Wilayah prioritas beserta estimasi objek pajak tak tercatat, potensi kehilangan penerimaan, dan progres survei berjalan."
          toolbarLayout="singleRow"
          rightHeaderAction={
            <ButtonApp
              id="btn-penugasan-massal"
              variant="primary"
              size="sm"
              rounded="lg"
              onClick={() =>
                toast.vibrant("Penugasan Massal Dibuat", {
                  description: `${ANTREAN_SURVEI.length} wilayah dimasukkan ke satu paket penugasan survei.`,
                })
              }
            >
              Penugasan Massal
            </ButtonApp>
          }
          data={ANTREAN_SURVEI}
          columns={tableColumns}
          getRowId={(row) => row.id}
          searchPlaceholder="Cari kemantren atau tingkat prioritas..."
          pageSize={5}
        />
      </CardApp>

      {/* ------------------------------------------------------------- */}
      {/* DIALOG DETAIL PENUGASAN                                        */}
      {/* ------------------------------------------------------------- */}
      {selectedWilayah && (
        <DialogApp
          id="dialog-detail-penugasan-survei"
          isOpen={isDetailOpen}
          onClose={() => setIsDetailOpen(false)}
          title={`Penugasan Survei: ${selectedWilayah.kemantren}`}
          description="Ringkasan beban survei wilayah sebelum tim diterjunkan."
        >
          <div className="space-y-3">
            <div className="flex items-center justify-between rounded-lg bg-surface-subtle px-3 py-2">
              <TextApp id="detail-label-op" variant="caption" className="text-ink-secondary">
                Estimasi OP Tak Tercatat
              </TextApp>
              <TextApp id="detail-value-op" variant="caption" weight="bold" className="font-mono text-ink">
                {selectedWilayah.opTakTercatat.toLocaleString("id-ID")} Unit
              </TextApp>
            </div>
            <div className="flex items-center justify-between rounded-lg bg-surface-subtle px-3 py-2">
              <TextApp id="detail-label-loss" variant="caption" className="text-ink-secondary">
                Estimasi Potensi Loss
              </TextApp>
              <TextApp id="detail-value-loss" variant="caption" weight="bold" className="font-mono text-ink">
                {formatMiliar(selectedWilayah.potensiLoss)}
              </TextApp>
            </div>
            <div className="rounded-lg bg-surface-subtle px-3 py-2">
              <div className="mb-2 flex items-center justify-between">
                <TextApp id="detail-label-progres" variant="caption" className="text-ink-secondary">
                  Progres Survei
                </TextApp>
                <TextApp id="detail-value-progres" variant="caption" weight="bold" className="font-mono text-ink">
                  {selectedWilayah.progres}%
                </TextApp>
              </div>
              <ProgressIndicatorApp
                id="detail-progres-bar"
                type="linear"
                value={selectedWilayah.progres}
                size="md"
                color="purple"
              />
            </div>
          </div>
        </DialogApp>
      )}
    </div>
  );
}

export default GISDashboardPage;
