import * as React from "react";
import {
  CardApp,
  BadgeApp,
  ButtonApp,
  TextApp,
  AdvanceFilterApp,
  DropdownApp,
  MapsApp,
  ProgressListApp,
  useToastApp,
  QuickPreset,
  MapPolygon,
} from "@/packages/design-system";
import { MapPin, RefreshCw, Download, Filter, Map as MapIcon, Calendar } from "lucide-react";
import { CHART_COLORS, CHART_TARGET_COLOR } from "@/constants/chartColors";
import { KEMANTREN_POLYGONS, YOGYAKARTA_CENTER } from "@/constants/mockKemantrenPolygons";

// Tiga kategori pelanggaran administrasi — warnanya konsisten dipakai di
// poligon peta, ikon daftar, dan badge, supaya satu wilayah selalu terbaca
// dengan warna yang sama di kedua panel.
const KATEGORI_ISU = {
  belum_registrasi: { label: "WP Belum Registrasi", color: "#f43f5e" },
  profil_tidak_lengkap: { label: "Profil Tidak Lengkap", color: CHART_COLORS.amber },
  belum_tervalidasi: { label: "OP Belum Tervalidasi", color: CHART_TARGET_COLOR },
} as const;

type KategoriIsu = keyof typeof KATEGORI_ISU;

interface WilayahFokus {
  id: string;
  kemantren: keyof typeof KEMANTREN_POLYGONS;
  kategori: KategoriIsu;
  jumlahWp: number;
}

// Nilai persis mengikuti acuan prototype BR-12.
const WILAYAH_FOKUS: WilayahFokus[] = [
  { id: "umbulharjo", kemantren: "Umbulharjo", kategori: "belum_registrasi", jumlahWp: 450 },
  { id: "gondokusuman", kemantren: "Gondokusuman", kategori: "profil_tidak_lengkap", jumlahWp: 320 },
  { id: "jetis", kemantren: "Jetis", kategori: "belum_registrasi", jumlahWp: 150 },
  { id: "tegalrejo", kemantren: "Tegalrejo", kategori: "belum_tervalidasi", jumlahWp: 90 },
  { id: "mergangsan", kemantren: "Mergangsan", kategori: "profil_tidak_lengkap", jumlahWp: 78 },
  { id: "kotagede", kemantren: "Kotagede", kategori: "belum_tervalidasi", jumlahWp: 64 },
];



const kepatuhanFilterFields = [
  {
    id: "kategoriIsu",
    label: "Kategori Pelanggaran",
    type: "select" as const,
    placeholder: "Pilih Kategori...",
    options: [
      { value: "all", label: "Semua Kategori Pelanggaran" },
      { value: "belum_registrasi", label: "WP Belum Registrasi" },
      { value: "profil_tidak_lengkap", label: "Profil WP Tidak Lengkap" },
      { value: "belum_tervalidasi", label: "OP Belum Tervalidasi" },
    ],
  },
  {
    id: "kemantren",
    label: "Wilayah Kemantren",
    type: "select" as const,
    placeholder: "Pilih Kemantren...",
    options: [
      { value: "all", label: "Semua Kemantren (14 Wilayah)" },
      ...Object.keys(KEMANTREN_POLYGONS).map((nama) => ({ value: nama.toLowerCase(), label: `Kemantren ${nama}` })),
    ],
  },
  {
    id: "tingkatUrgensi",
    label: "Tingkat Urgensi Penertiban",
    type: "select" as const,
    placeholder: "Semua Tingkat...",
    options: [
      { value: "all", label: "Semua Tingkat Urgensi" },
      { value: "kritis", label: "Kritis (> 300 WP)" },
      { value: "tinggi", label: "Tinggi (100 - 300 WP)" },
      { value: "sedang", label: "Sedang (< 100 WP)" },
    ],
  },
  {
    id: "tahunAnggaran",
    label: "Tahun Anggaran",
    type: "select" as const,
    placeholder: "Tahun...",
    options: [
      { value: "2026", label: "Tahun 2026 (Berjalan)" },
      { value: "2025", label: "Tahun 2025" },
      { value: "2024", label: "Tahun 2024" },
    ],
  },
];

const quickPresets: QuickPreset[] = [
  { label: "Semua Wilayah", values: { kategoriIsu: "all", kemantren: "all" } },
  { label: "Belum Registrasi", values: { kategoriIsu: "belum_registrasi" } },
  { label: "Zona Kritis", values: { tingkatUrgensi: "kritis" } },
  { label: "Profil Tidak Lengkap", values: { kategoriIsu: "profil_tidak_lengkap" } },
];

export function EarlyWarningDashboardPage() {
  const { toast } = useToastApp();

  const [filterValues, setFilterValues] = React.useState<Record<string, any>>({});
  // Wilayah terpilih menyatukan peta & daftar: klik poligon menyorot baris,
  // klik baris memfokuskan poligon. Tanpa ini kedua panel cuma dekoratif.
  const [selectedWilayah, setSelectedWilayah] = React.useState<string | null>(null);

  const handleResetFilter = () => {
    setFilterValues({});
    toast.info("Filter Kepatuhan Spasial Direset", {
      description: "Semua kriteria wilayah dan kategori pelanggaran dikembalikan ke kondisi awal.",
    });
  };

  const visibleWilayah = React.useMemo(() => {
    const kategori = filterValues.kategoriIsu;
    if (!kategori || kategori === "all") return WILAYAH_FOKUS;
    return WILAYAH_FOKUS.filter((w) => w.kategori === kategori);
  }, [filterValues.kategoriIsu]);

  const selectedWilayahData = React.useMemo(
    () => WILAYAH_FOKUS.find((w) => w.id === selectedWilayah),
    [selectedWilayah]
  );

  const KEMANTREN_CENTERS: Record<string, [number, number]> = {
    Umbulharjo: [-7.817, 110.388],
    Gondokusuman: [-7.7845, 110.38],
    Mergagangsan: [-7.812, 110.372],
    Tegalrejo: [-7.78, 110.355],
    Mantrijeron: [-7.82, 110.36],
    Danurejan: [-7.794, 110.37],
    Kotagede: [-7.828, 110.4],
  };

  const mapCenter = React.useMemo<[number, number]>(() => {
    if (selectedWilayahData && KEMANTREN_CENTERS[selectedWilayahData.kemantren]) {
      return KEMANTREN_CENTERS[selectedWilayahData.kemantren];
    }
    return YOGYAKARTA_CENTER;
  }, [selectedWilayahData]);

  const mapZoom = selectedWilayahData ? 14 : 12;

  const mapPolygons: MapPolygon[] = React.useMemo(
    () =>
      visibleWilayah.map((w) => {
        const kategori = KATEGORI_ISU[w.kategori];
        const isSelected = selectedWilayah === w.id;
        return {
          id: w.id,
          positions: KEMANTREN_POLYGONS[w.kemantren],
          title: w.kemantren,
          color: kategori.color,
          fillColor: kategori.color,
          // Wilayah terpilih dipertegas isiannya, bukan diganti warnanya —
          // supaya kategori tetap terbaca saat sedang disorot.
          fillOpacity: isSelected ? 0.65 : 0.25,
          weight: isSelected ? 3.5 : 1.5,
          // Nama wilayah dan jumlah WP menempel di tengah bentuknya, jadi peta
          // sudah menjawab "wilayah mana, berapa banyak" tanpa perlu diklik.
          centerLabel: `${w.kemantren} (${w.jumlahWp.toLocaleString("id-ID")} WP)`,
          centerLabelAlert: w.kategori === "belum_registrasi",
          popup: `${w.kemantren} (${w.jumlahWp} WP) — ${kategori.label}`,
          onClick: () => {
            setSelectedWilayah((prev) => (prev === w.id ? null : w.id));
            toast.info(`Fokus Wilayah: ${w.kemantren}`, {
              description: `${w.jumlahWp} WP dengan indikator ${kategori.label}. Map terfokus pada ${w.kemantren}.`,
            });
          },
        };
      }),
    [visibleWilayah, selectedWilayah, toast],
  );

  const listItems = React.useMemo(
    () =>
      visibleWilayah.map((w) => {
        const kategori = KATEGORI_ISU[w.kategori];
        return {
          id: w.id,
          label: w.kemantren,
          leading: <MapPin className="h-4 w-4" style={{ color: kategori.color }} />,
          value: `${w.jumlahWp.toLocaleString("id-ID")} WP`,
          badge: (
            <BadgeApp
              id={`badge-kategori-${w.id}`}
              variant={
                w.kategori === "belum_registrasi"
                  ? "solidRose"
                  : w.kategori === "profil_tidak_lengkap"
                    ? "solidAmber"
                    : "neutral"
              }
              size="sm"
            >
              {kategori.label}
            </BadgeApp>
          ),
          // Tanpa bar, mengikuti acuan: jumlah WP sudah tercetak di kanan dan
          // kategorinya dibawa badge, jadi bar hanya menambah bising.
          segments: [],
          meta: (
            <div className="flex items-center justify-between pt-1">
              <span className="text-[11px] font-bold text-vibrant-purple group-hover:text-vibrant-purple-dark group-hover:underline cursor-pointer flex items-center gap-1">
                Fokuskan Peta & Tugaskan Tim Penertiban &rarr;
              </span>
            </div>
          ),
          onClick: () => {
            setSelectedWilayah((prev) => (prev === w.id ? null : w.id));
            toast.info(`Fokus Wilayah: ${w.kemantren}`, {
              description: `${w.jumlahWp} WP dengan indikator ${kategori.label}. Map terfokus pada ${w.kemantren}.`,
            });
          },
        };
      }),
    [visibleWilayah, toast],
  );

  return (
    <div id="kepatuhan-spasial-dashboard-root" className="space-y-6 pb-12">
      {/* ------------------------------------------------------------- */}
      {/* HEADER PAGE                                                   */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col justify-between gap-4 border-b border-hairline-soft pb-4 md:flex-row md:items-center">
        <div>
          <div className="mb-1 flex flex-wrap items-center gap-x-3 gap-y-1.5">
            <BadgeApp id="hdr-badge-br12" variant="solidPurple" size="sm">
              BR-12 · Dashboard Peta Kepatuhan Spasial
            </BadgeApp>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <MapIcon className="h-3.5 w-3.5 text-vibrant-purple" />
              Distribusi Pelanggaran Administrasi
            </span>
            <span className="flex items-center gap-1 text-xs text-ink-muted">
              <Calendar className="h-3.5 w-3.5 text-vibrant-purple" />
              Tahun Anggaran 2026
            </span>
          </div>
          <TextApp id="hdr-title-kepatuhan-spasial" variant="h2" className="tracking-tight text-ink">
            Peta Kepatuhan Administrasi Wilayah
          </TextApp>
          <TextApp id="hdr-sub-kepatuhan-spasial" variant="body" className="text-xs text-ink-secondary">
            Visualisasi Distribusi Pelanggaran Administrasi & Prioritas Penertiban per Kemantren
          </TextApp>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <ButtonApp
            id="btn-refresh-kepatuhan-spasial"
            variant="secondary"
            size="sm"
            rounded="lg"
            onClick={() =>
              toast.info("Data Spasial Disinkronkan", {
                description: "Batas wilayah dan indikator pelanggaran diperbarui dari server GIS.",
              })
            }
            leftIcon={<RefreshCw className="h-3.5 w-3.5" />}
          >
            Sync Peta
          </ButtonApp>
          <ButtonApp
            id="btn-export-kepatuhan-spasial"
            variant="primary"
            size="sm"
            rounded="lg"
            leftIcon={<Download className="h-3.5 w-3.5" />}
            onClick={() =>
              toast.vibrant("Laporan Kepatuhan Spasial Diunduh", {
                description: "Berisi rincian wilayah prioritas penertiban beserta kategori pelanggarannya.",
              })
            }
          >
            Cetak Laporan Spasial
          </ButtonApp>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* FILTER BAR */}
      {/* ------------------------------------------------------------- */}
      <div className="flex w-full min-w-0 flex-nowrap items-center gap-2 overflow-x-auto rounded-2xl border border-hairline bg-surface px-3 py-3 shadow-xs">
        <span className="flex shrink-0 items-center gap-1.5 whitespace-nowrap text-xs font-semibold text-ink-secondary">
          <Filter className="h-4 w-4 text-vibrant-purple" />
          Filter:
        </span>

        {/* Shortcut inline utk field yang paling sering dipakai — nilainya
            dibagi dgn AdvanceFilterApp DAN menyaring poligon peta sekaligus
            daftar di sebelahnya, jadi bukan kontrol kosmetik. */}
        <div className="w-60 shrink-0">
          <DropdownApp
            id="select-kategori-isu-spasial"
            value={String(filterValues.kategoriIsu ?? "all")}
            onChange={(value) => setFilterValues((prev) => ({ ...prev, kategoriIsu: String(value) }))}
            options={[
              { label: "Semua Kategori Pelanggaran", value: "all" },
              { label: "WP Belum Registrasi", value: "belum_registrasi" },
              { label: "Profil WP Tidak Lengkap", value: "profil_tidak_lengkap" },
              { label: "OP Belum Tervalidasi", value: "belum_tervalidasi" },
            ]}
            size="sm"
            rounded="lg"
            menuPortal
          />
        </div>

        <div className="ml-auto shrink-0">
          <AdvanceFilterApp
            id="filter-kepatuhan-spasial"
            displayMode="modal"
            showActivePills={false}
            className="w-auto"
            triggerLabel="Advance Filter Spasial"
            triggerVariant="secondary"
            triggerSize="sm"
            triggerRounded="lg"
            title="Filter Wilayah & Kategori Pelanggaran Administrasi"
            fields={kepatuhanFilterFields}
            values={filterValues}
            onChange={setFilterValues}
            quickPresets={quickPresets}
            onReset={handleResetFilter}
            onApply={() => {
              toast.vibrant("Filter Kepatuhan Spasial Diterapkan", {
                description: "Peta dan daftar fokus penertiban menyesuaikan kriteria yang dipilih.",
              });
            }}
          />
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* PETA KEPATUHAN + FOKUS PENERTIBAN (BR-12)                      */}
      {/* Acuan tidak punya scorecard maupun tabel — dua panel ini saja. */}
      {/* ------------------------------------------------------------- */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <CardApp
          id="card-map-kepatuhan-spasial"
          className="flex flex-col border-hairline-soft p-5 lg:col-span-2"
          insight={{
            title: "Peta Kepatuhan Administrasi Wilayah",
            value: `${WILAYAH_FOKUS.reduce((acc, w) => acc + w.jumlahWp, 0).toLocaleString("id-ID")} WP Bermasalah`,
            status: "waspada",
            meta: ["Spasial", "Kepatuhan Administrasi", "TA 2026"],
            summary:
              "Peta ini memetakan di mana pelanggaran administrasi menumpuk, bukan sekadar berapa jumlahnya. Warna wilayah menyatakan kategori pelanggaran yang paling dominan di sana, sehingga tim penertiban tahu jenis tindakan apa yang harus disiapkan sebelum berangkat.",
            current: [
              "Umbulharjo menempati posisi tertinggi dengan 450 WP belum registrasi.",
              "Gondokusuman menyusul dengan 320 WP berprofil tidak lengkap — jenis masalah yang berbeda.",
            ],
            insights: [
              "Wilayah dengan pelanggaran terbanyak belum tentu butuh perlakuan sama: 'belum registrasi' menuntut penjangkauan lapangan, sedangkan 'profil tidak lengkap' bisa diselesaikan lewat verifikasi dokumen.",
            ],
            tacticalRecs: [
              "Kelompokkan penugasan tim berdasarkan warna wilayah, bukan berdasarkan besaran angkanya.",
            ],
            strategicRecs: [
              "Jadikan konsentrasi spasial ini dasar penempatan pos pelayanan bergerak di kemantren dengan beban terberat.",
            ],
            glossary: [
              { term: "WP", expansion: "Wajib Pajak", definition: "subjek yang menanggung kewajiban pajak daerah." },
            ],
            dataNotes: ["Batas wilayah adalah aproksimasi untuk keperluan visualisasi."],
          }}
        >
          <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
            <div>
              <TextApp id="title-map-kepatuhan" variant="h3" weight="bold" className="text-ink-primary">
                Peta Kepatuhan Administrasi Wilayah
              </TextApp>
              <TextApp id="sub-map-kepatuhan" variant="caption" className="text-ink-secondary">
                Klik wilayah untuk menyorot rinciannya pada panel Fokus Penertiban.
              </TextApp>
            </div>

            {/* Legenda kategori — warnanya sama persis dengan poligon & ikon
                daftar, jadi satu wilayah selalu dikenali dari warna itu. */}
            <div className="flex flex-wrap items-center gap-3">
              {Object.entries(KATEGORI_ISU).map(([key, kategori]) => (
                <span key={key} className="flex items-center gap-1.5">
                  <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: kategori.color }} />
                  <TextApp id={`legend-${key}`} variant="caption" className="text-[11px] text-ink-secondary">
                    {kategori.label}
                  </TextApp>
                </span>
              ))}
            </div>
          </div>

          <div className="h-[540px] w-full overflow-hidden rounded-xl border border-hairline-soft">
            <MapsApp
              id="map-kepatuhan-spasial"
              center={mapCenter}
              zoom={mapZoom}
              polygons={mapPolygons}
              tileProvider="openstreetmap"
              showControls
              className="h-full w-full"
            />
          </div>
        </CardApp>

        <CardApp
          id="card-fokus-penertiban"
          className="flex flex-col border-hairline-soft p-5"
          insight={{
            title: "Fokus Penertiban Spasial",
            value: `${visibleWilayah.length} Wilayah Prioritas`,
            status: "waspada",
            meta: ["Perencanaan", "Penertiban", "TA 2026"],
            summary:
              "Daftar ini mengurutkan wilayah berdasarkan beban pelanggaran administrasi, lengkap dengan jenis isunya. Fungsinya sebagai antrean kerja penertiban, bukan sekadar peringkat.",
            current: [
              "Empat wilayah teratas menyumbang lebih dari 80% total WP bermasalah.",
              "Dua kategori mendominasi: belum registrasi dan profil tidak lengkap.",
            ],
            insights: [
              "Beban terkonsentrasi di sedikit wilayah — penertiban akan jauh lebih efisien kalau digarap berurutan dari atas daftar ketimbang disebar merata.",
            ],
            tacticalRecs: [
              "Tuntaskan Umbulharjo dan Gondokusuman lebih dulu sebelum menyebar tim ke wilayah bernilai kecil.",
            ],
            strategicRecs: [
              "Evaluasi ulang daftar tiap triwulan; wilayah yang sudah tertangani harus digantikan oleh wilayah berikutnya, bukan dipertahankan sepanjang tahun.",
            ],
            dataNotes: ["Urutan mengikuti jumlah WP bermasalah, menyesuaikan filter aktif."],
          }}
        >
          <div className="mb-4">
            <TextApp id="title-fokus-penertiban" variant="h3" weight="bold" className="text-ink-primary">
              Fokus Penertiban Spasial
            </TextApp>
            <TextApp id="sub-fokus-penertiban" variant="caption" className="text-ink-secondary">
              Antrean wilayah prioritas — klik untuk memfokuskan peta.
            </TextApp>
          </div>

          <ProgressListApp
            id="list-fokus-penertiban"
            items={listItems}
            activeId={selectedWilayah ?? undefined}
            // Cukup untuk memuat seluruh wilayah pada filter default supaya
            // peringkat teratas tidak tergeser auto-loop; daftar yang lebih
            // panjang tetap melipat sendiri.
            maxHeight={540}
          />
        </CardApp>
      </div>
    </div>
  );
}

export default EarlyWarningDashboardPage;
