import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const skeletonAppVariants = cva(
  "relative overflow-hidden bg-hairline-soft",
  {
    variants: {
      variant: {
        rect: "rounded-sm",
        circle: "rounded-full",
        text: "rounded-xs h-3 w-full",
        avatar: "rounded-full aspect-square",
        image: "rounded-md aspect-video w-full",
      },
      size: {
        sm: "h-3",
        md: "h-5",
        lg: "h-8",
      },
    },
    defaultVariants: {
      variant: "rect",
      size: "md",
    },
  }
);

export interface SkeletonAppProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof skeletonAppVariants> {
  id: string;
  animation?: "pulse" | "shimmer" | "none";
  tone?: "light" | "medium" | "dark";
  opacity?: "soft" | "default" | "strong";
  rounded?: "none" | "sm" | "md" | "lg" | "full";
}

const tones = { light: "bg-hairline-soft", medium: "bg-hairline-hard", dark: "bg-ink-muted/25" };
const opacities = { soft: "opacity-60", default: "opacity-100", strong: "opacity-100" };
const roundedClasses = { none: "rounded-none", sm: "rounded-[var(--radius-sm)]", md: "rounded-[var(--radius-md)]", lg: "rounded-[var(--radius-lg)]", full: "rounded-full" };

export function SkeletonApp({
  id,
  variant,
  size,
  animation = "pulse",
  tone = "light",
  opacity = "default",
  rounded,
  className,
  ...props
}: SkeletonAppProps) {
  return (
    <div
      id={id}
      data-ui-id={id}
      aria-hidden="true"
      className={cn(
        skeletonAppVariants({ variant, size }),
        animation === "pulse" && "animate-pulse motion-reduce:animate-none",
        animation === "shimmer" && "ds-skeleton-shimmer motion-reduce:animate-none",
        tones[tone],
        opacities[opacity],
        rounded && roundedClasses[rounded],
        className
      )}
      {...props}
    />
  );
}
