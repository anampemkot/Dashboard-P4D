import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { Lightbulb } from "lucide-react";
import { cn } from "@/lib/utils";
import { BadgeApp } from "./BadgeApp";
import { PopoverApp } from "../molecules/PopoverApp";
import { InsightApp, type InsightContent } from "../molecules/InsightApp";

const cardAppVariants = cva(
  "border transition-all flex flex-col relative",
  {
    variants: {
      variant: {
        neutral: "bg-surface text-ink border-hairline-soft shadow-xs",
        primary: "bg-vibrant-purple-dark text-white border-transparent shadow-vibrant-purple-inset",
        brand: "bg-vibrant-purple text-vibrant-purple-ink border-transparent shadow-vibrant-purple",
        secondary: "bg-surface-soft text-ink border-hairline shadow-xs",
        danger: "bg-accent text-white border-transparent shadow-xs",
        purple: "bg-vibrant-purple text-vibrant-purple-ink border-transparent shadow-vibrant-purple",
        purpleDark: "bg-vibrant-purple-dark text-white border-transparent shadow-vibrant-purple-inset",
        yellow: "bg-vibrant-yellow text-vibrant-yellow-ink border-transparent shadow-vibrant-yellow",
        blue: "bg-vibrant-blue text-vibrant-blue-ink border-transparent shadow-vibrant-blue",
        clay: "clay-card text-ink border-transparent",
        clayPurple: "clay-card clay-card-purple text-white border-transparent",
        clayYellow: "clay-card clay-card-yellow text-[#6f5100] dark:text-amber-100 border-transparent",
        clayBlue: "clay-card clay-card-blue text-[#674bb5] dark:text-blue-100 border-transparent",
      },
      size: {
        sm: "p-4 gap-3",
        md: "p-6 gap-4",
        lg: "p-8 gap-5",
        none: "p-0",
      },
      theme: {
        default: "",
        playful: "font-display border-2 border-hairline-soft shadow-vibrant-heavy",
      },
      rounded: {
        // Aligned to the Foundation radius scale (none=0, sm=4px, md=8px, lg=16px)
        // so CardApp matches ButtonApp/InputApp/SelectApp/DropdownApp exactly.
        default: "rounded-card-custom",
        none: "rounded-none",
        sm: "rounded-[4px]",
        md: "rounded-[8px]",
        lg: "rounded-[16px]",
        full: "rounded-full",
        pill: "rounded-pill-custom",
        card: "rounded-card-custom",
      },
    },
    defaultVariants: {
      variant: "neutral",
      size: "md",
      rounded: "default",
      theme: "default",
    },
  }
);

// Ensures the badge always reads clearly against its host card's background
// AND still looks like it belongs to that card's color family (a flat
// white/black pill on every card reads as generic/disconnected from the
// variant). Each entry below pairs the card's own hue family with a fixed,
// always-dark shade of that family — NOT the app's "-ink"/"-dark" design
// tokens, which are deliberately remapped per light/dark theme to stay
// readable against their OWN (also-remapped) card background, and can flip
// to a near-white value in dark mode (e.g. --palette-vibrant-purple-ink
// becomes #f5f3ff), which would silently break a badge that assumed it was
// always dark. These hex values are fixed constants instead, so contrast is
// guaranteed identically in both themes. Verified against white/black:
// violet #6d28d9 (7.10:1), amber #78350f (9.07:1), navy #1e3a8a (10.36:1),
// rose #be123c (6.29:1) — all comfortably pass WCAG AA (4.5:1) either way.
// Light/pastel card fills get a solid dark-family pill (colored bg, white
// text); dark/saturated fills get a light pill (white bg, family-colored
// text) — mirrors the ink-vs-white text color already chosen per variant in
// cardAppVariants above. Colors are applied via inline `style`, not
// Tailwind arbitrary-value classes: dynamically-interpolated `bg-[#hex]`
// classes have silently failed to appear in this project's compiled CSS
// before (see focusRing.ts), so inline style is the reliable path here.
const PURPLE_FAMILY = "#6d28d9";
const YELLOW_FAMILY = "#78350f";
const BLUE_FAMILY = "#1e3a8a";
const RED_FAMILY = "#be123c";

export interface CardBadgeColors {
  background: string;
  color: string;
}

const badgeColorsByCardVariant: Record<string, CardBadgeColors> = {
  neutral: { background: PURPLE_FAMILY, color: "#ffffff" },
  primary: { background: "#ffffff", color: PURPLE_FAMILY },
  brand: { background: "#ffffff", color: PURPLE_FAMILY },
  secondary: { background: PURPLE_FAMILY, color: "#ffffff" },
  danger: { background: "#ffffff", color: RED_FAMILY },
  purple: { background: "#ffffff", color: PURPLE_FAMILY },
  purpleDark: { background: "#ffffff", color: PURPLE_FAMILY },
  yellow: { background: YELLOW_FAMILY, color: "#ffffff" },
  blue: { background: BLUE_FAMILY, color: "#ffffff" },
  clay: { background: PURPLE_FAMILY, color: "#ffffff" },
  clayPurple: { background: "#ffffff", color: PURPLE_FAMILY },
  clayYellow: { background: YELLOW_FAMILY, color: "#ffffff" },
  clayBlue: { background: BLUE_FAMILY, color: "#ffffff" },
};

export type CardBadgePosition = "top-left" | "top-center";

const badgePositionClasses: Record<CardBadgePosition, string> = {
  "top-left": "top-3 left-3",
  "top-center": "top-3 left-1/2 -translate-x-1/2",
};

export interface CardAppProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof cardAppVariants> {
  id: string;
  /**
   * Text/content for the auto-contrast corner badge.
   *
   * The badge's colors are NOT a `BadgeApp` variant picked per card
   * `variant` — see `badgeColorsByCardVariant` above and the render below.
   * `BadgeApp`'s own themed variants (`purple`, `yellow`, `blue`, etc.) are
   * remapped per light/dark theme to match their OWN card-like surface, so
   * reusing one of them here can land on nearly the same hue as this card's
   * background (that was the original bug). Use `badgeColors` if you need
   * a specific pair instead of the auto-picked one.
   */
  badge?: React.ReactNode;
  /** Overrides the auto-picked { background, color } pair (chosen per card `variant` for guaranteed, on-brand contrast). */
  badgeColors?: CardBadgeColors;
  /** Where the badge slot is anchored. Defaults to "top-left". */
  badgePosition?: CardBadgePosition;
  /** When provided, renders an interactive lightbulb trigger (top-right) that opens a PopoverApp with this content — the "Card + Insight" variant. */
  insightContent?: React.ReactNode;
  /**
   * Structured insight-dialog content (Ringkasan/Kondisi Saat Ini/Insight/
   * Rekomendasi/Glosarium) — renders via the shared `InsightApp` dialog
   * primitive instead of `insightContent`'s lighter popover. Prefer this for
   * anything beyond a short freeform note. Anchors to the same top-right
   * corner as `insightContent`, so use only one of the two per card.
   */
  insight?: InsightContent;
}

export function CardApp({
  id,
  variant,
  size,
  rounded,
  theme,
  className,
  children,
  badge,
  badgeColors,
  badgePosition = "top-left",
  insightContent,
  insight,
  ...props
}: CardAppProps) {
  const resolvedBadgeColors: CardBadgeColors =
    badgeColors ?? badgeColorsByCardVariant[variant ?? "neutral"] ?? badgeColorsByCardVariant.neutral;

  return (
    <div
      id={id}
      data-ui-id={id}
      className={cn(cardAppVariants({ variant, size, rounded, theme, className }))}
      {...props}
    >
      {badge && (
        <span className={cn("absolute z-10", badgePositionClasses[badgePosition])}>
          {/*
            variant="contrastLight" here is only a shape/padding/font-weight
            base — its own bg-white/text-zinc-900 classes are immediately
            overridden below via inline `style`. The actual color comes from
            resolvedBadgeColors (badgeColorsByCardVariant), not from this
            variant. See the BadgeApp variant's own comment in BadgeApp.tsx
            for the reasoning, and the prop doc on `badge` above.
          */}
          <BadgeApp
            id={`${id}-badge`}
            variant="contrastLight"
            size="sm"
            rounded="pill"
            className="border"
            style={{
              backgroundColor: resolvedBadgeColors.background,
              color: resolvedBadgeColors.color,
              borderColor: `${resolvedBadgeColors.color}26`,
            }}
          >
            {badge}
          </BadgeApp>
        </span>
      )}

      {insightContent && (
        <PopoverApp
          id={`${id}-insight-popover`}
          position="bottom"
          trigger={
            <button
              type="button"
              id={`${id}-insight-trigger`}
              aria-label="Lihat insight"
              onClick={(event) => event.stopPropagation()}
              className="absolute right-3 top-3 z-10 inline-flex h-7 w-7 items-center justify-center rounded-[16px] border border-hairline-soft bg-surface/90 text-vibrant-purple-dark shadow-xs backdrop-blur-md transition-all hover:scale-105 hover:bg-surface active:scale-95 cursor-pointer"
            >
              <Lightbulb className="h-3.5 w-3.5" />
            </button>
          }
        >
          <div className="max-w-xs text-xs text-ink">{insightContent}</div>
        </PopoverApp>
      )}

      {insight && (
        <InsightApp
          id={`${id}-insight`}
          content={insight}
          triggerClassName="absolute right-3 top-3 z-10 h-7 w-7 rounded-[16px] border border-hairline-soft bg-surface/90 shadow-xs backdrop-blur-md hover:scale-105 hover:bg-surface/90 active:scale-95"
        />
      )}

      {children}
    </div>
  );
}

// Subcomponents
export interface CardAppHeaderProps extends React.HTMLAttributes<HTMLDivElement> {}
export function CardAppHeader({ className, children, ...props }: CardAppHeaderProps) {
  return (
    <div className={cn("flex flex-col gap-1.5 text-left", className)} {...props}>
      {children}
    </div>
  );
}

export interface CardAppTitleProps extends React.HTMLAttributes<HTMLHeadingElement> {
  tooltip?: string;
  onInfoClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
}
export function CardAppTitle({ className, children, tooltip, onInfoClick, ...props }: CardAppTitleProps) {
  return (
    <h3 className={cn("font-extrabold font-display text-2xl leading-tight flex items-center gap-1.5", className)} {...props}>
      <span>{children}</span>
      {tooltip && (
        <span className="relative group inline-flex items-center hover:z-[100]">
          <button
            type="button"
            onClick={onInfoClick}
            className="text-ink-muted/60 hover:text-ink hover:scale-105 active:scale-95 transition-all p-0.5 rounded-full inline-flex items-center justify-center focus:outline-none focus:ring-1 focus:ring-vibrant-purple-dark"
            title={tooltip}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-info"
            >
              <circle cx="12" cy="12" r="10" />
              <path d="M12 16v-4" />
              <path d="M12 8h.01" />
            </svg>
          </button>
          <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 hidden group-hover:block bg-zinc-900 text-white text-[10px] p-2.5 rounded-md shadow-lg font-sans font-medium text-center z-[100] pointer-events-none transition-all duration-150 border border-white/10">
            {tooltip}
            <span className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 border-4 border-transparent border-t-zinc-900" />
          </span>
        </span>
      )}
    </h3>
  );
}

export interface CardAppDescriptionProps extends React.HTMLAttributes<HTMLParagraphElement> {}
export function CardAppDescription({ className, children, ...props }: CardAppDescriptionProps) {
  return (
    <p className={cn("text-xs font-medium opacity-80", className)} {...props}>
      {children}
    </p>
  );
}

export interface CardAppContentProps extends React.HTMLAttributes<HTMLDivElement> {}
export function CardAppContent({ className, children, ...props }: CardAppContentProps) {
  return (
    <div className={cn("flex-1", className)} {...props}>
      {children}
    </div>
  );
}

export interface CardAppFooterProps extends React.HTMLAttributes<HTMLDivElement> {}
export function CardAppFooter({ className, children, ...props }: CardAppFooterProps) {
  return (
    <div className={cn("mt-auto pt-4 flex items-center justify-between border-t border-hairline-soft", className)} {...props}>
      {children}
    </div>
  );
}

// Attach subcomponents for compound syntax
CardApp.Header = CardAppHeader;
CardApp.Title = CardAppTitle;
CardApp.Description = CardAppDescription;
CardApp.Content = CardAppContent;
CardApp.Footer = CardAppFooter;
