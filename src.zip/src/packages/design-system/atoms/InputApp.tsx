import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { Eye, EyeOff, ChevronUp, ChevronDown, Check, AlertCircle, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { TextApp } from "./TextApp";
import { resolveIconSizeForControlSize, withInheritedIconSize } from "./IconApp";
import { focusWithinBorderRingClass, FOCUS_WITHIN_RING_WIDTH_OFFSET } from "../tokens/focusRing";

export type InputVariant = "default" | "error" | "success" | "filled";
export type InputSize = "sm" | "md" | "lg";
export type InputRounded = "none" | "sm" | "md" | "lg" | "xl" | "full" | "pill" | "card" | "input" | "default";
export type InputTheme = "default" | "playful";

const inputWrapperVariants = cva(
  `w-full flex items-center transition-all duration-150 border outline-none focus-within:outline-none gap-1.5 ${FOCUS_WITHIN_RING_WIDTH_OFFSET}`,
  {
    variants: {
      variant: {
        default: `bg-surface border-hairline ${focusWithinBorderRingClass.default}`,
        filled: `bg-surface-soft border-transparent focus-within:bg-surface ${focusWithinBorderRingClass.default}`,
        error: `bg-surface border-error ${focusWithinBorderRingClass.error}`,
        success: `bg-surface border-success ${focusWithinBorderRingClass.success}`,
      },
      size: {
        // Heights (32/40/48px) match ButtonApp/DropdownApp exactly so a row mixing
        // buttons, inputs, and dropdown triggers at the same size tier stays aligned.
        sm: "px-3 py-1.5 min-h-[32px] text-xs",
        md: "px-3 py-2 min-h-[40px] text-sm",
        lg: "px-4 py-2.5 min-h-[48px] text-body",
      },
      theme: {
        default: "",
        playful: "bg-surface border-hairline shadow-[inset_0_0_0_1px_rgba(0,0,0,.04)] focus-within:border-vibrant-purple-dark focus-within:ring-vibrant-purple-dark font-display",
      },
      rounded: {
        // Aligned to the Foundation radius scale (none=0, sm=4px, md=8px, lg=16px)
        // so InputApp matches ButtonApp/CardApp/BadgeApp exactly.
        default: "rounded-[8px]",
        none: "rounded-none",
        sm: "rounded-[4px]",
        md: "rounded-[8px]",
        lg: "rounded-[16px]",
        xl: "rounded-xl",
        full: "rounded-full",
        pill: "rounded-full",
        card: "rounded-card-custom",
        input: "rounded-input-custom",
      },
      disabled: {
        true: "opacity-50 cursor-not-allowed bg-vibrant-grey-bg/60 text-ink-muted focus-within:ring-0",
        false: "",
      },
    },
    defaultVariants: {
      variant: "default",
      // Kept in lockstep with ButtonApp's defaults (size="sm", rounded="lg") per
      // project-wide alignment: Button/Input/TextArea/Select/Dropdown/DatePicker/
      // SearchBar/Otp/TradingInput all default to the same size & radius tier.
      size: "sm",
      rounded: "lg",
      theme: "default",
      disabled: false,
    },
  }
);

export interface InputAppProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "size">,
    Omit<VariantProps<typeof inputWrapperVariants>, "disabled" | "variant"> {
  id: string;
  variant?: InputVariant;
  label?: React.ReactNode;
  helperText?: string;
  errorMessage?: string;
  successMessage?: string;
  leadingIcon?: React.ReactNode;
  trailingIcon?: React.ReactNode;
  showClear?: boolean;
  onClear?: () => void;
  showPasswordToggle?: boolean;
  showStepper?: boolean;
  showMaxLength?: boolean;
  containerClassName?: string;
}

export const InputApp = React.forwardRef<HTMLInputElement, InputAppProps>(
  (
    {
      id,
      type = "text",
      variant = "default",
      size = "sm",
      rounded = "lg",
      theme = "default",
      label,
      helperText,
      errorMessage,
      successMessage,
      leadingIcon,
      trailingIcon,
      showClear = false,
      onClear,
      showPasswordToggle,
      showStepper,
      showMaxLength = false,
      maxLength,
      disabled = false,
      className,
      containerClassName,
      value,
      defaultValue,
      onChange,
      ...props
    },
    ref
  ) => {
    const inputRef = React.useRef<HTMLInputElement | null>(null);
    React.useImperativeHandle(ref, () => inputRef.current!);

    const [showPassword, setShowPassword] = React.useState(false);
    const [inputValue, setInputValue] = React.useState<string>(
      value !== undefined ? String(value) : defaultValue !== undefined ? String(defaultValue) : ""
    );

    React.useEffect(() => {
      if (value !== undefined) {
        setInputValue(String(value));
      }
    }, [value]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (value === undefined) {
        setInputValue(e.target.value);
      }
      onChange?.(e);
    };

    const handleClear = (e: React.MouseEvent) => {
      e.stopPropagation();
      if (disabled) return;
      if (value === undefined) {
        setInputValue("");
      }
      onClear?.();
      if (inputRef.current) {
        inputRef.current.value = "";
        const event = new Event("change", { bubbles: true });
        inputRef.current.dispatchEvent(event);
      }
    };

    const handleStep = (direction: "up" | "down", e: React.MouseEvent) => {
      e.stopPropagation();
      if (disabled || !inputRef.current) return;
      const step = Number(props.step) || 1;
      const currentVal = Number(inputRef.current.value) || 0;
      const newVal = direction === "up" ? currentVal + step : currentVal - step;
      inputRef.current.value = String(newVal);
      if (value === undefined) {
        setInputValue(String(newVal));
      }
      const event = new Event("change", { bubbles: true });
      inputRef.current.dispatchEvent(event);
    };

    // Determine state variant
    const computedVariant: InputVariant = errorMessage
      ? "error"
      : successMessage
      ? "success"
      : variant;

    // Password toggle handling
    const isPasswordType = type === "password" || showPasswordToggle;
    const currentInputType = isPasswordType ? (showPassword ? "text" : "password") : type;

    // Number stepper handling
    const isNumberType = type === "number" || showStepper;

    const currentLength = inputValue.length;
    const inheritedIconSize = resolveIconSizeForControlSize(size);

    return (
      <div className={cn("flex flex-col gap-2 w-full", containerClassName)}>
        {/* Support Label */}
        {label && (
          <label htmlFor={id} className="text-xs font-semibold text-ink flex items-center gap-1.5 select-none">
            {typeof label === "string" ? (
              <TextApp id={`${id}-label-text`} variant="caption" weight="semibold" className="text-ink">
                {label}
              </TextApp>
            ) : (
              label
            )}
          </label>
        )}

        {/* Input Wrapper Container */}
        <div
          className={cn(
            inputWrapperVariants({
              variant: computedVariant,
              size,
              rounded,
              theme,
              disabled,
            })
          )}
        >
          {/* Leading Icon */}
          {leadingIcon && (
            <div className="flex items-center justify-center text-ink-muted flex-shrink-0 gap-1.5">
              {withInheritedIconSize(leadingIcon, inheritedIconSize)}
            </div>
          )}

          {/* Native Input Element */}
          <input
            ref={inputRef}
            id={id}
            data-ui-id={id}
            type={currentInputType}
            disabled={disabled}
            maxLength={maxLength}
            value={value !== undefined ? value : inputValue}
            onChange={handleInputChange}
            className={cn(
              "w-full bg-transparent border-0 outline-none focus:outline-none text-ink placeholder:text-ink-muted/50 font-sans p-0 m-0 min-w-0 disabled:cursor-not-allowed",
              // Hide the browser's native number spin buttons — InputApp already
              // renders its own custom stepper (ChevronUp/ChevronDown) below.
              isNumberType && "[appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none",
              size === "sm" && "text-xs",
              size === "md" && "text-sm",
              size === "lg" && "text-body",
              className
            )}
            {...props}
          />

          {/* Trailing Icons / Clear / Password Toggle / Stepper / Success-Error Icons */}
          <div className="flex items-center gap-1.5 flex-shrink-0 text-ink-muted">
            {/* Clear Button */}
            {showClear && !disabled && inputValue.length > 0 && (
              <button
                type="button"
                onClick={handleClear}
                className="p-0.5 rounded-full hover:bg-vibrant-grey-bg/80 text-ink-muted hover:text-ink transition-colors cursor-pointer"
                title="Hapus teks"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}

            {/* Password Toggle Eye Icon */}
            {isPasswordType && (
              <button
                type="button"
                onClick={() => setShowPassword((prev) => !prev)}
                disabled={disabled}
                className="p-0.5 rounded hover:bg-vibrant-grey-bg/80 text-ink-muted hover:text-ink transition-colors cursor-pointer disabled:opacity-50"
                title={showPassword ? "Sembunyikan password" : "Tampilkan password"}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            )}

            {/* Number Stepper Controls — icon/padding scaled by size so the two
                stacked chevrons fit inside the row's own min-height instead of
                forcing it taller than a same-size text InputApp. */}
            {isNumberType && (
              <div className="flex flex-col justify-center -mr-1">
                <button
                  type="button"
                  onClick={(e) => handleStep("up", e)}
                  disabled={disabled}
                  className={cn(
                    "flex items-center justify-center hover:text-vibrant-purple-dark text-ink-muted transition-colors cursor-pointer leading-none disabled:opacity-50",
                    size === "sm" ? "p-0" : "p-0.5"
                  )}
                >
                  <ChevronUp className={size === "sm" ? "w-2.5 h-2.5" : "w-3 h-3"} />
                </button>
                <button
                  type="button"
                  onClick={(e) => handleStep("down", e)}
                  disabled={disabled}
                  className={cn(
                    "flex items-center justify-center hover:text-vibrant-purple-dark text-ink-muted transition-colors cursor-pointer leading-none disabled:opacity-50",
                    size === "sm" ? "p-0" : "p-0.5"
                  )}
                >
                  <ChevronDown className={size === "sm" ? "w-2.5 h-2.5" : "w-3 h-3"} />
                </button>
              </div>
            )}

            {/* Custom Trailing Icon or Default State Icon */}
            {trailingIcon ? (
              withInheritedIconSize(trailingIcon, inheritedIconSize)
            ) : computedVariant === "error" ? (
              <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
            ) : computedVariant === "success" ? (
              <Check className="w-4 h-4 text-emerald-500 flex-shrink-0" />
            ) : null}
          </div>
        </div>

        {/* Bottom Helper / Error / Success Message & Max Length Counter */}
        {(errorMessage || successMessage || helperText || (showMaxLength && maxLength)) && (
          <div className="flex items-center justify-between gap-2 px-0.5">
            {/* Message Area */}
            <div className="flex items-center gap-1.5 flex-1 min-w-0">
              {errorMessage ? (
                <>
                  <AlertCircle className="w-3.5 h-3.5 text-red-500 flex-shrink-0" />
                  <TextApp id={`${id}-error-text`} variant="caption" className="text-red-500 font-medium truncate">
                    {errorMessage}
                  </TextApp>
                </>
              ) : successMessage ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                  <TextApp id={`${id}-success-text`} variant="caption" className="text-emerald-600 font-medium truncate">
                    {successMessage}
                  </TextApp>
                </>
              ) : helperText ? (
                <TextApp id={`${id}-helper-text`} variant="caption" className="text-ink-muted truncate">
                  {helperText}
                </TextApp>
              ) : <div />}
            </div>

            {/* Max Length Counter (e.g., 45/50) */}
            {showMaxLength && maxLength && (
              <TextApp
                id={`${id}-maxlength-counter`}
                variant="caption"
                className={cn(
                  "font-mono text-ink-muted text-[11px] flex-shrink-0 whitespace-nowrap",
                  currentLength >= maxLength && "text-red-500 font-bold"
                )}
              >
                {currentLength}/{maxLength}
              </TextApp>
            )}
          </div>
        )}
      </div>
    );
  }
);

InputApp.displayName = "InputApp";

