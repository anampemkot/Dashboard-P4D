import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { TextApp } from "./TextApp";
import { focusPeerRingClass, FOCUS_PEER_RING_WIDTH_OFFSET } from "../tokens/focusRing";

export type RadioVariant = "default" | "brand" | "vibrant" | "success" | "error";
export type RadioSize = "sm" | "md" | "lg";

const radioBoxVariants = cva(
  `rounded-full border border-slate-400 dark:border-slate-500 bg-surface text-white transition-all duration-150 flex items-center justify-center select-none shrink-0 cursor-pointer pointer-events-none hover:border-vibrant-purple-dark ${FOCUS_PEER_RING_WIDTH_OFFSET}`,
  {
    variants: {
      variant: {
        default: `border-slate-400 dark:border-slate-500 bg-surface text-white peer-checked:bg-vibrant-purple-dark peer-checked:border-vibrant-purple-dark ${focusPeerRingClass.default}`,
        brand: `border-slate-400 dark:border-slate-500 bg-surface text-white peer-checked:bg-vibrant-purple-dark peer-checked:border-vibrant-purple-dark ${focusPeerRingClass.default}`,
        vibrant: `border-slate-400 dark:border-slate-500 bg-surface text-white peer-checked:bg-vibrant-purple-dark peer-checked:border-vibrant-purple-dark ${focusPeerRingClass.default}`,
        success: `border-slate-400 dark:border-slate-500 bg-surface text-white peer-checked:bg-success peer-checked:border-success ${focusPeerRingClass.success}`,
        error: `border-error bg-surface text-white peer-checked:bg-error peer-checked:border-error ${focusPeerRingClass.error}`,
      },
      size: {
        sm: "w-3.5 h-3.5",
        md: "w-4 h-4",
        lg: "w-5 h-5",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "sm",
    },
  }
);

export interface RadioAppProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "size"> {
  id: string;
  variant?: RadioVariant;
  size?: RadioSize;
  label?: React.ReactNode;
  description?: React.ReactNode;
  helperText?: React.ReactNode;
  error?: string;
  errorMessage?: string;
  onCheckedChange?: (checked: boolean) => void;
  containerClassName?: string;
}

export const RadioApp = React.forwardRef<HTMLInputElement, RadioAppProps>(
  (
    {
      id,
      variant = "default",
      size = "sm",
      label,
      description,
      helperText,
      error,
      errorMessage,
      disabled = false,
      checked,
      defaultChecked,
      onChange,
      onCheckedChange,
      className,
      containerClassName,
      ...props
    },
    ref
  ) => {
    const inputRef = React.useRef<HTMLInputElement | null>(null);
    React.useImperativeHandle(ref, () => inputRef.current!);

    const [isChecked, setIsChecked] = React.useState<boolean>(
      checked !== undefined ? !!checked : defaultChecked !== undefined ? !!defaultChecked : false
    );

    React.useEffect(() => {
      if (checked !== undefined) {
        setIsChecked(!!checked);
      }
    }, [checked]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (disabled) return;
      if (checked === undefined) {
        setIsChecked(e.target.checked);
      }
      onChange?.(e);
      onCheckedChange?.(e.target.checked);
    };

    const finalError = error || errorMessage;
    const computedVariant: RadioVariant = finalError ? "error" : variant;
    const descText = description || helperText;

    // Once an error has been shown, keep its row's height reserved even after the
    // error clears — otherwise toggling the radio makes the error message pop
    // in/out of layout and shifts every sibling below it.
    const hasEverHadError = React.useRef(false);
    if (finalError) hasEverHadError.current = true;

    return (
      <div className={cn("inline-flex flex-col gap-1 text-left", containerClassName)}>
        <label
          htmlFor={id}
          className={cn(
            "inline-flex items-start gap-2 select-none cursor-pointer group", // Step 2 Spacing (8px / gap-2)
            disabled && "cursor-not-allowed opacity-60"
          )}
        >
          <div className="relative inline-flex items-center shrink-0 mt-0.5">
            <input
              ref={inputRef}
              type="radio"
              id={id}
              data-ui-id={id}
              checked={isChecked}
              disabled={disabled}
              onChange={handleChange}
              className="peer absolute inset-0 opacity-0 w-full h-full cursor-pointer z-10 disabled:cursor-not-allowed"
              {...props}
            />
            <div
              className={cn(
                radioBoxVariants({ variant: computedVariant, size }),
                isChecked &&
                  (computedVariant === "error"
                    ? "bg-red-500 border-red-500 text-white"
                    : computedVariant === "success"
                    ? "bg-emerald-600 border-emerald-600 text-white"
                    : "bg-vibrant-purple-dark border-vibrant-purple-dark text-white"),
                disabled && "opacity-50 cursor-not-allowed bg-vibrant-grey-bg/60 border-slate-300 dark:border-slate-700",
                className
              )}
            >
              {isChecked && (
                <span
                  className={cn(
                    "rounded-full bg-white transition-all duration-150 transform scale-100",
                    size === "sm" ? "w-1.5 h-1.5" : size === "lg" ? "w-2.5 h-2.5" : "w-2 h-2"
                  )}
                />
              )}
            </div>
          </div>

          {(label || descText) && (
            <div className="flex flex-col text-left">
              {label && (
                typeof label === "string" ? (
                  <TextApp
                    id={`${id}-label`}
                    variant={size === "sm" ? "caption" : "body"}
                    weight="semibold"
                    className={cn(
                      "text-ink group-hover:text-vibrant-purple-dark transition-colors leading-snug",
                      disabled && "group-hover:text-ink text-ink-muted"
                    )}
                  >
                    {label}
                  </TextApp>
                ) : (
                  label
                )
              )}

              {descText && (
                typeof descText === "string" ? (
                  <TextApp
                    id={`${id}-desc`}
                    variant="caption"
                    className="text-ink-muted leading-tight mt-0.5"
                  >
                    {descText}
                  </TextApp>
                ) : (
                  descText
                )
              )}
            </div>
          )}
        </label>

        {hasEverHadError.current && (
          <div className="flex min-h-[1.125rem] items-center gap-1 pl-6">
            {finalError && (
              <>
                <AlertCircle className="w-3 h-3 text-red-500 shrink-0" />
                <TextApp id={`${id}-error`} variant="caption" className="font-medium text-red-500">
                  {finalError}
                </TextApp>
              </>
            )}
          </div>
        )}
      </div>
    );
  }
);

RadioApp.displayName = "RadioApp";

export interface RadioOption {
  value: string;
  label: React.ReactNode;
  description?: React.ReactNode;
  disabled?: boolean;
}

export interface RadioGroupAppProps {
  id: string;
  name?: string;
  label?: React.ReactNode;
  helperText?: string;
  errorMessage?: string;
  value?: string;
  defaultValue?: string;
  onChange?: (value: string) => void;
  options: RadioOption[];
  direction?: "vertical" | "horizontal" | "col" | "row";
  variant?: RadioVariant;
  size?: RadioSize;
  disabled?: boolean;
  className?: string;
}

export function RadioGroupApp({
  id,
  name,
  label,
  helperText,
  errorMessage,
  value,
  defaultValue,
  onChange,
  options,
  direction = "vertical",
  variant = "default",
  size = "md",
  disabled = false,
  className,
}: RadioGroupAppProps) {
  const [selectedValue, setSelectedValue] = React.useState<string>(
    value !== undefined ? value : defaultValue || ""
  );

  React.useEffect(() => {
    if (value !== undefined) {
      setSelectedValue(value);
    }
  }, [value]);

  const handleSelectOption = (optValue: string) => {
    if (value === undefined) {
      setSelectedValue(optValue);
    }
    onChange?.(optValue);
  };

  const isRow = direction === "horizontal" || direction === "row";
  const groupName = name || id;

  return (
    <div className={cn("flex flex-col gap-2 w-full text-left", className)}>
      {label && (
        typeof label === "string" ? (
          <TextApp id={`${id}-group-label`} variant="caption" weight="bold" className="text-ink uppercase tracking-wider">
            {label}
          </TextApp>
        ) : (
          label
        )
      )}

      {/* Options Container: Step 3 Spacing (12px / gap-3) */}
      <div className={cn(isRow ? "flex flex-wrap gap-3" : "flex flex-col gap-3")}>
        {options.map((opt, idx) => {
          const optId = `${id}-opt-${opt.value || idx}`;
          const isChecked = selectedValue === opt.value;
          const optDisabled = disabled || opt.disabled;

          return (
            <RadioApp
              key={opt.value}
              id={optId}
              name={groupName}
              value={opt.value}
              variant={variant}
              size={size}
              label={opt.label}
              description={opt.description}
              checked={isChecked}
              disabled={optDisabled}
              onChange={() => handleSelectOption(opt.value)}
            />
          );
        })}
      </div>

      {(errorMessage || helperText) && (
        <div className="mt-0.5">
          {errorMessage ? (
            <TextApp id={`${id}-group-error`} variant="caption" className="text-red-500 font-medium">
              {errorMessage}
            </TextApp>
          ) : (
            <TextApp id={`${id}-group-helper`} variant="caption" className="text-ink-muted">
              {helperText}
            </TextApp>
          )}
        </div>
      )}
    </div>
  );
}
