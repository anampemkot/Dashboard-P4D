import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

/**
 * SPACING SCALE (8px Base Grid with 4px Sub-steps)
 * 0  = 0px
 * 0.5= 2px
 * 1  = 4px  (0.25rem)
 * 1.5= 6px  (--space-xs)
 * 2  = 8px  (0.5rem)
 * 3  = 12px (0.75rem)
 * 4  = 16px (1rem, --space-sm)
 * 5  = 20px (1.25rem)
 * 6  = 24px (1.5rem, --space-md)
 * 8  = 32px (2rem)
 * 10 = 40px (2.5rem, --space-lg)
 * 12 = 48px (3rem)
 * 16 = 64px (4rem)
 * 20 = 80px (5rem, --space-xl)
 */
export const SPACING_SCALE = [
  { step: "0", px: "0px", rem: "0rem", use: "No gap / flush alignment" },
  { step: "1", px: "4px", rem: "0.25rem", use: "Tight micro padding, badge items" },
  { step: "1.5", px: "6px", rem: "0.375rem", use: "--space-xs token, icon-text gap" },
  { step: "2", px: "8px", rem: "0.5rem", use: "Form field gap, small button padding" },
  { step: "3", px: "12px", rem: "0.75rem", use: "Sub-card gap, compact list spacing" },
  { step: "4", px: "16px", rem: "1rem", use: "--space-sm token, standard card padding & grid gap" },
  { step: "5", px: "20px", rem: "1.25rem", use: "Medium component padding" },
  { step: "6", px: "24px", rem: "1.5rem", use: "--space-md token, section outer padding" },
  { step: "8", px: "32px", rem: "2rem", use: "Header to section gap, modal spacing" },
  { step: "10", px: "40px", rem: "2.5rem", use: "--space-lg token, major page container padding" },
  { step: "12", px: "48px", rem: "3rem", use: "Large section separator" },
  { step: "16", px: "64px", rem: "4rem", use: "Hero section gap" },
  { step: "20", px: "80px", rem: "5rem", use: "--space-xl token, desktop page footer margin" },
] as const;

/**
 * BREAKPOINT SYSTEM SPECIFICATION
 */
export const BREAKPOINTS = [
  { name: "Mobile (xs)", minWidth: "< 640px", cols: 4, margin: "16px", gap: "12px/16px", device: "Smartphone Portrait/Landscape" },
  { name: "Tablet Small (sm)", minWidth: "≥ 640px", cols: 6, margin: "24px", gap: "16px", device: "Large Phone / Mini Tablet" },
  { name: "Tablet Standard (md)", minWidth: "≥ 768px", cols: 8, margin: "24px", gap: "16px/24px", device: "iPad / Tablet Portrait" },
  { name: "Desktop Standard (lg)", minWidth: "≥ 1024px", cols: 12, margin: "32px", gap: "24px", device: "Laptop / Desktop" },
  { name: "Desktop Wide (xl)", minWidth: "≥ 1280px", cols: 12, margin: "40px", gap: "24px/32px", device: "1080p Monitor / Wide Screen" },
  { name: "Desktop Ultra (2xl)", minWidth: "≥ 1536px", cols: 12, margin: "48px", gap: "32px", device: "4K / Ultra-wide Display" },
] as const;

const gridAppVariants = cva("grid w-full items-stretch", {
  variants: {
    variant: {
      default: "grid-cols-4 sm:grid-cols-8 lg:grid-cols-12", // Best-practice: 4-col mobile, 8-col tablet, 12-col desktop
      full12: "grid-cols-12",
      bento: "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4",
      cards: "grid-cols-1 md:grid-cols-2 lg:grid-cols-3",
      metrics: "grid-cols-1 sm:grid-cols-2 lg:grid-cols-4",
      split: "grid-cols-1 lg:grid-cols-12",
      autoFit: "grid-cols-[repeat(auto-fit,minmax(280px,1fr))]",
      custom: "",
    },
    gap: {
      none: "gap-0",
      xs: "gap-1.5 sm:gap-2",      // 6px - 8px
      sm: "gap-3 sm:gap-4",        // 12px - 16px
      md: "gap-4 sm:gap-6",        // 16px - 24px (Standard)
      lg: "gap-6 sm:gap-8 lg:gap-10", // 24px - 40px
      xl: "gap-8 lg:gap-12",       // 32px - 48px
    },
    align: {
      start: "items-start",
      center: "items-center",
      end: "items-end",
      stretch: "items-stretch",
      baseline: "items-baseline",
    },
  },
  defaultVariants: {
    variant: "default",
    gap: "md",
    align: "stretch",
  },
});

type GridCount = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
const baseCols: Record<GridCount, string> = { 1: "grid-cols-1", 2: "grid-cols-2", 3: "grid-cols-3", 4: "grid-cols-4", 5: "grid-cols-5", 6: "grid-cols-6", 7: "grid-cols-7", 8: "grid-cols-8", 9: "grid-cols-9", 10: "grid-cols-10", 11: "grid-cols-11", 12: "grid-cols-12" };
const smCols: Record<GridCount, string> = { 1: "sm:grid-cols-1", 2: "sm:grid-cols-2", 3: "sm:grid-cols-3", 4: "sm:grid-cols-4", 5: "sm:grid-cols-5", 6: "sm:grid-cols-6", 7: "sm:grid-cols-7", 8: "sm:grid-cols-8", 9: "sm:grid-cols-9", 10: "sm:grid-cols-10", 11: "sm:grid-cols-11", 12: "sm:grid-cols-12" };
const mdCols: Record<GridCount, string> = { 1: "md:grid-cols-1", 2: "md:grid-cols-2", 3: "md:grid-cols-3", 4: "md:grid-cols-4", 5: "md:grid-cols-5", 6: "md:grid-cols-6", 7: "md:grid-cols-7", 8: "md:grid-cols-8", 9: "md:grid-cols-9", 10: "md:grid-cols-10", 11: "md:grid-cols-11", 12: "md:grid-cols-12" };
const lgCols: Record<GridCount, string> = { 1: "lg:grid-cols-1", 2: "lg:grid-cols-2", 3: "lg:grid-cols-3", 4: "lg:grid-cols-4", 5: "lg:grid-cols-5", 6: "lg:grid-cols-6", 7: "lg:grid-cols-7", 8: "lg:grid-cols-8", 9: "lg:grid-cols-9", 10: "lg:grid-cols-10", 11: "lg:grid-cols-11", 12: "lg:grid-cols-12" };
const xlCols: Record<GridCount, string> = { 1: "xl:grid-cols-1", 2: "xl:grid-cols-2", 3: "xl:grid-cols-3", 4: "xl:grid-cols-4", 5: "xl:grid-cols-5", 6: "xl:grid-cols-6", 7: "xl:grid-cols-7", 8: "xl:grid-cols-8", 9: "xl:grid-cols-9", 10: "xl:grid-cols-10", 11: "xl:grid-cols-11", 12: "xl:grid-cols-12" };
const twoXlCols: Record<GridCount, string> = { 1: "2xl:grid-cols-1", 2: "2xl:grid-cols-2", 3: "2xl:grid-cols-3", 4: "2xl:grid-cols-4", 5: "2xl:grid-cols-5", 6: "2xl:grid-cols-6", 7: "2xl:grid-cols-7", 8: "2xl:grid-cols-8", 9: "2xl:grid-cols-9", 10: "2xl:grid-cols-10", 11: "2xl:grid-cols-11", 12: "2xl:grid-cols-12" };

export interface GridAppProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof gridAppVariants> {
  id: string;
  cols?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
  colsSm?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
  colsMd?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
  colsLg?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
  colsXl?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
  cols2Xl?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
  as?: React.ElementType;
}

export function GridApp({
  id,
  className,
  variant,
  gap,
  align,
  cols,
  colsSm,
  colsMd,
  colsLg,
  colsXl,
  cols2Xl,
  as: Component = "div",
  children,
  ...props
}: GridAppProps) {
  // Dynamic column overrides if passed as direct props
  const colClasses = React.useMemo(() => {
    const classes: string[] = [];
    if (cols) classes.push(baseCols[cols]);
    if (colsSm) classes.push(smCols[colsSm]);
    if (colsMd) classes.push(mdCols[colsMd]);
    if (colsLg) classes.push(lgCols[colsLg]);
    if (colsXl) classes.push(xlCols[colsXl]);
    if (cols2Xl) classes.push(twoXlCols[cols2Xl]);
    return classes.join(" ");
  }, [cols, colsSm, colsMd, colsLg, colsXl, cols2Xl]);

  return (
    <Component
      id={id}
      className={cn(gridAppVariants({ variant: colClasses ? "custom" : variant, gap, align }), colClasses, className)}
      {...props}
    >
      {children}
    </Component>
  );
}

/* =========================================================================
   GRID COLUMN CHILD COMPONENT (ColApp)
   ========================================================================= */

export interface ColAppProps extends React.HTMLAttributes<HTMLDivElement> {
  id: string;
  span?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | "full";
  spanSm?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | "full";
  spanMd?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | "full";
  spanLg?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | "full";
  spanXl?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | "full";
  span2Xl?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | "full";
  offset?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11;
  offsetMd?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11;
  offsetLg?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11;
  as?: React.ElementType;
}

type GridSpan = GridCount | "full";
const baseSpans: Record<GridSpan, string> = { 1: "col-span-1", 2: "col-span-2", 3: "col-span-3", 4: "col-span-4", 5: "col-span-5", 6: "col-span-6", 7: "col-span-7", 8: "col-span-8", 9: "col-span-9", 10: "col-span-10", 11: "col-span-11", 12: "col-span-12", full: "col-span-full" };
const smSpans: Record<GridSpan, string> = { 1: "sm:col-span-1", 2: "sm:col-span-2", 3: "sm:col-span-3", 4: "sm:col-span-4", 5: "sm:col-span-5", 6: "sm:col-span-6", 7: "sm:col-span-7", 8: "sm:col-span-8", 9: "sm:col-span-9", 10: "sm:col-span-10", 11: "sm:col-span-11", 12: "sm:col-span-12", full: "sm:col-span-full" };
const mdSpans: Record<GridSpan, string> = { 1: "md:col-span-1", 2: "md:col-span-2", 3: "md:col-span-3", 4: "md:col-span-4", 5: "md:col-span-5", 6: "md:col-span-6", 7: "md:col-span-7", 8: "md:col-span-8", 9: "md:col-span-9", 10: "md:col-span-10", 11: "md:col-span-11", 12: "md:col-span-12", full: "md:col-span-full" };
const lgSpans: Record<GridSpan, string> = { 1: "lg:col-span-1", 2: "lg:col-span-2", 3: "lg:col-span-3", 4: "lg:col-span-4", 5: "lg:col-span-5", 6: "lg:col-span-6", 7: "lg:col-span-7", 8: "lg:col-span-8", 9: "lg:col-span-9", 10: "lg:col-span-10", 11: "lg:col-span-11", 12: "lg:col-span-12", full: "lg:col-span-full" };
const xlSpans: Record<GridSpan, string> = { 1: "xl:col-span-1", 2: "xl:col-span-2", 3: "xl:col-span-3", 4: "xl:col-span-4", 5: "xl:col-span-5", 6: "xl:col-span-6", 7: "xl:col-span-7", 8: "xl:col-span-8", 9: "xl:col-span-9", 10: "xl:col-span-10", 11: "xl:col-span-11", 12: "xl:col-span-12", full: "xl:col-span-full" };
const twoXlSpans: Record<GridSpan, string> = { 1: "2xl:col-span-1", 2: "2xl:col-span-2", 3: "2xl:col-span-3", 4: "2xl:col-span-4", 5: "2xl:col-span-5", 6: "2xl:col-span-6", 7: "2xl:col-span-7", 8: "2xl:col-span-8", 9: "2xl:col-span-9", 10: "2xl:col-span-10", 11: "2xl:col-span-11", 12: "2xl:col-span-12", full: "2xl:col-span-full" };

export function ColApp({
  id,
  className,
  span,
  spanSm,
  spanMd,
  spanLg,
  spanXl,
  span2Xl,
  offset,
  offsetMd,
  offsetLg,
  as: Component = "div",
  children,
  ...props
}: ColAppProps) {
  const spanClasses = React.useMemo(() => {
    const classes: string[] = [];

    // Base Mobile Span
    if (span) classes.push(baseSpans[span]);

    // Breakpoint Spans
    if (spanSm) classes.push(smSpans[spanSm]);

    if (spanMd) classes.push(mdSpans[spanMd]);

    if (spanLg) classes.push(lgSpans[spanLg]);

    if (spanXl) classes.push(xlSpans[spanXl]);

    if (span2Xl) classes.push(twoXlSpans[span2Xl]);

    // Offsets
    if (offset) classes.push(`col-start-${offset + 1}`);
    if (offsetMd) classes.push(`md:col-start-${offsetMd + 1}`);
    if (offsetLg) classes.push(`lg:col-start-${offsetLg + 1}`);

    return classes.join(" ");
  }, [span, spanSm, spanMd, spanLg, spanXl, span2Xl, offset, offsetMd, offsetLg]);

  return (
    <Component id={id} className={cn(spanClasses, className)} {...props}>
      {children}
    </Component>
  );
}

/* =========================================================================
   CONTAINER COMPONENT (ContainerApp)
   ========================================================================= */

export interface ContainerAppProps extends React.HTMLAttributes<HTMLDivElement> {
  id: string;
  fluid?: boolean;
  size?: "sm" | "md" | "lg" | "xl" | "full";
  as?: React.ElementType;
}

export function ContainerApp({
  id,
  className,
  fluid = false,
  size = "xl",
  as: Component = "div",
  children,
  ...props
}: ContainerAppProps) {
  const sizeClasses = {
    sm: "max-w-3xl",     // 768px
    md: "max-w-5xl",     // 1024px
    lg: "max-w-6xl",     // 1152px
    xl: "max-w-7xl",     // 1280px (BPKAD Standard Max Width)
    full: "max-w-full",
  };

  return (
    <Component
      id={id}
      className={cn(
        "w-full mx-auto px-4 sm:px-6 lg:px-8 transition-all",
        fluid ? "max-w-full" : sizeClasses[size],
        className
      )}
      {...props}
    >
      {children}
    </Component>
  );
}
