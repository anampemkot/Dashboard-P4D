import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "@/lib/utils";
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
  useTabsContext,
  type TabsProps,
  type TabsListProps,
  type TabsTriggerProps,
  type TabsContentProps,
} from "@/components/ui/tabs";
import { TextApp } from "../atoms/TextApp";
import { BadgeApp, BadgeAppProps } from "../atoms/BadgeApp";

export type TabsVariant = "underline" | "pills" | "enclosed" | "default" | "vibrant";
export type TabsOrientation = "horizontal" | "vertical";
export type TabsSize = "sm" | "md" | "lg";
export type TabsRounded = "none" | "sm" | "md" | "lg" | "xl" | "full";

export interface TabItem {
  id: string;
  label: string;
  icon?: React.ReactNode;
  disabled?: boolean;
  badge?: string | number;
  badgeVariant?: BadgeAppProps["variant"];
  content?: React.ReactNode;
}

// Skala Foundation — disamakan persis dengan ButtonApp/InputApp/SelectApp/
// CardApp (none=0, sm=4px, md=8px, lg=16px). Sebelumnya di sini memakai skala
// bawaan Tailwind (rounded-lg = 8px), sehingga rounded="lg" pada Tabs tidak
// sama lengkungannya dengan rounded="lg" pada Button/Select yang berdiri
// sebaris di toolbar yang sama. Varian underline tidak memakai peta ini sama
// sekali — lihat roundedClass di TabsListApp/TabsTriggerApp.
const roundedClasses: Record<TabsRounded, string> = {
  none: "rounded-none",
  sm: "rounded-[4px]",
  md: "rounded-[8px]",
  lg: "rounded-[16px]",
  xl: "rounded-xl",
  full: "rounded-full",
};

// Nilai piksel dari skala di atas — dipakai untuk menurunkan radius trigger
// dari radius track (lihat innerRoundedStyle di bawah).
const roundedPx: Record<TabsRounded, number | null> = {
  none: 0,
  sm: 4,
  md: 8,
  lg: 16,
  xl: 12,
  full: null, // pill: lingkaran penuh, sudah otomatis sekonsentris
};

// Padding track varian berkotak per size — harus sinkron dengan
// compoundVariants di tabsListVariants.
const trackPaddingPx: Record<TabsSize, number> = { sm: 2, md: 4, lg: 6 };

// Track varian berkotak punya border 1px. Border ikut menambah jarak antara
// kurva terluar (border-box, yang benar-benar terlihat) dan elemen di dalamnya,
// jadi harus ikut dikurangkan — lihat innerRoundedStyle.
const trackBorderPx = 1;

/**
 * Concentric (nested) border radius: supaya kurva trigger sejajar dengan
 * kurva track-nya, radius bagian dalam harus DIKURANGI jarak antar keduanya —
 *
 *     radius_dalam = radius_luar − (padding_track + border_track)
 *
 * Border ikut dihitung karena kurva terluar yang benar-benar terlihat ada di
 * border-box, sedangkan trigger duduk di dalam border DAN padding.
 *
 * Melewatkan border bukan cuma meleset 1px — di size="sm" hasilnya justru
 * membuat trigger jadi PILL. Tinggi track = trigger + 2·padding + 2·border,
 * jadi kalau border diabaikan, radius dalam selalu jatuh tepat di setengah
 * tinggi trigger (16−2 = 14 = 28÷2), dan CSS merendernya sebagai setengah
 * lingkaran. Akibatnya pil aktif terlihat jauh lebih bulat daripada track,
 * SelectApp, dan ButtonApp di sebelahnya yang rasionya ±0,47.
 * Dengan border ikut dikurangkan: 16−3 = 13px pada tinggi 28px → rasio 0,46,
 * praktis sama dengan track (16/34 = 0,47).
 */
function innerRoundedStyle(rounded: TabsRounded, size: TabsSize): React.CSSProperties | undefined {
  const outer = roundedPx[rounded];
  if (outer === null) return undefined; // full → biarkan rounded-full
  const inner = Math.max(0, outer - trackPaddingPx[size] - trackBorderPx);
  return { borderRadius: `${inner}px` };
}

// Variant definitions for TabsList
const tabsListVariants = cva(
  "inline-flex items-center transition-all max-w-full overflow-x-auto overflow-y-hidden no-scrollbar scroll-smooth shrink-0",
  {
    variants: {
      variant: {
        // Padding & gap varian berkotak sengaja TIDAK ditaruh di sini, tapi di
        // compoundVariants bawah — kalau dipatok di variant, wrapper-nya tidak
        // ikut mengecil saat size="sm" sehingga total tingginya 46px padahal
        // trigger-nya sudah 32px, dan jadi tidak sejajar dengan Button/Select
        // (34px) yang berdiri sebaris di toolbar. Varian underline tetap
        // memegang p-0/gap-2 sendiri karena memang tanpa track.
        underline: "bg-transparent p-0 pb-0 border-b border-slate-200 dark:border-slate-800 rounded-none gap-2 w-full justify-start",
        pills: "bg-slate-100 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700/80",
        enclosed: "bg-slate-100/80 dark:bg-slate-900 border border-slate-200 dark:border-slate-800",
        default: "bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700",
        vibrant: "bg-vibrant-purple/10 border border-vibrant-purple/20",
      },
      size: {
        sm: "text-xs",
        md: "text-sm",
        lg: "text-base",
      },
      orientation: {
        horizontal: "flex-row flex-nowrap w-full justify-start",
        // Tanpa space-y-*: jarak antar item sudah diatur `gap` dari
        // compoundVariants di bawah, dan gap berlaku untuk kedua arah. Kalau
        // space-y ikut dipasang, margin-nya menumpuk di atas gap sehingga
        // jarak vertikal jadi dua kali lipat jarak horizontal (terukur 8px
        // padahal gap-nya 4px). Border pemisah juga tidak lagi dipasang di
        // sini — lihat compoundVariants underline+vertical.
        vertical: "flex-col items-stretch w-full sm:w-60 justify-start shrink-0",
      },
    },
    compoundVariants: [
      // Track varian berkotak: padding mengikuti size supaya tinggi totalnya
      // sejajar dengan kontrol lain (sm → 28px trigger + 2×2px pad + 2×1px
      // border = 34px, sama dengan ButtonApp/SelectApp size="sm"). Padding
      // simetris p-* (bukan px/py terpisah) supaya jarak trigger ke tepi track
      // sama di keempat sisi, baik horizontal maupun vertikal.
      { variant: ["pills", "enclosed", "default", "vibrant"], size: "sm", class: "p-0.5 gap-1" },
      { variant: ["pills", "enclosed", "default", "vibrant"], size: "md", class: "p-1 gap-1.5" },
      { variant: ["pills", "enclosed", "default", "vibrant"], size: "lg", class: "p-1.5 gap-2" },
      // Garis pemisah rail hanya untuk underline: varian ini memang tanpa
      // track, jadi butuh satu garis sebagai batas. Varian berkotak TIDAK
      // boleh kena ini — sebelumnya border-r-0 dari orientation.vertical
      // menghapus border kanan mereka sehingga kotaknya terbuka sebelah.
      { variant: "underline", orientation: "vertical", class: "border-b-0 border-r border-slate-200 dark:border-slate-800 w-full" },
    ],
    defaultVariants: {
      variant: "underline",
      size: "sm",
      orientation: "horizontal",
    },
  }
);

// Variant definitions for TabsTrigger
const tabsTriggerVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 transition-all font-medium cursor-pointer relative focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-vibrant-purple disabled:pointer-events-none disabled:opacity-40 select-none",
  {
    variants: {
      variant: {
        underline:
          "rounded-none px-4 py-2.5 text-slate-600 dark:text-slate-400 border-b-2 border-transparent -mb-px hover:text-slate-900 dark:hover:text-slate-100 hover:border-slate-300 dark:hover:border-slate-700 data-[state=active]:border-vibrant-purple-dark dark:data-[state=active]:border-vibrant-purple-light data-[state=active]:text-vibrant-purple-dark dark:data-[state=active]:text-vibrant-purple-light data-[state=active]:font-bold",
        pills:
          "px-4 py-1.5 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-200/60 dark:hover:bg-slate-700/60 data-[state=active]:bg-vibrant-purple-dark dark:data-[state=active]:bg-vibrant-purple-dark data-[state=active]:text-white dark:data-[state=active]:text-white data-[state=active]:font-bold data-[state=active]:shadow-sm",
        enclosed:
          "px-3.5 py-1.5 text-slate-600 dark:text-slate-400 border border-transparent hover:text-slate-900 dark:hover:text-slate-100 data-[state=active]:bg-white dark:data-[state=active]:bg-slate-800 data-[state=active]:border-slate-200 dark:data-[state=active]:border-slate-700 data-[state=active]:text-slate-900 dark:data-[state=active]:text-slate-100 data-[state=active]:shadow-2xs data-[state=active]:font-bold",
        default:
          "px-3.5 py-1.5 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 data-[state=active]:bg-white dark:data-[state=active]:bg-slate-900 data-[state=active]:text-slate-900 dark:data-[state=active]:text-slate-100 data-[state=active]:shadow-2xs data-[state=active]:font-semibold",
        vibrant:
          "px-4 py-2 text-vibrant-purple-dark/80 dark:text-vibrant-purple-light/80 hover:bg-vibrant-purple/20 data-[state=active]:bg-vibrant-purple-dark dark:data-[state=active]:bg-vibrant-purple-dark data-[state=active]:text-white dark:data-[state=active]:text-white data-[state=active]:font-bold data-[state=active]:shadow-md",
      },
      size: {
        // sm sengaja dijadikan default (lihat defaultVariants di bawah):
        // min-h-[32px] sama persis dengan ButtonApp size="sm", sehingga tab
        // underline yang berdiri sebaris dengan Button/Input/Select tingginya
        // sejajar tanpa perlu override per pemakaian.
        sm: "text-xs px-2.5 py-1.5 min-h-[32px]",
        md: "text-sm px-3.5 py-2 min-h-[38px]",
        lg: "text-base px-4.5 py-2.5 min-h-[44px]",
      },
    },
    compoundVariants: [
      // Varian berkotak punya track dengan padding + border di sekelilingnya,
      // jadi trigger-nya harus lebih pendek dari tinggi target agar TOTAL
      // kontrolnya yang sejajar — bukan trigger-nya. sm: 28 + 2×2 + 2 = 34px,
      // sama dengan ButtonApp/SelectApp size="sm". Varian underline tidak ikut
      // karena tanpa track, trigger-nya sendiri yang jadi tinggi kontrol.
      { variant: ["pills", "enclosed", "default", "vibrant"], size: "sm", class: "min-h-[28px] py-1" },
    ],
    defaultVariants: {
      variant: "underline",
      size: "sm",
    },
  }
);

export interface TabsAppProps extends Omit<TabsProps, "orientation" | "children"> {
  id?: string;
  variant?: TabsVariant;
  orientation?: TabsOrientation;
  size?: TabsSize;
  rounded?: TabsRounded;
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  items?: TabItem[];
  children?: React.ReactNode;
  className?: string;
  listClassName?: string;
  triggerClassName?: string;
  contentClassName?: string;
}

export function TabsApp({
  id = "tabs-app",
  variant = "underline",
  orientation = "horizontal",
  size = "sm",
  rounded = "lg",
  value,
  defaultValue,
  onValueChange,
  items,
  children,
  className,
  listClassName,
  triggerClassName,
  contentClassName,
  ...props
}: TabsAppProps) {
  const initialValue =
    value !== undefined
      ? value
      : defaultValue || (items && items.length > 0 ? items[0].id : undefined);

  if (items && items.length > 0) {
    return (
      <Tabs
        id={id}
        data-ui-id={id}
        value={value}
        defaultValue={initialValue}
        onValueChange={onValueChange}
        orientation={orientation}
        className={cn(
          "w-full text-left",
          orientation === "vertical" ? "flex flex-col sm:flex-row gap-4 items-start" : "flex flex-col gap-3",
          className
        )}
        {...props}
      >
        <TabsListApp
          id={`${id}-list`}
          variant={variant}
          size={size}
          rounded={rounded}
          orientation={orientation}
          className={listClassName}
        >
          {items.map((item) => (
            <TabsTriggerApp
              key={item.id}
              id={`${id}-trigger-${item.id}`}
              value={item.id}
              variant={variant}
              size={size}
              rounded={rounded}
              icon={item.icon}
              badge={item.badge}
              badgeVariant={item.badgeVariant}
              disabled={item.disabled}
              className={triggerClassName}
            >
              {item.label}
            </TabsTriggerApp>
          ))}
        </TabsListApp>

        {items.map((item) =>
          item.content ? (
            <TabsContentApp
              key={item.id}
              id={`${id}-content-${item.id}`}
              value={item.id}
              className={cn(
                "w-full flex-1 min-w-0",
                contentClassName
              )}
            >
              {item.content}
            </TabsContentApp>
          ) : null
        )}
      </Tabs>
    );
  }

  return (
    <Tabs
      id={id}
      data-ui-id={id}
      value={value}
      defaultValue={defaultValue}
      onValueChange={onValueChange}
      orientation={orientation}
      className={cn(
        // min-w-0 is required whenever Tabs sits inside a flex container
        // (e.g. a centered showcase preview) — flex items default to
        // min-width:auto, so without this the tab list's own overflow-x-auto
        // never gets to activate and the whole row overflows its parent.
        "w-full min-w-0 text-left",
        orientation === "vertical" ? "flex flex-col sm:flex-row gap-4 items-start" : "flex flex-col gap-3",
        className
      )}
      {...props}
    >
      {children}
    </Tabs>
  );
}

export interface TabsListAppProps
  extends TabsListProps,
    VariantProps<typeof tabsListVariants> {
  id?: string;
  rounded?: TabsRounded;
  fitContent?: boolean;
}

export function TabsListApp({
  id,
  variant = "underline",
  size = "sm",
  rounded = "lg",
  fitContent = false,
  className,
  children,
  ...props
}: TabsListAppProps) {
  const { orientation } = useTabsContext();
  const roundedClass = variant === "underline" ? "rounded-none" : roundedClasses[rounded || "lg"];

  return (
    <TabsList
      id={id}
      data-ui-id={id}
      className={cn(
        tabsListVariants({ variant, size, orientation }),
        "min-w-0",
        roundedClass,
        fitContent && "w-fit shrink-0 max-w-none",
        className
      )}
      {...props}
    >
      {children}
    </TabsList>
  );
}

export interface TabsTriggerAppProps
  extends Omit<TabsTriggerProps, "variant" | "size">,
    VariantProps<typeof tabsTriggerVariants> {
  id?: string;
  rounded?: TabsRounded;
  icon?: React.ReactNode;
  badge?: string | number;
  badgeVariant?: BadgeAppProps["variant"];
  activeBadgeVariant?: BadgeAppProps["variant"];
  activeBadgeClassName?: string;
}

export function TabsTriggerApp({
  id,
  value,
  variant = "underline",
  size = "sm",
  rounded = "lg",
  icon,
  badge,
  badgeVariant = "neutral",
  activeBadgeVariant,
  activeBadgeClassName,
  className,
  children,
  ...props
}: TabsTriggerAppProps) {
  const { value: activeValue } = useTabsContext();
  const isActive = activeValue === value;

  const currentBadgeVariant = isActive && activeBadgeVariant ? activeBadgeVariant : badgeVariant;

  const isFilledVariant = variant === "pills" || variant === "vibrant";

  const activeBadgeStyle = isFilledVariant
    ? "bg-white text-vibrant-purple-dark font-bold shadow-2xs border-transparent"
    : "bg-vibrant-purple/15 text-vibrant-purple-dark dark:text-vibrant-purple-light font-bold border-vibrant-purple/30";

  const badgeClasses = cn(
    "ml-1 px-1.5 py-0 text-[10px] transition-all duration-200",
    isActive && (activeBadgeClassName || activeBadgeStyle)
  );

  const isUnderline = variant === "underline";
  const resolvedRounded = rounded || "lg";
  const roundedClass = isUnderline ? "rounded-none" : roundedClasses[resolvedRounded];
  // Trigger duduk DI DALAM track, jadi radiusnya diturunkan sebesar padding
  // track agar kurvanya sekonsentris — bukan disamakan mentah dengan track.
  const innerRadius = isUnderline ? undefined : innerRoundedStyle(resolvedRounded, size || "sm");

  return (
    <TabsTrigger
      id={id}
      data-ui-id={id}
      value={value}
      className={cn(tabsTriggerVariants({ variant, size }), roundedClass, className)}
      {...props}
      style={{ ...innerRadius, ...props.style }}
    >
      {icon && (
        <span
          className={cn(
            "shrink-0 transition-colors flex items-center justify-center gap-1.5",
            isActive
              ? variant === "pills" || variant === "vibrant"
                ? "text-white dark:text-white"
                : "text-vibrant-purple-dark dark:text-vibrant-purple-light"
              : "text-slate-500 dark:text-slate-400"
          )}
        >
          {icon}
        </span>
      )}

      {typeof children === "string" ? (
        <TextApp
          id={`${id || value}-text`}
          variant="body"
          weight={isActive ? "bold" : "medium"}
          className={cn(
            "leading-none transition-colors",
            size === "sm" && "text-xs",
            size === "md" && "text-sm",
            size === "lg" && "text-base",
            isActive && (variant === "pills" || variant === "vibrant") && "text-white dark:text-white"
          )}
        >
          {children}
        </TextApp>
      ) : (
        children
      )}

      {badge !== undefined && (
        <BadgeApp
          id={`${id || value}-badge`}
          variant={currentBadgeVariant}
          size="sm"
          rounded="pill"
          className={badgeClasses}
        >
          <TextApp id={`${id || value}-badge-text`} variant="caption" className="text-[10px] font-bold leading-none">
            {badge}
          </TextApp>
        </BadgeApp>
      )}
    </TabsTrigger>
  );
}

export interface TabsContentAppProps extends TabsContentProps {
  id?: string;
  animated?: boolean;
}

export function TabsContentApp({
  id,
  value,
  animated = true,
  className,
  children,
  ...props
}: TabsContentAppProps) {
  const { value: activeValue } = useTabsContext();
  const isActive = activeValue === value;

  if (!isActive) return null;

  if (!animated) {
    return (
      <TabsContent id={id} data-ui-id={id} value={value} className={cn("w-full flex-1 min-w-0", className)} {...props}>
        {children}
      </TabsContent>
    );
  }

  return (
    <TabsContent id={id} data-ui-id={id} value={value} className={cn("w-full flex-1 min-w-0", className)} {...props}>
      <AnimatePresence mode="wait">
        <motion.div
          key={value}
          initial={{ opacity: 0, y: 8, scale: 0.99 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -8, scale: 0.99 }}
          transition={{ duration: 0.18, ease: "easeOut" }}
          className="w-full flex-1 min-w-0"
        >
          {children}
        </motion.div>
      </AnimatePresence>
    </TabsContent>
  );
}
