import * as React from "react";
import { cn } from "@/lib/utils";
import {
  Filter,
  X,
  RotateCcw,
  Check,
  ChevronDown,
  Calendar,
  Search,
  SlidersHorizontal,
  Sparkles,
} from "lucide-react";
import { ButtonApp, ButtonAppProps } from "../atoms/ButtonApp";
import { InputApp } from "../atoms/InputApp";
import { BadgeApp } from "../atoms/BadgeApp";
import { DropdownApp } from "../molecules/DropdownApp";
import { CheckboxApp } from "../atoms/CheckboxApp";
import { RadioApp } from "../atoms/RadioApp";
import { DrawerApp } from "../molecules/DrawerApp";
import { DialogApp } from "../molecules/DialogApp";
import { PopoverApp } from "../molecules/PopoverApp";
import { DatePickerApp, DateRangeValue } from "../molecules/DatePickerApp";

export type FilterFieldType =
  | "select"
  | "multi-select"
  | "date-range"
  | "text"
  | "number-range";

export interface FilterOption {
  label: string;
  value: string;
  badge?: string;
}

export interface FilterFieldConfig {
  id: string;
  label: string;
  type: FilterFieldType;
  placeholder?: string;
  options?: FilterOption[];
  defaultValue?: any;
  colSpan?: 1 | 2; // For grid layout inside drawer
}

export interface QuickPreset {
  label: string;
  values: Record<string, any>;
}

export interface AdvanceFilterAppProps {
  id: string;
  fields: FilterFieldConfig[];
  values: Record<string, any>;
  onChange: (newValues: Record<string, any>) => void;
  onApply?: (values: Record<string, any>) => void;
  onReset?: () => void;
  displayMode?: "popover" | "drawer" | "inline" | "modal";
  title?: string;
  description?: string;
  quickPresets?: QuickPreset[];
  showActivePills?: boolean;
  triggerLabel?: string;
  /**
   * Defaults to `"icon"` unless `triggerLabel` is explicitly set (then
   * `"label"`) — set explicitly to override that derivation either way.
   * Icon-only shows just the funnel icon + a small unread-style dot when
   * filters are active; `aria-label`/`title` fall back to `triggerLabel` or
   * `title` so it stays accessible without visible text.
   */
  triggerMode?: "icon" | "label";
  triggerVariant?: ButtonAppProps["variant"];
  triggerTheme?: ButtonAppProps["theme"];
  triggerSize?: ButtonAppProps["size"];
  triggerRounded?: ButtonAppProps["rounded"];
  triggerClassName?: string;
  renderTrigger?: (props: {
    isOpen: boolean;
    activeCount: number;
    onClick: () => void;
  }) => React.ReactNode;
  className?: string;
}

export function AdvanceFilterApp({
  id,
  fields,
  values,
  onChange,
  onApply,
  onReset,
  displayMode = "popover",
  title = "Filter Lanjutan",
  description = "Sesuaikan kriteria pencarian dan visualisasi data dashboard BPKAD",
  quickPresets,
  showActivePills = true,
  triggerLabel,
  triggerMode,
  triggerVariant = "primary",
  triggerTheme = "default",
  triggerSize = "md",
  triggerRounded = "pill",
  triggerClassName,
  renderTrigger,
  className,
}: AdvanceFilterAppProps) {
  const [isOpen, setIsOpen] = React.useState(false);
  const [localValues, setLocalValues] = React.useState<Record<string, any>>(values);
  const [activeCategoryId, setActiveCategoryId] = React.useState<string>(fields[0]?.id ?? "");

  // Zero-regression default: existing pages that already pass a descriptive
  // triggerLabel keep their labeled button; only NEW call sites (no
  // triggerLabel) fall to icon-only.
  const resolvedTriggerMode: "icon" | "label" = triggerMode ?? (triggerLabel ? "label" : "icon");
  const resolvedTriggerAriaLabel = triggerLabel || title || "Filter Lanjutan";
  const iconOnlySize: Record<"sm" | "md" | "lg", ButtonAppProps["size"]> = {
    sm: "iconSm",
    md: "iconMd",
    lg: "iconLg",
  };

  // Sync local values when prop values change or filter opens
  React.useEffect(() => {
    if (isOpen) {
      setLocalValues(values);
    }
  }, [values, isOpen]);

  // Ref to measure trigger button width for popover alignment
  const triggerRef = React.useRef<HTMLDivElement>(null);
  const [triggerWidth, setTriggerWidth] = React.useState<number | null>(null);

  React.useLayoutEffect(() => {
    if (triggerRef.current) {
      setTriggerWidth(triggerRef.current.offsetWidth);
    }
  }, [isOpen]);

  // Helper to check if a filter value is actually active
  const isValActive = (val: any): boolean => {
    if (val === undefined || val === null || val === "") return false;
    if (Array.isArray(val)) return val.length > 0;
    if (typeof val === "object") {
      return Object.values(val).some((v) => v !== undefined && v !== null && v !== "");
    }
    if (typeof val === "boolean") return val;
    return true;
  };

  // Check if localValues differs from committed values prop
  const isChanged = React.useMemo(() => {
    const norm = (v: any) => {
      if (!isValActive(v)) return "";
      if (Array.isArray(v)) return JSON.stringify([...v].sort());
      if (typeof v === "object") return JSON.stringify(v);
      return String(v);
    };

    const allKeys = new Set([...Object.keys(values || {}), ...Object.keys(localValues || {})]);
    for (const key of allKeys) {
      if (norm(values?.[key]) !== norm(localValues?.[key])) {
        return true;
      }
    }
    return false;
  }, [values, localValues]);

  // Count active filters (ignoring empty arrays, empty objects, null, undefined, "")
  const activeCount = React.useMemo(() => {
    let count = 0;
    if (!values) return 0;
    Object.values(values).forEach((val) => {
      if (isValActive(val)) count++;
    });
    return count;
  }, [values]);

  const handleFieldChange = (fieldId: string, value: any) => {
    const updated = { ...localValues, [fieldId]: value };
    setLocalValues(updated);
    if (displayMode === "inline") {
      onChange(updated);
    }
  };

  const handleApply = () => {
    onChange(localValues);
    onApply?.(localValues);
    setIsOpen(false);
  };

  const handleCancel = () => {
    setLocalValues(values);
    setIsOpen(false);
  };

  const handleReset = () => {
    const emptyValues: Record<string, any> = {};
    fields.forEach((f) => {
      emptyValues[f.id] = f.type === "multi-select" ? [] : "";
    });
    setLocalValues(emptyValues);
    if (displayMode === "inline") {
      onChange(emptyValues);
      onReset?.();
    }
  };

  const handleResetAllCommitted = () => {
    const emptyValues: Record<string, any> = {};
    fields.forEach((f) => {
      emptyValues[f.id] = f.type === "multi-select" ? [] : "";
    });
    setLocalValues(emptyValues);
    onChange(emptyValues);
    onReset?.();
  };

  const handleRemoveSingleFilter = (fieldId: string) => {
    const updated = { ...values };
    const fieldConfig = fields.find((f) => f.id === fieldId);
    if (fieldConfig?.type === "multi-select") {
      updated[fieldId] = [];
    } else {
      delete updated[fieldId];
    }
    setLocalValues(updated);
    onChange(updated);
    onApply?.(updated);
  };

  const handlePresetSelect = (presetValues: Record<string, any>) => {
    const merged = { ...localValues, ...presetValues };
    setLocalValues(merged);
    if (displayMode === "inline") {
      onChange(merged);
      onApply?.(merged);
    }
  };

  // Helper to get friendly string representation for active pills
  const getDisplayValue = (field: FilterFieldConfig, val: any): string => {
    if (!isValActive(val)) return "";
    if (field.type === "select" && field.options) {
      const opt = field.options.find((o) => o.value === val);
      return opt ? opt.label : String(val);
    }
    if (field.type === "multi-select" && Array.isArray(val) && field.options) {
      const selectedLabels = val
        .map((v) => field.options?.find((o) => o.value === v)?.label)
        .filter(Boolean);
      return selectedLabels.join(", ");
    }
    if (field.type === "date-range" && typeof val === "object") {
      return `${val.from || "Awal"} s/d ${val.to || "Akhir"}`;
    }
    if (field.type === "number-range" && typeof val === "object") {
      return `Rp ${val.min || 0} - Rp ${val.max || "Max"}`;
    }
    return String(val);
  };

  // Render individual field inputs
  const renderFieldInput = (field: FilterFieldConfig) => {
    const val = localValues[field.id];

    switch (field.type) {
      case "select":
        return (
          <DropdownApp
            id={`filter-field-${field.id}`}
            value={val || ""}
            onChange={(value) => handleFieldChange(field.id, value)}
            placeholder={field.placeholder || `-- Pilih ${field.label} --`}
            options={
              field.options?.map((opt) => ({
                value: opt.value,
                label: opt.label,
                badge: opt.badge,
              })) ?? []
            }
            searchable
            showClear
            menuPortal
          />
        );

      case "multi-select": {
        const currentArr: string[] = Array.isArray(val) ? val : [];
        return (
          <div className="flex flex-wrap gap-1.5 p-2 bg-vibrant-grey-bg/50 border border-hairline-soft rounded-xl max-h-36 overflow-y-auto">
            {field.options?.map((opt) => {
              const isSelected = currentArr.includes(opt.value);
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => {
                    const next = isSelected
                      ? currentArr.filter((item) => item !== opt.value)
                      : [...currentArr, opt.value];
                    handleFieldChange(field.id, next);
                  }}
                  className={cn(
                    "px-2.5 py-1 text-[11px] font-medium rounded-lg border transition-all cursor-pointer flex items-center gap-1",
                    isSelected
                      ? "bg-vibrant-purple/15 text-vibrant-purple-dark border-vibrant-purple/40 font-bold shadow-xs"
                      : "bg-surface text-ink-secondary border-hairline-soft hover:bg-vibrant-purple/5"
                  )}
                >
                  {isSelected && <Check className="w-3 h-3 text-vibrant-purple-dark shrink-0" />}
                  <span>{opt.label}</span>
                </button>
              );
            })}
          </div>
        );
      }

      case "date-range":
        const parseIsoDate = (value?: string) => {
          if (!value) return null;
          const [year, month, day] = value.split("-").map(Number);
          return year && month && day ? new Date(year, month - 1, day) : null;
        };
        const formatIsoDate = (date: Date | null) => {
          if (!date) return "";
          const year = date.getFullYear();
          const month = String(date.getMonth() + 1).padStart(2, "0");
          const day = String(date.getDate()).padStart(2, "0");
          return `${year}-${month}-${day}`;
        };
        const rangeValue: DateRangeValue = {
          startDate: parseIsoDate(val?.from),
          endDate: parseIsoDate(val?.to),
        };
        return (
          <DatePickerApp
            id={`filter-date-range-${field.id}`}
            mode="range"
            rangeValue={rangeValue}
            onRangeChange={(range) => handleFieldChange(field.id, {
              from: formatIsoDate(range.startDate),
              to: formatIsoDate(range.endDate),
            })}
            format="DD/MM/YYYY"
            placeholder={field.placeholder || "Pilih rentang tanggal"}
            size="sm"
            showPresets
            showActions
            className="w-full"
          />
        );

      case "number-range":
        return (
          <div className="grid w-full grid-cols-[repeat(2,minmax(0,1fr))] gap-2">
            <InputApp
              id={`filter-number-min-${field.id}`}
              type="number"
              size="sm"
              containerClassName="min-w-0 grow"
              value={val?.min ?? ""}
              placeholder="Minimum"
              onChange={(e) => handleFieldChange(field.id, { ...val, min: e.target.value })}
            />
            <InputApp
              id={`filter-number-max-${field.id}`}
              type="number"
              size="sm"
              containerClassName="min-w-0 grow"
              value={val?.max ?? ""}
              placeholder="Maksimum"
              onChange={(e) => handleFieldChange(field.id, { ...val, max: e.target.value })}
            />
          </div>
        );

      case "text":
      default:
        return (
          <InputApp
            id={`filter-text-${field.id}`}
            type="text"
            placeholder={field.placeholder || `Cari ${field.label}...`}
            value={val || ""}
            onChange={(e) => handleFieldChange(field.id, e.target.value)}
            className="text-xs h-9"
          />
        );
    }
  };

  // Applied-filter chips row — reused above the trigger and inside the
  // two-pane modal (there it reflects localValues so chips update live as
  // the user picks options, before hitting Terapkan).
  const renderAppliedChips = (source: Record<string, any>, onRemove: (fieldId: string) => void) => (
    <>
      {Object.entries(source).map(([fieldId, val]) => {
        const field = fields.find((f) => f.id === fieldId);
        if (!field) return null;
        const displayVal = getDisplayValue(field, val);
        if (!displayVal) return null;
        return (
          <span
            key={fieldId}
            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-vibrant-purple/10 border border-vibrant-purple/30 text-vibrant-purple-dark animate-fade-in"
          >
            <span className="max-w-[90px] shrink-0 truncate font-bold">{field.label}:</span>
            <span className="max-w-[90px] truncate">{displayVal}</span>
            <button
              type="button"
              onClick={() => onRemove(fieldId)}
              className="hover:text-rose-500 p-0.5 rounded-full transition-colors cursor-pointer"
              aria-label={`Hapus filter ${field.label}`}
            >
              <X className="w-3 h-3" />
            </button>
          </span>
        );
      })}
    </>
  );

  // Right-pane options panel for the two-pane modal — real checkbox/radio
  // lists (per the Apollo-style benchmark) instead of the compact pill
  // buttons used elsewhere, since here each category gets its own full-
  // width panel with room to breathe.
  const renderModalOptionsPanel = (field: FilterFieldConfig) => {
    const val = localValues[field.id];

    if (field.type === "select" && field.options) {
      return (
        <div className="flex flex-col gap-0.5">
          {field.options.map((opt) => (
            <RadioApp
              key={opt.value}
              id={`filter-modal-${field.id}-${opt.value}`}
              name={`filter-modal-${field.id}`}
              label={opt.badge ? `${opt.label} (${opt.badge})` : opt.label}
              checked={val === opt.value}
              onCheckedChange={(checked) => checked && handleFieldChange(field.id, opt.value)}
              containerClassName="rounded-lg px-2 py-1.5 hover:bg-vibrant-grey-bg/60"
            />
          ))}
        </div>
      );
    }

    if (field.type === "multi-select" && field.options) {
      const currentArr: string[] = Array.isArray(val) ? val : [];
      return (
        <div className="flex flex-col gap-0.5">
          {field.options.map((opt) => (
            <CheckboxApp
              key={opt.value}
              id={`filter-modal-${field.id}-${opt.value}`}
              label={opt.badge ? `${opt.label} (${opt.badge})` : opt.label}
              checked={currentArr.includes(opt.value)}
              onCheckedChange={(checked) => {
                const next = checked ? [...currentArr, opt.value] : currentArr.filter((v) => v !== opt.value);
                handleFieldChange(field.id, next);
              }}
              containerClassName="rounded-lg px-2 py-1.5 hover:bg-vibrant-grey-bg/60"
            />
          ))}
        </div>
      );
    }

    return renderFieldInput(field);
  };

  // Filter form body
  const renderFilterBody = () => (
    <div className="space-y-4">
      {/* Quick Presets */}
      {quickPresets && quickPresets.length > 0 && (
        <div className="space-y-1.5 pb-2 border-b border-hairline-soft">
          <span className="text-[10px] font-bold font-mono uppercase tracking-wider text-ink-muted flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-vibrant-purple-dark" /> Preset Cepat
          </span>
          <div className="flex flex-wrap gap-1.5">
            {quickPresets.map((preset, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handlePresetSelect(preset.values)}
                className="px-2.5 py-1 text-[11px] font-medium font-display rounded-full bg-vibrant-purple/10 text-vibrant-purple-dark border border-vibrant-purple/20 hover:bg-vibrant-purple/20 transition-all cursor-pointer"
              >
                {preset.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Fields Grid */}
      <div
        className={cn(
          "grid gap-3.5",
          displayMode === "drawer" ? "grid-cols-1 sm:grid-cols-2" : "grid-cols-1"
        )}
      >
        {fields.map((field) => (
          <div
            key={field.id}
            className={cn(
              "space-y-1 text-left",
              field.colSpan === 2 && displayMode === "drawer" && "sm:col-span-2"
            )}
          >
            <label
              htmlFor={`filter-field-${field.id}`}
              className="text-xs font-bold font-display text-ink flex items-center justify-between"
            >
              <span>{field.label}</span>
              {localValues[field.id] && (
                <button
                  type="button"
                  onClick={() => handleFieldChange(field.id, field.type === "multi-select" ? [] : "")}
                  className="text-[10px] text-ink-muted hover:text-rose-500 underline font-normal"
                >
                  Clear
                </button>
              )}
            </label>
            {renderFieldInput(field)}
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div id={id} className={cn("inline-flex min-w-0 flex-col gap-2 w-full", className)}>
      {/* TRIGGER BAR */}
      <div className="flex items-center gap-2 flex-wrap max-w-full">
        {displayMode !== "inline" && (
          <div ref={triggerRef} className="relative inline-block max-w-full">
            {renderTrigger ? (
              renderTrigger({
                isOpen,
                activeCount,
                onClick: () => setIsOpen(!isOpen),
              })
            ) : (
              <ButtonApp
                id={`${id}-trigger-btn`}
                variant={activeCount > 0 ? "purpleDark" : (triggerVariant || "secondary")}
                theme={triggerTheme}
                size={resolvedTriggerMode === "icon" ? iconOnlySize[triggerSize as "sm" | "md" | "lg"] ?? "iconMd" : triggerSize}
                rounded={triggerRounded}
                onClick={() => setIsOpen(!isOpen)}
                aria-label={resolvedTriggerMode === "icon" ? resolvedTriggerAriaLabel : undefined}
                title={resolvedTriggerMode === "icon" ? resolvedTriggerAriaLabel : undefined}
                className={cn(
                  "relative inline-flex items-center gap-2 font-display shadow-xs max-w-full",
                  triggerClassName
                )}
              >
                <SlidersHorizontal className="w-4 h-4 shrink-0" />
                {resolvedTriggerMode === "label" && (
                  <>
                    <span className="truncate max-w-full">{resolvedTriggerAriaLabel}</span>
                    {activeCount > 0 && (
                      <span className="w-5 h-5 text-[10px] font-bold font-mono bg-white text-vibrant-purple-dark rounded-full flex items-center justify-center shadow-xs shrink-0">
                        {activeCount}
                      </span>
                    )}
                  </>
                )}
                {resolvedTriggerMode === "icon" && activeCount > 0 && (
                  <span
                    aria-hidden="true"
                    className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full bg-vibrant-purple-dark ring-2 ring-surface"
                  />
                )}
              </ButtonApp>
            )}

            {/* POPOVER PANEL (Positioned directly below trigger button) */}
            {displayMode === "popover" && isOpen && (
              <>
                {/* Transparent click-away layer (No dark/blur overlay) */}
                <div
                  className="fixed inset-0 z-40 bg-transparent cursor-default"
                  onClick={handleCancel}
                />

                <div
                  style={{
                    minWidth: triggerWidth ? `${Math.max(triggerWidth, 280)}px` : "280px",
                  }}
                  className="absolute top-full mt-2 left-0 w-80 sm:w-96 max-w-[calc(100vw-2rem)] max-h-[80vh] overflow-y-auto bg-surface text-ink border border-hairline-soft dark:border-vibrant-purple/50 rounded-2xl shadow-xl p-4 space-y-4 z-50 animate-in fade-in zoom-in-95 origin-top-left"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="flex items-center justify-between pb-2 border-b border-hairline-soft">
                    <div>
                      <h4 className="text-sm font-bold font-display text-ink">{title}</h4>
                      <p className="text-[11px] text-ink-secondary">{description}</p>
                    </div>
                    <button
                      type="button"
                      onClick={handleCancel}
                      className="p-1 text-ink-muted hover:text-ink rounded-lg cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {renderFilterBody()}

                  <div className="flex items-center justify-between pt-3 border-t border-hairline-soft">
                    <ButtonApp
                      id={`${id}-popover-reset`}
                      variant="ghost"
                      size="sm"
                      onClick={handleReset}
                      className="text-xs text-ink-muted hover:text-rose-500 inline-flex items-center gap-1"
                    >
                      <RotateCcw className="w-3.5 h-3.5" /> Reset
                    </ButtonApp>

                    <div className="flex items-center gap-2">
                      <ButtonApp
                        id={`${id}-popover-cancel`}
                        variant="secondary"
                        size="sm"
                        onClick={handleCancel}
                      >
                        Batal
                      </ButtonApp>
                      <ButtonApp
                        id={`${id}-popover-apply`}
                        variant={isChanged ? "purpleDark" : "secondary"}
                        size="sm"
                        disabled={!isChanged}
                        onClick={handleApply}
                        className={cn("shadow-md transition-all whitespace-nowrap shrink-0", isChanged && "ring-2 ring-vibrant-purple/40 font-bold")}
                      >
                        {isChanged ? "Simpan & Terapkan" : "Terapkan"}
                      </ButtonApp>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {/* ACTIVE FILTER PILLS */}
        {showActivePills && activeCount > 0 && (
          <div className="flex w-full min-w-0 items-center gap-1.5 flex-wrap">
            {renderAppliedChips(values, handleRemoveSingleFilter)}

            <button
              type="button"
              onClick={handleResetAllCommitted}
              className="text-xs text-ink-muted hover:text-rose-500 font-bold font-display underline px-1 cursor-pointer flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset Semua</span>
            </button>
          </div>
        )}
      </div>

      {/* MODAL 2: DRAWER / SLIDE-OVER MODE using DrawerApp */}
      {displayMode === "drawer" && (
        <DrawerApp
          id={`${id}-drawer`}
          isOpen={isOpen}
          onClose={handleCancel}
          title={title}
          description={description}
          icon={<Filter className="w-5 h-5 text-vibrant-purple-dark" />}
          position="right"
          size="md"
          rounded="3xl"
          footer={
            <div className="flex items-center justify-between gap-3">
              <ButtonApp
                id={`${id}-drawer-reset`}
                variant="ghost"
                size="md"
                onClick={handleReset}
                className="inline-flex items-center gap-1.5 text-xs text-ink-muted hover:text-rose-500 whitespace-nowrap"
              >
                <RotateCcw className="w-4 h-4" /> Reset Semua
              </ButtonApp>

              <div className="flex items-center gap-2">
                <ButtonApp
                  id={`${id}-drawer-cancel`}
                  variant="secondary"
                  size="md"
                  onClick={handleCancel}
                  className="whitespace-nowrap"
                >
                  Batal
                </ButtonApp>
                <ButtonApp
                  id={`${id}-drawer-apply`}
                  variant={isChanged ? "purpleDark" : "secondary"}
                  size="md"
                  disabled={!isChanged}
                  onClick={handleApply}
                  className={cn("shadow-md transition-all whitespace-nowrap shrink-0", isChanged && "ring-2 ring-vibrant-purple/50 font-bold")}
                >
                  {isChanged ? "Simpan & Terapkan" : "Terapkan Filter"}
                </ButtonApp>
              </div>
            </div>
          }
        >
          {renderFilterBody()}
        </DrawerApp>
      )}

      {/* MODAL 3: INLINE MODE */}
      {displayMode === "inline" && (
        <div className="p-4 bg-surface border border-hairline-soft dark:border-vibrant-purple/40 rounded-2xl space-y-4">
          {renderFilterBody()}
        </div>
      )}

      {/* MODAL 4: TWO-PANE MODAL (Apollo-style benchmark) — left category
          nav, right options panel for the selected category, applied-filter
          chips pinned at the top so the current state stays visible while
          switching categories. */}
      {displayMode === "modal" && (
        <DialogApp
          id={`${id}-modal`}
          isOpen={isOpen}
          onClose={handleCancel}
          title={title}
          description={description}
          icon={<Filter className="w-5 h-5 text-vibrant-purple-dark" />}
          size="lg"
          rounded="lg"
          footer={
            <div className="flex items-center justify-between gap-3">
              <ButtonApp
                id={`${id}-modal-reset`}
                variant="ghost"
                size="sm"
                onClick={handleReset}
                className="inline-flex items-center gap-1.5 text-xs text-ink-muted hover:text-rose-500 whitespace-nowrap"
              >
                <RotateCcw className="w-4 h-4" /> Reset Semua
              </ButtonApp>
              <div className="flex items-center gap-2">
                <ButtonApp id={`${id}-modal-cancel`} variant="secondary" size="sm" onClick={handleCancel}>
                  Batal
                </ButtonApp>
                <ButtonApp
                  id={`${id}-modal-apply`}
                  variant={isChanged ? "purpleDark" : "secondary"}
                  size="sm"
                  disabled={!isChanged}
                  onClick={handleApply}
                  className={cn("shadow-md transition-all whitespace-nowrap shrink-0", isChanged && "ring-2 ring-vibrant-purple/40 font-bold")}
                >
                  {isChanged ? "Simpan & Terapkan" : "Terapkan Filter"}
                </ButtonApp>
              </div>
            </div>
          }
        >
          <div className="flex min-w-0 flex-col gap-3">
            {quickPresets && quickPresets.length > 0 && (
              <div className="flex flex-wrap items-center gap-1.5 border-b border-hairline-soft pb-3">
                <Sparkles className="h-3.5 w-3.5 shrink-0 text-vibrant-purple-dark" />
                {quickPresets.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handlePresetSelect(preset.values)}
                    className="rounded-full border border-vibrant-purple/20 bg-vibrant-purple/10 px-2.5 py-1 text-[11px] font-medium font-display text-vibrant-purple-dark transition-all hover:bg-vibrant-purple/20"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            )}

            {Object.values(localValues).some(isValActive) && (
              <div className="flex min-w-0 flex-wrap items-center gap-1.5 border-b border-hairline-soft pb-3">
                {renderAppliedChips(localValues, (fieldId) => {
                  const field = fields.find((f) => f.id === fieldId);
                  handleFieldChange(fieldId, field?.type === "multi-select" ? [] : "");
                })}
              </div>
            )}

            <div className="grid min-w-0 grid-cols-1 gap-0 overflow-hidden rounded-xl border border-hairline-soft sm:grid-cols-[160px_1fr]">
              {/* Left pane: category nav */}
              <nav className="flex min-w-0 shrink-0 flex-row gap-1 overflow-x-auto border-b border-hairline-soft bg-vibrant-grey-bg/40 p-2 sm:flex-col sm:overflow-x-visible sm:border-b-0 sm:border-r">
                {fields.map((field) => {
                  const fieldActive = isValActive(localValues[field.id]);
                  const isSelected = activeCategoryId === field.id;
                  return (
                    <button
                      key={field.id}
                      type="button"
                      onClick={() => setActiveCategoryId(field.id)}
                      className={cn(
                        "flex shrink-0 items-center justify-between gap-2 whitespace-nowrap rounded-lg px-2.5 py-2 text-left text-xs font-semibold font-display transition-colors",
                        isSelected ? "bg-vibrant-purple/15 text-vibrant-purple-dark" : "text-ink-secondary hover:bg-vibrant-grey-bg"
                      )}
                    >
                      <span className="truncate">{field.label}</span>
                      {fieldActive && <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-vibrant-purple-dark" />}
                    </button>
                  );
                })}
              </nav>

              {/* Right pane: options for the selected category */}
              <div className="min-w-0 max-h-72 overflow-y-auto p-3">
                {fields.filter((f) => f.id === activeCategoryId).map((field) => (
                  <div key={field.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold font-display text-ink">{field.label}</span>
                      {localValues[field.id] && isValActive(localValues[field.id]) && (
                        <button
                          type="button"
                          onClick={() => handleFieldChange(field.id, field.type === "multi-select" ? [] : "")}
                          className="text-[10px] font-normal text-ink-muted underline hover:text-rose-500"
                        >
                          Clear
                        </button>
                      )}
                    </div>
                    {renderModalOptionsPanel(field)}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </DialogApp>
      )}
    </div>
  );
}

// ==========================================
// QUICK-FILTER CHIP TOOLBAR — compact per-field dropdown chips ("Class ▾ /
// Gender ▾ / Status ▾") meant to sit directly above a table for fast
// single-field filtering. Complements AdvanceFilterApp's displayMode="modal"
// (or "drawer"/"popover") which handles multi-criteria filtering — pair the
// two so quick, common filters stay one click away while complex filtering
// still has a dedicated place.
// ==========================================
export interface FilterChipToolbarAppProps {
  id: string;
  fields: FilterFieldConfig[];
  values: Record<string, any>;
  onChange: (newValues: Record<string, any>) => void;
  className?: string;
}

export function FilterChipToolbarApp({ id, fields, values, onChange, className }: FilterChipToolbarAppProps) {
  const [openFieldId, setOpenFieldId] = React.useState<string | null>(null);

  const isValActive = (val: any): boolean => {
    if (val === undefined || val === null || val === "") return false;
    if (Array.isArray(val)) return val.length > 0;
    return true;
  };

  const chipLabel = (field: FilterFieldConfig) => {
    const val = values[field.id];
    if (!isValActive(val)) return field.label;
    if (field.type === "multi-select" && Array.isArray(val)) {
      if (val.length === 1) return field.options?.find((o) => o.value === val[0])?.label ?? field.label;
      return `${field.label} (${val.length})`;
    }
    return field.options?.find((o) => o.value === val)?.label ?? field.label;
  };

  return (
    <div id={id} className={cn("flex min-w-0 flex-wrap items-center gap-2", className)}>
      {fields.map((field) => {
        const val = values[field.id];
        const active = isValActive(val);
        const currentArr: string[] = Array.isArray(val) ? val : [];
        const trigger = (
          <ButtonApp
            id={`${id}-${field.id}-chip`}
            type="button"
            variant={active ? "purpleDark" : "secondary"}
            size="sm"
            rounded="lg"
            className="inline-flex items-center gap-1 font-display"
          >
            <span className="max-w-[110px] truncate">{chipLabel(field)}</span>
            <ChevronDown className="h-3.5 w-3.5 shrink-0" />
          </ButtonApp>
        );

        return (
          <PopoverApp
            key={field.id}
            id={`${id}-${field.id}-popover`}
            trigger={trigger}
            open={openFieldId === field.id}
            onOpenChange={(next) => setOpenFieldId(next ? field.id : null)}
            width={220}
            showArrow={false}
          >
            <div className="flex max-h-64 flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold font-display text-ink">{field.label}</span>
                {active && (
                  <button
                    type="button"
                    onClick={() => onChange({ ...values, [field.id]: field.type === "multi-select" ? [] : "" })}
                    className="text-[10px] font-normal text-ink-muted underline hover:text-rose-500"
                  >
                    Clear
                  </button>
                )}
              </div>
              <div className="flex flex-col gap-0.5 overflow-y-auto">
                {field.type === "multi-select"
                  ? field.options?.map((opt) => (
                      <CheckboxApp
                        key={opt.value}
                        id={`${id}-${field.id}-${opt.value}`}
                        label={opt.label}
                        checked={currentArr.includes(opt.value)}
                        onCheckedChange={(checked) => {
                          const next = checked ? [...currentArr, opt.value] : currentArr.filter((v) => v !== opt.value);
                          onChange({ ...values, [field.id]: next });
                        }}
                        containerClassName="rounded-lg px-2 py-1.5 hover:bg-vibrant-grey-bg/60"
                      />
                    ))
                  : field.options?.map((opt) => (
                      <RadioApp
                        key={opt.value}
                        id={`${id}-${field.id}-${opt.value}`}
                        name={`${id}-${field.id}`}
                        label={opt.label}
                        checked={val === opt.value}
                        onCheckedChange={(checked) => checked && onChange({ ...values, [field.id]: opt.value })}
                        containerClassName="rounded-lg px-2 py-1.5 hover:bg-vibrant-grey-bg/60"
                      />
                    ))}
              </div>
            </div>
          </PopoverApp>
        );
      })}
    </div>
  );
}
