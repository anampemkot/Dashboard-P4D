import * as React from "react";
import {
  ColumnDef,
  ColumnFiltersState,
  SortingState,
  VisibilityState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
  Column,
  FilterFn,
} from "@tanstack/react-table";
import { createPortal } from "react-dom";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/packages/ui/table";
import { ButtonApp } from "@/packages/design-system/atoms/ButtonApp";
import { InputApp } from "@/packages/design-system/atoms/InputApp";
import { DropdownApp } from "@/packages/design-system/molecules/DropdownApp";
import { PaginationApp } from "@/packages/design-system/molecules/PaginationApp";
import { SearchBarApp } from "@/packages/design-system/molecules/SearchBarApp";
import { SkeletonApp } from "@/packages/design-system/atoms/SkeletonApp";
import { BadgeApp } from "@/packages/design-system/atoms/BadgeApp";
import { CheckboxApp } from "@/packages/design-system/atoms/CheckboxApp";
import { cn } from "@/lib/utils";
import {
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Trash2,
  Download,
  Database,
  ListFilter,
  X,
} from "lucide-react";

export type DataTableFilterOperator =
  | "contains"
  | "equals"
  | "notEquals"
  | "gt"
  | "gte"
  | "lt"
  | "lte";

export interface DataTableFilterOption {
  label: string;
  value: string;
}

export interface DataTableColumnFilterConfig {
  type?: "text" | "number" | "select";
  placeholder?: string;
  options?: DataTableFilterOption[];
  operators?: DataTableFilterOperator[];
}

export interface DataTableFilterValue {
  operator: DataTableFilterOperator;
  value: string;
}

const FILTER_OPERATOR_LABELS: Record<DataTableFilterOperator, string> = {
  contains: "Mengandung",
  equals: "Sama dengan (=)",
  notEquals: "Tidak sama dengan (!=)",
  gt: "Lebih besar (>)",
  gte: "Lebih besar/sama (>=)",
  lt: "Lebih kecil (<)",
  lte: "Lebih kecil/sama (<=)",
};

export const dataTableFilterFn: FilterFn<any> = (row, columnId, filterValue: DataTableFilterValue) => {
  if (!filterValue?.value) return true;

  const cellValue = row.getValue(columnId);
  const expected = filterValue.value;

  if (["gt", "gte", "lt", "lte"].includes(filterValue.operator)) {
    const actualNumber = Number(cellValue);
    const expectedNumber = Number(expected);
    if (!Number.isFinite(actualNumber) || !Number.isFinite(expectedNumber)) return false;
    if (filterValue.operator === "gt") return actualNumber > expectedNumber;
    if (filterValue.operator === "gte") return actualNumber >= expectedNumber;
    if (filterValue.operator === "lt") return actualNumber < expectedNumber;
    return actualNumber <= expectedNumber;
  }

  const actualText = String(cellValue ?? "").toLocaleLowerCase("id-ID");
  const expectedText = expected.toLocaleLowerCase("id-ID");
  if (filterValue.operator === "notEquals") return actualText !== expectedText;
  if (filterValue.operator === "equals") return actualText === expectedText;
  return actualText.includes(expectedText);
};

// ==========================================
// COLUMN HEADER SORTING HELPER COMPONENT
// ==========================================
export interface DataTableColumnHeaderProps<TData, TValue>
  extends React.HTMLAttributes<HTMLDivElement> {
  column: Column<TData, TValue>;
  title: string;
  filter?: DataTableColumnFilterConfig;
}

export function DataTableColumnHeader<TData, TValue>({
  column,
  title,
  filter,
  className,
}: DataTableColumnHeaderProps<TData, TValue>) {
  const [isFilterOpen, setIsFilterOpen] = React.useState(false);
  const filterButtonRef = React.useRef<HTMLButtonElement>(null);
  const [filterPosition, setFilterPosition] = React.useState({ top: 0, left: 0 });
  const committedFilter = column.getFilterValue() as DataTableFilterValue | undefined;
  const defaultOperator = filter?.operators?.[0] ?? (filter?.type === "number" ? "equals" : "contains");
  const [draftFilter, setDraftFilter] = React.useState<DataTableFilterValue>({
    operator: committedFilter?.operator ?? defaultOperator,
    value: committedFilter?.value ?? "",
  });

  React.useEffect(() => {
    if (isFilterOpen) {
      setDraftFilter({
        operator: committedFilter?.operator ?? defaultOperator,
        value: committedFilter?.value ?? "",
      });
    }
  }, [isFilterOpen, committedFilter?.operator, committedFilter?.value, defaultOperator]);

  if (!column.getCanSort() && !filter) {
    return <div className={cn("text-xs font-bold font-display uppercase tracking-wider text-ink-muted", className)}>{title}</div>;
  }

  const isSorted = column.getIsSorted();
  const isFiltered = Boolean(committedFilter?.value);
  const operators = filter?.operators ?? (filter?.type === "number"
    ? ["equals", "notEquals", "gt", "gte", "lt", "lte"]
    : ["contains", "equals", "notEquals"]);

  const applyFilter = () => {
    column.setFilterValue(draftFilter.value ? draftFilter : undefined);
    setIsFilterOpen(false);
  };

  const clearFilter = () => {
    setDraftFilter({ operator: defaultOperator, value: "" });
    column.setFilterValue(undefined);
    setIsFilterOpen(false);
  };

  const toggleFilter = () => {
    if (!isFilterOpen && filterButtonRef.current) {
      const rect = filterButtonRef.current.getBoundingClientRect();
      setFilterPosition({
        top: rect.bottom + 8,
        left: Math.min(Math.max(16, rect.left), window.innerWidth - 304),
      });
    }
    setIsFilterOpen((open) => !open);
  };

  return (
    <div className={cn("relative flex items-center gap-0.5", className)}>
      {column.getCanSort() ? (
        <ButtonApp
          id={`sort-col-${column.id}`}
          variant="ghost"
          size="sm"
          onClick={() => column.toggleSorting(isSorted === "asc")}
          className="h-8 px-2 -ml-2 font-display font-bold text-xs uppercase tracking-wider text-ink-muted hover:text-ink hover:bg-action-hover flex items-center gap-1.5 cursor-pointer"
        >
          <span>{title}</span>
          {isSorted === "desc" ? (
            <ArrowDown className="w-3.5 h-3.5 text-vibrant-purple-dark" />
          ) : isSorted === "asc" ? (
            <ArrowUp className="w-3.5 h-3.5 text-vibrant-purple-dark" />
          ) : (
            <ArrowUpDown className="w-3.5 h-3.5 opacity-50" />
          )}
        </ButtonApp>
      ) : (
        <span className="text-xs font-bold font-display uppercase tracking-wider text-ink-muted">{title}</span>
      )}

      {filter && (
        <>
          <button
            ref={filterButtonRef}
            type="button"
            onClick={toggleFilter}
            className={cn(
              "inline-flex h-7 w-7 items-center justify-center rounded-md transition-colors hover:bg-action-hover",
              isFiltered ? "text-vibrant-purple-dark bg-vibrant-purple/10" : "text-ink-muted"
            )}
            aria-label={`Filter kolom ${title}`}
            aria-expanded={isFilterOpen}
          >
            <ListFilter className="w-3.5 h-3.5" />
          </button>

          {isFilterOpen && typeof document !== "undefined" && createPortal(
            <>
              <button
                type="button"
                className="fixed inset-0 z-40 cursor-default"
                onClick={() => setIsFilterOpen(false)}
                aria-label="Tutup filter kolom"
              />
              <div
                style={filterPosition}
                className="fixed z-50 w-72 space-y-3 rounded-lg border border-hairline bg-surface p-3 text-left shadow-card"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-bold normal-case tracking-normal text-ink">Filter {title}</span>
                  <button
                    type="button"
                    onClick={() => setIsFilterOpen(false)}
                    className="rounded-sm p-1 text-ink-muted hover:bg-action-hover hover:text-ink"
                    aria-label={`Tutup filter ${title}`}
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
                <DropdownApp
                  id={`filter-operator-${column.id}`}
                  value={draftFilter.operator}
                  onChange={(value) => setDraftFilter((current) => ({
                    ...current,
                    operator: value as DataTableFilterOperator,
                  }))}
                  size="sm"
                  options={operators.map((operator) => ({ value: operator, label: FILTER_OPERATOR_LABELS[operator] }))}
                  menuPortal
                />
                {filter.type === "select" ? (
                  <DropdownApp
                    id={`filter-value-${column.id}`}
                    value={draftFilter.value}
                    onChange={(value) => setDraftFilter((current) => ({ ...current, value: String(value ?? "") }))}
                    size="sm"
                    placeholder={filter.placeholder ?? `Pilih ${title}`}
                    options={filter.options ?? []}
                    searchable
                    showClear
                    menuPortal
                  />
                ) : (
                  <InputApp
                    id={`filter-value-${column.id}`}
                    type={filter.type === "number" ? "number" : "text"}
                    value={draftFilter.value}
                    placeholder={filter.placeholder ?? `Masukkan ${title}`}
                    onChange={(event) => setDraftFilter((current) => ({ ...current, value: event.target.value }))}
                    size="sm"
                    onKeyDown={(event) => event.key === "Enter" && applyFilter()}
                  />
                )}
                <div className="flex items-center justify-between gap-2 border-t border-hairline-soft pt-3">
                  <ButtonApp id={`filter-clear-${column.id}`} variant="ghost" size="sm" onClick={clearFilter}>
                    Bersihkan
                  </ButtonApp>
                  <ButtonApp id={`filter-apply-${column.id}`} variant="purpleDark" size="sm" onClick={applyFilter}>
                    Terapkan
                  </ButtonApp>
                </div>
              </div>
            </>,
            document.body
          )}
        </>
      )}
    </div>
  );
}

// ==========================================
// DATA TABLE PROPS INTERFACE
// ==========================================
export interface DataTableAppProps<TData, TValue> {
  data: TData[];
  columns: ColumnDef<TData, TValue>[];
  id?: string;
  title?: string;
  description?: string;
  searchPlaceholder?: string;
  enableSearch?: boolean;
  enablePagination?: boolean;
  pageSize?: number;
  enableRowSelection?: boolean;
  isLoading?: boolean;
  emptyMessage?: string;
  rightHeaderAction?: React.ReactNode;
  bulkActions?: (selectedRows: TData[], clearSelection: () => void) => React.ReactNode;
  onDeleteSelected?: (selectedRows: TData[], clearSelection: () => void) => void;
  onExportSelected?: (selectedRows: TData[]) => void;
  getRowId?: (row: TData, index: number) => string;
  onRowClick?: (row: TData) => void;
  striped?: boolean;
  toolbarLayout?: "wrap" | "singleRow";
  className?: string;
  /**
   * Row ids to render as "just arrived" — a brief slide-in + tint that fades
   * over ~2.5s (via CSS `transition-colors`, not re-triggered by re-render).
   * Pairs with `useRealtimeRows`: pass its `newRowIds` straight through.
   * Must match whatever `getRowId` produces for that row.
   */
  newRowIds?: (string | number)[];
}

export function DataTableApp<TData, TValue>({
  data,
  columns,
  id = "data-table-app",
  title,
  description,
  searchPlaceholder = "Cari data...",
  enableSearch = true,
  enablePagination = true,
  pageSize = 10,
  enableRowSelection = true,
  isLoading = false,
  emptyMessage = "Tidak ada data yang ditemukan",
  rightHeaderAction,
  bulkActions,
  onDeleteSelected,
  onExportSelected,
  getRowId,
  onRowClick,
  striped = false,
  toolbarLayout = "wrap",
  className,
  newRowIds,
}: DataTableAppProps<TData, TValue>) {
  const newRowIdSet = React.useMemo(() => new Set((newRowIds ?? []).map(String)), [newRowIds]);
  const [sorting, setSorting] = React.useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([]);
  const [globalFilter, setGlobalFilter] = React.useState<string>("");
  const [rowSelection, setRowSelection] = React.useState<Record<string, boolean>>({});
  const [columnVisibility, setColumnVisibility] = React.useState<VisibilityState>({});

  // Augment columns with selection checkbox if enabled and not already provided
  const finalColumns = React.useMemo(() => {
    if (!enableRowSelection) return columns;

    const hasSelectionColumn = columns.some((col) => col.id === "select");
    if (hasSelectionColumn) return columns;

    const selectionColumn: ColumnDef<TData, TValue> = {
      id: "select",
      header: ({ table }) => (
        <div className="flex items-center justify-center">
          <CheckboxApp
            id={`${id}-select-all`}
            checked={table.getIsAllPageRowsSelected()}
            indeterminate={table.getIsSomePageRowsSelected()}
            onChange={(e) => table.toggleAllPageRowsSelected(!!e.target.checked)}
            aria-label="Pilih semua baris"
          />
        </div>
      ),
      cell: ({ row }) => (
        <div className="flex items-center justify-center" onClick={(e) => e.stopPropagation()}>
          <CheckboxApp
            id={`${id}-select-row-${row.id}`}
            checked={row.getIsSelected()}
            onChange={(e) => row.toggleSelected(!!e.target.checked)}
            aria-label={`Pilih baris ${row.id}`}
          />
        </div>
      ),
      enableSorting: false,
      enableHiding: false,
    };

    return [selectionColumn, ...columns];
  }, [columns, enableRowSelection, id]);

  const table = useReactTable({
    data,
    columns: finalColumns,
    state: {
      sorting,
      columnFilters,
      globalFilter,
      rowSelection,
      columnVisibility,
    },
    initialState: {
      pagination: {
        pageSize: pageSize,
      },
    },
    enableRowSelection: enableRowSelection,
    getRowId,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onGlobalFilterChange: setGlobalFilter,
    onRowSelectionChange: setRowSelection,
    onColumnVisibilityChange: setColumnVisibility,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: enablePagination ? getPaginationRowModel() : undefined,
    getSortedRowModel: getSortedRowModel(),
  });

  const selectedRows = table.getSelectedRowModel().rows.map((r) => r.original);
  const selectedCount = selectedRows.length;

  const clearSelection = React.useCallback(() => {
    table.resetRowSelection();
  }, [table]);

  return (
    <div id={id} className={cn("w-full space-y-4 text-left", className)}>
      {/* HEADER BAR: Title, Search & Bulk Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-1">
        {(title || description) && (
          <div>
            {title && (
              <h3 className="text-lg font-bold font-display text-ink tracking-tight flex items-center gap-2">
                {title}
                <BadgeApp id={`${id}-total-badge`} variant="neutral" size="sm">
                  {data.length} Data
                </BadgeApp>
              </h3>
            )}
            {description && (
              <p className="text-xs text-ink-secondary mt-0.5">{description}</p>
            )}
          </div>
        )}

        {/* Right side controls: Global Search & Custom Header Action */}
        <div className={cn(
          "ml-auto flex items-center gap-3",
          // px-1/py-1, not just pb-1: overflow-x-auto clips focus rings on
          // every edge — vertically because setting overflow-x without
          // overflow-y makes the browser compute overflow-y as `auto` too
          // (CSS spec quirk), and horizontally because the first/last
          // control's ring extends past the scroll container's own edge.
          toolbarLayout === "singleRow" ? "max-w-full flex-nowrap overflow-x-auto px-1 py-1" : "flex-wrap"
        )}>
          {enableSearch && (
            <SearchBarApp
              id={`${id}-search-input`}
              value={globalFilter ?? ""}
              onSearchChange={(val) => setGlobalFilter(val)}
              onClear={() => setGlobalFilter("")}
              placeholder={searchPlaceholder}
              size="sm"
              rounded="lg"
              bgColor="surface"
              showClear
              className={toolbarLayout === "singleRow" ? "w-56 shrink-0 sm:w-64" : "w-full sm:w-64"}
            />
          )}

          {rightHeaderAction}
        </div>
      </div>

      {/* BULK ACTION BAR (Floating when rows selected) */}
      {selectedCount > 0 && (
        <div className="bg-vibrant-purple/10 border border-vibrant-purple/40 rounded-xl p-3 px-4 flex items-center justify-between gap-4 animate-in fade-in slide-in-from-top-2 duration-200 shadow-vibrant-soft">
          <div className="flex items-center gap-2.5">
            <span className="w-6 h-6 rounded-lg bg-vibrant-purple-dark text-white text-xs font-bold font-mono flex items-center justify-center">
              {selectedCount}
            </span>
            <span className="text-xs font-bold font-display text-ink">
              Data Dipilih dari total {table.getFilteredRowModel().rows.length}
            </span>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {bulkActions ? (
              bulkActions(selectedRows, clearSelection)
            ) : (
              <>
                {onExportSelected && (
                  <ButtonApp
                    id={`${id}-bulk-export`}
                    variant="secondary"
                    size="sm"
                    onClick={() => onExportSelected(selectedRows)}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold"
                  >
                    <Download className="w-3.5 h-3.5" /> Ekspor ({selectedCount})
                  </ButtonApp>
                )}
                {onDeleteSelected && (
                  <ButtonApp
                    id={`${id}-bulk-delete`}
                    variant="danger"
                    size="sm"
                    onClick={() => onDeleteSelected(selectedRows, clearSelection)}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Hapus ({selectedCount})
                  </ButtonApp>
                )}
              </>
            )}

            <ButtonApp
              id={`${id}-clear-selection`}
              variant="ghost"
              size="sm"
              onClick={clearSelection}
              className="text-xs text-ink-muted hover:text-ink underline ml-1"
            >
              Batal Pilih
            </ButtonApp>
          </div>
        </div>
      )}

      {columnFilters.length > 0 && (
        <div className="flex flex-wrap items-center gap-2" aria-label="Filter kolom aktif">
          <span className="text-xs font-semibold text-ink-muted">Filter kolom:</span>
          {columnFilters.map((activeFilter) => {
            const value = activeFilter.value as DataTableFilterValue;
            return (
              <BadgeApp
                key={activeFilter.id}
                id={`${id}-filter-chip-${activeFilter.id}`}
                variant="solidPurple"
                size="sm"
                className="inline-flex items-center gap-1.5"
              >
                {activeFilter.id}: {FILTER_OPERATOR_LABELS[value.operator]} {value.value}
                <button
                  type="button"
                  onClick={() => table.getColumn(activeFilter.id)?.setFilterValue(undefined)}
                  className="rounded-full p-0.5 hover:bg-white/20"
                  aria-label={`Hapus filter ${activeFilter.id}`}
                >
                  <X className="h-3 w-3" />
                </button>
              </BadgeApp>
            );
          })}
          <ButtonApp
            id={`${id}-clear-column-filters`}
            variant="ghost"
            size="sm"
            onClick={() => table.resetColumnFilters()}
            className="text-xs text-error"
          >
            Bersihkan semua
          </ButtonApp>
        </div>
      )}

      {/* MAIN TABLE CONTAINER */}
      <Table>
        <TableHeader>
          {table.getHeaderGroups().map((headerGroup) => (
            <TableRow key={headerGroup.id}>
              {headerGroup.headers.map((header) => (
                <TableHead key={header.id} style={{ width: header.getSize() !== 150 ? header.getSize() : undefined }}>
                  {header.isPlaceholder
                    ? null
                    : flexRender(header.column.columnDef.header, header.getContext())}
                </TableHead>
              ))}
            </TableRow>
          ))}
        </TableHeader>

        <TableBody>
          {isLoading ? (
            // Skeleton loading rows
            Array.from({ length: pageSize > 5 ? 5 : pageSize }).map((_, idx) => (
              <TableRow key={`skeleton-row-${idx}`}>
                {finalColumns.map((col, colIdx) => (
                  <TableCell key={`skeleton-cell-${idx}-${colIdx}`}>
                    <SkeletonApp id={`${id}-skeleton-${idx}-${colIdx}`} className="h-5 w-full rounded-md" />
                  </TableCell>
                ))}
              </TableRow>
            ))
          ) : table.getRowModel().rows?.length ? (
            table.getRowModel().rows.map((row) => {
              const isNew = newRowIdSet.has(String(row.id));
              return (
                <TableRow
                  key={row.id}
                  data-state={row.getIsSelected() && "selected"}
                  onClick={onRowClick ? () => onRowClick(row.original) : undefined}
                  className={cn(
                    "group hover:bg-surface-soft/80 transition-colors duration-[2500ms]",
                    striped && "odd:bg-surface even:bg-surface-soft/40",
                    onRowClick && "cursor-pointer",
                    isNew && "bg-vibrant-purple/10 [animation:ds-row-insert_0.4s_ease-out]"
                  )}
                >
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </TableCell>
                  ))}
                </TableRow>
              );
            })
          ) : (
            <TableRow>
              <TableCell
                colSpan={finalColumns.length}
                className="h-36 text-center"
              >
                <div className="flex flex-col items-center justify-center gap-2 py-6 text-ink-muted">
                  <Database className="w-8 h-8 opacity-40 text-vibrant-purple-dark" />
                  <p className="text-sm font-semibold text-ink-secondary">{emptyMessage}</p>
                  {globalFilter && (
                    <ButtonApp
                      id={`${id}-reset-filter`}
                      variant="ghost"
                      size="sm"
                      onClick={() => setGlobalFilter("")}
                      className="text-xs text-vibrant-purple-dark font-bold underline mt-1"
                    >
                      Bersihkan pencarian "{globalFilter}"
                    </ButtonApp>
                  )}
                </div>
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>

      {/* PAGINATION BAR (Reusing PaginationApp Component) */}
      {enablePagination && (
        <PaginationApp
          id={`${id}-pagination`}
          type="standard"
          currentPage={table.getState().pagination.pageIndex + 1}
          totalPages={table.getPageCount() || 1}
          totalItems={table.getFilteredRowModel().rows.length}
          pageSize={table.getState().pagination.pageSize}
          pageSizeOptions={[5, 10, 20, 50, 100]}
          onPageChange={(page) => table.setPageIndex(page - 1)}
          onPageSizeChange={(size) => table.setPageSize(size)}
          className="pt-2"
        />
      )}
    </div>
  );
}
