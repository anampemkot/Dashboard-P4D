import * as React from "react";
import { useUiStore } from "@/stores/useUiStore";
import { useAuthStore } from "@/stores/useAuthStore";
import { MENU } from "@/constants/menu";
import { NavItemApp } from "../molecules/NavItemApp";
import { useLocation, useNavigate } from "react-router-dom";
import {
  Settings,
  LogOut,
  ChevronDown,
  ChevronRight,
  PanelLeftClose,
  LayoutDashboard,
  Hotel,
  Users,
  ClipboardList,
  UserPlus,
  Calculator,
  Database,
  MapPin,
  TrendingUp,
  FileSearch,
  Clock,
  ShieldCheck,
  AlertTriangle,
  FileCheck2,
  Scale,
  Palette,
  Building2,
  Receipt,
  LineChart,
} from "lucide-react";
import { JogjaLogo } from "@/components/ui/JogjaLogo";
import { cn } from "@/lib/utils";
import { TextApp } from "../atoms/TextApp";
import { AvatarApp } from "../atoms/AvatarApp";
import { BadgeApp } from "../atoms/BadgeApp";

export interface MenuItem {
  id: string;
  label: string;
  href?: string;
  path?: string;
  icon?: React.ReactNode;
  active?: boolean;
  badge?: React.ReactNode | string | number;
  badgeVariant?: "solidPurple" | "neutral" | "danger" | "success" | "warning";
  children?: MenuItem[];
  onClick?: (e?: React.MouseEvent) => void;
}

export interface MenuGroup {
  id?: string;
  heading?: string;
  items: MenuItem[];
}

export type SidebarPosition = "left" | "right";
export type SidebarVariant = "default" | "dark" | "glassmorphism";
export type SidebarSize = "sm" | "md" | "lg";
export type SidebarRounded = "none" | "sm" | "md" | "lg" | "xl" | "full";

export interface SidebarUserProfile {
  name: string;
  role: string;
  avatarUrl?: string;
  avatarInitials?: string;
  onSettingsClick?: () => void;
  onLogoutClick?: () => void;
}

export interface SidebarBrand {
  logo?: React.ReactNode;
  title?: string;
  subtitle?: string;
}

export interface SidebarAppProps {
  id: string;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
  position?: SidebarPosition;
  variant?: SidebarVariant;
  size?: SidebarSize;
  rounded?: SidebarRounded;
  offCanvas?: boolean;
  isOpen?: boolean;
  onClose?: () => void;
  menuGroups?: MenuGroup[];
  userProfile?: SidebarUserProfile;
  brand?: SidebarBrand;
  embedded?: boolean;
  className?: string;
  ariaLabel?: string;
}

const getItemIcon = (id: string) => {
  switch (id) {
    case "menu-1":
      return <Hotel className="w-4 h-4" />;
    case "menu-2":
      return <Users className="w-4 h-4" />;
    case "menu-3":
      return <ClipboardList className="w-4 h-4" />;
    case "menu-4":
      return <UserPlus className="w-4 h-4" />;
    case "menu-5":
      return <Calculator className="w-4 h-4" />;
    case "menu-6":
      return <Database className="w-4 h-4" />;
    case "menu-7":
      return <MapPin className="w-4 h-4" />;
    case "menu-8":
      return <TrendingUp className="w-4 h-4" />;
    case "menu-9":
      return <FileSearch className="w-4 h-4" />;
    case "menu-10":
      return <Clock className="w-4 h-4" />;
    case "menu-11":
      return <ShieldCheck className="w-4 h-4" />;
    case "menu-12":
      return <AlertTriangle className="w-4 h-4" />;
    case "menu-13":
      return <FileCheck2 className="w-4 h-4" />;
    case "menu-14":
      return <Scale className="w-4 h-4" />;
    case "menu-15":
      return <Receipt className="w-4 h-4" />;
    case "menu-16":
      return <LineChart className="w-4 h-4" />;
    case "menu-ui-kit":
      return <Palette className="w-4 h-4" />;
    default:
      return <Database className="w-4 h-4" />;
  }
};

const roundedClassesMap: Record<SidebarRounded, string> = {
  none: "rounded-none",
  sm: "rounded-sm",
  md: "rounded-md",
  lg: "rounded-lg",
  xl: "rounded-xl",
  full: "rounded-2xl",
};

const widthClassesMap: Record<SidebarSize, { collapsed: string; expanded: string }> = {
  sm: { collapsed: "w-[56px]", expanded: "w-[220px]" },
  md: { collapsed: "w-[68px]", expanded: "w-[260px]" },
  lg: { collapsed: "w-[80px]", expanded: "w-[300px]" },
};

export function SidebarApp({
  id,
  isCollapsed: propIsCollapsed,
  onToggleCollapse,
  position = "left",
  variant = "default",
  size = "md",
  rounded = "none",
  offCanvas = false,
  isOpen = true,
  onClose,
  menuGroups,
  userProfile,
  brand,
  embedded = false,
  className,
}: SidebarAppProps) {
  const { sidebarOpen, toggleSidebar } = useUiStore();
  const { logout } = useAuthStore();
  const location = useLocation();
  const navigate = useNavigate();

  // Controls hover expand state (icon-only when false)
  const [isHovered, setIsHovered] = React.useState(false);

  // Keep track of which main menus are expanded
  const [expandedMenus, setExpandedMenus] = React.useState<Record<string, boolean>>({});

  // Container ref for auto scrolling active menu into view
  const scrollContainerRef = React.useRef<HTMLDivElement>(null);

  // Auto-expand parent groups if child path is active
  React.useEffect(() => {
    const updated: Record<string, boolean> = { ...expandedMenus };
    let changed = false;
    for (const item of MENU) {
      if (item.children) {
        const hasActiveChild = item.children.some((child) => location.pathname === child.path);
        if (hasActiveChild && !updated[item.id]) {
          updated[item.id] = true;
          changed = true;
        }
      }
    }
    if (changed) {
      setExpandedMenus(updated);
    }
  }, [location.pathname]);

  // Auto-scroll active link into view
  React.useEffect(() => {
    const timer = setTimeout(() => {
      if (scrollContainerRef.current) {
        const activeEl = scrollContainerRef.current.querySelector<HTMLElement>("[data-active='true']");
        if (activeEl) {
          activeEl.scrollIntoView({ behavior: "smooth", block: "nearest" });
        }
      }
    }, 150);
    return () => clearTimeout(timer);
  }, [location.pathname, expandedMenus]);

  const toggleExpand = (menuId: string, e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    setExpandedMenus((prev) => ({
      ...prev,
      [menuId]: !prev[menuId],
    }));
  };

  const handleLogout = () => {
    setIsHovered(false);
    if (userProfile?.onLogoutClick) {
      userProfile.onLogoutClick();
    } else {
      logout();
      navigate("/login");
    }
  };

  const handleBlur = (e: React.FocusEvent<HTMLElement>) => {
    if (!e.currentTarget.contains(e.relatedTarget as Node)) {
      setIsHovered(false);
    }
  };

  const handleFocus = () => {
    setIsHovered(true);
  };

  const sizeWidths = widthClassesMap[size] || widthClassesMap.md;
  const roundedClass = roundedClassesMap[rounded] || roundedClassesMap.none;

  const variantClass = {
    default: "bg-surface text-ink border-hairline",
    dark: "bg-slate-900 text-slate-100 border-slate-800",
    glassmorphism: "bg-surface/80 backdrop-blur-md text-ink border-hairline/60 shadow-xl",
  }[variant];

  // If custom menuGroups are provided (e.g. in UI Kit Showcase or custom drawers), render custom mode
  if (menuGroups && menuGroups.length > 0) {
    const isCollapsed = propIsCollapsed !== undefined ? propIsCollapsed : !isHovered;
    const currentWidth = isCollapsed ? sizeWidths.collapsed : sizeWidths.expanded;

    // Off-Canvas Drawer handling
    if (offCanvas && !isOpen) {
      return null;
    }

    return (
      <>
        {offCanvas && isOpen && (
          <div
            className={cn(
              "inset-0 bg-black/50 z-40 backdrop-blur-xs transition-opacity duration-300 animate-in fade-in",
              embedded ? "absolute" : "fixed"
            )}
            onClick={onClose}
          />
        )}
        <aside
          id={id}
          data-ui-id={id}
          onMouseEnter={() => propIsCollapsed === undefined && setIsHovered(true)}
          onMouseLeave={() => propIsCollapsed === undefined && setIsHovered(false)}
          className={cn(
            "flex flex-col select-none transition-all duration-300 font-sans z-50",
            position === "right"
              ? (embedded ? "border-l" : "fixed top-0 right-0 h-screen border-l")
              : (embedded ? "border-r" : "fixed top-0 left-0 h-screen border-r"),
            variantClass,
            roundedClass,
            embedded ? "relative h-full overflow-hidden" : "",
            currentWidth,
            offCanvas && !embedded ? "fixed top-0 h-screen shadow-2xl" : "",
            className
          )}
        >
          {/* Header Section */}
          <div className="h-[56px] border-b border-hairline-soft flex items-center px-4 justify-between gap-2">
            <div className="flex items-center gap-2.5 min-w-0">
              {brand?.logo || <Building2 className="w-5 h-5 text-vibrant-purple" />}
              {!isCollapsed && (
                <div className="flex flex-col min-w-0">
                  <TextApp id={`sidebar-brand-title-${id}`} variant="body" weight="bold" className="text-xs truncate leading-tight">
                    {brand?.title || "BPKAD Kota Yogyakarta"}
                  </TextApp>
                  {brand?.subtitle && (
                    <TextApp id={`sidebar-brand-subtitle-${id}`} variant="caption" className="text-[10px] text-ink-muted truncate uppercase font-mono mt-0.5">
                      {brand.subtitle}
                    </TextApp>
                  )}
                </div>
              )}
            </div>
            {onToggleCollapse && !isCollapsed && (
              <button
                onClick={onToggleCollapse}
                className="p-1.5 rounded-full hover:bg-action-hover text-ink-secondary hover:text-ink transition-colors cursor-pointer"
                aria-label="Toggle collapse"
              >
                <PanelLeftClose className="w-4 h-4" />
              </button>
            )}
            {offCanvas && onClose && (
              <button
                onClick={onClose}
                className="p-1.5 rounded-full hover:bg-action-hover text-ink-secondary hover:text-ink transition-colors cursor-pointer"
                aria-label="Close drawer"
              >
                <PanelLeftClose className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Navigation Items */}
          <div className="flex-1 overflow-y-auto p-3 space-y-3 custom-sidebar-scrollbar">
            {menuGroups.map((grp, idx) => (
              <div key={grp.id || idx} className="space-y-1">
                {grp.heading && !isCollapsed && (
                  <TextApp id={`grp-heading-${id}-${grp.id || idx}`} variant="caption" weight="bold" className="text-[10px] uppercase text-ink-muted px-2 tracking-wider">
                    {grp.heading}
                  </TextApp>
                )}
                {grp.items.map((item) => {
                  const hasChildren = item.children && item.children.length > 0;
                  const isExpanded = !!expandedMenus[item.id];
                  const isChildActive = hasChildren && item.children!.some((c) => c.active);
                  const isParentActive = item.active || isChildActive;

                  return (
                    <div key={item.id} className="space-y-1">
                      <div className="relative">
                        <NavItemApp
                          id={`custom-${item.id}`}
                          label={item.label}
                          path={hasChildren ? "#" : item.path || "#"}
                          icon={item.icon}
                          active={isParentActive}
                          isCollapsed={isCollapsed}
                          onClick={() => {
                            if (hasChildren) {
                              toggleExpand(item.id);
                            } else if (item.onClick) {
                              item.onClick();
                            }
                          }}
                          badge={
                            hasChildren && !isCollapsed ? (
                              <button
                                onClick={(e) => toggleExpand(item.id, e)}
                                className="p-1 rounded-full text-ink-secondary hover:text-ink hover:bg-action-hover transition-colors"
                              >
                                {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                              </button>
                            ) : item.badge ? (
                              typeof item.badge === "string" || typeof item.badge === "number" ? (
                                <BadgeApp
                                  id={`custom-badge-${item.id}`}
                                  variant={item.badgeVariant || "solidPurple"}
                                  size="sm"
                                  className="whitespace-nowrap truncate max-w-full inline-block"
                                >
                                  {item.badge}
                                </BadgeApp>
                              ) : (
                                item.badge
                              )
                            ) : undefined
                          }
                        />
                      </div>

                      {/* Expandable Submenu */}
                      {hasChildren && isExpanded && !isCollapsed && (
                        <div className="pl-3 ml-4 border-l-2 border-vibrant-purple/20 flex flex-col gap-1 py-1 animate-in fade-in duration-150">
                          {item.children!.map((child) => (
                            <NavItemApp
                              key={child.id}
                              id={`custom-sub-${child.id}`}
                              label={child.label}
                              path={child.path || "#"}
                              isSub={true}
                              active={child.active}
                              onClick={child.onClick ? () => child.onClick?.() : undefined}
                            />
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>

          {/* User Profile Footer Section */}
          {userProfile && (
            <div className={cn(
              "p-3 border-t border-hairline-soft flex items-center justify-between gap-2",
              isCollapsed ? "justify-center px-2" : ""
            )}>
              <div className="flex items-center gap-2.5 min-w-0">
                <AvatarApp size="xs" name={userProfile.name} src={userProfile.avatarUrl} />
                {!isCollapsed && (
                  <div className="flex flex-col min-w-0">
                    <TextApp id={`user-profile-name-${id}`} variant="caption" weight="bold" className="text-xs truncate">
                      {userProfile.name}
                    </TextApp>
                    <TextApp id={`user-profile-role-${id}`} variant="caption" className="text-[10px] text-ink-muted truncate">
                      {userProfile.role}
                    </TextApp>
                  </div>
                )}
              </div>
              {!isCollapsed && (
                <div className="flex items-center gap-1">
                  {userProfile.onSettingsClick && (
                    <button
                      onClick={userProfile.onSettingsClick}
                      className="p-1.5 rounded-md hover:bg-action-hover text-ink-secondary hover:text-ink transition-colors cursor-pointer"
                      title="Settings"
                    >
                      <Settings className="w-3.5 h-3.5" />
                    </button>
                  )}
                  <button
                    onClick={handleLogout}
                    className="p-1.5 rounded-md hover:bg-action-hover text-ink-secondary hover:text-danger transition-colors cursor-pointer"
                    title="Logout"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          )}
        </aside>
      </>
    );
  }

  // Default App Mode: Original P4D Monitoring Sidebar
  if (!sidebarOpen) {
    return null;
  }

  // Touch devices have no hover state, so a mobile drawer would otherwise
  // get permanently stuck at the icon-only width. propIsCollapsed lets
  // AdminLayout force it open (labels visible) while offCanvas is active.
  const isCollapsed = propIsCollapsed !== undefined ? propIsCollapsed : !isHovered;
  const isVisuallyExpanded = !isCollapsed;

  return (
    <aside
      id={id}
      data-ui-id={id}
      onMouseEnter={() => propIsCollapsed === undefined && setIsHovered(true)}
      onMouseLeave={() => propIsCollapsed === undefined && setIsHovered(false)}
      onFocus={handleFocus}
      onBlur={handleBlur}
      tabIndex={0}
      // Inline width instead of a template-literal-embedded w-[260px]/w-[68px]
      // class: those arbitrary-value classes were silently missing from the
      // compiled CSS (Tailwind's JIT scanner is unreliable with dynamically
      // built class strings — see focusRing.ts for the same pitfall), which
      // left the expanded sidebar collapsed to its intrinsic content width.
      style={{ width: isVisuallyExpanded ? 260 : 68 }}
      className={cn(
        "h-screen bg-surface border-r border-hairline flex flex-col fixed top-0 left-0 z-50 select-none transition-all duration-300 ease-in-out outline-none",
        isVisuallyExpanded ? "shadow-2xl" : "shadow-sm overflow-hidden"
      )}
    >
      {/* Workspace Switcher Header */}
      <div
        id="sidebar-workspace-switcher"
        data-ui-id="sidebar-workspace-switcher"
        className={`h-[56px] border-b border-hairline-soft flex items-center bg-surface transition-all duration-300 ${
          isCollapsed ? "justify-center px-2" : "justify-between px-4 gap-2.5"
        }`}
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <JogjaLogo size="sm" />
          {!isCollapsed && (
            <div className="flex flex-col min-w-0 leading-none text-left animate-in fade-in duration-200">
              <span className="text-xs font-bold text-ink truncate font-display">BPKAD Kota Yogyakarta</span>
              <span className="text-[10px] text-ink-muted mt-1 font-semibold tracking-wider uppercase font-mono">P4D Monitoring</span>
            </div>
          )}
        </div>
        {!isCollapsed && (
          <button
            onClick={toggleSidebar}
            className="text-ink-secondary hover:text-ink hover:bg-action-hover p-1.5 rounded-full cursor-pointer transition-colors"
            aria-label="Close sidebar"
          >
            <PanelLeftClose className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Main Navigation Area (scrollable with custom slim scrollbar) */}
      <div
        id="sidebar-group-main"
        data-ui-id="sidebar-group-main"
        ref={scrollContainerRef}
        className={`flex-1 overflow-y-auto py-3 flex flex-col gap-1 custom-sidebar-scrollbar ${
          isCollapsed ? "px-2" : "px-3"
        }`}
      >
        {/* Core Link */}
        <div className="relative">
          <NavItemApp
            id="nav-item-dashboard-main"
            label="Utama"
            subtitle="Ringkasan Utama"
            path="/admin"
            icon={<LayoutDashboard className="w-4 h-4" />}
            active={location.pathname === "/admin"}
            isCollapsed={isCollapsed}
          />
        </div>

        <div className="h-px bg-hairline-soft my-1 mx-2" />

        {/* Dynamic Nested Menu Items */}
        {MENU.map((item) => {
          const hasChildren = item.children && item.children.length > 0;
          const isExpanded = !!expandedMenus[item.id];
          const isChildActive = hasChildren && item.children!.some((child) => location.pathname === child.path);
          const isParentActive = location.pathname === item.path || isChildActive;

          return (
            <div key={item.id} className="flex flex-col gap-1">
              <div className="relative">
                <NavItemApp
                  id={`nav-item-${item.id}`}
                  label={item.label}
                  path={hasChildren ? "#" : item.path}
                  subtitle={item.subtitle}
                  icon={getItemIcon(item.id)}
                  active={isParentActive}
                  isCollapsed={isCollapsed}
                  onClick={
                    hasChildren
                      ? () => toggleExpand(item.id)
                      : undefined
                  }
                  badge={
                    hasChildren && !isCollapsed ? (
                      <div
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          toggleExpand(item.id);
                        }}
                        className={`p-1 rounded-full transition-colors cursor-pointer ${
                          isParentActive
                            ? "text-white hover:bg-white/20"
                            : "text-ink-secondary hover:text-ink hover:bg-action-hover"
                        }`}
                      >
                        {isExpanded ? (
                          <ChevronDown className="w-3.5 h-3.5" />
                        ) : (
                          <ChevronRight className="w-3.5 h-3.5" />
                        )}
                      </div>
                    ) : undefined
                  }
                />
              </div>

              {/* Children Panel with line indent */}
              {hasChildren && isExpanded && !isCollapsed && (
                <div className="pl-3 ml-4 border-l-2 border-vibrant-purple/20 flex flex-col gap-1 py-1 animate-in fade-in slide-in-from-top-1 duration-150">
                  {item.children!.map((child) => (
                    <NavItemApp
                      key={child.id}
                      id={`nav-item-${child.id}`}
                      label={child.label}
                      path={child.path}
                      subtitle={child.subtitle}
                      isSub={true}
                      active={location.pathname === child.path}
                    />
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Sidebar Footer Operations */}
      <div className={`p-2 border-t border-hairline-soft bg-surface flex flex-col gap-1 ${
        isCollapsed ? "items-center" : ""
      }`}>
        <NavItemApp
          id="nav-item-settings"
          label="Pengaturan UI Kit"
          path="/admin/uikit"
          icon={<Settings className="w-4 h-4 text-ink-secondary" />}
          isCollapsed={isCollapsed}
        />
        <NavItemApp
          id="nav-item-logout"
          label="Logout"
          path="#"
          icon={<LogOut className="w-4 h-4 text-ink-secondary" />}
          isCollapsed={isCollapsed}
          onClick={handleLogout}
        />
      </div>
    </aside>
  );
}
