import * as React from "react";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  RadialBarChart,
  RadialBar,
  XAxis,
  YAxis,
  CartesianGrid,
  ScatterChart,
  Scatter,
  ZAxis,
  ComposedChart,
  ReferenceLine,
} from "recharts";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
  ChartConfig,
} from "@/packages/ui/chart";
import { cn } from "@/lib/utils";
import { Database } from "lucide-react";
import { SkeletonApp } from "../atoms/SkeletonApp";
import { TextApp } from "../atoms/TextApp";

// ==========================================
// DESIGN SYSTEM COLOR PALETTE FOR CHARTS
// ==========================================
export const CHART_PALETTES = {
  purple: {
    primary: "var(--color-chart-1)",
    secondary: "var(--color-vibrant-purple)",
    tertiary: "var(--color-chart-5)",
    accent: "var(--color-chart-2)",
  },
  blue: {
    primary: "var(--color-chart-2)",
    secondary: "var(--color-chart-1)",
    tertiary: "var(--color-chart-4)",
    accent: "var(--color-chart-5)",
  },
  yellow: {
    primary: "var(--color-chart-3)",
    secondary: "var(--color-chart-1)",
    tertiary: "var(--color-chart-2)",
    accent: "var(--color-chart-4)",
  },
  vibrant: {
    p1: "var(--color-chart-1)",
    p2: "var(--color-chart-2)",
    p3: "var(--color-chart-3)",
    p4: "var(--color-chart-4)",
    p5: "var(--color-chart-5)",
    p6: "var(--color-chart-1)",
  },
} as const;

export type ChartVariant = "purple" | "blue" | "yellow" | "vibrant" | "sequential";
export type ChartType = "area" | "bar" | "line" | "pie" | "radar" | "radial" | "scatter" | "bubble" | "combo";

/*
 * Recharts menghitung animasi masuk terhadap ukuran kontainer pada saat mark
 * pertama dipasang. Kalau kartunya masih berukuran nol ketika itu — persis yang
 * terjadi pada kartu ber-animasi scroll-reveal — animasinya mandek di tengah
 * jalan dan garis/batangnya tidak pernah selesai tergambar (`stroke-dasharray`
 * membeku di ~1%). Data yang tidak muncul jauh lebih merugikan daripada
 * kehilangan animasi masuk, jadi animasinya dimatikan di semua mark.
 */
const noEntranceAnimation = { isAnimationActive: false } as const;

export interface SeriesConfig {
  key: string;
  label: string;
  color?: string;
  type?: "monotone" | "linear" | "step";
  fillOpacity?: number;
  strokeDasharray?: string;
  barSize?: number;
  stackId?: string;
  chartType?: "bar" | "line";
  yAxisId?: "left" | "right";
  /** Short terminology note shown under this series' row in the tooltip — reuses the same glossary text as `InsightContent.glossary`. */
  description?: string;
}

/**
 * Garis acuan statis pada chart kartesian — mis. garis target, ambang SLA,
 * atau sepasang garis pembagi kuadran pada scatter.
 */
export interface ChartReferenceLine {
  id?: string;
  /** `"x"` = garis vertikal pada nilai sumbu-X, `"y"` = garis horizontal pada sumbu-Y. */
  axis: "x" | "y";
  value: number;
  label?: string;
  /** Default abu-abu netral supaya tidak bersaing dengan seri data. */
  color?: string;
  strokeDasharray?: string;
}

export interface ChartAppProps {
  id?: string;
  type: ChartType;
  variant?: ChartVariant;
  data: Array<Record<string, any>>;
  config?: ChartConfig;
  series?: SeriesConfig[];
  xKey?: string;
  yKey?: string;
  height?: number | string;
  className?: string;
  showGrid?: boolean;
  showTooltip?: boolean;
  showLegend?: boolean;
  valueFormatter?: (val: any) => string;
  innerRadius?: number;
  outerRadius?: number;
  barSize?: number;
  barLayout?: "vertical" | "horizontal";
  xAxisLabel?: string;
  yAxisLabel?: string;
  pieValueKey?: string;
  pieNameKey?: string;
  scatterXKey?: string;
  scatterYKey?: string;
  bubbleSizeKey?: string;
  /** Garis acuan statis; hanya berlaku untuk tipe kartesian (area/bar/line/scatter/bubble/combo). */
  referenceLines?: ChartReferenceLine[];
  loading?: boolean;
  emptyMessage?: string;
  /**
   * Overrides the tooltip row's rendering entirely — same signature as
   * `ChartTooltipContent`'s own `formatter`. When omitted, `valueFormatter`
   * and any per-series `description` are applied automatically (previously
   * `valueFormatter` only reached the axis tick, never the tooltip).
   */
  tooltipFormatter?: (value: any, name: any, item: any, index: number, payload: any) => React.ReactNode;
  tooltipLabelFormatter?: (label: any, payload: any) => React.ReactNode;
  tooltipNameKey?: string;
  tooltipIndicator?: "line" | "dot" | "dashed";
  tooltipHideLabel?: boolean;
  tooltipHideIndicator?: boolean;
}

export function ChartApp({
  id,
  type,
  variant = "vibrant",
  data,
  config: customConfig,
  series = [],
  xKey = "name",
  height = 220,
  className,
  showGrid = true,
  showTooltip = true,
  showLegend = true,
  valueFormatter,
  innerRadius = 50,
  outerRadius = 75,
  barSize,
  barLayout = "vertical",
  xAxisLabel,
  yAxisLabel,
  pieValueKey = "value",
  pieNameKey = "name",
  scatterXKey = "x",
  scatterYKey = "y",
  bubbleSizeKey = "z",
  referenceLines,
  loading = false,
  emptyMessage = "Tidak ada data untuk ditampilkan",
  tooltipFormatter,
  tooltipLabelFormatter,
  tooltipNameKey,
  tooltipIndicator,
  tooltipHideLabel,
  tooltipHideIndicator,
}: ChartAppProps) {
  // Generate default color set based on variant
  const colors = React.useMemo(() => {
    if (variant === "purple") {
      return [
        CHART_PALETTES.purple.primary,
        CHART_PALETTES.purple.secondary,
        CHART_PALETTES.purple.accent,
        CHART_PALETTES.purple.tertiary,
      ];
    }
    if (variant === "blue") {
      return [
        CHART_PALETTES.blue.primary,
        CHART_PALETTES.blue.secondary,
        CHART_PALETTES.blue.accent,
        CHART_PALETTES.blue.tertiary,
      ];
    }
    if (variant === "yellow") {
      return [
        CHART_PALETTES.yellow.primary,
        CHART_PALETTES.yellow.secondary,
        CHART_PALETTES.yellow.accent,
        CHART_PALETTES.yellow.tertiary,
      ];
    }
    if (variant === "sequential") {
      return [
        "color-mix(in srgb, var(--color-chart-1) 25%, var(--color-bg-surface))",
        "color-mix(in srgb, var(--color-chart-1) 45%, var(--color-bg-surface))",
        "color-mix(in srgb, var(--color-chart-1) 65%, var(--color-bg-surface))",
        "color-mix(in srgb, var(--color-chart-1) 82%, var(--color-bg-surface))",
        "var(--color-chart-1)",
      ];
    }
    return Object.values(CHART_PALETTES.vibrant);
  }, [variant]);

  // Build ChartConfig if not passed explicitly
  const chartConfig = React.useMemo(() => {
    if (customConfig) return customConfig;
    const generated: ChartConfig = {};
    series.forEach((s, idx) => {
      generated[s.key] = {
        label: s.label,
        color: s.color || colors[idx % colors.length],
      };
    });
    // Pie/donut charts have no `series` array — each data row is its own
    // slice, so the legend/tooltip label lookup (keyed by the row's
    // pieNameKey value) needs its own config entry per slice, otherwise
    // ChartLegendContent renders a blank label for every slice.
    if (type === "pie") {
      data.forEach((row, idx) => {
        const name = String(row[pieNameKey]);
        generated[name] = {
          label: name,
          color: row.fill || colors[idx % colors.length],
        };
      });
    }
    return generated;
  }, [customConfig, series, colors, type, data, pieNameKey]);

  const containerStyle = typeof height === "number" ? { height: `${height}px` } : { height };

  // Interactive legend: click a series to toggle its visibility. Applies to
  // every series-array chart type (area/bar/line/radar/combo) — Recharts'
  // own `hide` prop keeps the series out of rendering (and axis scaling)
  // without unmounting it, so toggling stays smooth.
  const [hiddenKeys, setHiddenKeys] = React.useState<Set<string>>(new Set());
  const toggleSeries = React.useCallback((dataKey: string) => {
    setHiddenKeys((prev) => {
      const next = new Set(prev);
      if (next.has(dataKey)) next.delete(dataKey);
      else next.add(dataKey);
      return next;
    });
  }, []);
  const interactiveLegend = (
    <ChartLegendContent inactiveKeys={hiddenKeys} onLegendItemClick={toggleSeries} />
  );

  const seriesByKey = React.useMemo(() => {
    const map = new Map<string, SeriesConfig>();
    series.forEach((s) => map.set(s.key, s));
    return map;
  }, [series]);

  // Garis acuan dirender identik di semua tipe kartesian, jadi dibangun sekali
  // lalu disebar sebagai children. Recharts butuh elemen ini jadi anak langsung
  // chart container, bukan dibungkus fragment bernama.
  const referenceLineElements = React.useMemo(
    () =>
      (referenceLines ?? []).map((line, idx) => (
        <ReferenceLine
          key={line.id || `${line.axis}-${line.value}-${idx}`}
          {...(line.axis === "x" ? { x: line.value } : { y: line.value })}
          stroke={line.color || "#94a3b8"}
          strokeDasharray={line.strokeDasharray ?? "4 4"}
          label={
            line.label
              ? {
                  value: line.label,
                  // Label ditaruh di dalam area plot: `position: "right"` untuk
                  // garis horizontal jatuh di luar margin kanan dan terpotong.
                  position: line.axis === "x" ? "insideTopRight" : "insideTopLeft",
                  fontSize: 10,
                  fill: "currentColor",
                }
              : undefined
          }
        />
      )),
    [referenceLines],
  );

  // Chart `combo` dengan seri yang satuannya sama (mis. Target vs Realisasi,
  // dua-duanya Rupiah) harus berbagi satu sumbu. Sumbu kanan baru dipasang
  // kalau ada seri yang memintanya secara eksplisit.
  const usesRightAxis = React.useMemo(
    () => series.some((s) => s.yAxisId === "right"),
    [series],
  );

  // Bug fix: valueFormatter previously only reached the axis tickFormatter,
  // never the tooltip — a chart with e.g. currency-formatted axes showed raw
  // numbers on hover. Built automatically whenever valueFormatter or a
  // per-series description is present, unless the caller supplies its own
  // tooltipFormatter.
  const autoTooltipFormatter = React.useCallback(
    (value: any, _name: any, item: any) => {
      const formattedValue = valueFormatter ? valueFormatter(value) : value;
      const description = seriesByKey.get(item?.dataKey as string)?.description;
      return (
        <div className="flex flex-col">
          <span>{formattedValue}</span>
          {description && <span className="text-[10px] font-normal text-ink-muted">{description}</span>}
        </div>
      );
    },
    [valueFormatter, seriesByKey]
  );

  const needsAutoFormatter = Boolean(valueFormatter) || series.some((s) => s.description);
  const tooltipContentProps = {
    formatter: tooltipFormatter ?? (needsAutoFormatter ? autoTooltipFormatter : undefined),
    labelFormatter: tooltipLabelFormatter,
    nameKey: tooltipNameKey,
    indicator: tooltipIndicator,
    hideLabel: tooltipHideLabel,
    hideIndicator: tooltipHideIndicator,
  };

  const renderChartContent = () => {
    switch (type) {
      case "area":
        return (
          <AreaChart data={data} margin={{ left: -15, right: 5, top: 10, bottom: 0 }}>
            <defs>
              {series.map((s, idx) => {
                const color = s.color || colors[idx % colors.length];
                return (
                  <linearGradient key={`grad-${s.key}`} id={`grad-${id || "chart"}-${s.key}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={color} stopOpacity={s.fillOpacity ?? 0.3} />
                    <stop offset="95%" stopColor={color} stopOpacity={0.0} />
                  </linearGradient>
                );
              })}
            </defs>
            {showGrid && <CartesianGrid strokeDasharray="3 3" vertical={false} className="stroke-hairline-soft" />}
            <XAxis dataKey={xKey} tickLine={false} axisLine={false} className="text-[10px] font-mono fill-ink-secondary" />
            <YAxis tickLine={false} axisLine={false} className="text-[10px] font-mono fill-ink-secondary" tickFormatter={valueFormatter} />
            {showTooltip && <ChartTooltip content={<ChartTooltipContent {...tooltipContentProps} />} />}
            {showLegend && <ChartLegend content={interactiveLegend} />}
            {series.map((s, idx) => {
              const color = s.color || colors[idx % colors.length];
              return (
                <Area
                  key={s.key}
                  type={s.type || "monotone"}
                  dataKey={s.key}
                  stroke={color}
                  strokeWidth={2}
                  fill={`url(#grad-${id || "chart"}-${s.key})`}
                  hide={hiddenKeys.has(s.key)}
                  {...noEntranceAnimation}
                />
              );
            })}
            {referenceLineElements}
          </AreaChart>
        );

      case "bar": {
        const resolvedBarSize = barSize ?? (series.length <= 1 ? 32 : 12);
        return (
          <BarChart data={data} layout={barLayout === "horizontal" ? "vertical" : "horizontal"} margin={{ left: barLayout === "horizontal" ? 5 : -15, right: 15, top: 10, bottom: xAxisLabel ? 20 : 0 }} barCategoryGap="20%">
            {showGrid && <CartesianGrid strokeDasharray="3 3" vertical={false} className="stroke-hairline-soft" />}
            <XAxis type={barLayout === "horizontal" ? "number" : "category"} dataKey={barLayout === "horizontal" ? undefined : xKey} tickLine={false} axisLine={false} className="text-[10px] font-mono fill-ink-secondary" tickFormatter={barLayout === "horizontal" ? valueFormatter : undefined} label={xAxisLabel ? { value: xAxisLabel, position: "insideBottom", offset: -12 } : undefined} />
            <YAxis type={barLayout === "horizontal" ? "category" : "number"} dataKey={barLayout === "horizontal" ? xKey : undefined} tickLine={false} axisLine={false} width={barLayout === "horizontal" ? 88 : 64} className="text-[10px] font-mono fill-ink-secondary" tickFormatter={barLayout === "horizontal" ? undefined : valueFormatter} label={yAxisLabel ? { value: yAxisLabel, angle: -90, position: "insideLeft" } : undefined} />
            {showTooltip && <ChartTooltip content={<ChartTooltipContent {...tooltipContentProps} />} />}
            {showLegend && <ChartLegend content={interactiveLegend} />}
            {series.map((s, idx) => {
              const color = s.color || colors[idx % colors.length];
              const hasCustomFills = series.length === 1 && data.some((d) => d.fill || d.color);
              return (
                <Bar
                  key={s.key}
                  dataKey={s.key}
                  fill={color}
                  radius={[4, 4, 0, 0]}
                  barSize={s.barSize ?? resolvedBarSize}
                  maxBarSize={48}
                  stackId={s.stackId}
                  hide={hiddenKeys.has(s.key)}
                  {...noEntranceAnimation}
                >
                  {hasCustomFills &&
                    data.map((entry, cellIdx) => (
                      <Cell
                        key={`cell-${cellIdx}`}
                        fill={entry.fill || entry.color || color}
                      />
                    ))}
                </Bar>
              );
            })}
            {referenceLineElements}
          </BarChart>
        );
      }

      case "line":
        return (
          <LineChart data={data} margin={{ left: -15, right: 5, top: 10, bottom: xAxisLabel ? 20 : 0 }}>
            {showGrid && <CartesianGrid strokeDasharray="3 3" vertical={false} className="stroke-hairline-soft" />}
            <XAxis dataKey={xKey} tickLine={false} axisLine={false} className="text-[10px] font-mono fill-ink-secondary" label={xAxisLabel ? { value: xAxisLabel, position: "insideBottom", offset: -12 } : undefined} />
            <YAxis tickLine={false} axisLine={false} className="text-[10px] font-mono fill-ink-secondary" tickFormatter={valueFormatter} label={yAxisLabel ? { value: yAxisLabel, angle: -90, position: "insideLeft" } : undefined} />
            {showTooltip && <ChartTooltip content={<ChartTooltipContent {...tooltipContentProps} />} />}
            {showLegend && <ChartLegend content={interactiveLegend} />}
            {series.map((s, idx) => {
              const color = s.color || colors[idx % colors.length];
              return (
                <Line
                  key={s.key}
                  type={s.type || "monotone"}
                  dataKey={s.key}
                  stroke={color}
                  strokeWidth={2}
                  strokeDasharray={s.strokeDasharray}
                  dot={{ r: 3 }}
                  activeDot={{ r: 6 }}
                  hide={hiddenKeys.has(s.key)}
                  {...noEntranceAnimation}
                />
              );
            })}
            {referenceLineElements}
          </LineChart>
        );

      case "pie": {
        // Keep the full `data` set on <Pie> (not filtered) so the legend —
        // which Recharts derives from the rendered sectors — still lists
        // every slice name. A toggled-off slice only loses its fill/stroke
        // (an invisible sector), it never disappears from the legend; the
        // legend label itself gets struck through via `inactiveKeys`.
        return (
          <PieChart>
            {showTooltip && <ChartTooltip content={<ChartTooltipContent {...tooltipContentProps} hideLabel />} />}
            <Pie
              data={data}
              dataKey={pieValueKey}
              nameKey={pieNameKey}
              innerRadius={innerRadius}
              outerRadius={outerRadius}
              paddingAngle={3}
              {...noEntranceAnimation}
            >
              {data.map((entry, idx) => {
                const isHidden = hiddenKeys.has(String(entry[pieNameKey]));
                const color = entry.fill || colors[idx % colors.length];
                return <Cell key={`cell-${idx}`} fill={isHidden ? "transparent" : color} stroke={isHidden ? "transparent" : undefined} />;
              })}
            </Pie>
            {showLegend && (
              <ChartLegend
                content={
                  <ChartLegendContent
                    className="flex-wrap"
                    nameKey={pieNameKey}
                    inactiveKeys={hiddenKeys}
                    onLegendItemClick={toggleSeries}
                  />
                }
              />
            )}
          </PieChart>
        );
      }

      case "radar":
        return (
          <RadarChart data={data} margin={{ top: 15, bottom: 15, left: 15, right: 15 }}>
            <PolarGrid stroke="currentColor" className="text-hairline-soft/80" />
            <PolarAngleAxis
              dataKey={xKey}
              tick={{ fill: "currentColor", fontSize: 10 }}
              className="text-ink-secondary font-mono"
            />
            {showTooltip && <ChartTooltip content={<ChartTooltipContent {...tooltipContentProps} />} />}
            {series.map((s, idx) => {
              const color = s.color || colors[idx % colors.length];
              return (
                <Radar
                  key={s.key}
                  name={s.label}
                  dataKey={s.key}
                  stroke={color}
                  strokeWidth={2}
                  fill={color}
                  fillOpacity={s.fillOpacity ?? 0.35}
                  dot={{ r: 3, fill: color }}
                  activeDot={{ r: 5, fill: color }}
                  hide={hiddenKeys.has(s.key)}
                  {...noEntranceAnimation}
                />
              );
            })}
            {showLegend && (
              <ChartLegend
                content={<ChartLegendContent className="pt-2" inactiveKeys={hiddenKeys} onLegendItemClick={toggleSeries} />}
              />
            )}
          </RadarChart>
        );

      case "radial":
        return (
          <RadialBarChart innerRadius="30%" outerRadius="100%" barSize={10} data={data}>
            <RadialBar
              background={{ fill: "var(--color-bg-surface-soft)" }}
              dataKey="value"
              cornerRadius={6}
              {...noEntranceAnimation}
            />
            {showTooltip && <ChartTooltip content={<ChartTooltipContent {...tooltipContentProps} nameKey={tooltipNameKey ?? "name"} />} />}
            {showLegend && <ChartLegend content={<ChartLegendContent className="flex-col items-start gap-1 text-[10px] pl-4" />} />}
          </RadialBarChart>
        );

      case "scatter":
      case "bubble":
        return (
          <ScatterChart margin={{ left: 0, right: 15, top: 10, bottom: xAxisLabel ? 20 : 0 }}>
            {showGrid && <CartesianGrid strokeDasharray="3 3" className="stroke-hairline-soft" />}
            <XAxis type="number" dataKey={scatterXKey} name={xAxisLabel || scatterXKey} tickLine={false} axisLine={false} label={xAxisLabel ? { value: xAxisLabel, position: "insideBottom", offset: -12 } : undefined} />
            <YAxis type="number" dataKey={scatterYKey} name={yAxisLabel || scatterYKey} tickLine={false} axisLine={false} label={yAxisLabel ? { value: yAxisLabel, angle: -90, position: "insideLeft" } : undefined} />
            {type === "bubble" && <ZAxis type="number" dataKey={bubbleSizeKey} range={[50, 500]} />}
            {showTooltip && <ChartTooltip content={<ChartTooltipContent {...tooltipContentProps} />} cursor={{ strokeDasharray: "3 3" }} />}
            {referenceLineElements}
            <Scatter name={series[0]?.label || "Data"} data={data} fill={series[0]?.color || colors[0]} {...noEntranceAnimation}>
              {/* Warna per titik: dipakai saat satu scatter membawa beberapa
                  kategori (mis. kuadran kritis vs stabil) tanpa perlu memecah
                  jadi beberapa <Scatter>. */}
              {data.some((row) => row.fill) &&
                data.map((entry, idx) => (
                  <Cell key={`scatter-cell-${idx}`} fill={entry.fill || series[0]?.color || colors[0]} />
                ))}
            </Scatter>
          </ScatterChart>
        );

      case "combo":
        return (
          <ComposedChart data={data} margin={{ left: -5, right: 5, top: 10, bottom: xAxisLabel ? 20 : 0 }}>
            {showGrid && <CartesianGrid strokeDasharray="3 3" vertical={false} className="stroke-hairline-soft" />}
            <XAxis dataKey={xKey} tickLine={false} axisLine={false} label={xAxisLabel ? { value: xAxisLabel, position: "insideBottom", offset: -12 } : undefined} />
            <YAxis yAxisId="left" width={64} tickLine={false} axisLine={false} className="text-[10px] font-mono fill-ink-secondary" tickFormatter={valueFormatter} label={yAxisLabel ? { value: yAxisLabel, angle: -90, position: "insideLeft" } : undefined} />
            {/* Sumbu kanan hanya dipasang kalau benar-benar ada seri yang
                memakainya. Kalau dipasang tanpa seri, Recharts gagal
                menghitung geometri Bar (x/width jadi NaN) dan seluruh chart
                combo tampil kosong. */}
            {usesRightAxis && <YAxis yAxisId="right" orientation="right" width={64} tickLine={false} axisLine={false} className="text-[10px] font-mono fill-ink-secondary" tickFormatter={valueFormatter} />}
            {showTooltip && <ChartTooltip content={<ChartTooltipContent {...tooltipContentProps} />} />}
            {showLegend && <ChartLegend content={interactiveLegend} />}
            {series.map((s, idx) => s.chartType === "line" ? (
              <Line key={s.key} yAxisId={s.yAxisId || "left"} type={s.type || "monotone"} dataKey={s.key} stroke={s.color || colors[idx % colors.length]} strokeWidth={2} dot={{ r: 3 }} strokeDasharray={s.strokeDasharray} hide={hiddenKeys.has(s.key)} {...noEntranceAnimation} />
            ) : (
              <Bar key={s.key} yAxisId={s.yAxisId || "left"} dataKey={s.key} fill={s.color || colors[idx % colors.length]} radius={[4, 4, 0, 0]} barSize={s.barSize || 24} stackId={s.stackId} hide={hiddenKeys.has(s.key)} {...noEntranceAnimation} />
            ))}
            {referenceLineElements}
          </ComposedChart>
        );

      default:
        return null;
    }
  };

  if (loading) {
    return <div id={id} aria-busy="true" className={cn("flex w-full items-end gap-2 rounded-lg border border-hairline-soft bg-surface p-4", className)} style={containerStyle}>{Array.from({ length: 8 }).map((_, index) => <SkeletonApp key={index} id={`${id || "chart"}-loading-${index}`} className="w-full rounded-sm" style={{ height: `${30 + (index % 4) * 14}%` }} />)}</div>;
  }

  if (!data.length) {
    return <div id={id} className={cn("flex w-full flex-col items-center justify-center gap-2 rounded-lg border border-hairline-soft bg-surface text-center", className)} style={containerStyle}><Database className="h-8 w-8 text-ink-muted" /><TextApp id={`${id || "chart"}-empty`} variant="caption" className="text-ink-muted">{emptyMessage}</TextApp></div>;
  }

  return (
    <ChartContainer
      id={id}
      config={chartConfig}
      // min-w-0 lets Recharts' internal ResponsiveContainer actually shrink
      // when ChartApp sits inside a flex container (e.g. a centered showcase
      // preview) — otherwise flex's default min-width:auto stops it from
      // measuring narrower than the chart's intrinsic content size.
      className={cn("w-full min-w-0", className)}
      style={containerStyle}
    >
      {renderChartContent()}
    </ChartContainer>
  );
}
