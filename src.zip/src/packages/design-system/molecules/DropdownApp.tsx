import * as React from "react";
import { cva } from "class-variance-authority";
import { createPortal } from "react-dom";
import { ChevronDown, Check, X, Search, CheckSquare, Square, Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import { BadgeApp } from "../atoms/BadgeApp";
import { ChipsApp } from "../atoms/ChipsApp";
import { TextApp } from "../atoms/TextApp";
import { focusBorderRingClass, jsStateRingClass, FOCUS_PSEUDO_RING_WIDTH_OFFSET } from "../tokens/focusRing";

export interface DropdownOption {
  label: string;
  value: string;
  icon?: React.ComponentType<{ className?: string }>;
  description?: string;
  disabled?: boolean;
  badge?: string;
  group?: string;
}

export type DropdownSize = "sm" | "md" | "lg";
export type DropdownVariant = "default" | "error" | "success";
export type DropdownRounded = "none" | "sm" | "md" | "lg" | "full";

// Foundation radius scale (none=0, sm=4px, md=8px, lg=16px) — kept in sync with
// ButtonApp/InputApp/TextAreaApp/SelectApp so the trigger and its panel match exactly.
const dropdownRoundedClasses: Record<DropdownRounded, string> = {
  none: "rounded-none",
  sm: "rounded-[4px]",
  md: "rounded-[8px]",
  lg: "rounded-[16px]",
  full: "rounded-full",
};

export interface DropdownAppProps {
  id?: string;
  label?: string;
  placeholder?: string;
  options: DropdownOption[];
  value?: string | string[];
  defaultValue?: string | string[];
  onChange?: (value: any, selectedOptions?: DropdownOption | DropdownOption[]) => void;
  disabled?: boolean;
  isMulti?: boolean;
  searchable?: boolean;
  isCreatable?: boolean;
  onCreateOption?: (inputValue: string) => void;
  tagType?: "badge" | "chip";
  size?: DropdownSize;
  variant?: DropdownVariant;
  rounded?: DropdownRounded;
  helperText?: string;
  showClear?: boolean;
  maxMenuHeight?: string;
  className?: string;
  dropdownClassName?: string;
  icon?: React.ComponentType<{ className?: string }>;
  name?: string;
  required?: boolean;
  readOnly?: boolean;
  emptyText?: string;
  searchPlaceholder?: string;
  /**
   * Render panel opsi ke `document.body` (position: fixed) alih-alih sebagai
   * anak absolut dari trigger. Wajib dinyalakan bila dropdown berada di dalam
   * kontainer ber-`overflow` (filter drawer AdvanceFilterApp, filter bar
   * `overflow-x-auto`, popover filter kolom DataTableApp) — tanpa ini panel
   * terpotong oleh kontainer induknya. Default `false` supaya perilaku
   * showcase UI Kit (ui:03/dropdown/*) tidak berubah.
   */
  menuPortal?: boolean;
}

const dropdownTriggerVariants = cva(
  `w-full flex items-center justify-between border bg-surface transition-all select-none focus:outline-none cursor-pointer ${FOCUS_PSEUDO_RING_WIDTH_OFFSET}`,
  {
    variants: {
      size: {
        sm: "min-h-[32px] px-2.5 py-1 text-xs gap-1.5",
        md: "min-h-[40px] px-3 py-1.5 text-sm gap-2",
        lg: "min-h-[48px] px-4 py-2 text-base gap-2.5",
      },
      rounded: {
        none: "rounded-none",
        sm: "rounded-[4px]",
        md: "rounded-[8px]",
        lg: "rounded-[16px]",
        full: "rounded-full",
      },
      variant: {
        default: `border-hairline text-ink hover:border-vibrant-purple/60 ${focusBorderRingClass.default}`,
        error: `border-error text-error ${focusBorderRingClass.error}`,
        success: `border-success text-success ${focusBorderRingClass.success}`,
      },
      disabled: {
        true: "bg-surface-soft border-hairline-soft opacity-60 cursor-not-allowed pointer-events-none text-ink-muted",
        false: "",
      },
    },
    defaultVariants: {
      // Aligned project-wide with ButtonApp/InputApp defaults (size="sm", rounded="lg").
      size: "sm",
      rounded: "lg",
      variant: "default",
      disabled: false,
    },
  }
);

export const DropdownApp = React.forwardRef<HTMLDivElement, DropdownAppProps>(
  (
    {
      id: propId,
      label,
      placeholder = "Pilih opsi...",
      options = [],
      value: controlledValue,
      defaultValue,
      onChange,
      disabled = false,
      isMulti = false,
      searchable = false,
      isCreatable = false,
      onCreateOption,
      tagType = "badge",
      size = "sm",
      rounded = "lg",
      variant = "default",
      helperText,
      showClear = false,
      maxMenuHeight = "max-h-60",
      className,
      dropdownClassName,
      icon: InputIcon,
      name,
      required = false,
      readOnly = false,
      emptyText = "Tidak ada hasil ditemukan",
      searchPlaceholder = "Cari opsi...",
      menuPortal = false,
    },
    ref
  ) => {
    const generatedId = React.useId();
    const id = propId || `dropdown-${generatedId}`;

    // Internal state for controlled/uncontrolled behavior
    const isControlled = controlledValue !== undefined;
    const [internalValue, setInternalValue] = React.useState<string | string[]>(() => {
      if (defaultValue !== undefined) return defaultValue;
      return isMulti ? [] : "";
    });

    const currentValue = isControlled ? controlledValue! : internalValue;

    const [isOpen, setIsOpen] = React.useState(false);
    const [searchQuery, setSearchQuery] = React.useState("");
    const [focusedIndex, setFocusedIndex] = React.useState<number>(-1);

    const containerRef = React.useRef<HTMLDivElement | null>(null);
    const popoverRef = React.useRef<HTMLDivElement | null>(null);
    const searchInputRef = React.useRef<HTMLInputElement | null>(null);

    // Auto placement states (top vs bottom, left vs right) to prevent viewport clipping
    const [placementY, setPlacementY] = React.useState<"bottom" | "top">("bottom");
    const [placementX, setPlacementX] = React.useState<"left" | "right">("left");
    // Koordinat viewport untuk mode menuPortal (panel di-render ke document.body)
    const [portalRect, setPortalRect] = React.useState<{ top: number; left: number; width: number } | null>(null);

    // Dynamic placement check on open, window scroll, or resize
    React.useLayoutEffect(() => {
      if (!isOpen || !containerRef.current) return;

      const updatePosition = () => {
        if (!containerRef.current) return;
        const triggerRect = containerRef.current.getBoundingClientRect();
        const viewportHeight = window.innerHeight;
        const viewportWidth = window.innerWidth;

        const popoverHeight = popoverRef.current ? popoverRef.current.offsetHeight : 260;
        const popoverWidth = popoverRef.current ? popoverRef.current.offsetWidth : triggerRect.width;

        const spaceBelow = viewportHeight - triggerRect.bottom;
        const spaceAbove = triggerRect.top;

        if (spaceBelow < popoverHeight && spaceAbove > spaceBelow) {
          setPlacementY("top");
        } else {
          setPlacementY("bottom");
        }

        const spaceRight = viewportWidth - triggerRect.left;
        const flipX = spaceRight < popoverWidth && triggerRect.right >= popoverWidth;
        setPlacementX(flipX ? "right" : "left");

        if (menuPortal) {
          // Panel di-render ke body dengan position: fixed, jadi koordinatnya
          // dihitung manual dari rect trigger (bukan lewat kelas top-full/bottom-full).
          const width = Math.max(triggerRect.width, 240);
          const flipY = spaceBelow < popoverHeight && spaceAbove > spaceBelow;
          const rawLeft = flipX ? triggerRect.right - width : triggerRect.left;
          const next = {
            top: flipY ? triggerRect.top - popoverHeight - 6 : triggerRect.bottom + 6,
            // Clamp ke dalam viewport pada kedua arah — trigger bisa saja sedang
            // di luar layar (mis. drawer yang masih beranimasi masuk).
            left: Math.max(8, Math.min(rawLeft, viewportWidth - width - 8)),
            width,
          };
          // Hindari re-render sia-sia: `scroll` capture menyala sangat sering.
          setPortalRect((prev) =>
            prev && prev.top === next.top && prev.left === next.left && prev.width === next.width ? prev : next
          );
        }
      };

      updatePosition();
      // Pass pertama pada mode portal berjalan sebelum panel ter-mount (tinggi
      // masih pakai fallback), jadi ukur ulang satu frame berikutnya.
      const raf = requestAnimationFrame(updatePosition);
      window.addEventListener("scroll", updatePosition, true);
      window.addEventListener("resize", updatePosition);

      return () => {
        cancelAnimationFrame(raf);
        window.removeEventListener("scroll", updatePosition, true);
        window.removeEventListener("resize", updatePosition);
      };
    }, [isOpen, menuPortal]);

    React.useEffect(() => {
      if (!isOpen) setPortalRect(null);
    }, [isOpen]);

    // Focus search input when popover opens
    React.useEffect(() => {
      if (isOpen && searchable && searchInputRef.current) {
        setTimeout(() => {
          searchInputRef.current?.focus();
        }, 50);
      }
      if (!isOpen) {
        setSearchQuery("");
        setFocusedIndex(-1);
      }
    }, [isOpen, searchable]);

    // Close on click outside
    React.useEffect(() => {
      const handleClickOutside = (event: MouseEvent) => {
        const target = event.target as Node;
        // Pada mode menuPortal panel hidup di document.body — di luar containerRef —
        // jadi klik di dalam panel harus ikut dianggap "di dalam".
        const insideTrigger = containerRef.current?.contains(target);
        const insidePanel = popoverRef.current?.contains(target);
        if (!insideTrigger && !insidePanel) {
          setIsOpen(false);
        }
      };
      document.addEventListener("mousedown", handleClickOutside);
      return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    // Filtered options based on search query
    const filteredOptions = React.useMemo(() => {
      if (!searchQuery.trim()) return options;
      const q = searchQuery.toLowerCase();
      return options.filter(
        (opt) =>
          opt.label.toLowerCase().includes(q) ||
          (opt.description && opt.description.toLowerCase().includes(q))
      );
    }, [options, searchQuery]);

    const exactMatchExists = React.useMemo(() => {
      if (!searchQuery.trim()) return true;
      const q = searchQuery.trim().toLowerCase();
      return options.some((opt) => opt.label.toLowerCase() === q);
    }, [options, searchQuery]);

    // Highlight text search match helper
    const renderHighlightedText = (text: string, query: string) => {
      if (!query.trim()) return text;
      const safeQuery = query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const parts = text.split(new RegExp(`(${safeQuery})`, "gi"));
      return (
        <span>
          {parts.map((part, i) =>
            part.toLowerCase() === query.toLowerCase() ? (
              <mark key={i} className="bg-vibrant-purple/30 text-vibrant-purple-dark font-semibold rounded px-0.5">
                {part}
              </mark>
            ) : (
              part
            )
          )}
        </span>
      );
    };

    // Value helpers
    const selectedOptionsList = React.useMemo(() => {
      if (isMulti) {
        const arr = Array.isArray(currentValue) ? currentValue : [];
        return options.filter((opt) => arr.includes(opt.value));
      } else {
        const valStr = typeof currentValue === "string" ? currentValue : "";
        const match = options.find((opt) => opt.value === valStr);
        return match ? [match] : [];
      }
    }, [options, currentValue, isMulti]);

    const isOptionSelected = (optValue: string) => {
      if (isMulti) {
        return Array.isArray(currentValue) && currentValue.includes(optValue);
      }
      return currentValue === optValue;
    };

    const handleSelectOption = (option: DropdownOption, e?: React.MouseEvent) => {
      if (e) e.stopPropagation();
      if (option.disabled || disabled || readOnly) return;

      if (isMulti) {
        const currentArr = Array.isArray(currentValue) ? [...currentValue] : [];
        const exists = currentArr.includes(option.value);
        let updated: string[];
        if (exists) {
          updated = currentArr.filter((v) => v !== option.value);
        } else {
          updated = [...currentArr, option.value];
        }
        if (!isControlled) {
          setInternalValue(updated);
        }
        const updatedSelectedOptions = options.filter((opt) => updated.includes(opt.value));
        onChange?.(updated, updatedSelectedOptions);
      } else {
        const updated = option.value;
        if (!isControlled) {
          setInternalValue(updated);
        }
        onChange?.(updated, option);
        setIsOpen(false);
      }
    };

    const handleCreateNewOption = (e?: React.MouseEvent) => {
      if (e) e.stopPropagation();
      if (!searchQuery.trim() || disabled || readOnly) return;
      const rawText = searchQuery.trim();
      const newOptVal = rawText.toLowerCase().replace(/\s+/g, "_");
      const newOpt: DropdownOption = {
        label: rawText,
        value: newOptVal,
      };
      onCreateOption?.(rawText);
      handleSelectOption(newOpt);
      setSearchQuery("");
    };

    const handleClearAll = (e: React.MouseEvent) => {
      e.stopPropagation();
      if (disabled || readOnly) return;
      const emptyVal = isMulti ? [] : "";
      if (!isControlled) {
        setInternalValue(emptyVal);
      }
      onChange?.(emptyVal, isMulti ? [] : undefined);
    };

    const handleSelectAll = (e: React.MouseEvent) => {
      e.stopPropagation();
      if (!isMulti || disabled || readOnly) return;
      const availableValues = filteredOptions.filter((o) => !o.disabled).map((o) => o.value);
      if (!isControlled) {
        setInternalValue(availableValues);
      }
      const selectedOpts = options.filter((opt) => availableValues.includes(opt.value));
      onChange?.(availableValues, selectedOpts);
    };

    // Keyboard navigation handlers
    const handleKeyDown = (e: React.KeyboardEvent) => {
      if (disabled || readOnly) return;

      if (!isOpen) {
        if (e.key === "Enter" || e.key === "ArrowDown" || e.key === " ") {
          e.preventDefault();
          setIsOpen(true);
        }
        return;
      }

      const totalItemsCount = filteredOptions.length + (isCreatable && !exactMatchExists ? 1 : 0);

      switch (e.key) {
        case "Escape":
        case "Tab":
          setIsOpen(false);
          break;
        case "ArrowDown":
          e.preventDefault();
          setFocusedIndex((prev) => (prev < totalItemsCount - 1 ? prev + 1 : 0));
          break;
        case "ArrowUp":
          e.preventDefault();
          setFocusedIndex((prev) => (prev > 0 ? prev - 1 : totalItemsCount - 1));
          break;
        case "Enter":
          e.preventDefault();
          if (focusedIndex >= 0 && focusedIndex < filteredOptions.length) {
            handleSelectOption(filteredOptions[focusedIndex]);
          } else if (isCreatable && !exactMatchExists && focusedIndex === filteredOptions.length) {
            handleCreateNewOption();
          }
          break;
      }
    };

    const hasValue = isMulti
      ? Array.isArray(currentValue) && currentValue.length > 0
      : Boolean(currentValue);

    // Pada mode portal, koordinat dipasang pada WRAPPER polos tanpa kelas
    // Tailwind apa pun. Panelnya sendiri membawa `duration-200`, dan karena
    // Tailwind v4 memberi `transition-property: all` secara default, memasang
    // top/left langsung di panel membuat keduanya ikut ditransisikan dari
    // `auto` — hasilnya panel nyangkut di pojok kiri-atas. Wrapper memutus itu.
    const withMenuPortal = (node: React.ReactElement) => {
      if (!menuPortal || typeof document === "undefined") return node;
      if (!portalRect) return null;
      return createPortal(
        <div
          style={{
            position: "fixed",
            top: portalRect.top,
            left: portalRect.left,
            width: portalRect.width,
            zIndex: 60,
          }}
        >
          {node}
        </div>,
        document.body
      );
    };

    return (
      <div
        ref={(node) => {
          containerRef.current = node;
          if (typeof ref === "function") ref(node);
          else if (ref) (ref as React.MutableRefObject<HTMLDivElement | null>).current = node;
        }}
        className={cn("relative inline-block w-full flex-col gap-1.5", isOpen ? "z-40" : "z-10", className)}
        onKeyDown={handleKeyDown}
      >
        {/* Label */}
        {label && (
          <label htmlFor={id} className="block text-xs font-semibold text-ink mb-1 select-none">
            {label}
            {required && <span className="text-error ml-0.5">*</span>}
          </label>
        )}

        {/* Trigger Button Input */}
        <div
          id={id}
          role="combobox"
          aria-expanded={isOpen}
          aria-haspopup="listbox"
          tabIndex={disabled ? -1 : 0}
          onClick={() => !disabled && !readOnly && setIsOpen((prev) => !prev)}
          className={cn(
            dropdownTriggerVariants({ size, rounded, variant, disabled }),
            isOpen && jsStateRingClass[variant]
          )}
        >
          <div className="flex items-center gap-2 flex-1 min-w-0 overflow-hidden">
            {InputIcon && (
              <InputIcon
                className={cn(
                  "text-ink-muted flex-shrink-0",
                  size === "sm" ? "w-3.5 h-3.5" : size === "lg" ? "w-5 h-5" : "w-4 h-4"
                )}
              />
            )}

            {/* Display Selected Items / Placeholder */}
            {isMulti ? (
              <div className="flex flex-wrap gap-1.5 items-center py-0.5 max-w-full overflow-hidden">
                {selectedOptionsList.length > 0 ? (
                  selectedOptionsList.map((opt) => (
                    tagType === "chip" ? (
                      <ChipsApp
                        id={`chip-opt-${opt.value}`}
                        key={opt.value}
                        chipType="input"
                        variant="vibrant"
                        size="sm"
                        removable={!disabled && !readOnly}
                        onRemove={(e) => handleSelectOption(opt, e as any)}
                        className="whitespace-nowrap truncate max-w-full"
                      >
                        {opt.label}
                      </ChipsApp>
                    ) : (
                      <BadgeApp
                        id={`badge-opt-${opt.value}`}
                        key={opt.value}
                        variant="solidPurple"
                        size="sm"
                        rounded="pill"
                        className="inline-flex items-center gap-1 max-w-full truncate whitespace-nowrap"
                      >
                        <span className="truncate whitespace-nowrap max-w-[120px] inline-block">{opt.label}</span>
                        {!disabled && !readOnly && (
                          <X
                            className="w-3 h-3 cursor-pointer opacity-70 hover:opacity-100 flex-shrink-0"
                            onClick={(e) => handleSelectOption(opt, e)}
                          />
                        )}
                      </BadgeApp>
                    )
                  ))
                ) : (
                  <span className="text-ink-muted truncate select-none">{placeholder}</span>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2 truncate flex-1 min-w-0">
                {selectedOptionsList[0] ? (
                  <>
                    {(() => {
                      const SelectedIcon = selectedOptionsList[0].icon;
                      return SelectedIcon ? (
                        <SelectedIcon className="w-4 h-4 text-vibrant-purple-dark flex-shrink-0" />
                      ) : null;
                    })()}
                    <span className="text-ink font-medium truncate">{selectedOptionsList[0].label}</span>
                    {selectedOptionsList[0].badge && (
                      <BadgeApp
                        id={`selected-badge-${selectedOptionsList[0].value}`}
                        variant="vibrantPurple"
                        size="sm"
                        rounded="pill"
                        className="ml-auto flex-shrink-0 whitespace-nowrap truncate max-w-full"
                      >
                        {selectedOptionsList[0].badge}
                      </BadgeApp>
                    )}
                  </>
                ) : (
                  <span className="text-ink-muted truncate select-none">{placeholder}</span>
                )}
              </div>
            )}
          </div>

          {/* Right Action Icons (Clear & Chevron) */}
          <div className="flex items-center gap-1.5 flex-shrink-0 ml-1">
            {showClear && hasValue && !disabled && !readOnly && (
              <button
                type="button"
                onClick={handleClearAll}
                className="p-1 text-ink-muted hover:text-ink rounded-md transition-colors focus:outline-none"
                title="Hapus pilihan"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
            <ChevronDown
              className={cn(
                "w-4 h-4 text-ink-muted transition-transform duration-200",
                isOpen && "rotate-180 text-vibrant-purple"
              )}
            />
          </div>
        </div>

        {/* Hidden Form Input for standard form compatibility */}
        {name && (
          <input
            type="hidden"
            name={name}
            value={Array.isArray(currentValue) ? currentValue.join(",") : currentValue}
          />
        )}

        {/* Helper text */}
        {helperText && (
          <p
            className={cn(
              "text-xs mt-1 select-none",
              variant === "error" ? "text-error font-medium" : variant === "success" ? "text-success font-medium" : "text-ink-muted"
            )}
          >
            {helperText}
          </p>
        )}

        {/* DROPDOWN MENU PANEL */}
        {isOpen && withMenuPortal(
          <div
            ref={popoverRef}
            tabIndex={-1}
            role="listbox"
            onKeyDown={menuPortal ? handleKeyDown : undefined}
            className={cn(
              menuPortal
                ? "w-full p-2 bg-surface border border-hairline shadow-xl animate-in fade-in zoom-in-95 duration-200 select-none min-w-[240px]"
                : "absolute z-50 p-2 bg-surface border border-hairline shadow-xl animate-in fade-in zoom-in-95 duration-200 select-none max-w-[calc(100vw-2rem)] w-full min-w-[240px]",
              dropdownRoundedClasses[rounded],
              !menuPortal && (placementY === "top" ? "bottom-full mb-1.5" : "top-full mt-1.5"),
              !menuPortal && (placementX === "right" ? "right-0 left-auto" : "left-0 right-auto"),
              dropdownClassName
            )}
          >
            {/* Search Bar Input */}
            {searchable && (
              <div className="relative mb-2 pb-2 border-b border-hairline-soft">
                <Search className="w-4 h-4 text-ink-muted absolute left-2.5 top-2.5" />
                <input
                  ref={searchInputRef}
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={searchPlaceholder}
                  className={cn(
                    "w-full pl-8 pr-7 py-1.5 text-xs sm:text-sm bg-surface-soft border border-hairline focus:outline-none focus:border-vibrant-purple text-ink placeholder:text-ink-muted",
                    dropdownRoundedClasses[rounded]
                  )}
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery("")}
                    className="absolute right-2 top-2.5 text-ink-muted hover:text-ink p-0.5"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            )}

            {/* Multi-Select Select All / Clear All Header */}
            {isMulti && filteredOptions.length > 2 && (
              <div className="flex items-center justify-between px-2 py-1 mb-1 border-b border-hairline-soft text-[11px] text-ink-muted">
                <button
                  type="button"
                  onClick={handleSelectAll}
                  className="hover:text-vibrant-purple font-medium flex items-center gap-1 transition-colors"
                >
                  <CheckSquare className="w-3 h-3" /> Pilih Semua
                </button>
                <button
                  type="button"
                  onClick={handleClearAll}
                  className="hover:text-error font-medium flex items-center gap-1 transition-colors"
                >
                  <Square className="w-3 h-3" /> Hapus Semua
                </button>
              </div>
            )}

            {/* Options List */}
            <div className={cn("overflow-y-auto space-y-0.5 custom-scrollbar pr-0.5", maxMenuHeight)}>
              {filteredOptions.length > 0 ? (
                filteredOptions.map((option, idx) => {
                  const selected = isOptionSelected(option.value);
                  const isFocused = idx === focusedIndex;
                  const OptionIcon = option.icon;

                  return (
                    <div
                      key={option.value}
                      role="option"
                      aria-selected={selected}
                      onClick={(e) => handleSelectOption(option, e)}
                      onMouseEnter={() => setFocusedIndex(idx)}
                      className={cn(
                        "flex items-center justify-between px-3 py-2 text-xs sm:text-sm transition-colors cursor-pointer select-none",
                        dropdownRoundedClasses[rounded],
                        selected
                          ? "bg-vibrant-purple/15 text-vibrant-purple-dark font-semibold dark:bg-purple-900/40 dark:text-purple-200"
                          : isFocused
                          ? "bg-vibrant-purple/10 text-ink"
                          : "hover:bg-vibrant-purple/10 text-ink",
                        option.disabled && "opacity-40 cursor-not-allowed pointer-events-none"
                      )}
                    >
                      <div className="flex items-start gap-2.5 min-w-0 flex-1">
                        {isMulti && (
                          <div className="mt-0.5 flex-shrink-0">
                            {selected ? (
                              <CheckSquare className="w-4 h-4 text-vibrant-purple-dark" />
                            ) : (
                              <Square className="w-4 h-4 text-ink-muted" />
                            )}
                          </div>
                        )}

                        {OptionIcon && (
                          <OptionIcon className={cn("w-4 h-4 mt-0.5 flex-shrink-0", selected ? "text-vibrant-purple-dark" : "text-ink-muted")} />
                        )}

                        <div className="flex flex-col min-w-0 flex-1">
                          <span className="truncate leading-snug">
                            {renderHighlightedText(option.label, searchQuery)}
                          </span>
                          {option.description && (
                            <span className="text-[11px] text-ink-muted font-normal truncate mt-0.5">
                              {renderHighlightedText(option.description, searchQuery)}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 ml-2 flex-shrink-0">
                        {option.badge && (
                          <BadgeApp
                            id={`opt-badge-${option.value}`}
                            variant={selected ? "solidPurple" : "outlineNeutral"}
                            size="sm"
                            rounded="pill"
                            className="whitespace-nowrap truncate max-w-full"
                          >
                            {option.badge}
                          </BadgeApp>
                        )}
                        {!isMulti && selected && <Check className="w-4 h-4 text-vibrant-purple-dark flex-shrink-0" />}
                      </div>
                    </div>
                  );
                })
              ) : !isCreatable ? (
                <div className="px-3 py-4 text-center text-xs text-ink-muted">
                  <TextApp id="dropdown-empty-text" variant="caption" className="text-ink-muted">
                    {emptyText}
                  </TextApp>
                </div>
              ) : null}

              {/* Add New Option (Creatable) item */}
              {isCreatable && searchQuery.trim() && !exactMatchExists && (
                <div
                  role="option"
                  onClick={handleCreateNewOption}
                  onMouseEnter={() => setFocusedIndex(filteredOptions.length)}
                  className={cn(
                    "flex items-center gap-2 px-3 py-2 text-xs sm:text-sm transition-colors cursor-pointer select-none border-t border-hairline-soft mt-1 text-vibrant-purple-dark font-medium hover:bg-vibrant-purple/10",
                    dropdownRoundedClasses[rounded],
                    focusedIndex === filteredOptions.length && "bg-vibrant-purple/10"
                  )}
                >
                  <Plus className="w-4 h-4 text-vibrant-purple-dark flex-shrink-0" />
                  <span className="truncate">
                    Tambah <span className="font-bold">"{searchQuery.trim()}"</span>
                  </span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  }
);

DropdownApp.displayName = "DropdownApp";
