import * as React from "react";
import { motion, useReducedMotion } from "motion/react";
import { cn } from "@/lib/utils";
import { Info, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { PopoverApp } from "./PopoverApp";
import { InsightApp, type InsightContent } from "./InsightApp";
import { AutoLoopListApp } from "./AutoLoopListApp";
import { TextApp } from "../atoms/TextApp";

export type ScorecardVariant = "default" | "purple" | "blue" | "yellow" | "emerald" | "rose" | "cyan" | "alert" | "clay" | "clayPurple" | "clayYellow" | "clayBlue" | "clayEmerald" | "playful" | "minimalist";
export type ScorecardLayout = "vertical" | "horizontal" | "minimalist";
export type ScorecardStatus = "normal" | "warning" | "danger" | "success";

export interface ScorecardTrend {
  value: string | number;
  label?: string;
  isPositive?: boolean;
  direction?: "up" | "down" | "neutral";
}

export interface ScorecardProgress {
  value: number;
  max?: number;
  label?: string;
  color?: string;
}

/**
 * One row of a KPI card's composition breakdown — e.g. a "Target PAD" card
 * broken down into Pajak Daerah / Retribusi / Kekayaan Daerah / LLPS. Each
 * row shows a label, its value, and (optionally) a share bar, so a single
 * scorecard can carry the whole composition instead of needing a separate
 * hand-rolled card next to it.
 */
export interface ScorecardBreakdownItem {
  id?: string;
  label: string;
  value: string | number;
  /** 0–100 share of the row's bar. Omit to render the row without a bar. */
  percent?: number;
  /** Bar color; falls back to the card's accent. */
  color?: string;
  onClick?: () => void;
}

export interface ScorecardInfoContent {
  /** Short explanation of what the metric means / how it's computed. */
  formula?: string;
  /** e.g. "Bulanan", "Real-time", "Per Kuartal". */
  period?: string;
  /** e.g. "SIMDA Keuangan Daerah". */
  source?: string;
  /** e.g. "2 menit lalu". */
  lastUpdated?: string;
}

// motion.div's own typed event handlers (onAnimationStart, onDrag*, etc.)
// conflict with the plain DOM ones from HTMLAttributes — omit the handful
// that actually collide since this component doesn't use them anyway.
export interface ScorecardAppProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, "onAnimationStart" | "onAnimationEnd" | "onDrag" | "onDragStart" | "onDragEnd"> {
  id: string;
  title: string;
  value: string | number;
  unit?: string;
  description?: string;
  icon?: React.ReactNode;
  trend?: ScorecardTrend;
  variant?: ScorecardVariant;
  layout?: ScorecardLayout;
  status?: ScorecardStatus;
  badge?: React.ReactNode | string;
  infoTooltip?: string;
  /**
   * Rich popover content for the info icon (formula/period/source/last
   * updated). When provided this takes over the info trigger and renders
   * an actual PopoverApp instead of a plain title="" tooltip — the doc
   * team's brief for what the info interaction should show. Overridden by
   * onInfoClick if that's set instead.
   */
  infoContent?: ScorecardInfoContent;
  /** Force the info popover open — used to document its active state. */
  infoOpenForShowcase?: boolean;
  onInfoClick?: (event: React.MouseEvent<HTMLButtonElement>) => void;
  /**
   * Structured insight-dialog content (Ringkasan/Kondisi Saat Ini/Insight/
   * Rekomendasi/Glosarium) — adds a lightbulb trigger next to the info icon
   * that opens the shared `InsightApp` dialog. Additive to `infoContent`
   * (which stays the quick-glance formula/period/source popover); this is
   * for the deeper analysis dialog.
   */
  insight?: InsightContent;
  progress?: ScorecardProgress;
  /** Composition rows rendered under the value (label + value + share bar). */
  breakdown?: ScorecardBreakdownItem[];
  /**
   * Caps the breakdown list's viewport height. Rows that fit within it
   * render statically with no scrollbar; rows that overflow it auto-loop
   * vertically instead (same technique as `MarqueeApp`'s vertical mode) —
   * never a manual scrollbar, regardless of row count.
   */
  breakdownMaxHeight?: number;
  onClick?: (event: React.MouseEvent<HTMLDivElement>) => void;
  /** Delay (seconds) before the entrance animation starts — for staggering a grid of cards. */
  animationDelay?: number;
  /**
   * For cards fed by a polling/streaming source: value changes after mount
   * animate (count from the previous number, brief pulse highlight) instead
   * of jumping instantly. Respects `prefers-reduced-motion` (pulse and
   * count-up both skip, value still updates).
   */
  live?: boolean;
}

// Animates a numeric value counting up from 0 on mount instead of popping
// straight to its final number — string values (already-formatted currency,
// percentages with symbols, etc.) are shown as-is. When `live` is true,
// value changes AFTER mount also animate — from the previously displayed
// number to the new one, not from 0 — for cards fed by a polling/streaming
// data source. Without `live`, post-mount changes jump instantly (the
// original behavior): only the first render counts up.
function useCountUp(value: string | number, durationMs = 900, skip = false, live = false) {
  const isNumeric = typeof value === "number";
  const [display, setDisplay] = React.useState(isNumeric && !skip ? 0 : value);
  const prevValueRef = React.useRef(value);
  const hasMountedRef = React.useRef(false);

  React.useEffect(() => {
    if (!isNumeric || skip) {
      setDisplay(value);
      hasMountedRef.current = true;
      prevValueRef.current = value;
      return;
    }

    const isFirstMount = !hasMountedRef.current;
    const from = isFirstMount ? 0 : live ? ((prevValueRef.current as number) ?? 0) : (value as number);
    const to = value as number;
    hasMountedRef.current = true;
    prevValueRef.current = value;

    if (!isFirstMount && !live) {
      setDisplay(to);
      return;
    }

    let raf: number;
    const start = performance.now();
    const tick = (now: number) => {
      const progress = Math.min(1, (now - start) / durationMs);
      const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
      setDisplay(Math.round(from + (to - from) * eased));
      if (progress < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value, isNumeric, durationMs, skip, live]);

  return isNumeric ? (display as number).toLocaleString("id-ID") : display;
}

export function ScorecardApp({
  id, title, value, unit, description, icon, trend, variant = "default", layout = "vertical",
  badge, infoTooltip, infoContent, infoOpenForShowcase, onInfoClick, insight, progress, breakdown,
  breakdownMaxHeight, onClick, className, animationDelay = 0, live = false, ...props
}: ScorecardAppProps) {
  const reducedMotion = useReducedMotion();
  const displayValue = useCountUp(value, 900, Boolean(reducedMotion), live);
  const [progressMounted, setProgressMounted] = React.useState(false);
  const [infoOpen, setInfoOpen] = React.useState(Boolean(infoOpenForShowcase));

  // Brief highlight pulse on the value whenever a `live` card's value
  // changes after mount — skipped on the initial mount (that's already the
  // count-up) and skipped entirely under reduced motion.
  const [pulsing, setPulsing] = React.useState(false);
  const isFirstValueRenderRef = React.useRef(true);
  React.useEffect(() => {
    if (isFirstValueRenderRef.current) {
      isFirstValueRenderRef.current = false;
      return;
    }
    if (!live || reducedMotion) return;
    setPulsing(true);
    const t = setTimeout(() => setPulsing(false), 600);
    return () => clearTimeout(t);
  }, [value, live, reducedMotion]);

  React.useEffect(() => {
    // Two-phase mount so the width transition below actually animates from
    // 0 instead of rendering straight at its final value. setTimeout, not
    // requestAnimationFrame: rAF callbacks are paused entirely while the
    // tab/webview isn't composited (backgrounded tab, mounting mid
    // navigation), which would leave this stuck at its pre-mount state
    // indefinitely — a plain timer always fires.
    const t = setTimeout(() => setProgressMounted(true), 0);
    return () => clearTimeout(t);
  }, []);
  const isClayPurple = variant === "clayPurple";
  const isClayYellow = variant === "clayYellow";
  const isClayBlue = variant === "clayBlue";
  const isClayEmerald = variant === "clayEmerald";
  const isColoredClay = isClayPurple || isClayYellow || isClayBlue || isClayEmerald;

  const variantStyles: Record<ScorecardVariant, string> = {
    default: "bg-surface text-ink border-hairline-soft shadow-xs",
    minimalist: "bg-surface text-ink border-hairline-soft shadow-xs",
    purple: "bg-vibrant-purple/10 border-vibrant-purple/30 text-ink shadow-xs",
    blue: "bg-vibrant-blue/10 border-vibrant-blue/30 text-ink shadow-xs",
    yellow: "bg-vibrant-yellow/10 border-vibrant-yellow/30 text-ink shadow-xs",
    emerald: "bg-success/10 border-success/30 text-ink shadow-xs",
    rose: "bg-error/10 border-error/30 text-ink shadow-xs",
    alert: "bg-error/10 border-error/30 text-ink shadow-xs",
    cyan: "bg-info/10 border-info/30 text-ink shadow-xs",
    clay: "clay-card text-ink border-vibrant-purple/20 shadow-xs",
    clayPurple: "clay-card clay-card-purple text-white border-transparent shadow-lg",
    clayYellow: "clay-card clay-card-yellow text-vibrant-yellow-ink dark:text-amber-100 border-transparent shadow-lg",
    clayBlue: "clay-card clay-card-blue text-vibrant-blue-ink dark:text-blue-100 border-transparent shadow-lg",
    clayEmerald: "clay-card clay-card-emerald text-white border-transparent shadow-lg",
    playful: "bg-surface text-ink border-2 border-hairline-soft shadow-vibrant-heavy font-display",
  };

  // clayYellow/clayBlue butuh override dark: eksplisit — bukan cuma token.
  // `.dark .clay-card-yellow`/`.clay-card-blue` membalik background-nya jadi
  // gelap (#451a03 / #1e293b), sedangkan token --palette-vibrant-*-ink
  // sengaja tetap gelap di dark mode (lihat catatan di theme.css: bg-vibrant-*
  // memang tidak ikut menggelap, jadi ink-nya harus tetap gelap agar badge/
  // toast tetap terbaca). Asumsi itu tidak berlaku untuk clay card, sehingga
  // tanpa override hasilnya teks gelap di atas kartu gelap — terukur hanya
  // 1,41:1 (biru) dan 1,65:1 (kuning). Override ini menaikkannya ke ~12:1 dan
  // ~13:1, sekaligus menyamakan perilaku dengan CardApp yang sudah benar.
  const titleClass = isClayPurple || isClayEmerald ? "text-white" : isClayYellow ? "text-vibrant-yellow-ink dark:text-amber-100" : isClayBlue ? "text-vibrant-blue-ink dark:text-blue-100" : "text-ink-secondary";
  const valueClass = isClayPurple || isClayEmerald ? "text-white" : isClayYellow ? "text-vibrant-yellow-ink dark:text-amber-100" : isClayBlue ? "text-vibrant-blue-ink dark:text-blue-100" : "text-ink";
  const mutedClass = isClayPurple || isClayEmerald ? "text-white/80" : isClayYellow ? "text-vibrant-yellow-ink/80 dark:text-amber-100/80" : isClayBlue ? "text-vibrant-blue-ink/80 dark:text-blue-100/80" : "text-ink-muted";
  const iconClass = isClayPurple || isClayEmerald ? "bg-white/20 text-white" : isClayYellow ? "bg-black/10 text-vibrant-yellow-ink" : isClayBlue ? "bg-white/40 text-vibrant-blue-ink" : "bg-vibrant-purple/10 text-vibrant-purple-dark";

  const renderTrend = () => {
    if (!trend) return null;
    let direction = trend.direction;
    if (!direction) {
      const trendValue = String(trend.value);
      direction = trendValue.startsWith("+") ? "up" : trendValue.startsWith("-") ? "down" : "neutral";
    }
    const positive = trend.isPositive ?? direction === "up";
    const TrendIcon = direction === "up" ? TrendingUp : direction === "down" ? TrendingDown : Minus;
    const trendClass = isClayPurple || isClayEmerald
      ? "bg-white/20 text-white border-white/30 font-bold"
      : isClayYellow
        ? "bg-black/10 text-vibrant-yellow-ink dark:text-amber-100 border-black/15 font-bold"
        : isClayBlue
          ? "bg-white/30 text-vibrant-blue-ink dark:text-blue-100 border-white/40 font-bold"
          : variant === "blue"
            ? "bg-vibrant-blue/20 text-vibrant-blue-ink border-vibrant-blue/30 font-bold"
            : variant === "yellow"
              ? "bg-vibrant-yellow/20 text-vibrant-yellow-ink border-vibrant-yellow/30 font-bold"
              : variant === "emerald"
                ? "bg-success/15 text-success border-success/30 font-bold"
                : variant === "rose" || variant === "alert"
                  ? "bg-error/15 text-error border-error/30 font-bold"
                  : positive
                    ? "bg-success/10 text-success border-success/20"
                    : "bg-error/10 text-error border-error/20";
    return (
      <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
        <span className={cn("inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-xs font-bold font-mono", trendClass)}>
          <TrendIcon className="h-3.5 w-3.5 shrink-0" />{trend.value}
        </span>
        {trend.label && <span className={cn("text-xs font-medium", mutedClass)}>{trend.label}</span>}
      </div>
    );
  };

  const infoButton = (
    <button
      id={`${id}-info-btn`}
      type="button"
      title={infoContent ? undefined : infoTooltip || "Informasi Metrik"}
      aria-label={`Info ${title}`}
      aria-expanded={infoContent ? infoOpen : undefined}
      onClick={(event) => {
        event.stopPropagation();
        if (infoContent && !onInfoClick) {
          setInfoOpen((v) => !v);
          return;
        }
        onInfoClick?.(event);
      }}
      className="inline-flex shrink-0 items-center justify-center rounded-full p-1 text-ink-muted transition-colors hover:bg-vibrant-purple/10 hover:text-vibrant-purple-dark"
    >
      <Info className="h-3.5 w-3.5" />
    </button>
  );

  // Rich info popover — what a developer should render inside the info
  // trigger: the metric's formula, reporting period, data source, and
  // freshness. Falls back to the plain title="" tooltip when only
  // infoTooltip (a short string) is provided.
  const renderInfoTrigger = () =>
    infoContent ? (
      <PopoverApp
        id={`${id}-info-popover`}
        position="bottom"
        open={infoOpen}
        onOpenChange={setInfoOpen}
        trigger={infoButton}
        width={240}
      >
        <div className="flex flex-col gap-2">
          <TextApp id={`${id}-info-popover-title`} variant="caption" weight="bold" className="text-ink">
            {title}
          </TextApp>
          {infoContent.formula && (
            <TextApp id={`${id}-info-popover-formula`} variant="caption" className="text-ink-secondary">
              {infoContent.formula}
            </TextApp>
          )}
          <div className="flex flex-col gap-1 border-t border-hairline-soft pt-2 text-[11px]">
            {infoContent.period && (
              <div className="flex items-center justify-between gap-2">
                <span className="text-ink-muted">Periode</span>
                <span className="font-semibold text-ink">{infoContent.period}</span>
              </div>
            )}
            {infoContent.source && (
              <div className="flex items-center justify-between gap-2">
                <span className="text-ink-muted">Sumber Data</span>
                <span className="font-semibold text-ink">{infoContent.source}</span>
              </div>
            )}
            {infoContent.lastUpdated && (
              <div className="flex items-center justify-between gap-2">
                <span className="text-ink-muted">Diperbarui</span>
                <span className="font-semibold text-ink">{infoContent.lastUpdated}</span>
              </div>
            )}
          </div>
        </div>
      </PopoverApp>
    ) : (
      (infoTooltip || onInfoClick) && infoButton
    );

  const renderInsightTrigger = () =>
    insight ? (
      <InsightApp
        id={`${id}-insight`}
        content={insight}
        triggerClassName={isColoredClay ? "text-current hover:bg-white/20" : undefined}
      />
    ) : null;

  // `suffix` distinguishes the real row from AutoLoopListApp's seamless-loop
  // clone (rendered a second time, off-screen-duplicated) — without it both
  // copies would share the same DOM id.
  const renderBreakdownRow = (item: ScorecardBreakdownItem, index: number, suffix: string) => {
    const rowId = `${item.id ?? `${id}-breakdown-${index}`}${suffix}`;
    const Row = item.onClick ? "button" : "div";
    return (
      <Row
        key={rowId}
        id={rowId}
        {...(item.onClick
          ? {
              type: "button" as const,
              onClick: (event: React.MouseEvent) => { event.stopPropagation(); item.onClick?.(); },
            }
          : {})}
        className={cn(
          "block w-full min-w-0 space-y-1 text-left",
          item.onClick && "cursor-pointer rounded-lg transition-colors hover:bg-black/[0.03] dark:hover:bg-white/[0.06]"
        )}
      >
        <div className="flex min-w-0 items-center justify-between gap-2 text-[11px]">
          <span className={cn("min-w-0 flex-1 truncate font-medium", mutedClass)}>{item.label}</span>
          <span className={cn("shrink-0 font-bold font-mono tabular-nums", valueClass)}>{item.value}</span>
        </div>
        {item.percent !== undefined && (
          <div className={cn("h-1.5 w-full overflow-hidden rounded-full", isColoredClay ? "bg-white/25" : "bg-black/10 dark:bg-white/15")}>
            <div
              className="h-full rounded-full bg-vibrant-purple-dark transition-[width] duration-700 ease-out"
              style={{
                width: progressMounted ? `${Math.min(100, Math.max(0, item.percent))}%` : "0%",
                backgroundColor: item.color,
              }}
            />
          </div>
        )}
      </Row>
    );
  };

  // Driven by our own React state instead of framer-motion's built-in
  // initial/animate mount coupling: this app runs in React 18 StrictMode,
  // which double-invokes mount effects, and this component is routinely
  // rendered deep inside React.lazy + Suspense content (which also
  // double-suspends in dev). That combination confuses framer-motion's
  // internal "has this element just mounted" bookkeeping and leaves the
  // card frozen at its initial values, never animating to rest. Toggling a
  // plain state flag on mount and letting `animate` react to that value
  // change goes through framer's ordinary (non-mount-coupled) animate path,
  // which isn't affected by the double-invoke.
  const restState = { opacity: 1, y: 0 };
  const [entered, setEntered] = React.useState(Boolean(reducedMotion));
  React.useEffect(() => {
    if (reducedMotion) {
      setEntered(true);
      return;
    }
    // setTimeout, not requestAnimationFrame — see note on progressMounted.
    const t = setTimeout(() => setEntered(true), 0);
    return () => clearTimeout(t);
  }, [reducedMotion]);

  const motionProps = {
    initial: false as const,
    animate: entered ? restState : { opacity: 0, y: 12 },
    whileHover: !reducedMotion && onClick ? { y: -2 } : undefined,
    transition: reducedMotion
      ? { duration: 0 }
      : { duration: 0.35, ease: "easeOut" as const, delay: animationDelay },
  };

  const isHorizontal = layout === "horizontal" || layout === "minimalist" || variant === "minimalist";
  if (isHorizontal) {
    return (
      <motion.div id={id} data-ui-id={id} onClick={onClick} className={cn("relative flex h-full w-full min-w-0 items-center gap-4 overflow-hidden rounded-card-custom border p-5 text-left transition-colors", variantStyles[variant], onClick && "cursor-pointer hover:border-vibrant-purple/40", className)} {...motionProps} {...props}>
        {icon && <div className={cn("relative z-10 flex h-12 w-12 shrink-0 items-center justify-center rounded-full shadow-xs transition-transform duration-300", iconClass)}>{icon}</div>}
        <div className="relative z-10 min-w-0 flex-1">
          <div className="flex min-w-0 items-center justify-between gap-1.5 overflow-hidden">
            <span className={cn("line-clamp-2 min-w-0 flex-1 break-words text-xs font-semibold uppercase tracking-wider leading-tight", titleClass)}>{title}</span>
            <span className="flex shrink-0 items-center gap-0.5">
              {renderInfoTrigger()}
              {renderInsightTrigger()}
              {badge && <span className="max-w-[130px] truncate rounded-full border border-vibrant-purple/20 bg-vibrant-purple/10 px-2 py-0.5 text-[9px] font-bold text-vibrant-purple-dark">{badge}</span>}
            </span>
          </div>
          <div className="mt-0.5 flex flex-wrap items-baseline gap-1.5">
            <span className={cn("text-xl font-bold font-display tracking-tight sm:text-2xl tabular-nums transition-[color,transform] duration-300", valueClass, pulsing && (isColoredClay ? "scale-110" : "scale-110 text-vibrant-purple-dark"))}>{displayValue}</span>
            {unit && <span className={cn("text-xs font-medium font-mono", mutedClass)}>{unit}</span>}
          </div>
          {description && <p className={cn("mt-0.5 truncate text-[11px] font-medium", mutedClass)}>{description}</p>}
          {renderTrend()}
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div id={id} data-ui-id={id} onClick={onClick} className={cn("relative flex h-full w-full min-w-0 flex-col justify-between gap-4 rounded-card-custom border px-5 py-6 text-left transition-colors", variantStyles[variant], onClick && "cursor-pointer hover:border-vibrant-purple/40", className)} {...motionProps} {...props}>
      <div className="flex w-full min-w-0 items-center justify-between gap-2">
        <div className="flex min-w-0 flex-1 items-center gap-1.5">
          <span className={cn("line-clamp-2 min-w-0 flex-1 break-words text-xs font-bold font-display uppercase tracking-wider leading-tight", titleClass)}>{title}</span>
          {renderInfoTrigger()}
          {renderInsightTrigger()}
        </div>
        {(badge || icon) && <div className="ml-auto flex shrink-0 items-center gap-1.5">
          {badge && (
            <span
              className={cn(
                "max-w-[140px] truncate rounded-full border px-2 py-0.5 text-[9px] font-bold font-mono uppercase",
                isClayPurple || isClayEmerald
                  ? "border-white/30 bg-white/20 text-white"
                  : isClayYellow
                    ? "border-[#78350f]/20 bg-[#78350f]/15 text-vibrant-yellow-ink dark:text-amber-100"
                    : isClayBlue
                      ? "border-[#1e3a8a]/20 bg-[#1e3a8a]/20 text-vibrant-blue-ink dark:text-blue-100 font-bold"
                      : variant === "blue"
                        ? "border-vibrant-blue/30 bg-vibrant-blue/20 text-vibrant-blue-ink"
                        : variant === "yellow"
                          ? "border-vibrant-yellow/30 bg-vibrant-yellow/20 text-vibrant-yellow-ink"
                          : variant === "emerald"
                            ? "border-success/30 bg-success/20 text-success"
                            : variant === "rose" || variant === "alert"
                              ? "border-error/30 bg-error/20 text-error"
                              : "border-vibrant-purple/20 bg-vibrant-purple/10 text-vibrant-purple-dark"
              )}
            >
              {badge}
            </span>
          )}
          {icon && <div className={cn("flex shrink-0 items-center justify-center rounded-xl p-2 transition-transform duration-300", iconClass)}>{icon}</div>}
        </div>}
      </div>
      <div className="space-y-1">
        <div className="flex flex-wrap items-baseline gap-1.5">
          <span className={cn("text-2xl font-black font-display tracking-tight leading-none sm:text-3xl tabular-nums transition-[color,transform] duration-300", valueClass, pulsing && (isColoredClay ? "scale-110" : "scale-110 text-vibrant-purple-dark"))}>{displayValue}</span>
          {unit && <span className={cn("text-xs font-bold font-mono", mutedClass)}>{unit}</span>}
        </div>
        {description && <p className={cn("text-[11px] font-medium leading-snug", mutedClass)}>{description}</p>}
      </div>
      {(trend || progress || (breakdown && breakdown.length > 0)) && <div className={cn("space-y-2.5 border-t pt-3", isColoredClay ? "border-white/20" : "border-hairline-soft/80")}>
        {renderTrend()}
        {progress && <div className="space-y-1.5">
          {progress.label && <div className={cn("flex items-center justify-between text-xs font-mono", mutedClass)}><span>{progress.label}</span><span className="font-bold">{Math.round((progress.value / (progress.max || 100)) * 100)}%</span></div>}
          <div className={cn("h-2.5 w-full overflow-hidden rounded-full border border-hairline-soft", isColoredClay ? "bg-black/15 dark:bg-white/20 border-white/20" : "bg-black/10 dark:bg-white/15")}>
            <div
              className={cn(
                "h-full rounded-full transition-[width] duration-700 ease-out",
                !progress.color && (
                  isClayYellow ? "bg-vibrant-yellow-ink dark:bg-amber-400" :
                  isClayPurple ? "bg-white" :
                  isClayBlue ? "bg-vibrant-blue-ink dark:bg-blue-300" :
                  isClayEmerald ? "bg-white" :
                  variant === "yellow" ? "bg-vibrant-yellow-ink dark:bg-amber-400" :
                  variant === "blue" ? "bg-vibrant-blue-ink dark:bg-blue-400" :
                  variant === "emerald" ? "bg-success" :
                  variant === "rose" || variant === "alert" ? "bg-error" :
                  "bg-vibrant-purple-dark"
                )
              )}
              style={{
                width: progressMounted ? `${Math.min(100, Math.max(0, (progress.value / (progress.max || 100)) * 100))}%` : "0%",
                ...(progress.color ? { backgroundColor: progress.color } : {}),
              }}
            />
          </div>
        </div>}
        {breakdown && breakdown.length > 0 && (
          breakdownMaxHeight ? (
            <AutoLoopListApp id={`${id}-breakdown`} maxHeight={breakdownMaxHeight} className="min-w-0">
              {(suffix) => (
                <div className="min-w-0 space-y-2.5 pb-0.5">
                  {breakdown.map((item, index) => renderBreakdownRow(item, index, suffix))}
                </div>
              )}
            </AutoLoopListApp>
          ) : (
            <div className="min-w-0 space-y-2.5">
              {breakdown.map((item, index) => renderBreakdownRow(item, index, ""))}
            </div>
          )
        )}
      </div>}
    </motion.div>
  );
}
