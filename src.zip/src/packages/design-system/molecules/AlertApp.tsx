import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";
import { ButtonApp } from "../atoms/ButtonApp";

export type AlertRounded = "default" | "none" | "sm" | "md" | "lg" | "full" | "pill" | "card";
type AlertChildRounded = Exclude<AlertRounded, "default">;

const AlertRoundedContext = React.createContext<AlertChildRounded>("md");

const alertAppVariants = cva(
  "relative w-full border flex flex-wrap items-start gap-3 transition-all text-left",
  {
    variants: {
      variant: {
        default: "border-hairline bg-surface text-ink",
        info: "border-vibrant-blue/40 bg-vibrant-blue/5 text-ink dark:text-white",
        success: "border-success/40 bg-success/5 text-success dark:text-green-400",
        warning: "border-warning/40 bg-warning/5 text-warning dark:text-amber-400",
        error: "border-red-500/40 bg-red-500/5 text-red-600 dark:text-red-400",
        brand: "border-vibrant-purple-dark/40 bg-vibrant-purple/5 text-ink dark:text-white",
      },
      size: {
        sm: "px-4 py-2 text-xs",
        md: "px-5 py-3 text-sm",
        lg: "px-6 py-3.5 text-base",
      },
      rounded: {
        default: "rounded-[var(--radius-md)]",
        none: "rounded-none",
        sm: "rounded-[var(--radius-sm)]",
        md: "rounded-[var(--radius-md)]",
        lg: "rounded-[var(--radius-lg)]",
        // Alert bodies wrap variable-height, multi-line text — a literal
        // rounded-full (9999px) turns them into a broken ellipse instead of
        // a pill. Cap the radius so it reads as a soft stadium shape at any
        // height instead of computing off the box's actual height.
        full: "rounded-[28px]",
        pill: "rounded-[28px]",
        card: "rounded-card-custom",
      },
      theme: {
        default: "",
        playful: "font-display shadow-vibrant-soft",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "md",
      rounded: "md",
      theme: "default",
    },
  }
);

export interface AlertAppProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof alertAppVariants> {
  id: string;
}

export function AlertApp({
  id,
  variant,
  size,
  rounded,
  theme,
  className,
  children,
  ...props
}: AlertAppProps) {
  const selectedRounded = (rounded || "md") as AlertRounded;
  const resolvedRounded: AlertChildRounded = selectedRounded === "default" ? "md" : selectedRounded;

  return (
    <AlertRoundedContext.Provider value={resolvedRounded}>
      <div
        id={id}
        data-ui-id={id}
        className={cn(alertAppVariants({ variant, size, rounded: resolvedRounded, theme, className }))}
        role="alert"
        {...props}
      >
        {children}
      </div>
    </AlertRoundedContext.Provider>
  );
}

// Sub-components for full composite control
export interface AlertIconProps extends React.HTMLAttributes<HTMLDivElement> {
  id: string;
}

export function AlertIconApp({ id, className, children, ...props }: AlertIconProps) {
  return (
    <div
      id={id}
      data-ui-id={id}
      className={cn("flex-shrink-0 mt-0.5 inline-flex items-center justify-center", className)}
      {...props}
    >
      {children}
    </div>
  );
}

export interface AlertTitleProps extends React.HTMLAttributes<HTMLHeadingElement> {
  id: string;
}

export function AlertTitleApp({ id, className, children, ...props }: AlertTitleProps) {
  return (
    <h5
      id={id}
      data-ui-id={id}
      className={cn("font-bold font-display tracking-tight text-ink", className)}
      {...props}
    >
      {children}
    </h5>
  );
}

export interface AlertDescriptionProps extends React.HTMLAttributes<HTMLParagraphElement> {
  id: string;
}

export function AlertDescriptionApp({ id, className, children, ...props }: AlertDescriptionProps) {
  return (
    <div
      id={id}
      data-ui-id={id}
      className={cn("text-xs text-ink-secondary leading-relaxed mt-1", className)}
      {...props}
    >
      {children}
    </div>
  );
}

export interface AlertActionProps extends React.HTMLAttributes<HTMLDivElement> {
  id: string;
}

export function AlertActionApp({ id, className, children, ...props }: AlertActionProps) {
  const rounded = React.useContext(AlertRoundedContext);
  const synchronizedChildren = React.Children.map(children, (child) => {
    if (React.isValidElement(child) && child.type === ButtonApp) {
      return React.cloneElement(child as React.ReactElement<React.ComponentProps<typeof ButtonApp>>, { rounded });
    }
    return child;
  });

  return (
    <div
      id={id}
      data-ui-id={id}
      className={cn("sm:ml-auto flex flex-wrap items-center gap-2 mt-3 sm:mt-0", className)}
      {...props}
    >
      {synchronizedChildren}
    </div>
  );
}
