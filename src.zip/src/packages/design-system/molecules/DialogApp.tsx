import * as React from "react";
import { createPortal } from "react-dom";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";
import { X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const dialogContentVariants = cva(
  "w-full overflow-hidden flex flex-col max-h-[90vh] relative border",
  {
    variants: {
      variant: {
        default: "bg-surface border-hairline",
        brand: "bg-surface border-brand/30 ring-1 ring-brand/10",
      },
      size: {
        sm: "max-w-md",
        md: "max-w-lg",
        lg: "max-w-2xl",
        xl: "max-w-4xl",
        full: "h-[100dvh] max-h-[100dvh] max-w-none rounded-none sm:h-[calc(100dvh-2rem)] sm:max-h-[calc(100dvh-2rem)] sm:max-w-[calc(100vw-2rem)]",
      },
      theme: {
        default: "border-hairline shadow-2xl",
        playful: "font-display border-0 shadow-vibrant-heavy bg-surface",
      },
      rounded: {
        default: "rounded-[var(--radius-md)]",
        none: "rounded-none",
        sm: "rounded-[var(--radius-sm)]",
        md: "rounded-[var(--radius-md)]",
        lg: "rounded-[var(--radius-lg)]",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "md",
      rounded: "md",
      theme: "default",
    },
  }
);

export interface DialogAppProps extends VariantProps<typeof dialogContentVariants> {
  id: string;
  isOpen: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children: React.ReactNode;
  type?: "alert" | "confirmation" | "form" | "fullScreen";
  icon?: React.ReactNode;
  footer?: React.ReactNode;
  showCloseButton?: boolean;
  closeOnOverlayClick?: boolean;
}

export function DialogApp({
  id,
  isOpen,
  onClose,
  title,
  description,
  variant = "default",
  size = "md",
  rounded,
  theme = "default",
  children,
  type = "form",
  icon,
  footer,
  showCloseButton = true,
  closeOnOverlayClick = true,
}: DialogAppProps) {
  const contentRef = React.useRef<HTMLDivElement>(null);
  const previousFocusRef = React.useRef<HTMLElement | null>(null);
  // Lock scroll on open & handle Escape key
  React.useEffect(() => {
    if (isOpen) {
      previousFocusRef.current = document.activeElement as HTMLElement | null;
      document.body.style.overflow = "hidden";
      requestAnimationFrame(() => {
        const firstFocusable = contentRef.current?.querySelector<HTMLElement>("button, [href], input, select, textarea, [tabindex]:not([tabindex='-1'])");
        firstFocusable?.focus();
      });
    } else {
      document.body.style.overflow = "";
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen) {
        onClose();
      }
      if (e.key === "Tab" && isOpen && contentRef.current) {
        const focusable = Array.from(contentRef.current.querySelectorAll<HTMLElement>("button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex='-1'])"));
        if (!focusable.length) return;
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => {
      document.body.style.overflow = "";
      previousFocusRef.current?.focus();
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [isOpen, onClose]);

  const isPlayful = theme === "playful";
  const resolvedSize = type === "fullScreen" ? "full" : size;

  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) return null;

  return createPortal(
    <AnimatePresence>
      {isOpen && (
        <motion.div
          id={id}
          data-ui-id={id}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2, ease: "easeInOut" }}
          className={cn("fixed inset-0 z-50 flex items-center justify-center bg-overlay-scrim backdrop-blur-xs", type === "fullScreen" ? "p-0 sm:p-4" : "p-4")}
          onClick={
            closeOnOverlayClick
              ? (e) => {
                  e.stopPropagation();
                  onClose();
                }
              : undefined
          }
        >
          <motion.div
            ref={contentRef}
            id={`${id}-content`}
            data-ui-id={`${id}-content`}
            initial={{ opacity: 0, scale: 0.94, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: 12 }}
            transition={{ type: "spring", stiffness: 380, damping: 28 }}
            role="dialog"
            aria-modal="true"
            aria-labelledby={`${id}-title`}
            aria-describedby={description ? `${id}-description` : undefined}
            className={cn(dialogContentVariants({ variant, size: resolvedSize, rounded: type === "fullScreen" ? "none" : rounded, theme }))}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div
              className={cn(
                "flex items-center justify-between px-6 py-5 border-b border-hairline-soft",
                variant === "brand" && "bg-brand/5 border-brand/10",
                isPlayful && "bg-vibrant-grey-bg/30 border-b border-vibrant-purple-dark/10 px-8 py-6"
              )}
            >
               <div className="flex min-w-0 items-start gap-3">
                 {icon && <div className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-full", type === "alert" || type === "confirmation" ? "bg-error/10 text-error" : "bg-vibrant-purple/10 text-vibrant-purple-dark")}>{icon}</div>}
                 <div className="min-w-0">
                 <h3
                   id={`${id}-title`}
                  className={cn(
                    "text-h4 text-ink",
                    isPlayful ? "font-extrabold text-2xl tracking-tight text-vibrant-purple-dark dark:text-vibrant-purple-dark" : "font-semibold"
                  )}
                >
                  {title}
                </h3>
                 {description && (
                   <p
                     id={`${id}-description`}
                    className={cn(
                      "text-xs mt-1",
                      isPlayful ? "text-vibrant-purple-dark/80 font-medium" : "text-ink-muted"
                    )}
                  >
                    {description}
                   </p>
                 )}
                 </div>
               </div>
               {showCloseButton && <button
                id={`${id}-close-btn`}
                data-ui-id={`${id}-close-btn`}
                onClick={onClose}
                className={cn(
                  "transition-all cursor-pointer inline-flex items-center justify-center",
                  isPlayful
                    ? "text-vibrant-purple-dark hover:text-vibrant-purple hover:bg-vibrant-purple/10 p-2 rounded-full border border-vibrant-purple-dark/10"
                    : "text-ink-secondary hover:text-ink hover:bg-action-hover p-1.5 rounded border border-transparent"
                )}
                aria-label="Close dialog"
              >
                <X className="w-5 h-5" />
               </button>}
            </div>

            {/* Content */}
            <div
              className={cn(
                "flex-1 overflow-y-auto text-body text-ink",
                isPlayful ? "px-8 py-6" : "px-6 py-5"
              )}
             >
               {children}
             </div>
             {footer && <div className={cn("flex flex-wrap items-center justify-end gap-2 border-t border-hairline-soft px-6 py-4", isPlayful && "px-8")}>{footer}</div>}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
}
