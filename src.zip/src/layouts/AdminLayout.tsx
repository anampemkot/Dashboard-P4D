import * as React from "react";
import { Outlet, useLocation } from "react-router-dom";
import { SidebarApp, HeaderApp, ScrollProgressApp } from "@/packages/design-system";
import { useUiStore } from "@/stores/useUiStore";
import { useIsMobile } from "@/hooks/useIsMobile";

export default function AdminLayout() {
  const { sidebarOpen, setSidebarOpen, theme } = useUiStore();
  const contentRef = React.useRef<HTMLElement>(null);
  const isMobile = useIsMobile();
  const location = useLocation();

  // Initialize theme on mount
  React.useEffect(() => {
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [theme]);

  // On mobile the sidebar behaves as an overlay drawer, not a permanent
  // column — auto-close it after navigating so it doesn't stay covering
  // the page content the user just tapped through to.
  React.useEffect(() => {
    if (isMobile && sidebarOpen) {
      setSidebarOpen(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.pathname]);

  return (
    <div
      id="layout-admin-root"
      data-ui-id="layout-admin-root"
      className="h-screen overflow-hidden bg-canvas text-ink transition-colors duration-200 flex flex-col"
    >
      {/* Sidebar (Fixed position). Forced expanded on mobile — touch has no
          hover state, so without this the drawer would be stuck showing
          icons only. */}
      <SidebarApp id="layout-sidebar" isCollapsed={isMobile ? false : undefined} />

      {/* Mobile backdrop — sidebar overlays content below the lg breakpoint,
          so tapping outside it should dismiss it like any drawer. */}
      {isMobile && sidebarOpen && (
        <div
          id="layout-sidebar-backdrop"
          className="fixed inset-0 z-40 bg-black/50 backdrop-blur-xs transition-opacity duration-300 animate-in fade-in"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content Area */}
      <div
        className={`flex flex-col flex-1 min-h-0 transition-all duration-300 ${
          sidebarOpen && !isMobile ? "pl-[68px]" : "pl-0"
        }`}
      >
        <div className="flex-1 flex flex-col bg-canvas min-h-0">
          {/* Header */}
          <HeaderApp id="layout-header" />

          {/* Scroll Container */}
          <main
            ref={contentRef}
            id="layout-content"
            data-ui-id="layout-content"
            className="flex-1 overflow-y-auto bg-canvas relative p-4 sm:p-6 md:p-8 h-[calc(100vh-56px)]"
            style={{ scrollbarWidth: "none" }}
          >
            {/* Scroll progress & Dot Indicator */}
            <ScrollProgressApp
              id="scroll-progress-root"
              containerRef={contentRef}
            />

            <Outlet />
          </main>
        </div>
      </div>
    </div>
  );
}
